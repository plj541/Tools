<!DOCTYPE html>
<html>
  <head>
    <base target="_top">
    <script>
      function onFailure(anError) {
        var myMsg = document.getElementById("myMsg");
        myMsg.innerHTML = "Error:  " + anError.message;
      }
      
      function onSuccess(aMsg) {
        var mySend = document.getElementById("mySend");
        mySend.value = "Done";
        var myMsg = document.getElementById('myMsg');
        myMsg.innerHTML = "Done:  " + aMsg;
      }

      function clickHtml() {
        var mySend = document.getElementById("mySend");
        if (mySend.value == "Done") {return};

        var myTo = document.getElementById("myTo").value;
        var myCc = document.getElementById("myCc").value;
        var mySubject = document.getElementById("mySubject").value;
        var myLogs = document.getElementById("myLogs").value;
        google.script.run
          .withFailureHandler(onFailure)
          .withSuccessHandler(onSuccess)
          .sendHtml(myTo, myCc, mySubject, "", myLogs);
      }
    </script>
  </head>
  <body>
    <input type="button" id="mySend" onclick="clickHtml()" value="Send HTML"><br>
    <table>
    <tr><td>To:</td>
    <td><input type="text" id="myTo" size="100" value=""></td></tr>
    <tr><td>CC:</td>/
    <td><input type="text" id="myCc" size="100" value=""></td></tr>
    <tr><td>Subject:</td>
    <td><input type="text" id="mySubject" size="100" value=""></td></tr>
    </table>
    <div id="myMsg">Paste HTML below:</div><br>
    <textarea id="myLogs" rows="32" cols="112"></textarea>
  </body>
</html>