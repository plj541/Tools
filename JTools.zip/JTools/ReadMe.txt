The directory
   Jay
contains a set of J Tools which provide commands like
   Load and Save
to ease the creation and use of collections of nouns and verbs.

The first time you use J, it will create a directory of
configuration information.

On Android it is 
   j805-user
On Windows it is
   j64-805-user

Move the related directory into the appropriate directory.
Then edit the files in the config subdirectory to conform to
your directory usage.