This zip file contains three directories:
   Jay                  Described below				
   juser-android        config directory for android
   juser-windows        config directory for windows

The first time you use J, it will create a directory:
   jpath '~user'
Move the config directory from the appropriate directory
into the directory named above.  Then edit the files in
the config subdirectory to conform to your directory usage.

The directory Jay contains a set of J tools:
   Tools.ijs             is loaded at startup
   aplAV.ini             provides conversion from older APL alphabets
   aplJS.ini             is to update files for APL.js
   go.ini                rebuilds Tools.ijs
It also contains subdirectories:
   docs                  files define older APL alphabets
   include               Include files in OnLoad, names are not preserved by Save
   test                  Load each file to test my features
   tools                 Edit each file to modify source for Tools.ijs
