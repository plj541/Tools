help=: {{)n
 NB.  To demonstrate Copy behavior, do the following:
 Names ''            NB.  Names from the last Load
 Copy  'test/copy'   NB.  then copy a script
 Names ''            NB.  Names after Copy
}}

notice=: {{)n
 This is from ~Jay/demos/Copy
}}