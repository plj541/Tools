help=: {{)n
 NB.  To demonstrate Copy behavior, do the following:
 Names ''            NB.  Names from Load
 Clear ''            NB.  then clear
 Copy  'tests/copy'  NB.  then copy a script
 Names ''            NB.  Names after Copy
}}
