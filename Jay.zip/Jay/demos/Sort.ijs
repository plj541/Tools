help=: {{)n
 NB. Keys provide dictionary sequence for grade
  ;:   show words  NB. Compare reordering words
 <;._2 show files  NB. Compare reordering files
}}

show=: {{
 y=. u y
 if. ';:'-: DEF 'u' do.  
  (Across /:~ y), LF, ' Above /: and (/:Keys) Below', LF, Across (/:Keys) y
 else.
  ' /:            (/:Keys)', (>/:~ y),. ' ',. >(/:Keys) y
 end.
}}

words=: 'CAT CATS Cat Cats DOG DOGS DR DR. Dog Dogs Dr Dr. cat cats dog dogs dr dr.'

files=: {{)n
Last.txt
Last (1).txt
Last (2).txt
Last (12).txt
Last1.txt
Last12.txt
Last123.txt
Last2.txt
Last23.txt
Last234.txt
Last5.txt
Last57.txt
Last579.txt
}}