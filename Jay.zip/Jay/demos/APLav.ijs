help=: {{)n
NB.  Early APL's assigned different characters to the 256 possible byte codes
NB.  Modern APL's use Unicode characters so different tables are needed to translate
      AV 'IPSA'             NB. Return 256 Unicode characters
      Table AV 'STSC'       NB. Format an AV result as 8 rows
      'STSC' FromAV 'FILE'  NB. Read bytes from y and translate with AV from m
'NEW' 'STSC' FromAV 'FILE'  NB. Write UTF-8 to x, translating bytes from y as above
      'IPSA' ToAV   'FILE'  NB. Read UTF-8 from y and translate to bytes with AV from m
'NEW' 'IPSA' ToAV   'FILE'  NB. Write bytes to x, translating UTF-8 from y as above
}}

AV=: {{
 NB. Provide the named table
 7 u: File '~Jay/demos/APLav/av', y, '.txt'
}}

Table=: {{
 assert. (,256)-: $y
 8 32$ y
}}

FromAV=: {{
 (a.&i. File y) { AV m
:
 x File~ m FromAV y
}}

ToAV=: {{
 'av file'=. y
 a.{~ (AV m)i. 7 u: File y
:
 x File~ ToAV y
 x
}}
