help=: {{)n
 NB. Tests for Replace and Split
 Do lengthReplace   NB. Different Lengths
 Do overlapReplace  NB. Overlaps
 Do variousSplit    NB. Break into boxes
}}

lengthReplace=: {{)n
 NB. Different Length Tests
 text=. 'this a is a test'
 text Replace ' a'; ','       NB. new shorter than old
 text Replace ' a'; '{and}'   NB. new longer than old
 text Replace 'is'; 'an'      NB. new and old the same length
 text Replace 'a@'            NB. both values are one character
}}

overlapReplace=: {{)n
 NB. Overlaps Tests
 text=. 'this is Canana test.'
 text Replace 'ana'; 'beth'
 text Replace 'ana'; 'ann'
 text Replace 'ana'; 'x'
}}

variousSplit=: {{)n
 NB. Split Tests
 now=: 'this is a test'
 now Split ' '
 now Split 'is'
 now Split 'is '
 now Split 'it '
}}
