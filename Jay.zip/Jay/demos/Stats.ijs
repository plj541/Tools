help=: {{)n
NB. Each of these verbs reduce the leading dimension.
NB. Rank controls which one that is.
NB. These examples use rank 2 to model 3 spreadsheets
NB. with 5 columns of 15 rows each.
 data=: 3 15 5 ?@$ 10        NB. Create a random array
 Range"2 data                NB. the largest minus the smallest
 Mean"2 data                 NB. the sum divided by the count
 Variance"2 data             NB. the Mean of the square of values minus their Mean
 Stddev"2 data               NB. the square root of the Variance
 Median"2 data               NB. the middle value, when ordered
 Mode"2 data                 NB. the most common value(s) or none 
}}

Range=: >./ - <./

Mean=: +/ % #

Variance=: {{Mean 2^~ y-"(<:#$y) Mean y}}

Stddev=: {{0.5^~ Variance y}}

Median=: {{
 middle=. 2%~ #order=. /:~ Rank_1 y  NB. /:~ arrange columns, not whole rows
 if. 2| #y do. order{~ <.middle
 else. 2%~ +/order{~ middle- i. 2 end.
}}

Mode=: (2&$:) : {{
 NB. Returns enclosed values to identify no modes
 NB. x is how many modes are reported, the default is 2
 x&{{
  order=. \:count=. +/ y=/unique=. ~.y
  unique=. order{ unique [count=. order{ count
  if. 1~: #x do. <unique,: count
  else. <({.x) {{y#~ x>: #y}} unique#~ count= {.count end.
 }} Rank_1 y
}}
