help=: {{)n
 NB. Browsers can send messages 
 Mail msg         NB. just inserts the message body
 NB. Search for:  window.location.href= "mailto
 NB. To learn about other parameters
 NB. Which can be inserted by a modified Mail 
 
 NB. Create data and view it as an html report
 data=. 100%~ 5 2 ?@$ 100000  NB. an example random table
 data=. 7j2 ":&.> <"0 data    NB. formatted like a spreadsheet
 NB. The browser share menu usually offers a print option
 Display data    NB. Printing html includes .pdf output
 
 Load '~Jay/demos/Display'  NB. to create additional examples
 
 NB. When you've tried multiple demos
 NB. you can review any of your results
    Dr '~Jay/temp'
Display...html  eMail.html
 NB. Focus on one file and copy its name
 NB. Press enter on the Rn line
   '~Jay/temp' Rn
 {{ Edit`View @. y ,'~Jay/temp/eMail.html' }} 0
 NB. Change the trailing 0 to 01 and press enter 
}}

msg=: {{)n
"This is how to confirm data is in a range"
   (>:&3 *. <:&7) #data
}}

Mail=: {{
 NB. Send an email via a local browser page
 html=. MAIL Replace '{MAIL}'; y
 View html File '~Jay/temp/eMail.html'
}}

MAIL=: {{)n
<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>eMail from J</title>
<script type="text/javascript">
var doit=1
function sendMail() {
 if (doit == 1) {
  doit=0
  var msg=document.getElementById("mail").innerHTML
  window.location.href= "mailto:?body=" + encodeURIComponent(msg)
 }
}
</script></head><body onload="sendMail()"><p>
Please close this window.
<div id="mail" style="display: none;">
{MAIL}
</div>
</body></html>
}}
