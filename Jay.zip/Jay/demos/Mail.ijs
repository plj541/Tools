help=: {{)n
 Mail msg     NB. A simple test to confirm your eMail accepts browser requests
 Display 7j2":&.> <"0 [100%~ ?3 2$ 100000  NB. A very simple report
 Report ''    NB. Have your browser Print a PDF of the report
 Mail ''      NB. Enter your message in the eMail app, or you can
 NB. Mail File 'yourMessage.txt'  NB. Any approach will do
 NB. In eMail, attach 'whereSaved/yourReport.pdf'
}}

msg=: {{)n
"This is a	test!"
   (>:&3 *. <:&7) #fun
}}

Report=: {{)m
 if. -.fexist file=. DISPLAY do.
  if. 0= #file=. '.html' Files '~Jay/temp/Display' do.
   'Display doesn''t have saved files' return.
  elseif. 1~: #file do.
   Say '   NB. Please look for the Display file you want'
   Dr~ '~Jay/temp' return.
  end.
 end.
 Browse '~Jay/temp/', file
}}

Mail=: {{
 NB. Send an email via a local browser page
 html=. MAIL Replace '{MAIL}'; y
 Browse html File '~Jay/temp/eMail.html'
}}

MAIL=: {{)n
<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>eMail from J</title>
<script type="text/javascript">
var doit=1
function sendMail() {
 if (doit == 1) {
  doit=0
  var msg=document.getElementById("mail").innerHTML
  window.location.href= "mailto:?body=" + encodeURIComponent(msg)
 }
}
</script></head><body onload="sendMail()"><p>
Please close this window.
<div id="mail" style="display: none;">
{MAIL}
</div>
</body></html
}}
