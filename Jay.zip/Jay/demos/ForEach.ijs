help=: {{)n
 NB. When using the same verb multiple times, the conjunction
 NB.   ForEach
 NB. eliminates the need for an explicit loop in the verb

 NB. When all arguments are single characters, no boxing is required
 'dad with cats' Replace ForEach 2 ' _aAcK'  NB. dAd_with_KAts

 NB. When new or old values are not single characters
 'dad with cats' Replace ForEach 2 <;._1 '| |_|ca|Co|a|An'  NB. dAnd_with_Cots
 'dad with cats' Replace ForEach 2 <;._1 '| |_|a|An|ca|Co'  NB. dAnd_with_cAnts

 NB. As seen above, the order of argument groups matters
 NB. Sometimes it is crucial as when transforming for HTML
 '(x<1){ &.> y' Replace ForEach 2 <;._1 '|&|&amp;|<|&lt;|>|&gt;'
}}
