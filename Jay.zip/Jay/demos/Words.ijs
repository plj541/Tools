help=: {{)n
 NB. Do help                     NB. Run all of these examples
 Do simple                       NB. Words is similar to monadic ;:

 Do rules                        NB. With and without J rules
 
 Do parts                        NB. Behavior of each left argument
}}

simple=: {{)n
 Words {{)n"It's" 12.95 'OK?'}}  NB. Monadic is usefull with APL HTML and JS files
 Words 'mask← m ∘.≤ m←⍳⍴⍵'       NB. It distinguishes Unicode characters
}}

look=: {{)n NB. Not Bad.
 'Such as: ',"1 ": <. 1.4 2.5 3.6+ 0.7
}}

rules=: {{)n
 '"`' Words look       NB. With J rules in effect, only ' denotes a quote
 'NB.:' Words look     NB. Without J rules, quotes delimited by ', " or `
}}

parts=: {{)n           NB. Experiment with indivdual rules
 '"'  Words look       NB. Just adds words in double quotes 
 '''' Words look       NB. Just adds words in quotes
 'NB' Words look       NB. Just adds words in comments   
 '.'  Words look       NB. Just adds words ending with .
 ':'  Words look       NB. Just adds words ending with :
}}