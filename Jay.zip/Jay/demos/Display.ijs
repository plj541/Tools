Include '~Jay/HTML'

help=: {{)n
 test1 ''       NB. Display expressions and their results
 test2 ''       NB. Display enclosed unusual characters
 test3 ''       NB. Display problem output
}}

line=: {{
 Tag y
 Tag ". y
}}

test1=: {{
 Clean ''

 line {{)n a.i. '⍺¡⍵'}}
 line {{)n '⍺¡⍵'; i. 2 3}}
 line {{)n (2 9$ '⍺¡⍵ ⍶ . ⍹'); 10+i. 2 3}}

 line {{)n '⍺¡⍵'}}
 line {{)n 2 9$ '⍺¡⍵ ⍶ . ⍹'}}

 Display ''
}}

test2=: {{
 Clean ''
 Display 2 2$ 'Dice'; (<"0 u: 9856 9857 9858 9859 9860 9861); this; i.2 2 3 4
}}

this=: {{)n
12345
.....
(김창준)
}}

test3=: {{
 Clean ''
 
 Tag {{)nDisplay of manipulated character vectors is unpredictable
Compare the following output to that in the J session
}}
 line {{)n a.i. '⍺ ⍉ ⍳⍴⍵'  NB. Not just the 7 visible characters}}
 line {{)n a.i. 'r←a'      NB. Not just the 3 visible characters}}
 line {{)n (,.('⍳⍴⍵'); i. 3 2); (2 7$ '⍺ ⍉ ⍳⍴⍵'); 2 7$ 'r←a'}}
 Tag 'For consistent results use 7 u: before manipulation'
 line {{)n a.i. 'r←a'}}
 line {{)n (,.('⍉⍳⍴⍵'); |:+i. 3 2); (2 7$ 7 u: '⍺ ⍉ ⍳⍴⍵'); 2 3$ 7 u: 'r←a'}}

 Display ''
}}
