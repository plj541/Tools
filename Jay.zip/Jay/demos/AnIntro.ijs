help=: {{)n
 NB. Load does 3 things
  1  NB. Clears the locale
  2  NB. Repopulates the locale
  3  NB. If help exists, displays it

 NB. There are several session verbs
 Load '~Jay/demos/Last'     NB. describes how they work
 Load '~Jay/demos/Clear'    NB. this is like )clear
 Load '~Jay/demos/Copy'     NB. this is like )copy
 Load '~Jay/demos/Display'  NB. produces an HTML report
 Load '~Jay/demos/Mail'     NB. shows how to send messages
 
 NB. There are two session apps
 Load '~Jay/PathFind'       NB. search a path several ways
 Load '~Jay/PathDiff'       NB. compares text files in two paths
 
 NB. How to use some of these Tools
 Load '~Jay/demos/Replace'  NB. text Replace old; new
 Load '~Jay/demos/ForEach'  NB. u modifies x with each group of y
 Load '~Jay/demos/Sort'     NB. demonstrate dictionary sort
 Load '~Jay/demos/Stats'    NB. ... version of statistics
 Load '~Jay/demos/Words'    NB. extended version of ;: word formation
}}
  