help=: {{)n
 NB. Debug a session with ]command instead of verbs
 NB. Once debugging begins, ]help gives you the list of commands
 Cr 'fun'                         NB. Shows the verb with line numbers for ]stop
 Cr Local 'mine'                  NB. Inside fun will show the local verb
 this=: 'cat' fubar i.3  []debug  NB. Start on a line which failed before
}}

NB. Define two test verbs
fun=: {{
 NB. This verb will fail either way it is called
 mine=. {{
  a=. 'this is mine '
  a, y}}
 now=. mine x
 one=. x- y
 Say 'fun'; now; one
 one
}}

fubar=: {{
 tis=. x [mine=. y
 now=. tis fun mine
 now; tis; mine
}}
