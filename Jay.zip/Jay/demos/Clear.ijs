help=: {{)n
 NB. To demonstrate Clear behavior, do the following:
 dbr 1       NB.  Stop inside the stack
 test 'now'  NB.  Invoke an error
 Clear ''    NB.  Try to clear the workspace
 
 Clear ''    NB.  Reissue as requested
 Names ''    NB.  Confirm Clear worked
}}

test=: {{
 NB.  A sample verb to suspend
 10+ y
}}
