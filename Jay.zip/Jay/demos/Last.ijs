help=: {{)n
 NB. several file handling verbs
 Load 'scr...'     NB. clears the locale, then loads a script
 Run 'scr...'      NB. runs a script, typically shows work
 Copy 'scr...'     NB. copies a script into a local
 Code 'scr...'     NB. invokes an editor on the script
 NB. All of the above supply the extension
 Edit 'file.ext'   NB. invokes an editor on the file
 NB. For all of the above  ''  means reuse the last argument
 View 'file.ext'   NB. invokes a local app based on the extension
 Save ''           NB. provides a backup of current globals

 NB. Last is a conjunction that supplements all of these verbs
 Load Last Save    NB. reloads a previous state of development
 Code Last Load    NB. invokes a browser on the previous Load
 NB. The left verb is anything that takes a full file name
 NB. View accepts an HTTP request, but it isn't a file name
}}