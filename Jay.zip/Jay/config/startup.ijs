NB.  Set Paths and start initialize
run=: 0!:01 <
debug=: {{
 y fwrite debug~ ''
:
 '~user/config/Debug'
}}

help=: {{)n
 help           NB. To see this list again
 ferase debug~ ''  NB. To stop debugging the next session
 dbr 0             NB. To end debugging in this session
 dberm ''          NB. To see the last error message 
 run jpath '~Jay/tools/initialize.ini'  NB. To continue debugging
}}

{{
 if. y do.
  dbr 1 [help 1!:3 [2
 else.
  load '~Jay/tools/initialize.ini'
 end.
}} fexist debug~ ''