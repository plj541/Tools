help=: {{)n
 PathDiff '~Jay'; '~user'; '/config'  NB. Between distribution copy and current
}}

PathDiff=: {{
 NB. Compare all files in both paths
 HEAD fwrite REPORT [Count=. 0
 'rootOld rootNew folder'=: y
 rootOld=. Path rootOld [rootNew=. Path rootNew
 REPORT fappend~ fixIt ' PathDiff ''', '''',~ y Join '''; '''
 dirsOld=. (#rootOld) }.&.> 'D' Paths pathsOld=. Paths rootOld, folder
 dirsNew=. (#rootNew) }.&.> 'D' Paths pathsNew=. Paths rootNew, folder 
 'old new'=. missing dirsOld; dirsNew; 'Folders'
 dirsOld=. 'D' Paths pathsOld=. old# pathsOld
 dirsNew=. 'D' Paths pathsNew=. new# pathsNew
 for_inPath. i.#pathsOld do.
  dirOld=. ;inPath{ dirsOld [filesOld=. 'F' Paths inPath{ pathsOld
  dirNew=. ;inPath{ dirsNew [filesNew=. 'F' Paths inPath{ pathsNew
  'old new'=. missing filesOld; filesNew; 'Files'
  files=. old# filesOld
  for_inFile. i.#files do. file=. ;inFile{ files
                   thisOld=. File myOld=. dirOld, '/', file
   if. -.thisOld-: thisNew=. File myNew=. dirNew, '/', file do.
    now=. LB Replace ''; ":Count=. >:Count
    now=. now, LA,~ (quote myOld), ' &nbsp;&nbsp;&nbsp;Diff&nbsp;1&nbsp;', quote myNew
    now fappend REPORT
    now=. now, '     ', myNew, LF2 [now=. DB Replace ''; ":Count
    REPORT fappend~ now, DA,~ (thisOld Diff 1 thisNew) Replace '<';'＜'
   end.
  end.
 end.
 Browse REPORT
}}

missing=: {{
 'nowOld nowNew what'=. y
 if. #now=. (-.new=. nowNew e. nowOld)# nowNew do.
  REPORT fappend~ fixIt what, ' missing from ', rootOld, NR, now Join '   '
 end.
 if. #now=. (-.old=. nowOld e. nowNew)# nowOld do.
  REPORT fappend~ fixIt what, ' missing from ', rootNew, NR, now Join '   '
 end.
 old; new
}}

fixIt=: {{
 NB. Ensure multiple blanks don't disappear
 (NB, y, NA) Replace '  '; ' &nbsp'
}}

NB. Note Before and After
NB=: LF, '<br>   NB.  '
NR=: LF, '   NB.  '
NA=: '<p>', LF

NB. Link Before and After
LB=: {{)n
&nbsp;&nbsp;<a href="#" onclick="mDiv('mD')">
}}

LA=: {{)n
</a><p>
}}

NB. Div Before and After
DB=: {{)n
<div id= 'mD' hidden><textarea rows="9" cols="139" readOnly=true>
}}

DA=: {{)n
</textarea></div>
}}

HEAD=: {{)n
<html><head><meta charset="UTF-8">
<script>
function mDiv(aDiv) {
 var x = document.getElementById(aDiv)
 if (x.style.display === "block") {
  x.style.display = "none"
 } else {
  x.style.display = "block"
 }
}
</script>
</head><body>
}}

REPORT=: '~Home/PathDiff.html'