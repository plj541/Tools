help=: {{)n
 Clean ''        NB. Create a new html page
 Tag 'An array'  NB. Add an html tag with simple display
 Tag <"0 i. 2 3  NB. Add an html tag as an html table
 Display ''      NB. Display the current html page
}}

Display=: {{
 NB. Tag y and Browse the file
 if. ''-.@-: y do. Tag y end.
 Browse DISPLAY_pj_
}}

Clean=: {{
 NB. Provide a new Display file
 TAG_pj_ File DISPLAY_pj_=: '~Jay/temp/Display' timeStamp_pj_ '.html'
}}

Tag=: {{
 NB. Append J values to their HTML equivalent
 if. -.fexist_z_ DISPLAY_pj_ do. TAG_pj_ File DISPLAY_pj_ end.
 if. 0= L. y do.
  y=. LF,~ '</span></pre>',~ Lines y
  DISPLAY_pj_ fappend_z_~ '<pre><span class="inner-pre" style="font-size: 18px">', y
 else.
  DISPLAY_pj_ fappend_z_~ '<br>', toUnboxed_pj_ y
 end.
}}

NB. Support for html

toUnboxed_pj_=: {{
 NB.  Convert each item in a box
 if. 0~: L. y do. toTable y
 else. toHtml y end.
}}

toHtml_pj_=: {{
 tags=. <;._1 '|&|&amp;|<|&lt;|>|&gt;| |&nbsp;|', LF, '|<br>', LF
 (Lines y) Replace ForEach 2 tags
}}

toTable_pj_=: {{
 NB.  Each box becomes an HTML table
 table=. toUnboxed &.> y
 table=. ,"2 tableRow "1 tableData &.> table
 blank=. LF, LF,~ '<tr class="blank_row"><td colspan="999999999">&nbsp;</td></tr>'
 table=. (-rep* #blank)}. ;(<blank) displayUnboxed ^: (rep=. 1-~#$table) table
 '<table border="1" cellspacing="0" cellpadding="3">', '</table>',~ LF, table 
}}

tableRow_pj_=: {{
 NB. Tag into a Table Row
 (<'<tr>'), (<'</tr>'),~ y
}}

tableData_pj_=: {{
 NB. Tag into Table Data
 '<td>', '</td>',~ y
}}

displayUnboxed_pj_=: {{
 NB.  Convert a multidimension array into a character vector
 y=. ": y
 if. 0< r=. _1+ #$ y do. y=. (-r)}. LF displayUnboxed ^: r y
 else. ,y end.  NB. {{,"2 y,"1 x}}
}} : ([:,"2 ,"1~)

TAG_pj_=: {{)n
<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Display of J</title>
<style>@import url(../config/display.css);</style>
</head><body>
<div id="myEdit"></div>
<div id="myView">
}}
