NB. Add plj to existing search path for locale base
(<~. 'plj'; (18!:2) <'base') (18!:2)&> <"0 ;:'base pj'
Tools=: '' [cocurrent 'plj'  NB. Switch to locale plj
NB.₨
Tools=: Tools, {{)n
   Code '~Jay/tools/libs'     NB. Code Lib Load Run Copy Include
}}

Lib=: {{
 NB. Names of Code files
 Across 'Load' libFiles_pj_ y
}}

Load=: {{
 NB. Load an app into a Clear locale
 if. 'Load' stack_pj_ '' do. return. end.
 try.
  if. ''-: file=. 'Load' fileName_pj_ y do.
   'No file name in use' return. end.
  if. Fexist full=. 0 Path file do. Clear ''
   (0!:000) <full ['Load' fileName_pj_ <file
   if. 0= (4!:0) <'help' do. file, LF, help else. file end.
  else.
   '‘', file, '’ does not exist'
  end.
 catch. dberm_z_ ''
 end.
}}

Run=: {{
 NB. Evaluate statements from a file, with display
 'Run' Script 001 y
:
 NB. Evaluate statements from a file, without display
 if. x-: y do. x=. 000 end.
 'Run' Script x y
}}

Copy=: {{
 NB. Like Load without Clear
 if. 0 0-: $y=. 'Copy' Script 000 y do. fileName_pj_ 'Copy'
 else. y end.
}}

Include=: {{
 NB. Like Copy but signals when an error occurrs
 if. 2= #$now=. Copy y do. (13!:8&45) ,now end.
}}

Code=: {{
 NB. Edit a code file
 'Code' editFile_pj_ y
}}

NB. Support for libs

stack_pj_=: {{
 0  NB. Remove stack and notify user
 if. '*' e. {."1 (13!:18) '' do.
  Say '   dbr 1  NB. Enter this line and reissue ', x
 end.
}}

libFiles_pj_=: {{
 NB. Provide File Names with specified extensions
 (-#x)}.&.> y Files~ >EXTS{~ VERBS i. <x
}}

Script=: {{
 NB. Run a Script File
 try.
  if. ''-: file=. m fileName_pj_ y do. ,:'No file in use' return. end.
  if. -.Fexist full=. 0 Path file do. ,:'‘', file, '’ does not exist' return. end.
  m fileName_pj_ <file
  (0!:n) <full
 catch. dberm_z_ ''
 end.
}}

editFile_pj_=: {{
 NB. Launch an External Editor
 if. ''-: file=. x fileName y do. 'No file in use' return. end.
 if. -.Fexist full=. 0 Path file do. '' File full end.
 x fileName <file
 0 0$ xedit_j_ full
}}

fileName_pj_=: {{
 NB. Last file name for verb named y
 >FILES{~ VERBS i. <y
:
 NB. Determine a file name
 file=. >in{ FILES [ext=. >in{ EXTS [in=. VERBS i. <x
 if. L. y do. 0 0$ FILES=: FILES in}~ y return. NB. Assign file used
 elseif. ''-: y do.
  if. ''-: file do. '' return.
  else. y=. file end.
 end.
 'path name extn'=. pathNameExtn y
 if. extn-: '' do. if. ext-: '' do. (13!:8&45) 'File extension required' end.
 elseif. ext-: '' do. ext=. extn
 elseif. -.extn-: ext do. (13!:8&45) 'Requires a different extension' end.
 path, name, ext
}}

pathNameExtn_pj_=: {{
 name=. y}.~ '/'i:~ '/', y
 path=. y}.~ -#name
 extn=. name}.~ dot=. name i: '.'
 if. (name-: '') +. '~'= {.name=. dot{. name do. (13!:8&45) 'File name required' end.
 path; name; extn
}}

Path=: (0&$:) : {{
 NB. Provide absolute path to file argument
 if. '://' +./@E. y=. ,y do. y return. end.  NB. It's http
 if. y +./@e.~ x}. '*?|<>' do. (13!:8&45) 'Illegal file name' end.
 if. isFull_pj_ y do. y return. end.
 if. '~'= {.y do.
  map=. SystemFolders_j_, UserFolders_j_
  map=. ({:"1 map){~ ({."1 map)i. {.y=. <;._1 '/', }.y
  ;map, '/',&.> }.y
 else.
  ({{ y (I. y= '\')} ~'/' }} 1!:43 ''), y,~ '/'#~ 0~: #y
 end.
}}

isFull_pj_=: _ {{)a
if. UNAME-: 'Win' do.  NB. Windows full path
 ('c:/'-: (a. (,65 97 +/ i. 26)}~ 'c'){~ a.i. 3{. ])
else.  NB. Non Windows full path
 ('/'= {.)
end.
}}

NB.₨
Tools=: Tools, {{)n
   Code '~Jay/tools/files'    NB. Edit Dir Dirs File Files Lines Page
}}

Dir=: {{
 NB. Formatted dir
 if. 0~: #dir=. '' Dir y do.
  time=. 'q[-]5.0,r[0]q[-]3.0,r[0]q[  ]4.0,r[0]q[:]3.0,r[0]2.0'
  time=. time Fmt 0 _1}. >1{"1 dir
  size=. 0j0 Fmt ,.>2{"1 dir
  name=. ' ',. >{."1 dir
  dir=. 'd'= 4({ >)"0 [4{"1 dir
  size=. ' ' (I. dir)} size
  (time,. size,. name)/: (1": -.dir),. Keys name
 end.
:
 NB. Boxed dir
 star=. '*'
 if. ''-.@-: y do.if. 1= #dir=. (1!:0) y=. 2 Path y do.
  if. 'd' e. >dir{~ <0 4 do. star=. '/*' end.
 end.end.
 (1!:0) y, star, x
}}

Dirs=: {{
 NB. Just directory names, with path if y ends with /
 (/:Keys) x 1 filesDirs_pj_ y
}}

Root=: _ {{)a
NB. Supporting multiple roots requires changes
if. UNAME-: 'Win' do.
 ROOT_pj_=: 'C:/'  NB. '~Home/' when not Administrator
{{ NB. Windows Root
 root=. ROOT_pj_, y
 if. ('Dr'-: (5!:5) <'u')*. ''-: y do.
  rn=. LF, '   ', ' Rn',~ quote_z_ root, '.'
  NB. 13 : 'x }. }: y'
  ds=. ds, LF#~ 0~: #ds=. Across (#root) ([}.[:}:])&.> ''Dirs root
  fs=. fs,~ LF#~ 0~: #fs=. Across (#root) }.&.> '' Files root
  ds, ' .  ..', fs, rn
 else. u root end.
:
 ROOT_pj_=: x, '/'
 if. -.x-: y do. u Root y end.
}}
 else. NB. There are minor differences
 ROOT_pj_=: '~Home/'  NB. '/' on rooted device
{{ NB. Non Windows Root
 root=. ROOT_pj_, y
 if. ('Dr'-: (5!:5) <'u')*. ''-: y do.
  rn=. LF, '   ', ' Rn',~ quote_z_ }:root
  root=. root, '*' 
  drs=. drs, LF#~ 0~: #drs=. Across '' Dirs root
  fls=. fls,~ LF#~ 0~: #fls=. Across '' Files root
  drs, ' .  ..', fls, rn
 else. u root end.
:
 ROOT_pj_=: x, '/'
 if. -.x-: y do. u Root y end.
}}
 end.
}}

Paths=: _ {{)a
NB. Start of creating Paths for Windows or Linux
if. UNAME-: 'Win' do.
{{  NB. Dirs and Files (Just for Windows)
 dirs=. ,< y=. '/' After y
 now=. '' 1 filesDirs_pj_ y
 while. #now do.
  dirs=. dirs, now
  now=. ;a: 1 filesDirs_pj_&.> now
 end.
 (/:Keys) dirs
:
 if. 0= L. y do. y=. Paths y end.
 select. x
 case. 'D' do. {."1 y  NB. Just the Dirs
 case. 'P' do. ;a: Files&.> y  NB. Just the files with full path
 case. 'F' do.
  if. 1~: #$y do. (13!:8&45) 'Just one element for F'
  else. '' Files >y end.
 case. do. (13!:8&45) 'D dirs, F files or P files and paths' end.
}}

else. NB. Above is pure J, but is much slower

{{  NB. Dirs and Files direct from host (Not for Windows)
 if. -.'/~'e.~ {.y do. y=. y,~ '/',~ (1!:43) '' end.
 paths=. }: (2!:0) 'ls -p -R ', 0 Path y
 paths=. paths Split LF2
 paths=. (paths ,&.> LF) Split&> <':', LF
 paths /:Keys {."1 paths
:
 if. 0= L. y do. y=. Paths y end.
 select. x
 case. 'D' do. {."1 y  NB. Just the Dirs
 case. 'P' do.  NB. Just the Files with full path
  files=. y #~ 0~:([:# [:>{:)"1 y NB. No empties: {{#>{:y}}
  NB. Join path/files: {{<(<'/',~ >{.y) ,&.> (/:Keys)<;._2 >{:y}}
  files=. ;([:<([:<'/',~ [:>{.) ,&.> [:(/:Keys) [:<;._2 [:>{:)"1 files
  files#~ files (]~: [:{:[) &> <'/'  NB. No paths: {{y~: {:x}}
 case. 'F' do. NB. Just the Files without path
  if. 1~: #$y do. (13!:8&45) 'Just one element for F'
  else. files#~ files (]~: [:{:[) &> <'/' [files=. (/:Keys)<;._2 >{: y end.
 case. do. (13!:8&45) 'D dirs, F files or P files and paths' end.
}}

end.
}}

File=: {{
 NB. Read a file
 if. -.isFull_pj_ full=. 0 Path y do. (13!:8&45) 'Illegal file name' end.
 now=. (1!:1) <full
 if. (239 187 191{ a.)-: 3{. now do.
  now=. 3}. now
 end.
:
 NB. Create or Replace a file, If ,:x Append
 if. -.isFull_pj_ full=. 0 Path y do. (13!:8&45) 'Illegal file name' end.
 if. 2< #$ x do. (13!:8&45) 'Invalid shape of x' end.
 wa=. (2+ (2= [:#$) (*.) 1= [:{.$) x
 y [(,x) (1!:wa) <full
}}

Fexist=: {{
 NB. Just files, not directories or http
 if. ([:1: 1!:4) ::0: <full=. 0 Path y do.
  if. 0= #look=. (1!:0) full do. 1 return.
  elseif. 'd'~: 4{ ;4{ ,look do. 1 return. end.
 end.
 0
}}

Files=: {{
 NB. Just file names, with path if y ends with /
 (/:Keys) x 0 filesDirs_pj_ y
}}

LastVersion=: {{
 NB. Name of last file version, using download version naming
 'path name extn'=. pathNameExtn_pj_ y 
 if. #file=. (')', extn) Files path, name, ' ('
  do. path, ;{:file
 elseif. #'' Files y do. y
 else. ,:'No version of ', y end.
:
 NB. Name of the next version
 if. 2= #$x=. LastVersion y do. y return. end.
 'path name extn'=. pathNameExtn_pj_ x
 if. ')'= {:name do.
  now=. ":>:".prev=. name}.~ name i:'('
  path, extn,~ (name}.~ -<:#prev), now, ')'
 else. path, name, ' (1)', extn end.
}}

Lines=: {{
 NB. Make y a character vector so it can be written to a file
 (9!:7) ascii=. 11{. 16}. a. [was=. (9!:6) ''
 ascii=. <"0 ascii [display=. <"1 [11 3$ '┌┬┐├┼┤└┴┘│─'
 now=. (displayUnboxed_pj_ y) Replace ForEach _ ascii,. display
 now [(9!:7) was
}}

displayUnboxed_pj_=: {{
 NB.  Convert a multidimension array into a character vector
 y=. ": y
 if. 0< r=. _1+ #$ y do. y=. (-r)}. LF displayUnboxed ^: r y
 else. ,y end.  NB. {{,"2 y,"1 x}}
}} : ([:,"2 ,"1~)

Edit=: {{
 NB. Edit a file with any extension
 'Edit' editFile_pj_ y
}}

Page=: {{
 NB. Fetch a web page as a string of characters
 name=. ;{: httpget_jpacman_ y
 if. '4000 : ' -: {.name do. '' return. end.
 page=. File name
 page [ferase name
}}

NB. Support for files

filesDirs_pj_=: {{
 NB. u= 0 Files or 1 Dirs, with path if y ends with /
:
 if. 0= #names=. x Dir y do. '' return. end.
 names=. {."1 names#~ 'd' (~:`= @. u) 4{"1 > 4{"1 names
 if. '/'= {:y do. names=. (<y) ,&.> names 
  if. u do. names ,&.> '/' end.
 end. 
}}

NB.₨
Tools=: Tools, {{)n
   Code '~Jay/tools/names'    NB. Names Erase Clear Do New Pax
}}

Names=: {{
 NB. List names, ''=all, 0=noun, 1=adverb, 2=conjunction, 3=verb
 Across (/:Keys) (<,'y')-.~ (4!:1) y, (y-: '')# i.4
:
 NB. List locales, ''=all, 0=named, 1=numbered
 Across (/:Keys) (18!:1) y, (y-: '')# i.2
}}

NB. Monad: Erase names in y, including locals
NB. Dyad:  Erase locales identified in y
Erase=: ([: 4!:55 ;: ::]) : ([: 18!:55 ])

Clear=: {{
 NB. Clear the active workspace
 if. 'Clear' stack_pj_ y do. return. end.
 'Cleared' [(4!:55) (4!:1) i.4
}}

Do=: {{
 NB. Evaluate statements from a noun, with display
 (0!:101) y
:
 NB. Evaluate statements from a noun, without display
 if. x-: y do. x=. 100 end.
 (0!:x) y
}}

New=: {{
 NB. Create an object
 locale=. (18!:3) ''
 locale (18!:2)~ (18!:2) <'base'  NB. Give it the name search path of base
 if. y-: '' do. locale
 elseif. locale {{ cocurrent_z_ x
  err_pj_=: 'Run' Script 000 y
  0 0-: $err_pj_ }} y do. locale
 else. (13!:8&45) ,err_pj_ [(18!:55) locale end.
}}

NB. Dyadic nl to see caller's locals
NB.  (y#~ (  <   , x)= y{.&.>~   #x) (4!:1)
NL=: (]#~ ([:< [:, [)= ]{.&.>~ [:#[) (4!:1)

NB. Definitions of caller's locals
DEF=: 5!:5&<

Pax=: {{
 NB. (<Names), Values  includes locals when called monadically
 if. '".'-: (5!:5)<'u' do. (< , u.&.>) y v. 0
 else. x, <(< , u.&.>) y v. }.i.4 [x=. <(< , u.&.>) y v. 0 end.
:
 NB. Ensure only global results  ((;:''x u v y'')-.~ y) x v y
 u Pax ([:((<;._1' x u v y')-.~ ]) v) y  NB. Ignore my arguments
}}

NB.₨
Tools=: Tools, {{)n
   Code '~Jay/tools/output'   NB. View Across Fmt Keys Unbox
}}

Across=: {{
 NB. Place two blanks between items and fold then to WIDTH_pj_
 2 foldBoxes_pj_ y
}}

{{)n Fmt Rules
 NB. If x is numeric, complex numbers create Fmt rules like ":
 NB. J will calculate a proper width where 0= {. +. x
 NB. Here are sample values
 0j0 ": y=. 10 ^ i. 10
1 10 100 1000 10000 100000 1000000 10000000 100000000 1000000000
 NB. To provide a width you should understand how to calculate one
 NB. This result has Whole number digits and Number of ,'s
 1 0+ <. 10 1000 ^./ y
1 2 3 4 5 6 7 8 9 10
0 0 0 1 1 1 2 2 2  3

 NB. add rows together for whole widths
 ]whole=. +/ 1 0+ <. 10 1000 ^./ y
1 2 3 5 6 7 9 10 11 13

 NB. If 0~: fraction=. {: +. x
 ]fraction=. 1+ fraction

 NB. Financial format has two decorators before and after
 decoration=. #' (', ')'

 NB. The minimum width is
 whole + fraction + decoration
}}

Fmt=: {{
 NB. Financial form of numbers
 NB. -    +   -   +  mp Before; nq After; b[zero]; d[nill]; r[fill]
 'm[ (]p[  ]n[)]q[ ]c0.2' Fmt y
:
 if. 0= {.0$ x do.  NB. See Fmt Rules above
  x=. ((a. 32}~'.'){~ a.i. ])&.> <@":"1 +.x
  x=. }: ;(<'m[ (]p[  ]n[)]q[ ]c^,') Replace&.> <"1 x,.~ <'^'
 end.
 x (8!:2) y
}}

NB. These provide keys for dictionary sort
NB. Keys=: {{ ((KSPELL_pj_ {~ a.i.]) y),. (KCASE_pj_ {~ a.i. ]) y=. >y}}
Keys=: {{ ((KSPELL_pj_ {~ a.i. ]),. KCASE_pj_ {~ a.i. ]) y=. >y }}

KSPELL_pj_=: '                                 """""""""""""""##########"""""""abcdefghijklmnopqrstuvwxyz""""""abcdefghijklmnopqrstuvwxyz""""'

KCASE_pj_=: '000000000000000000000000000000000b3pqmv256lkg1ds0123456789efihjcu111111111111111111111111118t7n04000000000000000000000000009oar0'

Unbox=: {{
 NB. Remove boxing characters from result
 if. 32~: (3!:0) y do. 
  if. ' '= {.0($,)y do. >y Split LF
  else. 1 1}. _1 _1}. ": <y end.
 else.
  was=. (9!:6) ''
  (9!:7) [11# rep=. 30{ a.
  (9!:7) was [now=. ": <y
  now=. 1 1}. _1 _1}. now
  rho=. $now=. (-.*./"1 now= rep)# now 
  rho$ ' ' (I. now= rep)} now=. ,now
 end.
}}

View=: {{
 NB. View an html page with a browser
 0 0$ browse_j_ viewRules_pj_ y
}}

viewRules_pj_=: {{
 if. -.isFull {.full=. 0 Path y do. full return. end.
 if. 1< #;{:pathNameExtn full do.
  FILES_pj_=: FILES_pj_ (VERBS_pj_ i. <'View')}~ <full
  'file://', full
 else. (13!:8&45) 'View requires an extension' end.
}}

NB. Support for output

displayLines_pj_=: {{
 NB. Format an array as a vector, correct appearance of LF at first level
 if. 0~: L. y do. fix=. LF&e. &> rav=. ,y
  y=. ($y)$ (,y) (I.fix)}~ ([:>;._2 (10{a.),~ ])&.> rav#~ fix
 end.
 if. 0< r=. _1+ #$ y=. ":y do. (-r)}. LF displayUnboxed^: r y
 else. ,y end.
}}

foldBoxes_pj_=: {{
 NB. Format the disclose of boxed characters into lines
 insert=. _1+ +/\ |. (WIDTH_pj_+ m) foldBoxes_pj_/ |. 0, 0,~ m+ #&> y
 (->:m)}. LF insert }'X',~ ;y ,&.> <m# ' '
:
 if. m> next=. x+ {.y do. next, }.y
 else. x, y end.
}}

NB.₨
Tools=: Tools, {{)n
   Code '~Jay/tools/html'     NB. Display Head Tag
}}

Display=: {{
 NB. Tag y and look at the result
 if. ''-.@-: y do. Tag y end.
 View DISPLAY_pj_
 DISPLAY_pj_=: '~Jay/temp/Display' timeStamp_pj_ '.html'
}}

Head=: {{
 TAG_pj_ File DISPLAY_pj_=: '~Jay/temp/Display' timeStamp_pj_ '.html'
}}

Tag=: {{
 NB. Append J values to their HTML equivalent
 if. -.Fexist DISPLAY_pj_ do. TAG_pj_ File DISPLAY_pj_ end.
 if. 0= L. y do.
  y=. LF,~ '</span></pre>',~ Lines y
  DISPLAY_pj_ File~ ,: '<pre><span class="inner-pre" style="font-size: 18px">', y
 else.
  DISPLAY_pj_ File~ ,:'<br>', toUnboxed_pj_ y
 end.
}}

NB. Support for html

toUnboxed_pj_=: {{
 NB.  Convert each item in a box
 if. 0~: L. y do. toTable y
 else. toHtml y end.
}}

toHtml_pj_=: {{
 tags=. <;._1 '|&|&amp;|<|&lt;|>|&gt;| |&nbsp;|', LF, '|<br>', LF
 (Lines y) Replace ForEach 2 tags
}}

toTable_pj_=: {{
 NB.  Each box becomes an HTML table
 table=. toUnboxed &.> y
 table=. ,"2 tableRow "1 tableData &.> table
 blank=. LF, LF,~ '<tr class="blank_row"><td colspan="999999999">&nbsp;</td></tr>'
 table=. (-rep* #blank)}. ;(<blank) displayUnboxed ^: (rep=. 1-~#$table) table
 '<table border="1" cellspacing="0" cellpadding="3">', '</table>',~ LF, table 
}}

tableRow_pj_=: {{
 NB. Tag into a Table Row
 (<'<tr>'), (<'</tr>'),~ y
}}

tableData_pj_=: {{
 NB. Tag into Table Data
 '<td>', '</td>',~ y
}}

displayUnboxed_pj_=: {{
 NB.  Convert a multidimension array into a character vector
 y=. ": y
 if. 0< r=. _1+ #$ y do. y=. (-r)}. LF displayUnboxed ^: r y
 else. ,y end.  NB. {{,"2 y,"1 x}}
}} : ([:,"2 ,"1~)

TAG_pj_=: {{)n
<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Display of J</title>
<style>@import url(../config/display.css);</style>
</head><body>
<div id="myEdit"></div>
<div id="myView">
}}

NB.₨
Tools=: Tools, {{)n
   Code '~Jay/tools/session'  NB. Del Dr Rn Last Say Ask Yes
}}

Del=: {{
 NB. Copy lines from the screen, then
 if. 0= (4!:0) <'u' do. m : (wd 'clippaste')
 else. u wd 'clippaste' end.
}}

Dr=: {{
 rn=. '' NB. Given a folder, display Dirs then Files
 if. 1= #dir=. (1!:0) 2 Path y do.if. 'd'= 4{ >4{ ,dir do.
  rn=. LF, '   ', ' Rn',~ quote_z_ y
 end.end.
 if. 0= #rn do. 'Specify a folder' return. end.
 ds=. ds, LF#~ 0~: #ds=. Across '' Dirs y
 fs=. fs,~ LF#~ 0~: #fs=. Across '' Files y
 ds, ' .  ..', fs, rn 
}}

Rn=: {{
 NB. Recall Dr if the copied value is a folder
 file=. (wdclippaste_z_ ''),~ >(m-: ''){ m;~ m, '/' 
 if. 1= #dir=. (1!:0) 2 Path file do.
  if. 'd'= dir=. 4{ >4{ ,dir do. Dr file return. end.
 else. '‘', file, '’ does not exist' return. end.
 NB. Offer launch choice with a copied file name 
 now=. quote file
 if. '.ijs'-: tolower _4{. file do.
  ' {{ Code`Load`Run`Copy @. y ,', now, ' }} 0'
 else. ' {{ Edit`View @. y ,', now, ' }} 0' end.
}}

fileType_pj_=: {{
 NB. Find an appropriate editor
 view=. VERBS i. ;:'Code Edit'  NB. Assumes Edit is empty in EXTS
 >VERBS{~ {.view#~ (<y)EndsWith&> view{ EXTS
}}

Last=: {{
 NB. What file did verb last use
 type=. VERBS_pj_ i. <verb=. v verb_pj_
 if. ''-.@-: file=. >type{ FILES_pj_ do. u file
 else. verb, ' has not used a file' end.
}}

verb_pj_=: {{)a
 if. 3= (4!:0) <'u' do. (5!:5) <'u' else. m end.
}}

Say=: {{
 NB. Should display an intermediate value
 if. ([:#,) y do. y (1!:2) 2 end.
}}

Ask=: {{
 NB. Ask a question and wait for user response
 (1!:1) 1 [Say y
}}

Yes=: {{
 NB. Ask a question, require a yes or no answer
 now=. Ask y
 while. 1 do.
  if. 4= now=. 'nyNY'i. {.now TrimStart ' ' do.
   now=. Ask y, ' (Yes or No)'
  else. 2| now return. end.
 end.
}}

Today=: {{
 NB. Today with y days offset
 now=. 3{. (6!:0) ''
 if. 0-: y do. now
 else. todate y+ todayno now end.
}}

NB.₨
Tools=: Tools, {{)n
   Code '~Jay/tools/debug'    NB. Save Cr ]debug
}}

NB. 13 : {{)nLF2,~ y, '=: ', (5!:5) <y}}
Save=: {{
 y=. (y,~ '_'#~ 0~: #y), ;{.EXTS_pj_
 y=. '~Jay/temp/Saved' timeStamp_pj_ y
 x=. (;:'x y')-.~ ((4!:1) }.i.4), (4!:1) 0
 y File~ ; a: Save &.> x
 0 0$ FILES_pj_=: FILES_pj_ (VERBS_pj_ i.<'Save')}~ <y
:
 if. 0= 4!:0 <y do.if. 2= 3!:0 x=. ".y do.if. 1= #$x do.
  (LF,'}}',LF2),~ (y,'=: }:{{)n',LF),x Replace(LF,'}}');LF,' }}' return.
 end.end.end.
 ((10 10{a.),~],'=: ',[:5!:5<) y
}}

Cr=: {{
 NB. Displays lines with line numbers used during debugging
 mon=. y Cr~ <1 [dia=. y Cr~ <2 [y=. ,y
 cr=. y, (>{:mon), (,':'), >{:dia
 ln=. 'p<[>q<] >0'8!:2 ,.(>{.mon), _, >{.dia
 ln=. ' ', ln (<0;~ #>{.mon)}~ ' '
 ln,. cr
:
 cr=. md (5!:7) <y [md=. >x
 if. 0= #cr do. (i.0); 0 0$ '' return. end.
 line=. {:&> 1{"1 cr
 lines=. i.>:{:line
 lines=. lines#~ lines e. line
 cr=. ' ' Join~ (lines =/line)#"1 [2{"1 cr
 if. md~: x do. lines; cr
 else. (y, cr),.~ (3": md), 'p<[>q<] >0' (8!:2) ,.lines end.
}}

debug=: {{
 Include '~Jay/tools/debugs'
 u debug_plj_
}}

NB.₨
Tools=: Tools, {{)n
   Code '~Jay/tools/words'    NB. Rank_1 Diff Words
}}

NB. Works on first dimension, with u getting rank 1 arguments
Rank_1=: {{u"1 &. |:}}

Diff=: {{
 NB. Usage: x [m] Diff n y
 m '' Diff n y
:
 n=. 2$ n  NB. n should be ⎕IO for x and y, 1 for external editors, 0 for J nouns
 x=. boxedLines_pj_ x [y=. boxedLines_pj_ y
 if. x-: y do. 'They are identical' return. end.
 if. m-: '' do. m=. ',Old lines,New lines' end.
 label=. ' ↑ ', old, ' --   -- ↓ ', new, LF ['old new'=. <;._1 m
 label=. label,~ '-'#~ #":#x ['old new'=. n
 (x old diffLines_pj_ y), label, y new diffLines_pj_ x
}}

boxedLines_pj_=: {{
 NB. Provide boxed lines from one of three possible formats
 if. L. y do. y                  NB. Already boxed lines
 elseif. LF e. y do. y Split LF  NB. Contains LF's
 else. LF Split~ File y end.     NB. A file name
}}

NB. diffLines will report lines which are new or removed
NB. It will not notice issues when common lines are new or removed
NB. It will also not notice incorrect line order
NB. With all of these caveats, it's surprisingly useful with code changes
diffLines_pj_=: {{
 NB. Display lines which are missing in the other version, m is ⎕IO
:
 'No lines are missing', LF  NB. Which lines in x are missing in y
 if. 0~: #gone=. (i=. z= #y)# x [z=.y i. x do.
  ;(<"1 ' | ',"1~ ":,. m+ I. i),. gone,. <LF
 end. 
}}
 
Words=: {{
 NB. Usefull for English, APL, HTML and JavaScript
 NB. Each word in plain text is boxed
 NB. A comment or quote is in one box
 NB. Each unicode character in plain text is boxed
 NB. Quotes contain control characters including LF
 (0; sj_pj_; mj_pj_) ;: y
:
 NB. x indicates features to turn off
 x=. ,x [mj=. mj_pj_ [sj=. sj_pj_
 mj=. mj (a.i. x#~ x e. ':''"`')}~ 0
 mj=. mj (a.i. x#~ x e. 'NB')}~ 2
 if. '.' e. x do. sj=. sj (<1 2; 6; 0 1)}~1 2 end.
 (0; sj; mj) ;: y
}}

NB. Define column for each character grouping
mj=. 256$00                         NB. X other
mj=.  1 (9, a.&i. ' ')} mj          NB. S space and tab
mj=.  2 (,(a.&i. 'Aa')+/ i.26)} mj  NB. A A-Z a-z excluding N B
mj=.  3 4 (a.&i. 'NB')} mj          NB. N the letter N then B
mj=.  5 (a.&i. '0123456789_')} mj   NB. 9 digits and _
mj=.  6 (a.&i. '.')} mj             NB. . period and decimal point
mj=.  7 (a.&i. ':')} mj             NB. : the colon
mj=.  8 (a.&i. '''')} mj            NB. ' quote
mj=.  9 (a.&i. '{')} mj             NB. { the left curly brace
mj=. 10 (10)} mj                    NB. LF
mj=. 11 (a.&i. '}')} mj             NB. } the right curly brace
mj=. 12 (192+ i. 64)} mj            NB. U utf-8 octet prefix
mj=. 13 (128+ i. 64)} mj            NB. V utf-8 octet suffix
mj=. 14 15 (a.&i. '"`')} mj         NB. other " quotes `
mj_pj_=: mj

NB. Define row for each state with transition based on column of next character
sj_pj_=: +.}. ".;._2 {{)n
' X    S    A    N    B    9    .    :    Q    {    LF   }    U    V    "   `   ']0
 1j1  0j0  2j1  3j1  2j1  6j1  1j1  1j1  7j1 11j1 10j1 12j1 19j1 19j1 17j1 15j1 NB.  0 space
 1j2  0j3  2j2  3j2  2j2  6j2  1j0  1j0  7j2 11j2 10j2 12j2 19j2 19j2 17j2 15j2 NB.  1 other
 1j2  0j3  2j0  2j0  2j0  2j0  1j0  1j0  7j2 11j2 10j2 12j2 19j2 19j2 17j2 15j2 NB.  2 alp/num
 1j2  0j3  2j0  2j0  4j0  2j0  1j0  1j0  7j2 11j2 10j2 12j2 19j2 19j2 17j2 15j2 NB.  3 N
 1j2  0j3  2j0  2j0  2j0  2j0  5j0  1j0  7j2 11j2 10j2 12j2 19j2 19j2 17j2 15j2 NB.  4 NB
 9j0  9j0  9j0  9j0  9j0  9j0  1j0  1j0  9j0  9j0 10j2  9j0  9j0  9j0  9j0  9j0 NB.  5 NB.
 1j4  0j5  6j0  6j0  6j0  6j0  6j0  1j0  7j4 11j4 10j2 12j4 19j2 19j2 17j4 15j2 NB.  6 num
 7j0  7j0  7j0  7j0  7j0  7j0  7j0  7j0  8j0  7j0  7j0  7j0  7j0  7j0  7j0  7j0 NB.  7 '
 1j2  0j3  2j2  3j2  2j2  6j2  1j2  1j2  7j0 11j2 10j2 12j2 19j2 19j2 17j2 15j2 NB.  8 ''
 9j0  9j0  9j0  9j0  9j0  9j0  9j0  9j0  9j0  9j0 10j2  9j0  9j0  9j0  9j0  9j0 NB.  9 comment
 1j2  0j2  2j2  3j2  2j2  6j2  1j2  1j2  7j2 11j2 10j2 12j2 19j2 19j2 17j2 15j2 NB. 10 LF
 1j2  0j3  2j2  3j2  2j2  6j2  1j0  1j0  7j2 13j0 10j2  1j2 19j2 19j2 17j2 15j2 NB. 11 {
 1j2  0j3  2j2  3j2  2j2  6j2  1j0  1j0  7j2  1j2 10j2 14j0 19j2 19j2 17j2 15j2 NB. 12 }
 1j2  0j3  2j2  3j2  2j2  6j2  1j7  1j7  7j2  1j2 10j2  1j2 19j2 19j2 17j2 15j2 NB. 13 {{
 1j2  0j3  2j2  3j2  2j2  6j2  1j7  1j7  7j2  1j2 10j2  1j2 19j2 19j2 17j2 15j2 NB. 14 }}
15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 16j0 NB. 15 `
 1j2  0j3  2j2  3j2  2j2  6j2  1j2  1j2 16j0 11j2 10j2 12j2 15j2 19j2 17j2 16j0 NB. 16 ``
17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 18j0 17j0 NB. 17 "
 1j2  0j3  2j2  3j2  2j2  6j2  1j2  1j2 17j0 11j2 10j2 12j2 15j2 19j2 17j0 15j2 NB. 18 ""
 1j2  0j3  2j2  3j2  2j2  6j2  1j2  1j2  7j2 11j2 10j2 12j2 19j2 19j0 17j2 15j2 NB. 19 utf-8 
}}

NB.₨
Tools=: Tools, {{)n
   Code '~Jay/tools/strings'  NB. After Split Join Replace ForEach
                              NB. Trim TrimStart TrimEnd StartsWith EndsWith
}}

NB. Insure a trailing value
After=: (13 :'y, x#~ x~: {:y')"1

Split=: {{
 NB. Split x into boxes at each y
 if. ''-: x do. 0#a: return. end.
 if. ''-: y do. <@,"0 x return. end.
 if. 1= #y do.
  <;._2 x, y
 else.
  if. #now=. x noOverlap_pj_ y do.
   (x{.~ {.now); (#y)}. &.> now indexCut_pj_ x
  else.
   ,<,x
  end.
 end.
}}"1

NB. Put y between each box of x
Join=: (13 :';}.,x,.~ <y')"1

NB. White space for HTML and XML
WS=: 32 13 10 9{ a.

NB. Trim characters at the start
TrimStart=: (13 :'x#~ -. *./\ x e. y')"1

NB. Trim characters at the end
TrimEnd=: (13 :'x#~ -. *./\. x e. y')"1

NB. Trim characters at the start and end
Trim=: (TrimStart TrimEnd])f.

NB. Does x start with y
StartsWith=: (13 :'(,y)-: x{.~ x <.&# y')"1

NB. Does x end with y
EndsWith=: (13 :'(,y)-: x{.~ -(#x)<. #y')"1

Replace=: {{
 NB.    Usage: text Replace old; new
 NB. Multiple: text Replace ForEach 2 ;:'this that now then'
 'old new'=. y
 if. 1 1-: #&> y do. x (x I.@:= {.old)}~ {.new
 else. new Join~ x Split old end.
}}"1

ForEach=: {{
 NB. Usage: left verb ForEach eachSize multipleEachSizeArgs
 y=. |., <"1 (-n) ]\ y
 >u~ &.>/ y, <x
}}

NB. Support for strings

indexCut_pj_=: {{
 NB. Cut with x as indexes instead booleans
 y <;.1~ 1 x} 0#~ #y
}}

noOverlap_pj_=: {{
 NB. Find non-overlapping indexes of y in x
 NB. See nosindx: https://code.jsoftware.com/wiki/Essays/Substring_Replacement
 if. ''-: y do. i.0 return. end.
 now=. y I.@E. x
 if. -.({.e.}.) y do. now return. end.
 all=. now I. now+ #y
 NB.         Avoid error with _1 as 23rd element and last
 (i.&_1{.]) (now, _1){~ (all, _1 _1){~ ^:a: 0
}}

NB.₨
{{)n
   Code '~Jay/tools/settings' NB. Nouns control code in other source files
}}

NB. Given a verb name, which file extension is assumed and remembered
NB.             0    1    2    3    4    5    6
VERBS_pj_=: ;: 'Save Load Run  Copy Code Edit View'
EXTS_pj_=: (<;._1 '|.ijs|.ijs|.ijs|.ijs|.ijs||'){.~ >:#VERBS_pj_
FILES_pj_=: (#EXTS_pj_)$ <''
{{ NB. enable   verb Last Save
 if. 1= L. last=. {:/:~ '.ijs' Files '~Jay/temp/Saved_' do.
  last=. '~Jay/temp/', ;last
  FILES_pj_=: FILES_pj_ (VERBS_pj_ i.<'Save')}~ <last
 end.
}} _

timeStamp_pj_=: {{
 NB. Time stamps make file names unique
 x, y,~ (6!:0) '_YYMMDD_hhmmss_sss' [(6!:3) 0.001
}}

NB. Initial file name for Tag
DISPLAY_pj_=: '~Jay/temp/Display' timeStamp_pj_ '.html'
NB. Proper .html output calls  Head ''  first!

WIDTH_pj_=: {.wcsize ''  NB. Initial output width
PS=: New ''  NB. A locale to pass items across Load, or locals between verbs

Help=: {{)n
 Load '~Jay/tools/Build'      NB. Update Tools
 Load '~Jay/PathDiff'         NB. Find different between paths x and y
 Load '~Jay/PathFind'         NB. Find files in path x containing y
}}

cocurrent'base'
NB.₨
NB. End of Tools