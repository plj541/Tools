help=: {{)n
 NB. {.x must be " or '  and  {:x must be , or TAB
 mat=. '",' csvLoad File 'was.csv'  NB. Matrix of boxes from a .csv file
 ('",' csvSave mat) File 'now.csv'  NB. Matrix of boxes into a .csv file
}}

csvLoad=: {{
 NB. To create a nested matrix from a .csv file
 ^csvArg x
 mj=. 10 8 0 (10, a.&i. x)} 256$2
 now=. (0; sj_pj_; mj);: LF After y
 now=. now ((2# <}.x)I.@E. now)}~ <''
 now=. now#~ now~: <}.x
 ><;._2 now in}~ ([:}.}:)&.> now{~ in=. I.({.x)= {.&>now
}}

csvSave=: {{
 NB. To format a nested matrix into a .csv file
 ^csvArg x
 right=. LF,~ left=. {.x [between=. 3$ x
 ; ([:<left, right,~ between Join~ ])"1 y
}}

csvArg=: {{
 if. 0 e. y e.&> '"'; ',;|', TAB do.
  Say {{)n {.x must be "  and  {:x must be one of , ; | or TAB }} return. end.
}}
