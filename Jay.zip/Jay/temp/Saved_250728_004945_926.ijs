Across=: 3 : 0
 NB. Place two blanks between items and fold then to WIDTH_pj_
 2 foldBoxes_pj_ y
)
After=: (] , [ #~ [ ~: [: {: ])"1
Args=: 3 : 0
 NB. Config file format:  names LF value1 LF value2 etc
 args=. <;._2 LF,~ File 'config/',y,'.cfg'
 if. (#args)~: >:#;:;{.args do. ^'File damaged' end.
:
 if. (#x=. }.0; x)= <:#args=. Args y do.
  (LF Join~ x,~ {.args) File 'config/', y, '.cfg' return. end.
 (quote y), ' Args~ ', '  NB. Press Enter after updating',~ '; ' Join~  quote &.>}.args
)
Ask=: 3 : 0
 NB. Ask a question and wait for user response
 (1!:1) 1 [Say y
)
Clear=: 3 : 0
 NB. Clear the active workspace
 if. 'Clear' stack_pj_ y do. return. end.
 'Cleared' [(4!:55) (4!:1) i.4
)
Code=: 3 : 0
 NB. Edit a code file
 'Code' editFile_pj_ y
)
Copy=: 3 : 0
 NB. Like Load without Clear
 if. 0 0-: $y=. 'Copy' Script 000 y do. fileName_pj_ 'Copy'
 else. y end.
)
Cr=: 3 : 0
 NB. Displays lines with line numbers used during debugging
 mon=. y Cr~ <1 [dia=. y Cr~ <2 [y=. ,y
 cr=. y, (>{:mon), (,':'), >{:dia
 ln=. 'p<[>q<] >0'8!:2 ,.(>{.mon), _, >{.dia
 ln=. ' ', ln (<0;~ #>{.mon)}~ ' '
 ln,. cr
:
 cr=. md (5!:7) <y [md=. >x
 if. 0= #cr do. (i.0); 0 0$ '' return. end.
 line=. {:&> 1{"1 cr
 lines=. i.>:{:line
 lines=. lines#~ lines e. line
 cr=. ' ' Join~ (lines =/line)#"1 [2{"1 cr
 if. md~: x do. lines; cr
 else. (y, cr),.~ (3": md), 'p<[>q<] >0' (8!:2) ,.lines end.
)
DEF=: 5!:5&<
Def=:  :0
Del=: 1 : 0
 NB. Copy lines from the screen, then
 if. 0= (4!:0) <'u' do. m : (wd 'clippaste')
 else. u wd 'clippaste' end.
)
Diff=: 2 : 0
 NB. Usage: x [m] Diff n y
 m '' Diff n y
:
 n=. 2$ n  NB. n should be ⎕IO for x and y, 1 for external editors, 0 for J nouns
 x=. boxedLines_pj_ x [y=. boxedLines_pj_ y
 if. x-: y do. 'They are identical' return. end.
 if. m-: '' do. m=. ',Old lines,New lines' end.
 label=. ' ↑ ', old, ' --   -- ↓ ', new, LF ['old new'=. <;._1 m
 label=. label,~ '-'#~ #":#x ['old new'=. n
 (x old diffLines_pj_ y), label, y new diffLines_pj_ x
)
Dir=: 3 : 0
 NB. Formatted dir
 if. 0~: #dir=. '' Dir y do.
  time=. 'q[-]5.0,r[0]q[-]3.0,r[0]q[  ]4.0,r[0]q[:]3.0,r[0]2.0' Fmt 0 _1}. >1{"1 dir
  size=. 'p[ ]q[  ]13.0' Fmt ,.>2{"1 dir
  name=. >0{"1 dir
  dir=. 'd'= 4({ >)"0 [4{"1 dir
  size=. ' ' (I. dir)} size
  (time,. size,. name)/: (1": -.dir),. Keys name
 end.
:
 NB. Boxed dir
 star=. '*'
 if. ''-.@-: y do.if. 1= #dir=. (1!:0) y=. 2 Path y do.
  if. 'd' e. >dir{~ <0 4 do. star=. '/*' end.
 end.end.
 (1!:0) y, star, x
)
Dirs=: 4 : 0
 NB. Just directory names, with path if y ends with /
 (/:Keys) x 1 filesDirs_pj_ y
)
Display=: 3 : 0
 NB. Tag y and look at the result
 if. ''-.@-: y do. Tag y end.
 View DISPLAY_pj_
 DISPLAY_pj_=: '~Jay/temp/Display' timeStamp_pj_ '.html'
)
Do=: 3 : 0
 NB. Evaluate statements from a noun, with display
 (0!:101) y
:
 NB. Evaluate statements from a noun, without display
 if. x-: y do. x=. 100 end.
 (0!:x) y
)
Dr=: 3 : 0
 rn=. '' NB. Given a folder, display Dirs then Files
 if. 1= #dir=. (1!:0) 2 Path y do.if. 'd'= 4{ >4{ ,dir do.
  rn=. LF, '   ', ' Rn',~ quote_z_ y
 end.end.
 if. 0= #rn do. 'Specify a folder' return. end.
 ds=. ds, LF#~ 0~: #ds=. Across '' Dirs y
 fs=. fs,~ LF#~ 0~: #fs=. Across '' Files y
 ds, ' .  ..', fs, rn 
)
Edit=: 3 : 0
 NB. Edit a file with any extension
 'Edit' editFile_pj_ y
)
EndsWith=: (([: , ]) -: [ {.~ [: - ([: # [) <. [: # ])"1
Erase=: ([: 4!:55 ;: ::]) :([: 18!:55 ])
Fexist=: 3 : 0
 NB. Just files, not directories or http
 if. ([:1: 1!:4) ::0: <full=. 0 Path y do.
  if. 0= #look=. (1!:0) full do. 1 return.
  elseif. 'd'~: 4{ ;4{ ,look do. 1 return. end.
 end.
 0
)
File=: 3 : 0
 NB. Read a file
 if. -.isFull_pj_ full=. 0 Path y do. (13!:8&45) 'Illegal file name' end.
 now=. (1!:1) <full
 if. (239 187 191{ a.)-: 3{. now do.
  now=. 3}. now
 end.
:
 NB. Create or Replace a file, If ,:x Append
 if. -.isFull_pj_ full=. 0 Path y do. (13!:8&45) 'Illegal file name' end.
 if. 2< #$ x do. (13!:8&45) 'Invalid shape of x' end.
 wa=. (2+ (2= [:#$) (*.) 1= [:{.$) x
 y [(,x) (1!:wa) <full
)
Files=: 4 : 0
 NB. Just file names, with path if y ends with /
 (/:Keys) x 0 filesDirs_pj_ y
)
Fmt=: 3 : 0
 NB. Financial form of numbers
 NB. -    +   -   +  mp Before; nq After; b[zero]; d[nill]; r[fill]
 'm[ (]p[  ]n[)]q[ ]c0.2' Fmt y
:
 if. 0 e. $y do. ''$~ $y return. end.
 if. L. x do.
  x=. }: ;(<'m[ (]p[  ]n[)]q[ ]⍕,') Replace&.> <"1 x,.~ <'⍕'
 end.
 x (8!:2) y
)
Folders=: 3 : 0
 Unbox UserFolders_j_
:
 Unbox SystemFolders_j_
)
ForEach=: 2 : 0
:
 NB. Usage: left verb ForEach eachSize multipleEachSizeArgs
 y=. |., <"1 (-n) ]\ y
 >u~ &.>/ y, <x
)
Head=: 3 : ' TAG_pj_ File DISPLAY_pj_=: ''~Jay/temp/Display'' timeStamp_pj_ ''.html'''
How=: 3 : 0
 NB. Document areas
 if. y-: 2 do. {{ ' How ''', '''',~ }. _4}.y }}  &> '.txt' Files 'data/How2/_'
 else. File 'data/How2/_', y, '.txt' end.
:
 NB. Save a Last note  Last~'tests'
 'Sink' editFile_pj_ 'data/How2/_', (toupper {.y), }.y=. y, '.txt'
)
Include=: 3 : 0
 NB. Like Copy but signals when an error occurrs
 if. 2= #$now=. Copy y do. (13!:8&45) ,now end.
)
Join=: ([: ; [: }. [: , [ ,.~ [: < ])"1
Keys=: 3 : 0
 keys=. (('                                 """""""""""""""##########"""""""abcdefghijklmnopqrstuvwxyz""""""abcdefghijklmnopqrstuvwxyz""""'{~ ]), '000000000000000000000000000000000b3pqmv256lkg1ds0123456789efihjcu111111111111111111111111118t7n04000000000000000000000000009oar0'{~ ])
 ([:keys a.i. ])"1 >y
)
Last=: 2 : 0
 NB. What file did verb last use
 type=. VERBS_pj_ i. <verb=. v verb_pj_
 if. ''-.@-: file=. >type{ FILES_pj_ do. u file
 else. verb, ' has not used a file' end.
)
LastVersion=: 3 : 0
 NB. Name of last file version, using download version naming
 'path name extn'=. pathNameExtn_pj_ y 
 if. #file=. (')', extn) Files path, name, ' ('
  do. path, ;{:file
 elseif. #'' Files y do. y
 else. ,:'No version of ', y end.
:
 NB. Name of the next version
 if. 2= #$x=. LastVersion y do. y return. end.
 'path name extn'=. pathNameExtn_pj_ x
 if. ')'= {:name do.
  now=. ":>:".prev=. name}.~ name i:'('
  path, extn,~ (name}.~ -<:#prev), now, ')'
 else. path, name, ' (1)', extn end.
)
Lib=: 3 : 0
 NB. Names of Code files
 Across 'Load' libFiles_pj_ y
)
Libs=: 3 : 0
 NB. Look at my libraries
 line=. {{ LF, '   ', y, LF, ".y }} 
 now=. line  'Lib ''''' 
 now=. now, line  'Lib ''code''' 
 now=. now, line  'Lib ''test''' 
 now=. now, line  'Lib ''../demos''' 
    }. now, line  'Across '''' Dirs ''data''' 
)
Lines=: 3 : 0
 NB. Make y a character vector so it can be written to a file
 (9!:7) ascii=. 11{. 16}. a. [was=. (9!:6) ''
 ascii=. <"0 ascii [display=. <"1 [11 3$ '┌┬┐├┼┤└┴┘│─'
 now=. (displayUnboxed_pj_ y) Replace ForEach _ ascii,. display
 now [(9!:7) was
)
Load=: 3 : 0
 NB. Load an app into a Clear locale
 if. 'Load' stack_pj_ '' do. return. end.
 try.
  if. ''-: file=. 'Load' fileName_pj_ y do.
   'No file name in use' return. end.
  if. Fexist full=. 0 Path file do. Clear ''
   (0!:000) <full ['Load' fileName_pj_ <file
   if. 0= (4!:0) <'help' do. file, LF, help else. file end.
  else.
   '‘', file, '’ does not exist'
  end.
 catch. dberm_z_ ''
 end.
)
Log=: 3 : 0
 NB. Say with append to today's log
 empty LOG_pj_ File~ ,:LF, displayUnboxed_pj_ y
 if. #y do. y 1!:2 [2 end.
)
Lrc=: 3 : 0
 NB. File names and who used them
 top=. 'Users'; 'Current File',~ ' '#~ 0>. _6+<.-: >./ #&> FILES_pj_
 Unbox top, VERBS_pj_,. }: FILES_pj_
)
NL=: (] #~ ([: < [: , [) = ] {.&.>~ [: # [) 4!:1
Names=: 3 : 0
 NB. List names, ''=all, 0=noun, 1=adverb, 2=conjunction, 3=verb
 Across (/:Keys) (<,'y')-.~ (4!:1) y, (y-: '')# i.4
:
 NB. List locales, ''=all, 0=named, 1=numbered
 Across (/:Keys) (18!:1) y, (y-: '')# i.2
)
New=: 3 : 0
 NB. Create an object
 locale=. (18!:3) ''
 locale (18!:2)~ (18!:2) <'base'  NB. Give it the name search path of base
 if. y-: '' do. locale
 elseif. locale {{ cocurrent_z_ x
  err_pj_=: 'Run' Script 000 y
  0 0-: $err_pj_ }}  y do. locale
 else. (13!:8&45) ,err_pj_ [(18!:55) locale end.
)
Page=: 3 : 0
 NB. Fetch a web page as text
 File ;{: httpget_jpacman_ y
)
Path=: 0&$: :(4 : 0)
 NB. Provide absolute path to file argument
 if. ':/' +./@E. y=. ,y do. y return. end.  NB. It's http
 if. y +./@e.~ x}. '*?|<>' do. (13!:8&45) 'Illegal file name' end.
 if. isFull_pj_ y do. y return. end.
 if. '~'= {.y do.
  map=. SystemFolders_j_, UserFolders_j_
  map=. ({:"1 map){~ ({."1 map)i. {.y=. <;._1 '/', }.y
  ;map, '/',&.> }.y
 else.
  ({{ y (I. y= '\')} ~'/' }}  1!:43 ''), y,~ '/'#~ 0~: #y
 end.
)
Paths=: 3 : 0
 if. -.'/~'e.~ {.y do. y=. y,~ '/',~ (1!:43) '' end.
 paths=. }: (2!:0) 'ls -p -R ', 0 Path y
 paths=. paths Split LF2
 paths=. (paths ,&.> LF) Split&> <':', LF
 paths /:Keys {."1 paths
:
 if. 0= L. y do. y=. Paths y end.
 select. x
 case. 'D' do. {."1 y  NB. Just the Dirs
 case. 'P' do.  NB. Just the Files with full path
  files=. y #~ 0~:([:# [:>{:)"1 y NB. No empties: {{#>{:y}}
  NB. Join path/files: {{<(<'/',~ >{.y) ,&.> (/:Keys)<;._2 >{:y}}
  files=. ;([:<([:<'/',~ [:>{.) ,&.> [:(/:Keys) [:<;._2 [:>{:)"1 files
  files#~ files (]~: [:{:[) &> <'/'  NB. No paths: {{y~: {:x}}
 case. 'F' do. NB. Just the Files without path
  if. 1~: #$y do. (13!:8&45) 'Just one element for F'
  else. files#~ files (]~: [:{:[) &> <'/' [files=. (/:Keys)<;._2 >{: y end.
 case. do. (13!:8&45) 'D for dirs, F for files or P for files with paths' end.
)
Pax=: 2 : 0
 NB. (<Names), Values  includes locals when called monadically
 if. '".'-: (5!:5)<'u' do. (< , u.&.>) y v. 0
 else. x, <(< , u.&.>) y v. }.i.4 [x=. <(< , u.&.>) y v. 0 end.
:
 NB. Ensure only global results  ((;:''x u v y'')-.~ y) x v y
 u Pax ([:((<;._1' x u v y')-.~ ]) v) y  NB. Ignore my arguments
)
Rank_1=: 1 : 'u"1 &. |:'
Replace=: 4 : 0"1
 NB.    Usage: text Replace old; new
 NB. Multiple: text Replace ForEach 2 ;:'this that now then'
 'old new'=. y
 if. 1 1-: #&> y do. x (x I.@:= {.old)}~ {.new
 else. new Join~ x Split old end.
)
Rn=: 1 : 0
 NB. Recall Dr if the copied value is a folder
 file=. (wdclippaste_z_ ''),~ >(m-: ''){ m;~ m, '/' 
 if. 1= #dir=. (1!:0) 2 Path file do.
  if. 'd'= dir=. 4{ >4{ ,dir do. Dr file return. end.
 else. '‘', file, '’ does not exist' return. end.
 NB. Offer launch choice with a copied file name 
 now=. quote file
 if. '.ijs'-: tolower _4{. file do.
  ' {{ Code`Load`Run`Copy @. y ,', now, ' }} 0'
 else. ' {{ Edit`View @. y ,', now, ' }} 0' end.
)
Root=: 1 : 0
 root=. ROOT_pj_, y
 if. ('Dr'-: (5!:5) <'u')*. ''-: y do.
  rn=. LF, '   ', ' Rn',~ quote_z_ }:root
  root=. root, '*' 
  drs=. drs, LF#~ 0~: #drs=. Across '' Dirs root
  fls=. fls,~ LF#~ 0~: #fls=. Across '' Files root
  drs, ' .  ..', fls, rn
 else. u root end.
:
 ROOT_pj_=: x, '/'
 if. -.x-: y do. u Root y end.
)
Run=: 3 : 0
 NB. Evaluate statements from a file, with display
 'Run' Script 001 y
:
 NB. Evaluate statements from a file, without display
 if. x-: y do. x=. 000 end.
 'Run' Script x y
)
Save=: 3 : 0
 y=. (y,~ '_'#~ 0~: #y), ;{.EXTS_pj_
 y=. '~Jay/temp/Saved' timeStamp_pj_ y
 y File~ }.;a: Save&.> (<,'y')-.~ ((4!:1) }.i.4), (4!:1) 0
 0 0$ FILES_pj_=: FILES_pj_ (VERBS_pj_ i.<'Save')}~ <y
:
 if. 0= 4!:0 <y do.if. 2= 3!:0 x=. ".y do.if. 1= #$x do.
  LF, (LF,'}}'),~ (y,'=: }:{{)n',LF),x Replace(LF,'}}');LF,' }}' return.
 end.end.end.
 ((10{a.),],'=: ',[:5!:5<) y
)
Say=: 3 : 0
 NB. Should display an intermediate value
 if. ([:#,) y do. y (1!:2) 2 end.
)
Script=: 2 : 0
 NB. Run a Script File
 try.
  if. ''-: file=. m fileName_pj_ y do. ,:'No file in use' return. end.
  if. -.Fexist full=. 0 Path file do. ,:'‘', file, '’ does not exist' return. end.
  m fileName_pj_ <file
  (0!:n) <full
 catch. dberm_z_ ''
 end.
)
Split=: 4 : 0"1
 NB. Split x into boxes at each y
 if. ''-: x do. 0#a: return. end.
 if. ''-: y do. <@,"0 x return. end.
 if. 1= #y do.
  <;._2 x, y
 else.
  if. #now=. x noOverlap_pj_ y do.
   (x{.~ {.now); (#y)}. &.> now indexCut_pj_ x
  else.
   ,<,x
  end.
 end.
)
StartsWith=: (([: , ]) -: [ {.~ <.&#)"1
Tag=: 3 : 0
 NB. Append J values to their HTML equivalent
 if. -.Fexist DISPLAY_pj_ do. TAG_pj_ File DISPLAY_pj_ end.
 if. 0= L. y do.
  y=. LF,~ '</span></pre>',~ Lines y
  DISPLAY_pj_ File~ ,: '<pre><span class="inner-pre" style="font-size: 18px">', y
 else.
  DISPLAY_pj_ File~ ,:'<br>', toUnboxed_pj_ y
 end.
)
Today=: 3 : 0
 NB. Today with y days offset
 now=. 3{. (6!:0) ''
 if. 0-: y do. now
 else. todate y+ todayno now end.
)
Trim=: ([ #~ [: -. [: *./\ e.)"1 ([ #~ [: -. [: *./\. e.)"1 ]
TrimEnd=: ([ #~ [: -. [: *./\. e.)"1
TrimStart=: ([ #~ [: -. [: *./\ e.)"1
Unbox=: 3 : 0
 NB. Remove boxing characters from result
 if. 32~: (3!:0) y do. 
  if. ' '= {.0($,)y do. >y Split LF
  else. 1 1}. _1 _1}. ": <y end.
 else.
  was=. (9!:6) ''
  (9!:7) [11# rep=. 30{ a.
  (9!:7) was [now=. ": <y
  now=. 1 1}. _1 _1}. now
  rho=. $now=. (-.*./"1 now= rep)# now 
  rho$ ' ' (I. now= rep)} now=. ,now
 end.
)
View=: 3 : 0
 NB. View an html page with a browser
 0 0$ browse_j_ viewRules_pj_ y
)
Vr=: 3 : 0
 NB. Visual Representation
 if. 0= (4!:0) <y do.
  LF,~ 'NB. ', y, ' is a Noun'
 else. t=. >('1234'i. {.d){ ')a'; ')c'; ''; ')d'; 'X' [d=. (5!:5) <y
  if. ' : '-: 3{.}.d do. e=. 4{. }.d
   if.     ' : 0'-:  e do. d=. }:d}.~ #e=. (d i. LF){. d=. 5}. d
   elseif. ' : '''-: e do. d=. ".d}.~ -#e=. (>:d i: '''')}. d=. 4}. d
   elseif. ' : ('-:  e do. d=. 4}. d
    if. (;:')"(')+./@E. ;:d do. d=. d}.~ -#e=. d}.~ >:1 i:~ ') " ('E. d
    else. d=. d}.~ -#e=. (>:d i: ')')}. d end.
    d=. LF,LF,~ LF Join~ ". d
   else. (13!:8&45) 'Unrecognized' end.
   LF,~ y, '=: {{', t, d, '}}', e
  else. LF,~ y, '=: ', d end.
 end.
)
Words=: 3 : 0
 NB. Usefull with understanding APL, HTML and JavaScript
 NB. LF is part of quotes, whether beginning with ' or "
 NB. Unicode characters outside quotes are words
 (0; (7 0 (<7; 10; 0 1)} sj_pj_); mj_pj_) ;: y
:
 NB. Useful with PathFind
 x=. ,x [mj=. mj_pj_ [sj=. sj_pj_
 NB. Turn off characters in x which hide non-J words
 if. +./'NB'E. x do. mj=. mj (a.i.'NB')}~ 2 end.   NB. NB makes them just part of user names
 if. '.'e. x do. sj=. sj (<1 2; 6; 0 1)}~1 2 end.  NB. . removed from #. and i. but not 12.3
 if. #x=. x {{ y#~ y e. x }}  ':''"`' do. mj=. mj (a.i. x)}~ 0 end.  NB. Any of : ' " can be removed
 (0; sj; mj) ;: y
)
Yes=: 3 : 0
 NB. Ask a question, require a yes or no answer
 now=. Ask y
 while. 1 do.
  if. 4= now=. 'nyNY'i. {.now TrimStart ' ' do.
   now=. Ask y, ' (Yes or No)'
  else. 2| now return. end.
 end.
)
debug=: 1 : 0
 Include '~Jay/tools/debugs'
 u debug_plj_
)
io=: 1 : 0
 u guard_pj_~ _  NB. Arguments without quotes
 LOG_pj_ File~ ,:LF, '§ Session ', 6!:0 'YYYY/MM/DD hh:mm:ss'
 Ask=. {{ y [LOG_pj_ File~ ,:(LF,'¶ '), y=. ' 'Trim~ 1!:1 [1 }} 

 while. 1 do.try.
  select. tolower ;2{. part=. ;:ioLine_pj_=: line=. Ask ''
  case. '';,']'  do. Say ']q  NB. To leave, ]h to learn more'
  case. ']io' do. Say 'Already, io is'
  case. ']q' do. 'Done, are we' return.
  case. ']h' do. Say ioHelp_pj_
  case. ']debug' do. Say 'In here, cannot'
  case. ']nm';']names' do. Log Names ".(}.part) ioArg_pj_ line 
  case. ']lo';']load' do. Log Load (}.part) ioArg_pj_ line
  case. ']kp';']copy' do. Log Copy (}.part) ioArg_pj_ line
  case. ']li';']lib' do. Log Lib (}.part) ioArg_pj_ line
  case. ']lm';']libs' do. Log Libs ''
  case. ']ll';']wsid' do. Log fileName_pj_ 'Load'
  case. ']il' do. Log ioIn_pj_ (}.part) ioArg_pj_ line
  case. do.
   if. ']'= ;{.part do.  NB. For ], everything after verb is quoted
    Log ".line=. (;2{.part), ' ', quote(}.part)ioArg_pj_ line    
   elseif. '@'= ;{.part do. Log ioJA_pj_ }.line   NB. Help using TryAPL
   else.if. ({.}.part)e. '=.'; '=:' do. ".line    NB. Assignment doesn't display
        else. Log ".line end.end.                 NB. Others do display
  end.
 catch. Log {{ }.(<./y i. ':', LF){.y }}  13!:12 '' end.end. 'Done, I am'
)
Help=: }:{{)n
 jpkg ''                      NB. Command line Package Manager
 Undo ''                      NB. Retract previously published HTML files
 Load '~Jay/tools/Build'      NB. Update Tools.ijs
 Load 'code/Rebuild'          NB. Sync ~Jay/tools with ~Jay/Tools.ijs
 Load 'PathDiff'              NB. Find different between paths x and y
 Load 'PathFind'              NB. Find files in path x containing y

}}
PS=: <,'0'
Tools=: }:{{)n
   Code '~Jay/tools/libs'     NB. Code Lib Load Run Copy Include
   Code '~Jay/tools/files'    NB. Edit Dir Dirs File Files Lines Page
   Code '~Jay/tools/names'    NB. Names Erase Clear Do New Pax
   Code '~Jay/tools/output'   NB. View Across Fmt Keys Unbox Vr
   Code '~Jay/tools/html'     NB. Display Head Tag
   Code '~Jay/tools/session'  NB. Del Dr Rn Last Say Ask Yes
   Code '~Jay/tools/debug'    NB. Save Cr ]debug
   Code '~Jay/tools/words'    NB. Rank_1 Diff Words
   Code '~Jay/tools/strings'  NB. After Split Join Replace ForEach
                              NB. Trim TrimStart TrimEnd StartsWith EndsWith
   Code 'begin/]Extras'       NB. Folders How Iam Lrc

}}
WS=: }:{{)n
 
	
}}
dbhelp=: }:{{)n
dbr     dbq                   debugging
dberr   dberm                 report
dbst    dbstack   dblocals    stack
dbss    dbsq      dbtrace     stop or trace           
dbrun   dbnxt     dbret       resume

}}