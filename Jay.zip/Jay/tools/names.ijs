Tools=: Tools, {{)n
   Code '~Jay/tools/names'    NB. Names Erase Clear Do New Pax
}}

Names=: {{
 NB. List names, ''=all, 0=noun, 1=adverb, 2=conjunction, 3=verb
 Across (/:Keys) (<,'y')-.~ (4!:1) y, (y-: '')# i.4
:
 NB. List locales, ''=all, 0=named, 1=numbered
 Across (/:Keys) (18!:1) y, (y-: '')# i.2
}}

NB. Monad: Erase names in y, including locals
NB. Dyad:  Erase locales identified in y
Erase=: ([: 4!:55 ;: ::]) : ([: 18!:55 ])

Clear=: {{
 NB. Clear the active workspace
 if. 'Clear' stack_pj_ y do. return. end.
 'Cleared' [(4!:55) (4!:1) i.4
}}

Do=: {{
 NB. Evaluate statements from a noun, with display
 (0!:101) y
:
 NB. Evaluate statements from a noun, without display
 if. x-: y do. x=. 100 end.
 (0!:x) y
}}

New=: {{
 NB. Create an object
 locale=. (18!:3) ''
 locale (18!:2)~ (18!:2) <'base'  NB. Give it the name search path of base
 if. y-: '' do. locale
 elseif. locale {{ cocurrent_z_ x
  err_pj_=: 'Run' Script 000 y
  0 0-: $err_pj_ }} y do. locale
 else. (13!:8&45) ,err_pj_ [(18!:55) locale end.
}}

NB. Dyadic nl to see caller's locals
NB.  (y#~ (  <   , x)= y{.&.>~   #x) (4!:1)
NL=: (]#~ ([:< [:, [)= ]{.&.>~ [:#[) (4!:1)

NB. Definitions of caller's locals
DEF=: 5!:5&<

Pax=: {{
 NB. (<Names), Values  includes locals when called monadically
 if. '".'-: (5!:5)<'u' do. (< , u.&.>) y v. 0
 else. x, <(< , u.&.>) y v. }.i.4 [x=. <(< , u.&.>) y v. 0 end.
:
 NB. Ensure only global results  ((;:''x u v y'')-.~ y) x v y
 u Pax ([:((<;._1' x u v y')-.~ ]) v) y  NB. Ignore my arguments
}}
