{{)n
   Code '~Jay/tools/settings' NB. Nouns control code in other source files
}}

NB. Given a verb name, which file extension is assumed and remembered
NB.             0    1    2    3    4    5    6    7   8
VERBS_pj_=: ;: 'Save Load Run  Copy Code Note Edit Use Modify'
EXTS_pj_=: (<;._1 '||.ijs|.ijs|.ijs|.ijs|.txt|'){.~ >:#VERBS_pj_
FILES_pj_=: (#EXTS_pj_)$ <''

NB. Given an extension, which verb should Use invoke
UEXTS_pj_=: <;._1 '|.html|.htm|.ijs|.txt'  NB. !!!Why distinguished .txt
UVERBS_pj_=: Browse ` Browse ` Load ` File

timeStamp_pj_=: {{
 NB. Time stamps make file names unique
 x, y,~ 6!:0 '_YYMMDD_hhmmsss'
}}

WIDTH_pj_=: {.wcsize ''  NB. Initial output width
DISPLAY_pj_=: '~Jay/temp/Display' timeStamp_pj_ '.html'  NB. Initial file name for Tag
PS=: New ''  NB. A locale to pass items across Load, or locals between verbs

Help=: {{)n
 Load '~Jay/tools/Build'      NB. Update Tools
 Load '~Jay/PathFind'         NB. Find files in path x containing y
 Load '~Jay/PathDiff'         NB. Find different files between paths x and y
}}

cocurrent'base'