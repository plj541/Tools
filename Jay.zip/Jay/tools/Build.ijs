help=: {{)n
 ViewAll ''  NB. View all Build files
 Refresh ''  NB. Only needed with Compare while changing code
 Compare ''  NB. See tools changes for one source file
 All ''      NB. Compare each file
 Update 0    NB. Is tools.ijs updated? 1 will update
}}

NB. Public names

All=: {{
 Refresh _
 if. 0= #buildPax__PS do. NC return. end.
 (>{.buildPax__PS)=. }.buildPax__PS
 for_nam. myNxtHas# myNowName do.
  if. 'They are identical'-: now=. Compare >nam do. continue. end.
  Say now
 end.
 empty _
}}

Compare=: {{
 NB. Find unique lines in two versions of a tool
 if. 0= #buildPax__PS do. NC return. end.
 (>{.buildPax__PS)=. }.buildPax__PS
 both=. myNxtHas# myNowName
 if. 0= #y do.  NB. Display names in both versions
  now=. '  ', ,LF,.~ Unbox (<"0 i.#both),: both
  now, '   Compare 0            NB.  Index or ''name'''
  return.
 elseif. 0= {.0# y do.  NB. Convert your number to a name
  y=. >y{ both
 end.
 NB. Check for lost lines in named version
 s=. >myNow{~ myNowName i. y=. <z=. y
 y=. >myNxt{~ myNxtName i. y
 if. 'They are identical'-: s=. s ';Tools;../tools' Diff 1 y do. s return. end.
 s,~ z, '''s missing lines:', LF
}}

Refresh=: {{
 NB. Save myNouns for others to use
 if. (myNow=. toolsNow '') -: myNxt=. toolsNext '' do.
  empty buildPax__PS=: ''
 else.
  'myNow     myNxt    '=. toolsFiles&.> myNow;  myNxt
  'myNowName myNxtName'=. toolsNames&.> myNow; <myNxt
  myNxtHas=. myNowName e. myNxtName 
  myNowHas=. myNxtName e. myNowName
  empty buildPax__PS=: ". Pax NL 'my'
 end.
}}

Update=: {{
 if. y-: 1 do.
  if. '~Jay/Tools.ijs'frename~ '~Jay/Tools' timeStamp_pj_ '.ijs' do.
   (toolsNext '') File '~Jay/Tools.ijs'
   'Updated ~Jay/Tools.ijs' [reload _
  else.
  'Not updated, ~Jay/Tools.ijs could not be renamed' 
  end.
 else. differences '' [Refresh _ end.
}}

ViewAll=: {{
 NB. View all tools files 
 Do~ 'Edit ''~Jay/tools.ijs''', LF, Tools, LF, 'Code ''~Jay/tools/settings'''
}}

NB. Refresh support

toolsFiles=: {{
 NB. Break a single file into its sources
 files=. y Split 10 78 66 46 226 130 168 10{a.
 files#~ 'NB.'-.@-:"1 [3{.&> files
}}

toolsNames=: {{
 NB. Find the file name in each element
 names=. 70{.&.> y
 {.&> ''''Split&.>~ 1{&> names Split &.> <'Code ''~Jay/tools/'
}}

toolsNext=: {{
 NB. Build Tools
 (3 : (File '~Jay/tools/aBuild.txt')) ''
}}

toolsNow=: {{
 NB. Current Tools
 File '~Jay/Tools.ijs'
}}

NB. Update support

differences=: {{
 NB. Are Jay/tools.ijs and Results of Jay/tools/aBuild the same
 if. 0= #buildPax__PS do. NC return. end.
 (>{.buildPax__PS)=. }.buildPax__PS
 NB. Compare two versions and report the first difference in each segment
 if. -. myNowName-: myNxtName do.  NB. Compare the two file Name lists
  if. 0 e. myNowHas do. Say Across ' Now is missing:'; myNxtName#~ -.myNowHas end.
  if. 0 e. myNxtHas do. Say Across 'Next is missing:'; myNowName#~ -.myNxtHas end.
 end.
 for_nam. myNxtHas# myNowName do.
  now=. >myNow{~ myNowName i. nam [nxt=. >myNxt{~ myNxtName i. nam
  if. now-.@-: nxt do.
   Say (>nam), ' is different'
  end.
 end.
 empty _
}}

reload=: {{
 NB. Reload Tools after an Update changed it
 try.
  nouns=. EXTS__PLJ; FILES__PLJ; WIDTH__PLJ
  load '~Jay/Tools.ijs'
  'EXTS__PLJ FILES__PLJ WIDTH__PLJ'=: nouns
  buildPax__PS=: ''  NB. Refresh nouns are invalid after a reload
 catch. dberm '' end.
}}

NC=: 'No changes since last Update'
NB. Execute expressions
Refresh ''
