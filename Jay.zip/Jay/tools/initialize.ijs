NB. Load Tools into plj
 load '~Jay/Tools.ijs'  NB. load public code
 
NB. Set preferences, these are your choice
{{
 try.
  9!:11 [10
  9!:37 [0 500 200 10

  if. UNAME-: 'Android' do.
   wd 'setj smfont @apl385 18'
   if. APILEVEL_ja_> 29 do.  NB. From Android 11 "am start" is not supported
    Tools_plj_=: Tools_plj_ Replace ForEach 2 <;._1 ';Code Note;C̶o̶d̶e̶ N̶o̶t̶e̶;Edit;E̶d̶i̶t̶;Browse;B̶r̶o̶w̶s̶e̶'
    Say 'NB. Code, Note, Edit and Browse not supported in this Android version'
   end.
  end.
  NB. Navigate to directory where you save your code
  1!:44 Path '~Jay/mine'
  Say Load 'Start'        NB. Load your initial workspace here
 catch. Say dberm ''
 end.
}} ''
