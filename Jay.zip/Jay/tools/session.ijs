Tools=: Tools, {{)n
 Code 'tools/session'  NB. Del Dr Rn Last Say Ask Yes
}}

Del=: {{
 NB. Copy lines from the screen, then
 if. 0= (4!:0) <'u' do. m : (wd 'clippaste')
 else. u wd 'clippaste' end.
}}

Dr=: {{
 rn=. '' NB. Given a folder, display Dirs then Files
 if. 1= #dir=. (1!:0) 2 Path y do.if. 'd'= 4{ >4{ ,dir do.
  rn=. LF, '   ', ' Rn',~ quote_z_ y
 end.end.
 if. 0= #rn do. 'Specify a folder' return. end.
 ds=. ds, LF#~ 0~: #ds=. Across '' Dirs y
 fs=. fs,~ LF#~ 0~: #fs=. Across '' Files y
 ds, ' .  ..', fs, rn 
}}

Rn=: {{
 NB. Recall Dr if the copied value is a folder
 file=. (wdclippaste_z_ ''),~ >(m-: ''){ m;~ m, '/' 
 if. 1= #dir=. (1!:0) 2 Path file do.
  if. 'd'= dir=. 4{ >4{ ,dir do. Dr file return. end.
 else. '‘', file, '’ does not exist' return. end.
 NB. User provides verb to file name argument
 '     ', quote file
}}

fileType_pj_=: {{
 NB. Find an appropriate editor
 view=. VERBS i. ;:'Code Edit'  NB. Assumes Edit is empty in EXTS
 >VERBS{~ {.view#~ (<y)EndsWith&> view{ EXTS
}}

Last=: {{
 NB. What file did verb last use
 type=. VERBS_pj_ i. <verb=. v verb_pj_
 if. ''-.@-: file=. >type{ FILES_pj_ do. u file
 else. verb, ' has not used a file' end.
}}

verb_pj_=: {{)a
 if. 3= (4!:0) <'u' do. (5!:5) <'u' else. m end.
}}

Say=: {{
 NB. Should display an intermediate value
 if. ([:#,) y do. y (1!:2) 2 end.
}}

Ask=: {{
 NB. Ask a question and wait for user response
 (1!:1) 1 [Say y
}}

Yes=: {{
 NB. Ask a question, require a yes or no answer
 now=. Ask y
 while. 1 do.
  if. 4= now=. 'nyNY'i. {.now TrimStart ' ' do.
   now=. Ask y, ' (Yes or No)'
  else. 2| now return. end.
 end.
}}

Today=: {{
 NB. Today with y days offset
 now=. 3{. (6!:0) ''
 if. 0-: y do. now
 else. todate y+ todayno now end.
}}
