Tools=: Tools, {{)n
   Code '~Jay/tools/session'  NB. Del Dr Rn Use Modify Last Say Ask Yes
}}

Del=: {{
 NB. Copy lines from the screen, then  m specifies the definition
 m : (wd 'clippaste')
}}

Dr=: {{
 rn=. '' NB. Given a folder, display Dirs then Files
 if. 1= #dir=. 1!:0 [1 path_pj_ y do.if. 'd'= 4{ >4{ ,dir do.
  rn=. LF, '   ', ' Rn',~ quote_z_ y
 end.end.
 if. 0= #rn do. 'Specify a folder' return. end.
 d=. Across '' Dirs y [f=. Across '' Files y
 (d, LF#~ 0~: #d), ' .  ..', rn,~ f,~ LF#~ 0~: #f
}}

Rn=: {{
 NB. Recall Dr if the copied value is a folder
 NB. Offer launch choice with a copied file name
 file=. (wdclippaste_z_ ''),~ >(m-: ''){ m;~ m, '/' 
 if. 1= #dir=. 1!:0 [1 path_pj_ file do.
  if. 'd'= dir=. 4{ >4{ ,dir do. Dr file return. end.
 else. '‘', file, '’ does not exist' return. end.
 which=. '}} 0', ": +./ (<file)EndsWith &><;._1' .htm .html'
 which,~ '{{Modify`Use @. y [',quote file
}}

Use=: {{
 NB. Choose an appropriate app
 'path name extn'=. pathNameExtn_pj_ y
 if. (#UEXTS_pj_)= now=. UEXTS_pj_ i. <extn do.
  'Use doesn''t support ', name, extn return.
 else. use=. UVERBS_pj_ @. now end.
 now=. use y
 now ['Use' fileName_pj_ <y
}}

Modify=: {{
 NB. Provide an appropriate editor
 y editFile_pj_~ fileType_pj_ y
 'Modify' fileName_pj_ <y
}}

fileType_pj_=: {{
 NB. Find an appropriate editor
 view=. VERBS i. ;:'Code Note Edit'  NB. Assumes Edit is empty in EXTS
 >VERBS{~ {.view#~ (<y)EndsWith&> view{ EXTS
}}

Last=: {{
 NB. What file did verb last use
 type=. VERBS_pj_ i. <verb=. v verb_pj_
 if. type= 0 do.  ('   ', u verb_pj_), ' Saved ''''  NB. Try this instead'
 elseif. ''-.@-: file=. >type{ FILES_pj_ do. u file
 else. verb, ' has not used a file' end.
}}

verb_pj_=: {{)a
 if. 3= 4!:0 <'u' do. 5!:5 <'u' else. m end.
}}

Say=: {{
 NB. Should display an intermediate value
 if. #y do. y 1!:2 [2 end.
}}

Ask=: {{
 NB. Ask a question and wait for user response
 1!:1 [1 [Say y
}}

Yes=: {{
 NB. Ask a question, require a yes or no answer
 now=. Ask y
 while. 1 do.
  if. 4= now=. 'nyNY'i. {.now TrimStart ' ' do.
   now=. Ask y, ' (Yes or No)'
  else. 2| now return. end.
 end.
}}

Today=: {{
 NB. Today with y days offset
 now=. 3{. 6!:0 ''
 if. 0-: y do. now
 else. todate y+ todayno now end.
}}
