Tools=: Tools, {{)n
   Code '~Jay/tools/debug'    NB. Save Cr ]debug
}}

NB. 13 : {{)nLF2,~ y, '=: ', (5!:5) <y}}
Save=: {{
 y=. (y,~ '_'#~ 0~: #y), ;{.EXTS_pj_
 y=. '~Jay/temp/Saved' timeStamp_pj_ y
 x=. (;:'x y')-.~ ((4!:1) }.i.4), (4!:1) 0
 y File~ ; a: Save &.> x
 0 0$ FILES_pj_=: FILES_pj_ (VERBS_pj_ i.<'Save')}~ <y
:
 if. 0= 4!:0 <y do.if. 2= 3!:0 x=. ".y do.if. 1= #$x do.
  (LF,'}}',LF2),~ (y,'=: }:{{)n',LF),x Replace(LF,'}}');LF,' }}' return.
 end.end.end.
 ((10 10{a.),~],'=: ',[:5!:5<) y
}}

Cr=: {{
 NB. Displays lines with line numbers used during debugging
 mon=. y Cr~ <1 [dia=. y Cr~ <2 [y=. ,y
 cr=. y, (>{:mon), (,':'), >{:dia
 ln=. 'p<[>q<] >0'8!:2 ,.(>{.mon), _, >{.dia
 ln=. ' ', ln (<0;~ #>{.mon)}~ ' '
 ln,. cr
:
 cr=. md (5!:7) <y [md=. >x
 if. 0= #cr do. (i.0); 0 0$ '' return. end.
 line=. {:&> 1{"1 cr
 lines=. i.>:{:line
 lines=. lines#~ lines e. line
 cr=. ' ' Join~ (lines =/line)#"1 [2{"1 cr
 if. md~: x do. lines; cr
 else. (y, cr),.~ (3": md), 'p<[>q<] >0' (8!:2) ,.lines end.
}}

debug=: {{
 Include '~Jay/tools/debugs'
 u debug_plj_
}}
