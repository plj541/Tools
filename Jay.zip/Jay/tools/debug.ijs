help=: {{)n
 Save ''    NB. Save globals in an active session
 Cr ''      NB. With [line numbers], helpfull for Stop and Trace
 ]debug     NB. Load before debugging something on Android
 Local ''   NB. I cannot remember what this is for
}}

cocurrent 'plj'  NB.  Load brings this into _plj_

NB. 13 : {{)nLF2,~ y, '=: ', (5!:5) <y}}
Save=: {{
 y=. (y,~ '_'#~ 0~: #y), ;{.EXTS_pj_
 y=. '~Jay/temp/Saved' timeStamp_pj_ y
 x=. (;:'x y')-.~ ((4!:1) }.i.4), (4!:1) 0
 y File~ ; a: Save &.> x
 0 0$ FILES_pj_=: FILES_pj_ (VERBS_pj_ i.<'Save')}~ <y
:
 if. 0= 4!:0 <y do.if. 2= 3!:0 x=. ".y do.if. 1= #$x do.
  (LF,'}}',LF2),~ (y,'=: }:{{)n',LF),x Replace(LF,'}}');LF,' }}' return.
 end.end.end.
 ((10 10{a.),~],'=: ',[:5!:5<) y
}}

Cr=: {{
 NB. Displays lines with line numbers used during debugging
 mon=. y Cr~ <1 [dia=. y Cr~ <2 [y=. ,y
 cr=. y, (>{:mon), (,':'), >{:dia
 ln=. 'p<[>q<] >0'8!:2 ,.(>{.mon), _, >{.dia
 ln=. ' ', ln (<0;~ #>{.mon)}~ ' '
 ln,. cr
:
 cr=. md (5!:7) <y [md=. >x
 if. 0= #cr do. (i.0); 0 0$ '' return. end.
 line=. {:&> 1{"1 cr
 lines=. i.>:{:line
 lines=. lines#~ lines e. line
 cr=. ' ' Join~ (lines =/line)#"1 [2{"1 cr
 if. md~: x do. lines; cr
 else. (y, cr),.~ (3": md), 'p<[>q<] >0' (8!:2) ,.lines end.
}}

debug=: {{
 if. '".'-: 5!:5 <'u' do.  NB.  Debugging
  if. '*'e. {."1 [13!:18 '' do. Say 13!:12 ''
  else. 13!:0 [0 return. end.
  while. '*'e. {."1 [13!:18 '' do. 9!:29 [1 [9!:27 '". debug'
   try. select. ;2{. part_pj_=: ;:line_pj_=: Ask 'Enter debug request'
    case. ']debug'  do.
    case. ']help'   do. Say HELP_pj_
    case. ']alert'  do. Say 13!:12 ''
    case. ']stack'  do. Say 2}. _2}. 13!:18 ''
    case. ']locals' do. Say locals_pj_ }.13!:13 ''
    case. ']resume' do. 13!:4 '' return.
    case. ']next'   do. 13!:5 '' return.
    case. ']return' do. 13!:6 [u. ]arg_pj_ return.
    case. ']stop'   do. 13!:3 [arg_pj_
    case. ']stops'  do. Say 13!:2 ''
    case. ']quit'   do. 13!:0 [0 [9!:29 [0 return.
    case. do.
     if. #part_pj_ do. resp_pj_=: u. line_pj_
      if. #resp_pj_ do. Say resp_pj_
      elseif. _1 e. 4!:0 part_pj_ do. 0!:101 line_pj_
      else. Say '' end.
     end.
    end.  
   catch. Say 13!:12 '' end.
  end.
  ''
 else.
  if. -.13!:17 '' do. 13!:0 [1 end. NB. Suspend on an error, if not already set
  9!:29 [1 [9!:27 '". debug'
 end.
}}

Local=: {{
 NB. Run u with local definition y on stack
 '' u Local y
:
 find=. {{if. (#y)~: in=. ({."1 y)i. <m do. ;x{ in{ y else. '' end.}} 
 stk=. 13!:13 ''
 if. ''-: name=. 4 y find stk do. name=. 1 y find ;7{ 1{stk end.
 if. ''-: name do. 'Name not found' return. end.
 cocurrent PS [Do~ (y, '__PS=: '), name
 if. x-: '' do. u y
 else. x u y end.
}}

HELP_pj_=: }:{{)n
 ]help    NB. This list of commands
 ]alert   NB. The most recent message from an error or stop
 ]stack   NB. The execution stack
 ]locals  NB. Locals at each level of the execution stack
 ]resume  NB. Resume the current line
 ]next    NB. Restart on the next line
 ]return  NB. Return the value provided, e.g.  ]return 541
 ]stop    NB. Set lines to stop on, e.g.  ]stop fun 3:2
 ]stops   NB. Reports current stops
 ]quit    NB. Turn off debugging
 NB. Anything else is evaluated, including assignments to your locals
}}

flag_pj_=: {{
 if. _-: m do. 9!:29 [1 [9!:27 '". debug' end.
}}

arg_pj_=: {{)a
 cmd=. ;1{ part_pj_
 line_pj_}.~ (#cmd)+ {.cmd I.@E. line_pj_
}}

locals_pj_=: {{
 now=. <"_1 (2 2$ 0 3 7 8{ ])"1 y
 {{b (<a:;'|'I.@:= {. b=. 1 1}. _1 _1}. ":y)}~' '}} now
}}

cocurrent 'base'
