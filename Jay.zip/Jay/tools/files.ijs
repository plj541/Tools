Tools=: Tools, {{)n
   Code '~Jay/tools/files'    NB. Dir Dirs File Files Lines Edit Page
}}

Dir=: {{
 NB. Formatted dir
 if. 0~: #dir=. '' Dir y do.
  time=. 'q[-]5.0,r[0]q[-]3.0,r[0]q[  ]4.0,r[0]q[:]3.0,r[0]2.0' Fmt 0 _1}. >1{"1 dir
  size=. 'p[ ]q[  ]13.0' Fmt ,.>2{"1 dir
  name=. >0{"1 dir
  dir=. 'd'= 4({ >)"0 [4{"1 dir
  size=. ' ' (I. dir)} size
  (time,. size,. name)/: (1": -.dir),. Keys name
 end.
:
 NB. Boxed dir
 star=. '*'
 if. ''-.@-: y do.if. 1= #dir=. 1!:0 y=. 1 path_pj_ y do.
  if. 'd' e. >dir{~ <0 4 do. star=. '/*' end.
 end.end.
 1!:0 y, star, x
}}

Dirs=: {{
 NB. Just directory names, with path if y ends with /
 (/:Keys) now=. x 1 filesDirs_pj_ y
}}

Paths=: _ {{)a
NB. Start of creating Paths for Windows or Linux
if. UNAME-: 'Win' do.

{{
 NB. Dirs and Files (Just for Windows)
 dirs=. ,< y=. '/' After y
 now=. '' 1 filesDirs_pj_ y
 while. #now do.
  dirs=. dirs, now
  now=. ;a: 1 filesDirs_pj_&.> now
 end.
 (/:Keys) dirs
:
 if. 0= L. y do. y=. Paths y end.
 select. x
 case. 'D' do. {."1 y  NB. Just the Dirs
 case. 'P' do. ;a: Files&.> y  NB. Just the files with full path
 case. 'F' do.
  if. 1~: #$y do. 'Just one element for F' Signal 25
  else. '' Files >y end.
 case. do. 'D for dirs, F for files or P for files with paths' Signal 25 end.
}}

else. NB. The version above is pure J, but is substantially slower

{{
 NB. Dirs and Files direct from host (Not for Windows)
 if. -.'/~'e.~ {.y do. y=. y,~ '/',~ 1!:43 '' end.
 paths=. }: 2!:0 'ls -p -R ', path_pj_ y
 paths=. paths Split LF2
 paths=. (paths ,&.> LF) Split&> <':', LF
 paths /:Keys {."1 paths
:
 if. 0= L. y do. y=. Paths y end.
 select. x
 case. 'D' do. {."1 y  NB. Just the Dirs
 case. 'P' do.  NB. Just the Files with full path
  files=. y #~ 0~:([:# [:>{:)"1 y NB. No empties: {{#>{:y}}
  NB. Join path/files: {{<(<'/',~ >{.y) ,&.> (/:Keys)<;._2 >{:y}}
  files=. ;([:<([:<'/',~ [:>{.) ,&.> [:(/:Keys) [:<;._2 [:>{:)"1 files
  files#~ files (]~: [:{:[) &> <'/'  NB. No paths: {{y~: {:x}}
 case. 'F' do. NB. Just the Files without path
  if. 1~: #$y do. 'Just one element for F' Signal 25
  else. files#~ files (]~: [:{:[) &> <'/' [files=. (/:Keys)<;._2 >{: y end.
 case. do. 'D for dirs, F for files or P for files with paths' Signal 25 end.
}}

end. NB. End of creating Paths for Windows or Linux
}}

File=: {{
 NB. Read a file
 now=. 1!:1 <path_pj_ y
 if. (239 187 191{ a.)-: 3{. now do.
  now=. 3}. now
 end.
:
 NB. Write a file
 y [x 1!:2 <path_pj_ y
}}

Files=: {{
 NB. Just file names, with path if y ends with /
 (/:Keys) x 0 filesDirs_pj_ y
}}

LastVersion=: {{
 NB. Name of last file version, using download version naming
 'path name extn'=. pathNameExtn_pj_ y 
 if. #file=. (')', extn) Files path, name, ' ('
  do. path, ;{:file
 elseif. #'' Files y do. y
 else. ,:'No version of ', y end.
:
 NB. Name of the next version
 if. 2= #$x=. LastVersion y do. y return. end.
 'path name extn'=. pathNameExtn_pj_ x
 if. ')'= {:name do.
  now=. ":>:".prev=. name}.~ name i:'('
  path, extn,~ (name}.~ -<:#prev), now, ')'
 else. path, name, ' (1)', extn end.
}}

Lines=: {{
 NB. Make y a character vector so it can be written to a file
 9!:7 ascii=. 11{. 16}. a. [was=.9!:6 ''
 ascii=. <"0 ascii [display=. <"1 [11 3$ '┌┬┐├┼┤└┴┘│─'
 now=. (displayUnboxed_pj_ y) Replace ForEach _ ascii,. display
 now [9!:7 was
}}

displayUnboxed_pj_=: {{
 NB.  Convert a multidimension array into a character vector
 y=. ": y
 if. 0< r=. _1+ #$ y do. y=. (-r)}. LF displayUnboxed ^: r y
 else. ,y end.  NB. {{,"2 y,"1 x}}
}} : ([:,"2 ,"1~)

Edit=: {{
 NB. Edit a file with any extension
 'Edit' editFile_pj_ y
}}

Page=: {{
 NB. Fetch a web page as text
 File ;{: httpget_jpacman_ y
}}

NB. Support for files

filesDirs_pj_=: {{
 NB. u= 0 Files or 1 Dirs, with path if y ends with /
:
 if. 0= #names=. x Dir y do. '' return. end.
 names=. {."1 names#~ 'd' (~:`= @. u) 4{"1 > 4{"1 names
 if. '/'= {:y do. names=. (<y) ,&.> names 
  if. u do. names ,&.> '/' end.
 end. 
}}
