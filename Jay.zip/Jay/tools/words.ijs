Tools=: Tools, {{)n
   Code '~Jay/tools/words'    NB. Rank_1 Diff Words
}}

NB. Works on first dimension, with u getting rank 1 arguments
Rank_1=: {{u"1 &. |:}}

Diff=: {{
 NB. Usage: x [m] Diff n y
 m '' Diff n y
:
 n=. 2$ n  NB. n should be ⎕IO for x and y, 1 for external editors, 0 for J nouns
 x=. boxedLines_pj_ x [y=. boxedLines_pj_ y
 if. x-: y do. 'They are identical' return. end.
 if. m-: '' do. m=. ',Old lines,New lines' end.
 label=. ' ↑ ', old, ' --   -- ↓ ', new, LF ['old new'=. <;._1 m
 label=. label,~ '-'#~ #":#x ['old new'=. n
 (x old diffLines_pj_ y), label, y new diffLines_pj_ x
}}

boxedLines_pj_=: {{
 NB. Provide boxed lines from one of three possible formats
 if. L. y do. y                  NB. Already boxed lines
 elseif. LF e. y do. y Split LF  NB. Contains LF's
 else. LF Split~ File y end.     NB. A file name
}}

NB. diffLines will report lines which are new or removed
NB. It will not notice issues when common lines are new or removed
NB. It will also not notice incorrect line order
NB. With all of these caveats, it's surprisingly useful with code changes
diffLines_pj_=: {{
 NB. Display lines which are missing in the other version, m is ⎕IO
:
 'No lines are missing', LF  NB. Which lines in x are missing in y
 if. 0~: #gone=. (i=. z= #y)# x [z=.y i. x do.
  ;(<"1 ' | ',"1~ ":,. m+ I. i),. gone,. <LF
 end. 
}}
 
Words=: {{
 NB. Usefull for English, APL, HTML and JavaScript
 NB. Each word in plain text is boxed
 NB. A comment or quote is in one box
 NB. Each unicode character in plain text is boxed
 NB. Quotes contain control characters including LF
 (0; sj_pj_; mj_pj_) ;: y
:
 NB. x indicates features to turn off
 x=. ,x [mj=. mj_pj_ [sj=. sj_pj_
 mj=. mj (a.i. x#~ x e. ':''"`')}~ 0
 mj=. mj (a.i. x#~ x e. 'NB')}~ 2
 if. '.' e. x do. sj=. sj (<1 2; 6; 0 1)}~1 2 end.
 (0; sj; mj) ;: y
}}

NB. Define column for each character grouping
mj=. 256$00                         NB. X other
mj=.  1 (9, a.&i. ' ')} mj          NB. S space and tab
mj=.  2 (,(a.&i. 'Aa')+/ i.26)} mj  NB. A A-Z a-z excluding N B
mj=.  3 4 (a.&i. 'NB')} mj          NB. N the letter N then B
mj=.  5 (a.&i. '0123456789_')} mj   NB. 9 digits and _
mj=.  6 (a.&i. '.')} mj             NB. . period and decimal point
mj=.  7 (a.&i. ':')} mj             NB. : the colon
mj=.  8 (a.&i. '''')} mj            NB. ' quote
mj=.  9 (a.&i. '{')} mj             NB. { the left curly brace
mj=. 10 (10)} mj                    NB. LF
mj=. 11 (a.&i. '}')} mj             NB. } the right curly brace
mj=. 12 (192+ i. 64)} mj            NB. U utf-8 octet prefix
mj=. 13 (128+ i. 64)} mj            NB. V utf-8 octet suffix
mj=. 14 15 (a.&i. '"`')} mj         NB. other " quotes `
mj_pj_=: mj

NB. Define row for each state with transition based on column of next character
sj_pj_=: +.}. ".;._2 {{)n
' X    S    A    N    B    9    .    :    Q    {    LF   }    U    V    "   `   ']0
 1j1  0j0  2j1  3j1  2j1  6j1  1j1  1j1  7j1 11j1 10j1 12j1 19j1 19j1 17j1 15j1 NB.  0 space
 1j2  0j3  2j2  3j2  2j2  6j2  1j0  1j0  7j2 11j2 10j2 12j2 19j2 19j2 17j2 15j2 NB.  1 other
 1j2  0j3  2j0  2j0  2j0  2j0  1j0  1j0  7j2 11j2 10j2 12j2 19j2 19j2 17j2 15j2 NB.  2 alp/num
 1j2  0j3  2j0  2j0  4j0  2j0  1j0  1j0  7j2 11j2 10j2 12j2 19j2 19j2 17j2 15j2 NB.  3 N
 1j2  0j3  2j0  2j0  2j0  2j0  5j0  1j0  7j2 11j2 10j2 12j2 19j2 19j2 17j2 15j2 NB.  4 NB
 9j0  9j0  9j0  9j0  9j0  9j0  1j0  1j0  9j0  9j0 10j2  9j0  9j0  9j0  9j0  9j0 NB.  5 NB.
 1j4  0j5  6j0  6j0  6j0  6j0  6j0  1j0  7j4 11j4 10j2 12j4 19j2 19j2 17j4 15j2 NB.  6 num
 7j0  7j0  7j0  7j0  7j0  7j0  7j0  7j0  8j0  7j0  7j0  7j0  7j0  7j0  7j0  7j0 NB.  7 '
 1j2  0j3  2j2  3j2  2j2  6j2  1j2  1j2  7j0 11j2 10j2 12j2 19j2 19j2 17j2 15j2 NB.  8 ''
 9j0  9j0  9j0  9j0  9j0  9j0  9j0  9j0  9j0  9j0 10j2  9j0  9j0  9j0  9j0  9j0 NB.  9 comment
 1j2  0j2  2j2  3j2  2j2  6j2  1j2  1j2  7j2 11j2 10j2 12j2 19j2 19j2 17j2 15j2 NB. 10 LF
 1j2  0j3  2j2  3j2  2j2  6j2  1j0  1j0  7j2 13j0 10j2  1j2 19j2 19j2 17j2 15j2 NB. 11 {
 1j2  0j3  2j2  3j2  2j2  6j2  1j0  1j0  7j2  1j2 10j2 14j0 19j2 19j2 17j2 15j2 NB. 12 }
 1j2  0j3  2j2  3j2  2j2  6j2  1j7  1j7  7j2  1j2 10j2  1j2 19j2 19j2 17j2 15j2 NB. 13 {{
 1j2  0j3  2j2  3j2  2j2  6j2  1j7  1j7  7j2  1j2 10j2  1j2 19j2 19j2 17j2 15j2 NB. 14 }}
15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 15j0 16j0 NB. 15 `
 1j2  0j3  2j2  3j2  2j2  6j2  1j2  1j2 16j0 11j2 10j2 12j2 15j2 19j2 17j2 16j0 NB. 16 ``
17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 17j0 18j0 17j0 NB. 17 "
 1j2  0j3  2j2  3j2  2j2  6j2  1j2  1j2 17j0 11j2 10j2 12j2 15j2 19j2 17j0 15j2 NB. 18 ""
 1j2  0j3  2j2  3j2  2j2  6j2  1j2  1j2  7j2 11j2 10j2 12j2 19j2 19j0 17j2 15j2 NB. 19 utf-8 
}}
