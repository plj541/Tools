Tools=: Tools, {{)n
   Code '~Jay/tools/words'    NB. Rank_1 Diff Words
}}

NB. Works on first dimension, with u getting rank 1 arguments
Rank_1=: {{u"1 &. |:}}

Diff=: {{
 NB. Usage: x [m] Diff n y
 m '' Diff n y
:
 n=. 2$ n  NB. n should be ⎕IO for x and y, 1 for external editors, 0 for J nouns
 x=. boxedLines_pj_ x [y=. boxedLines_pj_ y
 if. x-: y do. 'They are identical' return. end.
 if. m-: '' do. m=. ',Old lines,New lines' end.
 label=. ' ↑ ', old, ' --   -- ↓ ', new, LF ['old new'=. <;._1 m
 label=. label,~ '-'#~ #":#x ['old new'=. n
 (x old diffLines_pj_ y), label, y new diffLines_pj_ x
}}

boxedLines_pj_=: {{
 NB. Provide boxed lines from one of three possible formats
 if. L. y do. y                  NB. Already boxed lines
 elseif. LF e. y do. y Split LF  NB. Contains LF's
 else. LF Split~ File y end.     NB. A file name
}}

NB. diffLines will report lines which are new or removed
NB. It will not notice issues when common lines are new or removed
NB. It will also not notice incorrect line order
NB. With all of these caveats, it's surprisingly useful with code changes
diffLines_pj_=: {{
 NB. Display lines which are missing in the other version, m is ⎕IO
:
 'No lines are missing', LF  NB. Which lines in x are missing in y
 if. 0~: #gone=. (i=. z= #y)# x [z=.y i. x do.
  ;(<"1 ' | ',"1~ ":,. m+ I. i),. gone,. <LF
 end. 
}}
 
Words=: {{
 NB. Usefull with understanding APL, HTML and JavaScript
 NB. LF is part of quotes, whether beginning with ' or "
 NB. Unicode characters outside quotes are words
 (0; (7 0 (<7; 10; 0 1)} sj_pj_); mj_pj_) ;: y
:
 NB. Useful with PathFind
 x=. ,x [mj=. mj_pj_ [sj=. sj_pj_
 NB. Turn off characters in x which hide non-J words
 if. +./'NB'E. x do. mj=. mj (a.i.'NB')}~ 2 end.   NB. NB makes them just part of user names
 if. '.'e. x do. sj=. sj (<1 2; 6; 0 1)}~1 2 end.  NB. . removed from #. and i. but not 12.3
 if. #x=. x {{y#~ y e. x}} ':''"`' do. mj=. mj (a.i. x)}~ 0 end.  NB. Any of : ' " can be removed
 (0; sj; mj) ;: y
}}

mj=. 256$0                      NB. X other
mj=.  1 (9,a.i.' ')}mj          NB. S space and tab
mj=.  2 (,(a.i.'Aa')+/i.26)}mj  NB. A A-Z a-z excluding N B
mj=.  3 (a.i.'N')}mj            NB. N the letter N
mj=.  4 (a.i.'B')}mj            NB. B the letter B
mj=.  5 (a.i.'0123456789_')}mj  NB. 9 digits and _
mj=.  6 (a.i.'.')}mj            NB. . the decimal point
mj=.  7 (a.i.':')}mj            NB. : the colon
mj=.  8 (a.i.'''')}mj           NB. ' quote
mj=.  9 (a.i.'{')}mj            NB. { the left curly brace
mj=. 10 (10)} mj                NB. LF
mj=. 11 (a.i.'}')}mj            NB. } the right curly brace
mj=. 12 (192+i.64)}mj           NB. U utf-8 octet prefix
mj=. 13 (128+i.64)}mj           NB. V utf-8 octet suffix
mj=. 14 (a.i.'"')}mj            NB. " quote
mj=. 15 (a.i.'`')}mj            NB. ` quote
mj_pj_=: mj

sj_pj_=: 0 10#:10*}.".;._2 {{)n
' X    S    A    N    B    9    .    :    Q    {    LF   }    U    V    "   `   ']0
 1.1  0.0  2.1  3.1  2.1  6.1  1.1  1.1  7.1 11.1 10.1 12.1 15.1 16.1 17.1 19.1 NB.  0 space
 1.2  0.3  2.2  3.2  2.2  6.2  1.0  1.0  7.2 11.2 10.2 12.2 15.2 16.2 17.2 19.2 NB.  1 other
 1.2  0.3  2.0  2.0  2.0  2.0  1.0  1.0  7.2 11.2 10.2 12.2 15.2 16.2 17.2 19.2 NB.  2 alp/num
 1.2  0.3  2.0  2.0  4.0  2.0  1.0  1.0  7.2 11.2 10.2 12.2 15.2 16.2 17.2 19.2 NB.  3 N
 1.2  0.3  2.0  2.0  2.0  2.0  5.0  1.0  7.2 11.2 10.2 12.2 15.2 16.2 17.2 19.2 NB.  4 NB
 9.0  9.0  9.0  9.0  9.0  9.0  1.0  1.0  9.0  9.0 10.2  9.0  9.0  9.0  9.0  9.0 NB.  5 NB.
 1.4  0.5  6.0  6.0  6.0  6.0  6.0  1.0  7.4 11.4 10.2 12.4 15.2 16.2 17.4 19.2 NB.  6 num
 7.0  7.0  7.0  7.0  7.0  7.0  7.0  7.0  8.0  7.0 10.2  7.0  7.0  7.0  7.0  7.0 NB.  7 '
 1.2  0.3  2.2  3.2  2.2  6.2  1.2  1.2  7.0 11.2 10.2 12.2 15.2 16.2 17.2 19.2 NB.  8 ''
 9.0  9.0  9.0  9.0  9.0  9.0  9.0  9.0  9.0  9.0 10.2  9.0  9.0  9.0  9.0  9.0 NB.  9 comment
 1.2  0.2  2.2  3.2  2.2  6.2  1.2  1.2  7.2 11.2 10.2 12.2 15.2 16.2 17.2 19.2 NB. 10 LF
 1.2  0.3  2.2  3.2  2.2  6.2  1.0  1.0  7.2 13.0 10.2  1.2 15.2 16.2 17.2 19.2 NB. 11 {
 1.2  0.3  2.2  3.2  2.2  6.2  1.0  1.0  7.2  1.2 10.2 14.0 15.2 16.2 17.2 19.2 NB. 12 }
 1.2  0.3  2.2  3.2  2.2  6.2  1.7  1.7  7.2  1.2 10.2  1.2 15.2 16.2 17.2 19.2 NB. 13 {{
 1.2  0.3  2.2  3.2  2.2  6.2  1.7  1.7  7.2  1.2 10.2  1.2 15.2 16.2 17.2 19.2 NB. 14 }}
 1.2  0.3  2.2  3.2  2.2  6.2  1.0  1.0  7.2 11.2 10.2 12.2 15.2 16.0 17.2 19.2 NB. 15 partial
 1.2  0.3  2.2  3.2  2.2  6.2  1.0  1.0  7.2 11.2 10.2 12.2 15.2 16.0 17.2 19.2 NB. 16 utf-8
17.0 17.0 17.0 17.0 17.0 17.0 17.0 17.0 17.0 17.0 10.2 17.0 17.0 17.0 18.0 17.0 NB. 17 "
 1.2  0.3  2.2  3.2  2.2  6.2  1.2  1.2 17.0 11.2 10.2 12.2 15.2 16.2 17.0 19.2 NB. 18 ""
19.0 19.0 19.0 19.0 19.0 19.0 19.0 19.0 19.0 19.0 10.2 19.0 19.0 17.2 19.0 20.0 NB. 19 `
 1.2  0.3  2.2  3.2  2.2  6.2  1.2  1.2 19.0 11.2 10.2 12.2 15.2 16.2 17.2 19.0 NB. 20 ``
}}
