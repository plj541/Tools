{{ if. APILEVEL_ja_> 29 do.

NB. From Android 11 "am start" is not supported in apps
launch_pj_=: {{
 NB. Send file name to DroidScript Launch
 wd 'clipcopy *', y [was=. wd 'clippaste'
 Say 'Start the Launch app!'
 while. -.':*?'-: wd 'clippaste' do. (6!:3) 2 end.
 0 0$Say y [wd 'clipcopy *', was
}}

xedit_j_=: launch_pj_
browse_j_=: launch_pj_

 '' end.
}} _
