Tools=: Tools, {{)n
 Code 'tools/strings'  NB. After Split Join Replace ForEach
                       NB. Trim TrimStart TrimEnd StartsWith EndsWith
}}

NB. Insure a trailing value
After=: (13 :'y, x#~ x~: {:y')"1

Split=: {{
 NB. Split x into boxes at each y
 if. ''-: x do. 0#a: return. end.
 if. ''-: y do. <@,"0 x return. end.
 if. 1= #y do.
  <;._2 x, y
 else.
  if. #now=. x noOverlap_pj_ y do.
   (x{.~ {.now); (#y)}. &.> now indexCut_pj_ x
  else.
   ,<,x
  end.
 end.
}}"1

NB. Put y between each box of x
Join=: (13 :';}.,x,.~ <y')"1

NB. White space for HTML and XML
WS=: 32 13 10 9{ a.

NB. Trim characters at the start
TrimStart=: (13 :'x#~ -. *./\ x e. y')"1

NB. Trim characters at the end
TrimEnd=: (13 :'x#~ -. *./\. x e. y')"1

NB. Trim characters at the start and end
Trim=: (TrimStart TrimEnd])f.

NB. Does x start with y
StartsWith=: (13 :'(,y)-: x{.~ x <.&# y')"1

NB. Does x end with y
EndsWith=: (13 :'(,y)-: x{.~ -(#x)<. #y')"1

Replace=: {{
 NB.    Usage: text Replace old; new
 NB. Multiple: text Replace ForEach 2 ;:'this that now then'
 'old new'=. y
 if. 1 1-: #&> y do. x (x I.@:= {.old)}~ {.new
 else. new Join~ x Split old end.
}}"1

ForEach=: {{
 NB. Usage: left verb ForEach eachSize multipleEachSizeArgs
 y=. |., <"1 (-n) ]\ y
 >u~ &.>/ y, <x
}}

NB. Support for strings

indexCut_pj_=: {{
 NB. Cut with x as indexes instead booleans
 y <;.1~ 1 x} 0#~ #y
}}

noOverlap_pj_=: {{
 NB. Find non-overlapping indexes of y in x
 NB. See nosindx: https://code.jsoftware.com/wiki/Essays/Substring_Replacement
 if. ''-: y do. i.0 return. end.
 now=. y I.@E. x
 if. -.({.e.}.) y do. now return. end.
 all=. now I. now+ #y
 NB.         Avoid error with _1 as 23rd element and last
 (i.&_1{.]) (now, _1){~ (all, _1 _1){~ ^:a: 0
}}
