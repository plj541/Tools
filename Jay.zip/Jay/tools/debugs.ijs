debug=: {{
 if. '".'-: 5!:5 <'u' do.  NB.  Debugging
  if. '*'e. {."1 [13!:18 '' do. Say 13!:12 ''
  else. 13!:0 [0 return. end.
  while. '*'e. {."1 [13!:18 '' do. 9!:29 [1 [9!:27 '". debug'
   try. select. ;2{. part_pj_=: ;:line_pj_=: Ask 'Enter debug request'
    case. ']debug'  do.
    case. ']help'   do. Say HELP_pj_
    case. ']alert'  do. Say 13!:12 ''
    case. ']stack'  do. Say 2}. _2}. 13!:18 ''
    case. ']locals' do. Say locals_pj_ }.13!:13 ''
    case. ']resume' do. 13!:4 '' return.
    case. ']next'   do. 13!:5 '' return.
    case. ']return' do. 13!:6 [u. ]arg_pj_ return.
    case. ']stop'   do. 13!:3 [arg_pj_
    case. ']stops'  do. Say 13!:2 ''
    case. ']quit'   do. 13!:0 [0 [9!:29 [0 return.
    case. do.
     if. #part_pj_ do. resp_pj_=: u. line_pj_
      if. #resp_pj_ do. Say resp_pj_
      elseif. _1 e. 4!:0 part_pj_ do. 0!:101 line_pj_
      else. Say '' end.
     end.
    end.  
   catch. Say 13!:12 '' end.
  end.
  ''
 else.
  if. -.13!:17 '' do. 13!:0 [1 end. NB. Suspend on an error, if not already set
  9!:29 [1 [9!:27 '". debug'
 end.
}}

Local=: {{
 NB. Run u with local definition y on stack
 '' u Local y
:
 find=. {{if. (#y)~: in=. ({."1 y)i. <m do. ;x{ in{ y else. '' end.}} 
 stk=. 13!:13 ''
 if. ''-: name=. 4 y find stk do. name=. 1 y find ;7{ 1{stk end.
 if. ''-: name do. 'Name not found' return. end.
 cocurrent PS [Do~ (y, '__PS=: '), name
 if. x-: '' do. u y
 else. x u y end.
}}

HELP_pj_=: }:{{)n
 ]help    NB. This list of commands
 ]alert   NB. The most recent message from an error or stop
 ]stack   NB. The execution stack
 ]locals  NB. Locals at each level of the execution stack
 ]resume  NB. Resume the current line
 ]next    NB. Restart on the next line
 ]return  NB. Return the value provided, e.g.  ]return 541
 ]stop    NB. Set lines to stop on, e.g.  ]stop fun 3:2
 ]stops   NB. Reports current stops
 ]quit    NB. Turn off debugging
 NB. Anything else is evaluated, including assignments to your locals
}}

flag_pj_=: {{
 if. _-: m do. 9!:29 [1 [9!:27 '". debug' end.
}}

arg_pj_=: {{)a
 cmd=. ;1{ part_pj_
 line_pj_}.~ (#cmd)+ {.cmd I.@E. line_pj_
}}

locals_pj_=: {{
 now=. <"_1 (2 2$ 0 3 7 8{ ])"1 y
 {{b (<a:;'|'I.@:= {. b=. 1 1}. _1 _1}. ":y)}~' '}} now
}}
