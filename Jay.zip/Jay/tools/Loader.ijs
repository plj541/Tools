NB. Add plj to existing search path for locale base'
 (<~. 'plj'; (18!:2) <'base') (18!:2)&> <"0 ;:'base pj'
 Tools=: '' [cocurrent 'plj'  NB. Switch to locale plj
 
NB. These verbs assume their file extension
 load '~Jay/tools/libs.ijs'
NB. These verbs require their file extension
 load '~Jay/tools/files.ijs'

NB. These verbs display and modify the active session
 load '~Jay/tools/names.ijs'
 load '~Jay/tools/output.ijs'
 load '~Jay/tools/html.ijs'
 
NB. These help create and find code
 load '~Jay/tools/session.ijs'
 load '~Jay/tools/words.ijs'
 load '~Jay/tools/csv.ijs'

NB. These verbs are commonly available in other languages
 load '~Jay/tools/strings.ijs'
 
NB. These are nouns which provide values for public verbs
 load '~Jay/tools/config.ijs'
NB. End of Tools
