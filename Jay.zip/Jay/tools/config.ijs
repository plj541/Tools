Tools=: Tools, {{)n
 Code 'tools/config'   NB. Nouns have settings for some Verbs
}}

NB. Given a verb name, which file extension is assumed and remembered
NB.             0    1    2    3    4    5    6
VERBS_pj_=: ;: 'Save Load Run  Copy Code Edit View'
EXTS_pj_=: (<;._1 '|.ijs|.ijs|.ijs|.ijs|.ijs||'){.~ >:#VERBS_pj_
FILES_pj_=: (#EXTS_pj_)$ <''
{{ NB. enable   verb Last Save
 if. 1= L. last=. {:/:~ '.ijs' Files '~Jay/temp/Saved_' do.
  last=. '~Jay/temp/', ;last
  FILES_pj_=: FILES_pj_ (VERBS_pj_ i.<'Save')}~ <last
 end.
}} _

timeStamp_pj_=: {{
 NB. Time stamps make file names unique
 x, y,~ (6!:0) '_YYMMDD_hhmmss_sss' [(6!:3) 0.001
}}

NB. Initial file name for Tag
DISPLAY_pj_=: '~Jay/temp/Display' timeStamp_pj_ '.html'
NB. Proper .html output calls  Head ''  first!

WIDTH_pj_=: {.wcsize ''  NB. Initial output width
PS=: New ''  NB. A locale to pass items across Load, or locals between verbs

Help=: {{)n
 Load '~Jay/PathDiff'  NB. Find different between paths x and y
 Load '~Jay/PathFind'  NB. Find files in path x containing y
}}

cocurrent'base'