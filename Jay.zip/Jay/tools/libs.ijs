Tools=: Tools, {{)n
   Code '~Jay/tools/libs'     NB. Lib Load Run Copy Include Code Note Notes
}}

Lib=: {{
 NB. Names of Code files
 Across 'Load' libFiles_pj_ y
}}

Load=: {{
 NB. Load an app into a Clear locale
 if. 'Load' stack_pj_ '' do. return. end.
 try.
  if. ''-: file=. 'Load' fileName_pj_ y do. 'No file name in use' return. end.
  if. fexist_z_ full=. path_pj_ file do. Clear ''
   0!:00 <full ['Load' fileName_pj_ <file
   if. 0= 4!:0 <'help' do. file, LF, help else. file end.
  else.
   '‘', file, '’ does not exist'
  end.
 catch. dberm_z_ ''
 end.
}}

Run=: {{
 NB. Evaluate statements from a file, with display
 'Run' ScriptFile 001 y
:
 NB. Evaluate statements from a file, without display
 if. x-: y do. x=. 000 end.
 'Run' ScriptFile x y
}}

Copy=: {{
 NB. Like Load without Clear
 if. 0 0-: $y=. 'Copy' ScriptFile 000 y do. fileName_pj_ 'Copy'
 else. y end.
}}

Include=: {{
 NB. Like Copy but signals when an error occurrs
 if. 2= #$now=. Copy y do. 25 Signal~ ,now end.
}}

Code=: {{
 NB. Edit a code file
 'Code' editFile_pj_ y
}}

Note=: {{
 NB. Edit a note file
 'Note' editFile_pj_ y
}}

Notes=: {{
 NB. Names of Note files
 Across 'Note' libFiles_pj_ y
}}

NB. Support for libs

stack_pj_=: {{
 0  NB. Remove stack and notify user
 if. '*' e. {."1 [13!:18 '' do.
  1 [0!:11 'dbr 1  NB. Please reissue ', x
 end.
}}

libFiles_pj_=: {{
 NB. Provide File Names with specified extensions
 (-#x)}.&.> y Files~ >EXTS{~ VERBS i. <x
}}

ScriptFile=: {{
 NB. Run a File
 try.
  if. ''-: file=. m fileName_pj_ y do. ,:'No file in use' return. end.
  if. -.fexist_z_ full=. path_pj_ file do. ,:'‘', file, '’ does not exist' return. end.
  m fileName_pj_ <file
  0!:n <full
 catch. dberm_z_ ''
 end.
}}

editFile_pj_=: {{
 NB. Launch an External Editor
 if. ''-: file=. x fileName y do. 'No file in use' return. end.
 if. -.fexist_z_ full=. path file do. '' File full end.
 x fileName <file
 0 0$ xedit_j_ full
}}

fileName_pj_=: {{
 NB. Last file name for verb named y
 >FILES{~ VERBS i. <y
:
 NB. Determine a file name
 file=. >in{ FILES [ext=. >in{ EXTS [in=. VERBS i. <x
 if. L. y do. 0 0$ FILES=: FILES in}~ y return. NB. Assign file used
 elseif. ''-: y do.
  if. ''-: file do. '' return.
  else. y=. file end.
 end.
 'path name extn'=. pathNameExtn y
 if. extn-: '' do. if. ext-: '' do. 'File extension required' Signal 25 end.
 elseif. ext-: '' do. ext=. extn
 elseif. -.extn-: ext do. 'Requires a different extension' Signal 25 end.
 path, name, ext
}}

pathNameExtn_pj_=: {{
 name=. y}.~ '/'i:~ '/', y
 path=. y}.~ -#name
 extn=. name}.~ dot=. name i: '.'
 if. (name-: '') +. '~'= {.name=. dot{. name do. 'File name required' Signal 25 end.
 path; name; extn
}}

pathOf_pj_=: {{
 NB. Find the full path of y
 now=. '\/' Replace~ 1!:43 ''
 if. 0= #y do. now return. end.
 try. was=. now
  now=. '\/' Replace~ 1!:43 [1!:44 path y
 catch.
 end.
 now [1!:44 was
}}

Path=: path_pj_

path_pj_=: {{
 NB. Resolve leading ~ with jpath folders
 0 path y
:
 if. ':/' +./@E. ,y do. y return. end.
 if. '/'= {.y do. y return. end.
 map=. SystemFolders_j_, UserFolders_j_
 if. -.'~/' e.~ {.y do.
  len=. \:~len [rev=. map\: len=. #&> {:"1 map
  in=. I.(<pre) StartsWith&> {:"1 rev=. rev#~ len<: #pre=. 1!:43 ''
  if. #in do. pre=. '~', til, pre}.~ #one ['til one'=. rev{~ {.in end.
  y=. pre, y,~ '/'#~ 0~: #y
 end.
 if. '~'= {.y do.
  map=. ({:"1 map){~ ({."1 map)i. {.y=. <;._1 '/', }.y
  y=. ;map, '/',&.> }.y
 end.
 if. '/.' EndsWith~ y=. y}.~ -'/'= {:y do. y=. _2}. y end.
 if. y EndsWith '/..' do. y=. '/'Join~ _2}. y Split '/' end.
 if. y +./@e.~ x}. '*?|<>' do. 'Illegal file name' Signal 25 end.
}}
