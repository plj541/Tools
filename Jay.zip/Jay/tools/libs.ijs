Tools=: Tools, {{)n
 Code 'tools/libs'     NB. Code Lib Load Run Copy Include
}}

Lib=: {{
 NB. Names of Code files
 Across 'Load' libFiles_pj_ y
}}

Load=: {{
 NB. Load an app into a Clear locale
 if. 'Load' stack_pj_ '' do. return. end.
 try.
  if. ''-: file=. 'Load' fileName_pj_ y do.
   'No file name in use' return. end.
  if. Fexist full=. 0 Path file do. Clear ''
   (0!:000) <full ['Load' fileName_pj_ <file
   if. 0= (4!:0) <'help' do. file, LF, help else. file end.
  else.
   '‘', file, '’ does not exist'
  end.
 catch. dberm_z_ ''
 end.
}}

Run=: {{
 NB. Evaluate statements from a file, with display
 'Run' Script 001 y
:
 NB. Evaluate statements from a file, without display
 if. x-: y do. x=. 000 end.
 'Run' Script x y
}}

Copy=: {{
 NB. Like Load without Clear
 if. 0 0-: $y=. 'Copy' Script 000 y do. fileName_pj_ 'Copy'
 else. y end.
}}

Include=: {{
 NB. Like Copy but signals when an error occurrs
 if. 2= #$now=. Copy y do. (13!:8&45) ,now end.
}}

Code=: {{
 NB. Edit a code file
 'Code' editFile_pj_ y
}}

NB. Support for libs

stack_pj_=: {{
 0  NB. Remove stack and notify user
 if. '*' e. {."1 (13!:18) '' do.
  Say '   dbr 1  NB. Enter this line and reissue ', x
 end.
}}

libFiles_pj_=: {{
 NB. Provide File Names with specified extensions
 (-#x)}.&.> y Files~ >EXTS{~ VERBS i. <x
}}

Script=: {{
 NB. Run a Script File
 try.
  if. ''-: file=. m fileName_pj_ y do. ,:'No file in use' return. end.
  if. -.Fexist full=. 0 Path file do. ,:'‘', file, '’ does not exist' return. end.
  m fileName_pj_ <file
  (0!:n) <full
 catch. dberm_z_ ''
 end.
}}

editFile_pj_=: {{
 NB. Launch an External Editor
 if. ''-: file=. x fileName y do. 'No file in use' return. end.
 if. -.Fexist full=. 0 Path file do. '' File full end.
 x fileName <file
 0 0$ xedit_j_ full
}}

fileName_pj_=: {{
 NB. Last file name for verb named y
 >FILES{~ VERBS i. <y
:
 NB. Determine a file name
 file=. >in{ FILES [ext=. >in{ EXTS [in=. VERBS i. <x
 if. L. y do. 0 0$ FILES=: FILES in}~ y return. NB. Assign file used
 elseif. ''-: y do.
  if. ''-: file do. '' return.
  else. y=. file end.
 end.
 'path name extn'=. pathNameExtn y
 if. extn-: '' do. if. ext-: '' do. (13!:8&45) 'File extension required' end.
 elseif. ext-: '' do. ext=. extn
 elseif. -.extn-: ext do. (13!:8&45) 'Requires a different extension' end.
 path, name, ext
}}

pathNameExtn_pj_=: {{
 name=. y}.~ '/'i:~ '/', y
 path=. y}.~ -#name
 extn=. name}.~ dot=. name i: '.'
 if. (name-: '') +. '~'= {.name=. dot{. name do. (13!:8&45) 'File name required' end.
 path; name; extn
}}

Path=: (0&$:) : {{
 NB. Provide absolute path to file argument
 if. '://' +./@E. y=. ,y do. y return. end.  NB. It's http
 if. y +./@e.~ x}. '*?|<>' do. (13!:8&45) 'Illegal file name' end.
 if. isFull_pj_ y do. y return. end.
 if. '~'= {.y do.
  map=. SystemFolders_j_, UserFolders_j_
  map=. ({:"1 map){~ ({."1 map)i. {.y=. <;._1 '/', }.y
  ;map, '/',&.> }.y
 else.
  ({{ y (I. y= '\')} ~'/' }} 1!:43 ''), y,~ '/'#~ 0~: #y
 end.
}}

isFull_pj_=: _ {{)a
if. UNAME-: 'Win' do.  NB. Windows full path
 ('c:/'-: (a. (,65 97 +/ i. 26)}~ 'c'){~ a.i. 3{. ])
else.  NB. Non Windows full path
 ('/'= {.)
end.
}}
