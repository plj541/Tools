Tools=: Tools, {{)n
 Code 'tools/csv'      NB. csvLoad csvSave
}}

{{)n
 {.x must be " or '  and  {:x must be , or TAB
 mat=. '",' csvLoad File 'was.csv'  NB. Matrix of boxes from a .csv file
 ('",' csvSave mat) File 'now.csv'  NB. Matrix of boxes into a .csv file
}}

csvLoad=: {{
 NB. To create a nested matrix from a .csv file
 ^csvArg x
 mj=. 10 8 0 (10, a.&i. x)} 256$ 2
 now=. (0; sj_pj_; mj);: LF, LF After y

 badC=. 2# <}.x [fixC=. <({:x), 2# {.x [fixed=. 0
 if. #fix=. badC I.@E. now do. now=. now fix}~ fixC [fixed=. 1 end.
 
 badL=. ({.now), <}.x [fixL=. <LF, 2# {.x
 if. #fix=. badL I.@E. now do. now=. now fix}~ fixL [fixed=. 1 end.
 
 now=. }.now
 if. fixed do. now=. (0; sj_pj_; mj);: ;now end.
 
 now=. now#~ now~: <}.x
 ];._2 now in}~ ([:}.}:)&.> now{~ in=. ({.x) I.@:= {.&>now
}}

csvSave=: {{
 NB. To format a nested matrix into a .csv file
 ^csvArg x
 right=. LF,~ left=. {.x [between=. 3$ x
 ; ([:<left, right,~ between Join~ ])"1 y
}}

csvArg=: {{
 if. 0 e. y e.&> '"'; ',;|', TAB do.
  Say {{)n {.x must be "  and  {:x must be one of , ; | or TAB }} return. end.
}}
