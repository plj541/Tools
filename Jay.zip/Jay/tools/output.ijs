Tools=: Tools, {{)n
   Code '~Jay/tools/output'   NB. View Across Fmt Keys Unbox
}}

Across=: {{
 NB. Place two blanks between items and fold then to WIDTH_pj_
 2 foldBoxes_pj_ y
}}

{{)n Fmt Rules
 NB. If x is numeric, complex numbers create Fmt rules like ":
 NB. J will calculate a proper width where 0= {. +. x
 NB. Here are sample values
 0j0 ": y=. 10 ^ i. 10
1 10 100 1000 10000 100000 1000000 10000000 100000000 1000000000
 NB. To provide a width you should understand how to calculate one
 NB. This result has Whole number digits and Number of ,'s
 1 0+ <. 10 1000 ^./ y
1 2 3 4 5 6 7 8 9 10
0 0 0 1 1 1 2 2 2  3

 NB. add rows together for whole widths
 ]whole=. +/ 1 0+ <. 10 1000 ^./ y
1 2 3 5 6 7 9 10 11 13

 NB. If 0~: fraction=. {: +. x
 ]fraction=. 1+ fraction

 NB. Financial format has two decorators before and after
 decoration=. #' (', ')'

 NB. The minimum width is
 whole + fraction + decoration
}}

Fmt=: {{
 NB. Financial form of numbers
 NB. -    +   -   +  mp Before; nq After; b[zero]; d[nill]; r[fill]
 'm[ (]p[  ]n[)]q[ ]c0.2' Fmt y
:
 if. 0= {.0$ x do.  NB. See Fmt Rules above
  x=. ((a. 32}~'.'){~ a.i. ])&.> <@":"1 +.x
  x=. }: ;(<'m[ (]p[  ]n[)]q[ ]c^,') Replace&.> <"1 x,.~ <'^'
 end.
 x (8!:2) y
}}

NB. These provide keys for dictionary sort
NB. Keys=: {{ ((KSPELL_pj_ {~ a.i.]) y),. (KCASE_pj_ {~ a.i. ]) y=. >y}}
Keys=: {{ ((KSPELL_pj_ {~ a.i. ]),. KCASE_pj_ {~ a.i. ]) y=. >y }}

KSPELL_pj_=: '                                 """""""""""""""##########"""""""abcdefghijklmnopqrstuvwxyz""""""abcdefghijklmnopqrstuvwxyz""""'

KCASE_pj_=: '000000000000000000000000000000000b3pqmv256lkg1ds0123456789efihjcu111111111111111111111111118t7n04000000000000000000000000009oar0'

Unbox=: {{
 NB. Remove boxing characters from result
 if. 32~: (3!:0) y do. 
  if. ' '= {.0($,)y do. >y Split LF
  else. 1 1}. _1 _1}. ": <y end.
 else.
  was=. (9!:6) ''
  (9!:7) [11# rep=. 30{ a.
  (9!:7) was [now=. ": <y
  now=. 1 1}. _1 _1}. now
  rho=. $now=. (-.*./"1 now= rep)# now 
  rho$ ' ' (I. now= rep)} now=. ,now
 end.
}}

View=: {{
 NB. View an html page with a browser
 0 0$ browse_j_ viewRules_pj_ y
}}

viewRules_pj_=: {{
 if. -.isFull {.full=. 0 Path y do. full return. end.
 if. 1< #;{:pathNameExtn full do.
  FILES_pj_=: FILES_pj_ (VERBS_pj_ i. <'View')}~ <full
  'file://', full
 else. (13!:8&45) 'View requires an extension' end.
}}

NB. Support for output

displayLines_pj_=: {{
 NB. Format an array as a vector, correct appearance of LF at first level
 if. 0~: L. y do. fix=. LF&e. &> rav=. ,y
  y=. ($y)$ (,y) (I.fix)}~ ([:>;._2 (10{a.),~ ])&.> rav#~ fix
 end.
 if. 0< r=. _1+ #$ y=. ":y do. (-r)}. LF displayUnboxed^: r y
 else. ,y end.
}}

foldBoxes_pj_=: {{
 NB. Format the disclose of boxed characters into lines
 insert=. _1+ +/\ |. (WIDTH_pj_+ m) foldBoxes_pj_/ |. 0, 0,~ m+ #&> y
 (->:m)}. LF insert }'X',~ ;y ,&.> <m# ' '
:
 if. m> next=. x+ {.y do. next, }.y
 else. x, y end.
}}
