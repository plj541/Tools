Tools=: Tools, {{)n
   Code '~Jay/tools/output'   NB. View Across Fmt Keys Unbox Vr
}}

Across=: {{
 NB. Place two blanks between items and fold then to WIDTH_pj_
 2 foldBoxes_pj_ y
}}

Fmt=: {{
 NB. Financial form of numbers
 NB. -    +   -   +  mp Before; nq After; b[zero]; d[nill]; r[fill]
 'm[ (]p[  ]n[)]q[ ]c0.2' Fmt y
:
 if. 0 e. $y do. ''$~ $y return. end.
 if. L. x do.
  x=. }: ;(<'m[ (]p[  ]n[)]q[ ]⍕,') Replace&.> <"1 x,.~ <'⍕'
 end.
 x (8!:2) y
}}

Keys=: {{
 keys=. (('                                 """""""""""""""##########"""""""abcdefghijklmnopqrstuvwxyz""""""abcdefghijklmnopqrstuvwxyz""""'{~ ]), '000000000000000000000000000000000b3pqmv256lkg1ds0123456789efihjcu111111111111111111111111118t7n04000000000000000000000000009oar0'{~ ])
 ([:keys a.i. ])"1 >y
}}

Unbox=: {{
 NB. Remove boxing characters from result
 if. 32~: (3!:0) y do. 
  if. ' '= {.0($,)y do. >y Split LF
  else. 1 1}. _1 _1}. ": <y end.
 else.
  was=. (9!:6) ''
  (9!:7) [11# rep=. 30{ a.
  (9!:7) was [now=. ": <y
  now=. 1 1}. _1 _1}. now
  rho=. $now=. (-.*./"1 now= rep)# now 
  rho$ ' ' (I. now= rep)} now=. ,now
 end.
}}

Vr=: {{
 NB. Visual Representation
 if. 0= (4!:0) <y do.
  t=. <;._1' 1 a. 2 3.5 j < x r , , s1 sa. s2 s3.5 sj s< sn u2 u4'
  t=. (":$d), '$ of ', ;t{~ 2^. 3!:0 d=. ".y
  LF,~ 'NB. ', y, '=: ', t, LF, displayLines_pj_ d 
 else. t=. >('1234'i. {.d){ ')a'; ')c'; ''; ')d'; 'X' [d=. (5!:5) <y
  if. ' : '-: 3{.}.d do. e=. 4{. }.d
   if.     ' : 0'-:  e do. d=. }:d}.~ #e=. (d i. LF){. d=. 5}. d
   elseif. ' : '''-: e do. d=. ".d}.~ -#e=. (>:d i: '''')}. d=. 4}. d
   elseif. ' : ('-:  e do. d=. 4}. d
    if. (;:')"(')+./@E. ;:d do. d=. d}.~ -#e=. d}.~ >:1 i:~ ') " ('E. d
    else. d=. d}.~ -#e=. (>:d i: ')')}. d end.
    d=. LF,LF,~ LF Join~ ". d
   else. (13!:8&45) 'Unrecognized' end.
   LF,~ y, '=: {{', t, d, '}}', e
  else. LF,~ y, '=: ', d end.
 end.
}}

View=: {{
 NB. View an html page with a browser
 0 0$ browse_j_ viewRules_pj_ y
}}

viewRules_pj_=: {{
 if. '/'~: {.full=. 0 Path y do. full return. end.
 if. 1< #;{:pathNameExtn full do.
  FILES_pj_=: FILES_pj_ (VERBS_pj_ i. <'View')}~ <full
  'file://', full
 else. (13!:8&45) 'View requires an extension' end.
}}

NB. Support for output

displayLines_pj_=: {{
 NB. Format an array as a vector, correct appearance of LF at first level
 if. 0~: L. y do. fix=. LF&e. &> rav=. ,y
  y=. ($y)$ (,y) (I.fix)}~ ([:>;._2 (10{a.),~ ])&.> rav#~ fix
 end.
 if. 0< r=. _1+ #$ y=. ":y do. (-r)}. LF displayUnboxed^: r y
 else. ,y end.
}}

foldBoxes_pj_=: {{
 NB. Format the disclose of boxed characters into lines
 insert=. _1+ +/\ |. (WIDTH_pj_+ m) foldBoxes_pj_/ |. 0, 0,~ m+ #&> y
 (->:m)}. LF insert }'X',~ ;y ,&.> <m# ' '
:
 if. m> next=. x+ {.y do. next, }.y
 else. x, y end.
}}
