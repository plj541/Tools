Tools=: Tools, {{)n
   Code '~Jay/tools/output'   NB. Across Fmt Keys Unbox Vr Browse
}}

Across=: {{
 NB. Place two blanks between items and fold then to WIDTH_pj_
 2 foldBoxes_pj_ y
}}

Fmt=: {{
 NB. Financial form of numbers
 NB. -    +   -   +  mp Before; nq After; b[zero]; d[nill]; r[fill]
 'm[ (]p[  ]n[)]q[ ]c0.2' Fmt y
:
 if. 0 e. $y do. ''$~ $y return. end.
 if. L. x do.
  x=. }: ;(<'m[ (]p[  ]n[)]q[ ]⍕,') Replace&.> <"1 x,.~ <'⍕'
 end.
 x 8!:2 y
}}

Keys=: {{
 keys=. (('                                 """""""""""""""##########"""""""abcdefghijklmnopqrstuvwxyz""""""abcdefghijklmnopqrstuvwxyz""""'{~ ]), '000000000000000000000000000000000b3pqmv256lkg1ds0123456789efihjcu111111111111111111111111118t7n04000000000000000000000000009oar0'{~ ])
 ([:keys a.i. ])"1 >y
}}

Unbox=: {{
 NB. Remove boxing characters from result
 was=. 9!:6 ''
 9!:7 [11# rep=. 30{ a.
 9!:7 was [now=. ": <y
 now=. 1 1}. _1 _1}. now
 rho=. $now=. (-.*./"1 now= rep)# now 
 rho$ ' ' (I. now= rep)} now=. ,now
}}

Vr=: {{
 NB. Visual Representation
 if. 0= 4!:0<y do. t=.<;._1' 1 a. 2 3.5 j < x r , , s1 sa. s2 s3.5 sj s< sn u2 u4'
  LF,~ 'NB. ', y, '=: ', (LF, displayLines_pj_ d),~ (":$d), '$ of ', ;t{~ 2^. 3!:0 d=. ".y
 else. t=. >('1234'i. {.d){ ')a'; ')c'; ''; ')d'; 'X' [d=. 5!:5 <y
  if. ' : '-: 3{.}.d do. e=. 4{. }.d
   if.     ' : 0'-:  e do. d=. }:d}.~ #e=. (d i. LF){. d=. 5}. d
   elseif. ' : '''-: e do. d=. ".d}.~ -#e=. (>:d i: '''')}. d=. 4}. d
   elseif. ' : ('-:  e do. d=. 4}. d
    if. (;:')"(')+./@E. ;:d do. d=. d}.~ -#e=. d}.~ >:1 i:~ ') " ('E. d
    else. d=. d}.~ -#e=. (>:d i: ')')}. d end.
    d=. LF,LF,~ LF Join~ ". d
   else. 'DOMAIN ERROR' Signal 0 end.  NB. Unrecognized
   LF,~ y, '=: {{', t, d, '}}', e
  else. LF,~ y, '=: ', d end.
 end.
}}

Browse=: {{
 NB. View an html page with a browser
 0 0$ 6!:3 [0.541 [browse_j_ 1 path_pj_ y
 NB. Some browsers miss multiple rapid requests
}}

NB. Support for output

displayLines_pj_=: {{
 NB. Format an array as a vector, correct appearance of LF at first level
 if. 0~: L. y do. fix=. LF&e. &> rav=. ,y
  y=. ($y)$ (,y) (I.fix)}~ ([:>;._2 (10{a.),~ ])&.> rav#~ fix
 end.
 if. 0< r=. _1+ #$ y=. ":y do. (-r)}. LF displayUnboxed^: r y
 else. ,y end.
}}

foldBoxes_pj_=: {{
 NB. Format the disclose of boxed characters into lines
 insert=. _1+ +/\ |. (WIDTH_pj_+ m) foldBoxes_pj_/ |. 0, 0,~ m+ #&> y
 (->:m)}. LF insert }'X',~ ;y ,&.> <m# ' '
:
 if. m> next=. x+ {.y do. next, }.y
 else. x, y end.
}}
