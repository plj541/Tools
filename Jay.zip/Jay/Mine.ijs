help=: {{)n
 NB. help is displayed by Load
 Help                  NB. Help is global
 Lib ''                NB. Lists personal applications
 Dr ''                 NB. Lists folders and files
}}
