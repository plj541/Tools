help=: {{)n
 NB. Click Backup Viewer, then choose a file to View
 NB. Click Select, then Ctrl-c
 Fix ''    NB. Converts copy buffer
 NB. Paste into an eMail
}}

Fix=: {{
 a=. wd 'clippaste'
 b=. a Trim LF
 b=. }."1 b Split LF
 c=. b Split &> TAB
 d=. ;(Unbox }:"1 c){{<x, LF, LF2,~ >y}}"1 0 {:"1 c
 wd 'clipcopy *', d
}}

parse=: {{
 now=. File LastVersion '~Down/SMS.xml'
 now=. now Split '<smses '
 if. '</smses>' EndsWith~ now=. ;{:now do.
  if. (<'count=')= {.count=. '"' Split~  21{. now do.
   now=. now Split '<mms '
   if. (#now)= >:".;1{count do. now return. end.
  end.
 end.
 ,.'XML is not as expected'
}}

fixAmp=: (<"0 [9 10 13 34 60 62 38 {a.),.~<;.1 '&#9;&#10;&#13;&#34;&lt;&gt;&amp;'
fix=: {{
 date=. ;{:y Split ' readable_date="'
 date=. ;{.date Split '"'
	
 text=. ;{:y Split ' text="'
 text=. ;{.text Split '"'
 text=. text Replace ForEach _ fixAmp
 
 date, LF, text
}}
