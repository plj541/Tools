help=: {{)n
 IfOrLoop               NB. Compare or Count
 If                     NB. Examles of ^: with items of y
 While                  NB. Examles of ^: with items of y
}}

IfOrLoop=: {{)n
NB. [possible x] {{verb}} ^: (compare or count) y   
  [x] u ^: n y
NB. If n= 0, returns y
NB. If n= 1, calls [x] u y
NB. If n= 2, calls [x] u [x] u y
NB. If n> 2, continue like two 
}}

If=: {{)n
NB. Scalar IF
 2&*^:(<&6)"0 i.3 5     NB. double y if it is less than 6
   
 2&*^:(>&6)"0 i.3 5     NB. double y if it is greater than 6

NB. Concatenate when characters
 'Mr. '&, ^: (2= 3!:0@]) &.> 'Smith'; 5; 'Jones'; 10; 'Williams'; 15
}}

While=: {{)n
 3&* ^: (<&100) ^:_"0 ]5 7 11      NB. triple items while they are less than 100
 
 %&3 ^: (>&40) ^:_"0 ]135 189 297  NB. divide items by 3 while they are greater than 40
}}

