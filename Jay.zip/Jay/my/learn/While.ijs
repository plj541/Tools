help=: {{)n
 While=: ]F.([.[((_2:Z:-.)@:].))   NB. like u^:v^:_  but w/o convergence 
 kbd=: 1!:1@1     NB. keyboard input
 'result: ', (, kbd) While ('q'~:{:) 'A'
}}