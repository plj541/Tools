help=: {{)n
 NB.Learn Fold
 foo=: {{ x-y [Say 'y=';y [Say 'x=';x}}
 100 200 300 ] F:. foo 1 2 3 4
}}