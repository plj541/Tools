testb=: 3 Def
 try.
  Say 'try'; 13!:17 ''
  10 100+ y
 catch.
  empty Say 'catch'; 13!:17 ''
 catchd.
  empty Say 'catchd'; 13!:17 ''
 end.
)

testc=: 3 Def
 try.
  Say 'try'; 13!:17 ''
  10 100+ y
 catch.
  empty Say 'catch'; 13!:17 ''
 end.
)

testd=: 3 Def
 try.
  Say 'try'; 13!:17 ''
  10 100+ y
 catchd.
  empty Say 'catchd'; 13!:17 ''
 end.
)

Say'testb both, testc catch, testd catchd'

dbr 1
