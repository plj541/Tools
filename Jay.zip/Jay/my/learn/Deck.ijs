help=: {{)n
 NB. Examples from YouTube Channel tangentstorm
 Do Deck     NB.  Dealing cards in J
}}

Deck=: {{)n
 suits=: 'cdhs'
 ranks=: '23456789TJQKA'
 |: { ranks; suits
 bySuit=: , s: |: { ranks; suits
 byRank=: , s: { ranks; suits
 deck=: byRank
 deal=: {{ deck {~ y ? 52 }}
 shuffle=: deal @ 52
 shuffle2=: {{ deck A.~ ? ~52x }}
}}
