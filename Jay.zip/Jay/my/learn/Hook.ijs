
B=: {{
 y u B v y
:
 (u x) v y
}}