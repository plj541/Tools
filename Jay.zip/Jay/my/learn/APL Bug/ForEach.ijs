ReduceArgs=: {{)n
NB. _______ J _______

NB. Replace and ForEach already available
 NB. Usage: left verb ForEach eachSize multipleEachSizeArgs
 y=. |., <"1 (-n) ]\ y
 >u~ &.>/ y, <x

 now=. 'now this cat ate fish'
 now Replace ForEach 2 'cat'; 'dog'; 'fish'; 'stew'; 'now'; 'then'

NB. _______ APL2 _______
 
ForEach← {
 pairs← ⌽ (⊂⍤1) ((⍵⍵ ÷⍨ ≢⍵) ⍵⍵)⍴ ⍵
 ⊃⍺⍺⍨ / pairs, ⊂⍺
}

Replace← {
 ⎕← ⍵ ⋄ ⍞← ⍺ ⋄ ⍞
}

Replace← {
 (old new)← ⍵ ⋄ (old ⎕R new) ⍺ 
}


 now← 'now this cat ate fish'
 now Replace ForEach 2 ⊢'cat' 'dog' 'fish' 'stew' 'now' 'then'

 cat  dog 
now this dog ate fish
 fish  stew 
now this dog ate stew
 now  then 
then this dog ate stew
then this dog ate stew

}}
