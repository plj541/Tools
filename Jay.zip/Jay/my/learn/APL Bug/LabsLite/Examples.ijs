Run~ '~Jay/demos/Support/KeepNext'

Keep 0 Def
 The current version was focused on interesting uses of adverbs and
 conjunctions. It was written before I learned how to avoid problems
 with shared names.
)

Keep~ 0 Def
NB. Probably the cutest example was in the verb View:
View=: 3 Def
 NB. Provide an appropriate editor
 y fileType editFile y
 y ['View' fileName~ y
NB.)
)

Keep 0 Def
 While  pathNameExtn fileName were both in current Tools
 Neither were used in tempName, the rewrite prompted pathOf
)

Keep~ 0 Def
NB. First let's look at tempName
tempName_pj_
)

Keep~ 0 Def
NB. Now let's look at pathOf
pathOf_pj_
)

Keep 0 Def
Check if I mentioned
 1 Def Del ForEach
 2 Dr Rn Diff
 3 View Use Last Keys
)

Next~ _
