help=: menu_plj_=: 0 Def
    NB. APL to J
 Browse 'https://plj541.github.io/Tools/APLtoJ.html'
 Load '~Jay/demos/Examples/semicolons'
 Load '~Jay/demos/Examples/globalVlocal'
    NB. Demo Jay
 Tools
 Load '~Jay/demos/Display
 Load '~Jay/demos/Examples/createAobject'
 Browse 'https://code.jsoftware.com/wiki/Vocabulary/com#What_Is_The_Implied_Locale_When_The_Body_Is_Executed.3F'
    NB. Shared Locales
 Load '~Jay/demos/Examples/sharedLocales'
    NB. Wrapup
 Load 'lessons/Presentation/Examples'
 Load '~Jay/demos/Examples/writingExamples'
)