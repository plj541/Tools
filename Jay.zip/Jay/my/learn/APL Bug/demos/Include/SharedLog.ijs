NB. Here only for viewing in Examples/sharedLocales, not intended for use
log_plj_=: '' NB. Initial value

Get_plj_=: 3 Def
 log_plj_
)

Set_plj_=: 3 Def
 0 0 $log_plj_=: log_plj_, y
)

Gets_plj_=: 1 Def
 log_plj_
)