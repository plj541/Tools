log=: '' NB. Initial value

Get=: 3 Def
 log
)

Set=: 3 Def
 0 0 $log=: log, y
)

Gets=: 1 Def
 log
)