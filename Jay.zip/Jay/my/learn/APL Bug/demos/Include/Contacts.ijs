NB. A simple Class to capture and select Contacts

NB. Provide empty initial values
names=: 0 3$ phones=: ''

Contact=: 3 Def
 NB. Get all fields
 (;:'Last First Middle Phone'), names,. phones
:
 NB. Set all fields
 'name phone'=. x
 names=: names, 3{. ;:name
 phones=: phones, <phone
 i. 0 0
)

Name=: 3 Def
 NB. Select by name
 (y IsIn names)# names,. phones
)

Phone=: 3 Def
 NB. Select by phone
 (y IsIn ,.phones)# names,. phones
)

IsIn=: 4 Def
 NB. Create a selection rule
 x +./@E."1 Unbox y
)
