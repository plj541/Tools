Next=: 3 Def
 NB. Step through the demo
 items=. #Items__PS
 while. items> Count__PS=: Count__PS+ 1 do.
  if. (1= #y)*. 0= {.0#,y do. y=. '' [Count__PS=. y- 1
   if. (<&0 +. >:&items) Count__PS do.
    'There are ', ": #Items__PS return.
   end.
  end.
  
  if. 0= #y do.
   Say ' Item ', (": 1+ Count__PS), ' of ', ": #Items__PS
   now=. >Items__PS{~ Count__PS
   if. L. now do. Say Do >now
   else. Say now end.
  else. 'Say again' return. end.
  
  if. 0~: #now=. ' ' Trim~ Ask '...' do.
   Say '   Next ''''  NB. To resume'
   Say Do now return.
  end.
 end.
:
 Say 'NB. To begin, press enter on the following line:', LF, '   Next '''''
)

Keep=: 3 Def
 NB. Gather the Items for Next
 Items__PS=: Items__PS, <y
:
 Keep <y Replace <;._1 a.{~ 0 10 78 66 46 41 10 0 10 41 10
{{)n!
NB.)
!
)

}}
)

Items__PS=: $Count__PS=: _1