help=: 0 Def
 NB. This is a simple example using multiple identical objects
 Do script  NB. Enter this line, or try things yourself
)

script=: 0 Def
 NB. Timestamps are unrealistic, the computer is submitting them
 Setup&> ;:'Peace Love Joy'  NB. This line to start the demo
 Peace Log 'good morning'
 Peace Log 'just fed mitten;ask about her schedule'
 Love Log 'Up now'
 Peace Log ''
 Love Log 'Taking a shower first'
 Joy Log 'What a lovely morning'
 Peace Log _  NB. Any number acts like Unix head or tail
 Love Log _
 Joy Log _
)

Setup=: 3 Def
 NB. Create an object for y
 (y)=: New '~Jay/demos/Include/Log'
)

Log=: 1 Def
 NB. Work with object m
 if. y-: '' do. ' Entries',~ ": #Get__m ''
 elseif. 0= {.0# y do. Unbox ,. y{. Get__m ''
 else. note=. >;._2 y, ';'
  time=. ,: 6!:0 'YYYY MM DD hh mm ss  '
  Set__m <note,.~ time{.~ #note
 end.
)
