help=: 0 Def
 NB. From: Raul Miller via general@jsoftware.com
 NB. To see all of these examples    Do help
 mean=: +/ % #
 Shape 'mean'
 1 Shape 'mean'
 Shape }. i. 2 4
 Shape }. <"1 i. 2 3
 Shape 'Shape '
 Shape a=. 'cat'; 'dogs'
 Shape }. a
 Shape > a
)

load=. 0 Def
Shape__PLJ=: 3 Def
 NB. Display shape information, nouns are boxed to insure they benefit
 2 Shape y
:
 if. (2 ~: 3!:0 y) +. (1< #$ y) +. (y-: i.0) +. ' 'e. y do.
  if. L. y do. y=. 5!:x <'y' [y=. <y
  else. y=. 5!:x <'y' end.
 elseif. 0> 4!:0 <y do. y=. 5!:x <'y'
 else. y=. 5!:x <y end.
 thsh__x y [x=. Z
NB.)

thsh=: 3 Def
 if. 0=L.y do. thflat y return. end.
 thflat (":@$each y) thshe"2 thsh each y
NB.)

thflat=: 1 1}._1 _1}.":@<

thshe=: 4 Def
 if. 2>#$y do.
  x=. (_2{.1 1,$x)$,x
  y=. (_2{.1 1,$y)$,y
 end.
 'ul um ur ml mm mr ll lm lr vert horz'=. 9!:6 ''
 h=. >./"1 #@> y
 w=. >./(#@>x),{:@$@> y
 shs=. {h;w
 y=. shs {.&.> y
 hs=. {.@> shs
 ws=. {:@> shs
 topdetail=. ws {.each x,each ws#each horz
 top0=. ur,~ul,}.;um,each {.topdetail
 topn=. (mr,~ml,[:}.@;mm,each ])"1 }.topdetail
 tops=. top0,topn
 bot=. lr,~ll,}.;lm,each ({:ws)#each horz
 bot,~,/tops,"1 2 (vert,.~[:;,.each/)"1 vert ,.each y
NB.)
)

mean=: +/ % #

{{
 if. 3= 4!:0<'Shape__PLJ' do. return. end.
 link=. New ''
 Do__link~ y Replace ForEach 2 <;._1 '|NB.)|)|Z|<":', ": >link
}} load