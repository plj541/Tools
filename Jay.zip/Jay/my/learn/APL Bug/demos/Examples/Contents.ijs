help=: 0 Def
    NB. Where to find Jay Tools
 Browse 'https://plj541.github.io/Tools/APLtoJ.html'
    NB. Examples
 Tools
 Load '~Jay/demos/Display'
 Load '~Jay/demos/Examples/createAobject'
 Browse 'https://code.jsoftware.com/wiki/Vocabulary/com#What_Is_The_Implied_Locale_When_The_Body_Is_Executed.3F'
    NB. Shared Locales
 Load '~Jay/demos/Examples/sharedLocales'
    NB. Wrapup
 Load '~Jay/demos/Examples/writingExamples'
)
