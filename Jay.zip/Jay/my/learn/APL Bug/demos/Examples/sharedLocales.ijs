Run~ '~Jay/demos/Include/KeepNext'

Keep~ 0 Def
NB. To demonstrate issues with running as shared names
load_plj_ '~Jay/demos/Include/Log.ijs'
NB. This is the same simple code from createAobject
)

Keep~ 0 Def
NB. Set values into the log
Set <'some'
Set <'of this'
)

Keep~ 0 Def
NB. As a reminder, here is the verb Set
Set
)

Keep~ 0 Def
NB. After the assignment, the log value in plj is unchanged
log_plj_
)

Keep~ 0 Def
NB. Since it is executing in base, the assignment results went here
log
)

Keep~ 0 Def
NB. First erase the local log value
Erase 'log'
)

Keep~ 0 Def
NB. Now redefine Set_z_ to modify 
Set_plj_=: 3 Def
 0 0 $log_plj_=: log, y
NB.)
)

Keep~ 0 Def
NB. Now use Set again
Set <'this'
Set <'and that'
)

Keep~ 0 Def
NB. This time the log value in plj has been modified
log_plj_
)

Keep~ 0 Def
NB. There is no log value in base
log
)

Keep~ 0 Def
NB. The Get verb seems to work correctly
Get ''
)

Keep~ 0 Def
NB. However, if we create a value for log in base
log=: <'hide me'
)

Keep~ 0 Def
NB. Get returns the base value rather then the shared value in plj
Get ''
)

Keep~ 0 Def
NB. Let's redefine Get_plj_
Get_plj_=: 3 Def
 log_plj_
NB.)
)

Keep~ 0 Def
NB. The Get verb now works correctly
Get ''
)

Keep~ 0 Def
NB. The Set verb also has a problem
NB. Let's redefine Set_plj_
Set_plj_=: 3 Def
 0 0 $log_plj_=: log_plj_, y
NB.)
)

Keep~ 0 Def
NB. Using Set should now work correctly
Set <'another'
)

Keep~ 0 Def
NB. And indeed it does
Get ''
)

Keep 0 Def
   NB. The changes described here are saved as:
   Code '~Jay/demos/Include/SharedLog'
)

Next~ _
