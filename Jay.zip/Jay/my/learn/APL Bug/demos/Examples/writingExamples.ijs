Run~ '~Jay/demos/Include/KeepNext'

Keep 0 Def
 The verbs in KeepNext are intended as a simple way to present J
 There are only two verbs:
   Keep  which is used to capture each of the items you wish to describe
   Next  which displays each item one at a time
)

Keep 0 Def
 The line:
  Run~ '~Jay/demos/Include/KeepNext'
 brings the verbs Keep and Next into the active locale
 It must appear before the first use of Keep
)

Keep 0 Def
 When you just need to display descriptive text
 Type as follows:
 
Keep 0 Def
 Your lines
 go here
 followed by a line with just )
)  NB. Even a comment will prevent closure
)

Keep 0 Def
 When you want expressions evaluated for the user to see
 Type as follows:
 
Keep~ 0 Def
 NB. Comment only lines must be preceded by NB.
 i. 2 3  NB. Both the expression and the result will appear
)			

 NB. Note the ~ to invoke Keep dyadically
)

Keep 0 Def
 When you want to define a multi-line verb, adverb or conjunction
 Type as follows:
 
Keep~ 0 Def
try=: 3 Def  
 NB. Simple verb
 10+ i. y  NB. Both this expression and its result will appear
NB.) 

 Note the internal closing line:
 NB.)
 must appear on a line by itself
)

Keep 0 Def
 The last line of the Example should be:
 
 Next~ _  NB. To remind the user how to begin
 
)

Next~ _