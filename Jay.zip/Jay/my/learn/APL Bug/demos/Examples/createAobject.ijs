Run~ '~Jay/demos/Include/KeepNext'

Keep 0 Def
Demonstrate creating code intended for an object
Like that at:   ~Jay/demos/Include/Log.ijs
)
 
Keep~ 0 Def
NB. Create the verb Set
Set=: 3 Def
 0 0 $log=: log, y
NB.)
)

Keep~ 0 Def
log=: '' NB. Initial value
)

Keep~ 0 Def
NB. Set some values
Set <'one'  
Set <'two'
)

Keep~ 0 Def
NB. Create the verb Get
Get=: 3 Def
 log
NB.)
)

Keep~ 0 Def
NB. Get the values you've set
Get ''
)

Keep~ 0 Def
NB. Having learned about adverbs without derived verb arguments
Gets=: 1 Def
 log
NB.)
)

Keep~ 0 Def
NB. Test the adberb
]Gets
)

Keep~ 0 Def
NB. Having created the code access it as an object
a=: New  '~Jay/demos/Include/Log'
)

Keep~ 0 Def
NB. Set some values
Set__a <'this'  
Set__a <'and that'
)

Keep~ 0 Def
NB. Get the values you've set with the verb
Get__a ''
)

Keep~ 0 Def
NB. Try the adverb Gets
]Gets__a
)

Next~ ''