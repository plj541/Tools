help=: 0 Def
 NB. New creates and populates an object instance
 Do test1  NB. Enter this line for the first demonstration
)

test1=: 0 Def
 NB. Create an object from a simple class
 my=. New '~Jay/demos/Include/Contacts'
 Contacts=: Contact__my
 Contacts~ 'Howland John J'; '210-756-0103'
 Contacts~ 'Hill Jim'; '214-969-1972'
 Contacts~ 'Cassedy John H'; '214-969-1974'
 Contacts ''  NB. Show the updated Contacts list

 my__PS=: my     NB. Save for later
' Do test2          NB. Enter this line for next demonstration'
)

test2=: 0 Def
 NB. Demonstrates reuse in another context
 Contacts           NB. Assigned earlier as a global
 Contacts ''        NB. my was a local in the previous script, now a value error
 my=: my__PS        NB. Get back the saved copy
 Contacts ''        NB. The object still exists
 Contacts~ 'Steinbrook David A'; '415-323-1986'
 Name__my 'John'    NB. Searches can find names in any field
 Name__my ' J '     NB. All fields are surrounded by blanks, which can limit searches
 Phone__my ' 214'   NB. Just a blank prefix ensures the area code
 Unbox Contacts ''  NB. The report without the boxes is the basis for searches
)
