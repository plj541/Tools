help=: 0 Def
 Dr                          NB. The first version
 Do DrRn Replace 'NB.)';')'  NB. The second version includes Rn
)

Dr=: 3 Def
 NB. Dirs and Files
 d=. Across '' Dirs y [f=. Across '' Files y
 d, (LF#~ 0~: #d) , '.   ..', (LF#~ 0~: #f), f
)

DrRn=: 0 Def
Dr=: 3 Def
 NB. Dirs and Files
 rn=. ''
 if. (y-: '')+. 1= #1!:0 y do.
  rn=. LF, '   ', 'Rn _',~ quote y
 end. 
 d=. Across '' Dirs y [f=. Across '' Files y
 d, (LF#~ 0~: #d) , '.   ..', (LF#~ 0~: #f), f, rn
NB.)

Rn=: 2 Def
 NB. Launch a verb to handle the request
 file=. wdclippaste ''
 m=. m, '/'#~ 0~: #m
 if. 3= 4!:0 <'v' do.
  v m, file
 else.
  Edit m,file
 end.
NB.)
)