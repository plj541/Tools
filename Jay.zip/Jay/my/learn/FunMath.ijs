help=: {{)n
 AdjPowers 5     NB. (-/5^ 6 5)% 4
 Kaprekar ?9999  NB. arrange large & small with those digits, becomes 6174
 Math3 123       NB. Any three-digit number, three divides gets back to start
}}

AdjPowers=: {{
 NB. First column demonstrates why equation below is true
 y2pow=. y^/ pow=. i. 11
 mat=. (}:pow), (}:y2pow),: }.y2pow
 ]dif=. -~/}.mat
 >.mat, dif% y- 1
:
 (y^ pow)= ((y^ pow+ 1)- y^ pow=. >.i. 10)% y- 1
}}" 0

Kaprekar=: {{
 NB. Kaprekar’s constant
 now=. y
 while. Yes '  Again?', ":now do.
  now=. (4#10)#: now
  up=. 10#. /:~ now
  dn=. 10#. \:~ now
  Say (":dn), ' - ', ":up
  now=. dn- up
 end.
}}

Math3=: {{
 NB. Supply a three-digit number
 Do ']now=: ', ' % 13',~ ": y+ 1000 * y
 Do ']now=: ', ' % 11',~ ": now
 Do ']now=: ', ' % 7',~ ": now
 if. now = y do. 'QED'
 else. 'OMG' end.
}}
