help=: 0 Def
 '789' set 2 2    NB. Modify a panel of working Set
 See ''           NB. Formatted display of working Set
 Solve Set ''     NB. Sudoku solutions to working Set
 Keep 23          NB. Save working Set as '23' and clear working set
)

Index=: 3 Def
 NB. y indexes of any set
 (27 3+/ .* y) + 0 9 18+/ 0 1 2
)

InitSudoku=: 3 Def
 j=. (]/. i.@#) ,{;~ 3# i.3
 r=. 9# i.9 9
 c=. 81$|: i.9 9
 b=. (,j{ 9# i.9){ j
 r=. ~."1 r,. c,. b

 R =: j, (,|:) i.9 9
 free=: 0&= >(1+ i.9) e."1 r&{
 regions=: R {"_ 1 ]
 i. 0 0
)

Keep=: 3 Def
 NB. Keep Set value to y and reset to all 0's
 if. 0~: #y do.
  if. fexist setName y do.
   y, ' already exists'  return.
  end.
  now=. Set ''
  if. now-: 81# '0' do.
   'Nothing to keep'  return.
  end.
  now fwrite setName y
 end.
 0 0$ (81# '0')fwrite setName '@SudokuSet'
)

See=: 3 Def
 NB. Display form of a Set
 see '0123456789'i. Set y
)

Set=: 3 Def
 if. 0= #y do.
  y=. '@SudokuSet'
 end.
 fread setName y
:
 if. 0~: #y do.
  'Cannot rewrite ', y  return.
 end.
 x fwrite setName '@SudokuSet'
)

Sets=: 3 Def
 NB. Lib style list of Sudoku sets
 names=. _4&}. &.> '.txt' Files 'my/Sudoku'
 names=. names-. <'@SudokuSet'
 Across ((Set '')-: 81# '0')}. 'Unsaved'; names
)

Solve=: 3 Def
 if. ' '= {.0$ y do.
  y=. '0123456789'i. y
 end.
 solve=. sudoku y
 if. 1~: #solve do.
  Say (": #solve), ' solutions'
  solve=. (,0){ solve
 end.
 see y, solve
)

ac=: +/ .*&(1+ i.9)* 1= +/"1

ar=: 3 Def
 m=. 1= +/"2 R{y
 j=. I. +./"1 m
 k=. 1 i."1~ j{ m
 i=. ,(k{"_1 |:"2 (j{ R){ y) #"1 j{ R
 (1+ k) i} 81$ 0
)

assign=: (+ (ac >. ar)@free)^:_"1

diff=: * 0&=@}:@(0&,)

guess=: ;@:(<@guessa"1)

guessa=: 3 Def
 if. -. 0 e. y do.
  ,:y return.
 end.
 b=. free y
 i=. (i. <./) (+/"1 b){ 10, }. i.10
 y +"1 (1+ I. i{ b)*/ i= i. 81
)

ok=: (27 9$ 1) -:"2 (0&= +. ~:"1)@ regions

see=: <@see1 "1`see1@.(1: = #@$)

see1=: (1 0 0 1 0 0 1 0 0; 1 0 0 1 0 0 1 0 0)&(<;.1)@({&'.123456789')@(9 9&$)@,

set=: 3 Def
 (Index y){ Set ''
:
 0 0$ '' Set~ (9{. x, 9# '0') (,Index y)} Set ''
)

setName=: 3 Def
 NB. Provide name for a Sudoku Set
 'data/Sudoku/', (":y), '.txt'
)

sudoku=: guess@: (ok # ])@: assign^: _@,

InitSudoku ''