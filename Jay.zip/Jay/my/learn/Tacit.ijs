help=: {{)n
 Tacit                       NB. Rules for Hooks and Forks
 Idioms                      NB. Tacit expressions
}}

Tacit=: {{)n
 NB. When a b c are verbs:
 NB.  (a b)R  means  (R a (b R))
 NB. L(a b)R  means  (L a (b R))

 NB.  (a b c)R  means  ((  a R) b (  c R))
 NB. L(a b c)R  means  ((L a R) b (L c R))
}}

Idioms=: {{)n
 NB. Delete Multiple Blanks
 (*.& (2= #@$))              NB. Two matrices are required
 
 (3&<: *. 10&>:)             NB. Is between 3 and 10
 (]#~ (3&<: *. 10&>:))       NB. Just between 3 and 10
 
 ((+:@[) ; -:@])             NB. Fork Double left ; Half right
 ((; -:)~ +:)~               NB. Two hooks without identifying argument

 NB. Join alternatives
 }.;',' ,&.> ;:'steak  fish  chicken'
 }.;',' ,L:0 ;:'steak  fish  chicken'
 }: @:(;@:(,&','&.>)) ;:'steak fish chicken'
}}
