help=: {{)n
 ;Vr &.> ;:'Pivot Show'         NB. See how it works
 data=: 0,"0 2~ 10 15?@$ 16     NB. Create an initial rank 3 value
 mask=. 3> Show data            NB. Create a mask
 data=. mask Pivot data         NB. Pivot some values based on a mask
 Show data                      NB. Show the data Pivot didn't move
 
 Show text                      NB. Alternatively, consider text
 mask=: ~:/\"1 ''''= Show text  NB. Mask what is in quotes
 Show mask Pivot text           NB. Now analize without quoted text

 NB. How it looks on TryAPL
 Pivot← {⍺⊖ ⍵}          
 Show← {(1↓ ⍴⍵)⍴ ⍵}
 data← (?10 15⍴ 16),[0.5] 0     ⍝ Create an initial rank 3 value
 mask← 3> Show data             ⍝ Create a mask
 data← mask Pivot data          ⍝ Pivot some values based on a mask
 Show data                      ⍝ Show the data Pivot didn't move
}}

Pivot=: {{
 NB. Pivot a rank 3 with a rank 2
 x|."0 1 y
}}

Show=: {{ {."1 y}}

text=: >;._2 {{)n
 this=. 'This is a test.'
 this=. this,: 'So, is this.'
 this=. this, 'And finally, this!'
}}
text=: ' ',"0 2~ text

NB. screen=:  0,"0 2~ 1600 2560 ?@$ 16b7ffffff