V=: dyad define
z=. y + 0.01
z [smoutput x ; 'v' ; y ; '-->' ; z
)

U=: monad define
z=. -y
z [smoutput '    u' ; y ; '-->' ; z
)

X=: 100
Y=: 0.1 + i.4
100 0.1 1.1 2.1 3.1

]z=: V F:. U X, Y   NB. multiple forward
