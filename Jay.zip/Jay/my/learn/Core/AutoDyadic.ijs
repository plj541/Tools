help=: 0 Def
 Do test
)

test=: 0 Def
NB. adverbs and conjunctions recognize dyadic use
1 : 'x u. y'
2 : 'x v. y'
NB. But verbs do not
3 : 'x *. y'

NB. These show you can force them to ignore the presence of x
1 : ('x u. y'; ':'; '')
2 : ('x v. y'; ':'; '')
3 : ('x *. y'; ':'; '')

NB. But you really need to mean it
1 : ('x u. y'; ':')
2 : ('x v. y'; ':')
3 : ('x *. y'; ':')

NB. adverbs and conjunctions work without u v
a=: 1 : ('x'; ':'; 'x')
c=: 2 : ('x'; ':'; 'y')

NB. An adverb
- a 7
10 * a 7

NB. A conjunction
- c * 7
10 - c * 7
)