'x m n'=: 1001 2002 3003
'`u v'=: (<:&2) ` (>:&3)
verbs=: ((4!:0 ; (5!:5))&<)
sees=: 0 Def
 (;:'Mon x m u n v y'),: ''; x; m; (verbs'u'); n; (verbs'v'); y
:
 (;:'Dia x m u n v y'),: ''; x; m; (verbs'u'); n; (verbs'v'); y
)

NB. Verb arguments

a=: 1 : sees
      #:&2 a 10j4         NB.      (3 :'#:&2 a y [x=. 10j1') 10j4
 10j1 #:&2 a 10j4         NB. (3 :'10j1 #:&2 a y') 10j4

c=: 2 : sees
      #:&2 c ($:&3) 20j4  NB.      (3 :'#:&2 c ($:&3) y [x=. 20j1') 20j4
 20j1 #:&2 c ($:&3) 20j4  NB. (3 :'20j1 #:&2 c ($:&3) y') 20j4
