in=: {{
 NB. test if inner verb can see outer verbs local
 goo=. {{a+ y}}
 a=. 10
 goo y
}}

out=: {{
 NB. test if outer verb can see inner verbs local
 goo=. {{a=. 100+ y}}
 goo y
 a
}}

NB. J
lcl=: {{
 NB. test locals
 Say fun y
 fun=. {{ -y }} 
 fun y
}}
   
gbl=: {{
 NB. test locals
 Say fun y
 fun=: {{ -y }} 
 fun y
 fun=. {{ 1006-y }} 
 fun y
}}  

fun=: {{
 NB. Display y
 'Global Fun'; y
}}
