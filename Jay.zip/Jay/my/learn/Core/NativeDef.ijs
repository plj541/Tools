Oblique=: {{
 NB. Given shape return Oblique indexes
 (;</. y)i. y=. i. y
}}

Rank=: {{
 NB. Given any part, return all 3 Rank meanings
 3$&.|. y  NB. Monadic, Diadic Left, Diadic Right
}}

Base=: {{
 NB. #:
 10#. >:i. 3 3
 NB. Or, with a vector left
 (|.10^ i.3)+/ . * ~>:i. 3 3
}}

modPlus=: {{
 NB. modPlus=: |+[*0=|
 NB. x & | &. <: y
 r =. x|y
 r + x * r = 0
}}
