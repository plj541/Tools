{{
 'x m n'=: 1001 2002 3003
 'u v'=: (<:&2) ` (>:&3)
}} ''
'Am Cm Cn'=: 10j2 20j2 20j3
verbs=: ((4!:0 ; (5!:5))&<)
sees=: {{)n
 (;:'Mon x m u n v y'),: ''; x; m; (verbs'u'); n; (verbs'v'); y
:
 (;:'Dia x m u n v y'),: ''; x; m; (verbs'u'); n; (verbs'v'); y
}}

NB. Noun arguments

f=: 3 : sees
      f 30j4        NB.        (3 : 'f y [x=. 30j1') 30j4
 30j1 f 30j4        NB.    (3 :'30j1 f y') 30j4

a=: 1 : sees
      Am a 10j4     NB.      (3 :'Am a y [x=. 10j1') 10j4
 10j1 Am a 10j4     NB. (3 :'10j1 Am a y') 10j4

c=: 2 : sees
      Cm c Cn 20j4  NB.      (3 :'Cm c Cn y [x=. 20j1') 20j4
 20j1 Cm c Cn 20j4  NB. (3 :'20j1 Cm c Cn y') 20j4
