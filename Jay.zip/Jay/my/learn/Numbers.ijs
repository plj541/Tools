help=: 0 Def
 roman 42               NB. convert to Roman
 arabic 'liv'           NB. convert from Roman
)

arabic=: 3 Def
 NB.  convert from roman numerals
 1 arabic"0 boxopen y
:
 x=. 1 5 10 50 100 500 1000{~ 'ivxlcdm' i. ,>y
 x +/ .* _1+2* x>: 1}. x, 0
)

measures=: 3 Def
 '' measures ''
:
 y=. ,y
 t=. 'tab2tea';'cup2oz';'qt2cup';'gal2qt';'oz2g'
 c=.  3         8        4        4        28.3495231
 t=. t, 'kg2lb';   'm2yd'; 'mi2km'; 'c2f' NB. Not Found
 c=. c,  2.20462262 1.09361 1.609344 1.8      0

 if. 1= +/y e. '2' do.
  r=. c{~ t i. <y
  if. r~: 0 do.
   x=. x* r
   if. y-: 'c2f' do. x=. x+ 32 end.
   x return.
  end.

  r=. c{~ t i. <1}. (y i. '2')|. y, '2'
  if. r~: 0 do.
   if. y-: 'f2c' do. x=. x- 32 end.
   x% r return.
  end.
 end.
 Across 'Choose from:'; t
)

roman=: 3 Def "0
 NB.  convert to roman numerals
 x=. 4 1 3 2 2 3 1 1 1 2 1 3 1 1 2 1 2 1 1 4 1 2
 x=. x# 2 0 2 0 2 0 2 0 _1 2 _1 2 _1 0 2 _1 0 2 _1 0 _2 2
 x=. ,(10 4$ x){~ (4# 10) #: y
 <'mdclxvi'{~ (x~: 2)# x+ 2* <.0.25* i.16
)