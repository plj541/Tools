NB. Space← {⍵,⍨ ⊂'&nbsp;'⍴⍨ 6× ⍺}
Space=: {{y,~ <'&nbsp;'$~ 6* x}}

Handle=: {{y, 0#x}}

Button=: {{
 '' Button y
:
 now=. '<input type="button" ', 'Button' Handle x
 <now, ' value="', y, '">'
}}

Text=: {{
 '' Text y
:
 now=. 'Text' Handle x
 if. 1= #y do. <'<input type="Text"', now, ' size="', '" />',~ ":y
 else. 'row col'=. ":&.> y
  <'<textarea ', now, ' rows="', row, '" cols="', col, '"></textarea>'
 end.
}}