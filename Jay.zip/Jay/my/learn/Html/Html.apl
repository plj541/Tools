define← {
 btn← 7 Space 'onclick:goClear' Button 'Clear ', thisStore, ' List'
 btn← btn, 21 Space 'onclick:goNote' Button 'Note for:'
 btn← btn, 14 Space 'myItem' 'readOnly=true' Text 42
 cols← 5
 (key lin)← shop thisConfig
 thisValues← makeItem¨ lin
 thisNotes← (⍴thisValues)⍴ ⊂''
 lin← lin {(,⍕⍵) (2↓⍺)}¨ ⍳⍴lin
 tab← cols Columns (⊂'myItems' 'onclick:goCheck') Check¨ lin
 tab← tab⍪ cols Columns (⊂'onclick:goExtra') Button¨ key
 ∆← btn, BR, Table tab
 ∆← ∆, BR, 'myNext' Text 39
 ∆← ∆, 21 Space 'onclick:goRemove' Button 'Remove'
 ∆← ∆, 42 Space 'mySend' 'onclick:goSend' Button 'Send this List'
 ∆← ∆, BR, 'myExtras' 'readOnly=true' Text 33 42
}

NB. 'me' Handle 'onclick:goNote'
NB. onclick="onEvent(this, event, 'goNote')"

NB. 'me' Handle 'onclick=goNote(e)'
NB. onclick="goNote(e)"

Handle← {
 ⍝ 'whoCalled' Handle 'myField' 'multiple≠⋄width=27⋄onclick:goSave'
 0= ⍴⍵← ,⍵ : '' ⋄ 2< ≡⍵ : ↗'DOMAIN ERROR:  ', ⍺
 ⍵← {2= ≡⍵ : ⍵ ⋄ (∨/':=≠'∊ ⍵)⌽ ⍵ ''} ⍵
 2≠ ⍴⍵ : ↗'LENGTH ERROR:  ', ⍺
 (∆ ⍵)← ⍵ ⋄ ∆← {0= ⍴⍵ : '' ⋄ 'id="', ∆, '"'} ∆
 0= ⍴⍵ : ∆
 ⍵← ⍵ ⎕split '⋄'
 ∆, ∊(⊂⍺) {
  2= ⍴myParm← ⍵ ⎕split '≠' : ' ', myParm[0]                       ⍝ ≠, Parm has no value
  2= ⍴myParm← ⍵ ⎕split '=' : ' ', myParm[0], '="', myParm[1], '"' ⍝ =, Quote normal HTML value
  2≠ ⍴myParm← ⍵ ⎕split ':' : ↗'DOMAIN ERROR:  ', ⍺ 
  ' ', myParm[0], '="onEvent(this, event, ''', myParm[1], ''')"'  ⍝ :, Call APL, with field and event
 }¨ ⍵
}

(LF TAB NBS)← ⎕UCS 10 9 160
BR← ⊂'<br>' ⋄ MT← ⊂''
Space← {⍵,⍨ ⊂'&nbsp;'⍴⍨ 6× ⍺}

Button← {
 '' Button ⍵
;
 ∆← '<input type="button" ', 'Button' Handle ⍺
 ⊂∆, ' value="', ⍵, '">'
}

Text← {
 '' Text ⍵
;
 ∆← 'Text' Handle ⍺
 1= ≢⍵ : ⊂'<input type="Text" ', ∆, ' size="', (,⍕⍵), '" />'
 (⍺ ⍵)← {,⍕⍵}¨ ⍵
 ⊂'<textarea ', ∆, ' rows="', ⍺, '" cols="', ⍵, '"></textarea>'
}

Check← {
 '' Check ⍵
;
 ∆← '<input type="checkbox" ', 'Check' Handle ⍺
 (⍺ ⍵)← ⍵ ⋄ ⊂∆, ' value="', ⍺, '">', ⍵
}

List← {
 '' List ⍵
;
 ∆← '<select ', '>',⍨ 'List' Handle ⍺
 ⊂∊∆ (Options ⍵) '</select>'
}

Options← {
 ⊂∊{(∆ ⍵)← ⍵ ⋄ '<option value="', ∆, '">', ⍵, '</option>'}¨ ⍵
}

Columns← {
 (⍺,⍨ ⌈⍺÷⍨ ⍴⍵)⍴ ⍵, ⍺⍴ ⊂''
}

Pairs← {
 {2≤ ≡⍵ : ⍵ ⋄ 2⍴ ⊂,⍕⍵}¨ ⍵
}

Table← {
 '0' Table ⍵
;
 ⍵← {1= ≢⍵← ⍕⍵ : ,⍵ ⋄ ,⍵, (4,⍨ ≢⍵)⍴ '<br>'}¨ ⍵
 ⍵← {'<td>', ⍵, '</td>'}¨ ⍵
 ⍵← (⊂'<tr>'), ⍵, ⊂'</tr>'
 ⊂('<table border="', ⍺, '">'), (∊⍵), '</table>'
}

Html← {
 ⍵← 2↑ &⍵
 «document.getElementsByTagName(_w.data[0])[_w.data[1]].innerHTML»
;
 ⍵← 2↑ &⍵
 «document.getElementsByTagName(_w.data[0])[_w.data[1]].innerHTML = _a.toString()»
}

&← {
 2> ≡⍵ : ,⊂⍵ ⋄ ⍵
;
 2> ≡⍵ : ⍺ ⍵
 1≡ ≢⍴⍵ : (⊂⍺), ⍵
 ⍺ ⍵
}

Values← {
 «fieldValues(_w.toSimpleString())»
;
 «fieldValues(_w.toSimpleString(), _a)»
}

Checks← {
 «fieldChecks(_w.toSimpleString())»
;
 «fieldChecks(_w.toSimpleString(), _a)»
}

Defines← {
 «fieldDefines(_w.toSimpleString())»
;
 «fieldDefines(_w.toSimpleString(), _a)»
}

Field← {
 ⍎'«thisField.', ⍵, '»'
;
 ⍺← {' '∊2↑1⍴ ⍵ : '"', ⍵, '"' ⋄ ,⍕⍵} ⍺
 ⍎'«thisField.', ⍵, ' = ', ⍺, '»'
}

FieldNum← {
 ⍎'«+thisField.', ⍵, '»'
;
 ⍺← {' '∊2↑1⍴ ⍵ : '"', ⍵, '"' ⋄ ,⍕⍵} ⍺
 ⍎'«thisField.', ⍵, ' = ', ⍺, '»'
}

Event← {
 ⍎'«"" + thisEvent.', ⍵, '»'
;
 ⍺← {' '∊2↑1⍴ ⍵ : '"', ⍵, '"' ⋄ ,⍕⍵} ⍺
 ⍎'«thisEvent.', ⍵, ' = ', ⍺, '»'
}

get_Help← { 1↓ "
	Button       verb, defines an HTML button
	Text         verb, defines an HTML text or textarea
	Check        verb, defines an HTML checkbox
	List         verb, defines an HTML listbox
	Debug        noun, defines an HTML button that invokes #Debug dialog
	Table        verb, transforms a matrix into an HTML table

	Html		 verb, to get/put html into item with Tag
	Values       verb, to get/put value property from fields with ID
	Checks       verb, to get/put checked property from fields with ID
	Defines      verb, to put innerHTML property of field with ID

	Field        verb, to get/put a property of a field in an event
	Event        verb, to get/put an event property in an event
}