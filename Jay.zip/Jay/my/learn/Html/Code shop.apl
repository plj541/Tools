#include Html

thisArguments← thisStore← thisConfig← ''
thisIndex← -thisNotInit← 1
thisValues← thisNotes← ''

get_onDefine← {
 thisArguments← Arguments
 thisNotInit← 0= ≢thisStore← parm 'Store' : ⎕prompt 'Store is not specified!'
 thisNotInit← 0= ≢thisConfig← parm 'Config' : ⎕prompt 'Config is not specified!'
 thisNotInit← 0= ≢⎕file thisConfig : ⎕prompt thisConfig, ' is empty!'
 ∊define ''
}

parm← {
 myArg← thisArguments[; 0]⍳ ⊂⍵
 myArg= ≢thisArguments : ''
 ↑thisArguments[myArg; 1]
}

define← {
 btn← 7 Space 'onclick:goClear' Button 'Clear ', thisStore, ' List'
 btn← btn, 21 Space 'onclick:goNote' Button 'Note for:'
 btn← btn, 14 Space 'myItem' 'readOnly=true' Text 42
 cols← 5
 (key lin)← shop thisConfig
 thisValues← makeItem¨ lin
 thisNotes← (⍴thisValues)⍴ ⊂''
 lin← lin {(,⍕⍵) (2↓⍺)}¨ ⍳⍴lin
 tab← cols Columns (⊂'myItems' 'onclick:goCheck') Check¨ lin
 tab← tab⍪ cols Columns (⊂'onclick:goExtra') Button¨ key
 ∆← btn, BR, Table tab
 ∆← ∆, BR, 'myNext' Text 39
 ∆← ∆, 21 Space 'onclick:goRemove' Button 'Remove'
 ∆← ∆, 42 Space 'mySend' 'onclick:goSend' Button 'Send this List'
 ∆← ∆, BR, 'myExtras' 'readOnly=true' Text 33 42
}

makeItem← {
 ⍝Provide clean output with non breaking blanks replacing embedded blanks
 (⎕trim ⍵) ⎕replace  ' ' NBS
}

shop← {
 lin← ⎕file ⍵
 (key lin)← {(⎕trim ⍵) ⎕split LF}¨ lin ⎕split ';'
 key lin
}

get_onLoad← {
 thisNotInit : ''
 0= ≢lin← ⎕file thisConfig, 'Result' : ''
 (myValues myExtras myNotes)← { ⍵ ⎕split TAB }¨ lin ⎕split ';'
 myNotes← myValues { 1 0≡ ≢¨⍺ ⍵ : ⊂'' ⋄ ⍵ } myNotes
 mySelect← (≢thisValues)≠ myIndex← thisValues⍳ myValues
 myChecks← (≢thisValues)⍴ 0 ⋄ myIndex← mySelect/ myIndex
 myChecks[myIndex]← 1 ⋄ myChecks Checks 'myItems'
 thisNotes[myIndex]← mySelect/ myNotes
 myExtras← myExtras, (~mySelect)/ myValues
 0= ≢myExtras : ''
 'myExtras' Values⍨ ⊂myExtras ⎕join ', '
}

get_goClear← {
 thisIndex← ¯1
 MT Values 'myItem'
 0 Checks 'myItems'
 MT Values 'myExtras'
 goSave
}

get_goExtra← {
 0= ≢myNext← next : ''
 myExtras← ↑Values 'myExtras'
 myNext← myNext, (0≠ ⍴myExtras)/', '
 'myExtras' Values⍨ ⊂((2↑ Field 'value'), myNext), myExtras
 goSave
}

get_goRemove← {
 0= ≢myNext← next : ''
 wrap← {' ', ⍵, ','}
 myExtras← wrap ↑Values 'myExtras'
 myExtras← myExtras ⎕replace (wrap myNext) ''
 'myExtras' Values⍨ ⊂1↓¯1↓ myExtras
 goSave
}

get_next← {
 myNext← makeItem ↑Values 'myNext'
 0= ≢myNext : ⎕prompt 'Type in an extra value first!'
 ∨/',;'∊ myNext : ⎕prompt 'No commas or semicolons!'
 MT Values 'myNext'
 myNext
}

get_goNote← {
 thisIndex< 0 : ⎕prompt 'Nothing was just selected!'
 myItem← (thisIndex⊃ thisNotes) ⎕prompt 2↓ thisIndex⊃ thisValues
 thisNotes[thisIndex]← ⊂makeItem myItem
 goSave
}

get_goCheck← {
 FieldNum 'checked' : {
  thisIndex← FieldNum 'value'
  (⊂2↓ thisIndex⊃ thisValues) Values 'myItem'
  goSave
 } ''
 thisIndex← ¯1
 MT Values 'myItem'
 goSave
}

get_goSave← {
 ⍝ NB.  In case VALUE ERROR reemerges
 ⍝ (myValues myExtras myNotes)← current
 ⍝ myStore← (myValues ⎕join TAB), ';', (myExtras ⎕join TAB), ';', (myNotes ⎕join TAB)
 
 myStore← ';' ⎕join ⍨ TAB ⎕join ⍨¨ current
 myStore ⎕file thisConfig, 'Result'
}

get_goSend← {
 (myValues myExtras myNotes)← current
 myItems← (myValues {0= ≢⍵ : ⍺ ⋄ ⍺, '#', ⍵}¨ myNotes), myExtras
 myItems← 2↓¨ myItems[⍋myItems]
 myItems← myItems ⎕join ', '
 myList← 'shopList', 4↓ thisConfig
 0= ≢myItems : myList {⎕drop ⍺ ⋄ ⎕prompt thisStore, ⍵} ' has nothing to send!'
 (myItems, LF, stamp 'Created  ') ⎕file myList
 myAddr← parm 'Addr'
 0≠ ≢myAddr : myItems mail myAddr thisStore
 ⎕edit myList
}

get_current← {
 mySelect← Checks 'myItems'
 myValues← mySelect/ thisValues
 myExtras← (⎕trim ↑Values 'myExtras')⎕split ', '
 myNotes← mySelect/ thisNotes
 myValues myExtras myNotes
}

mail← {
 2≠ ≡⍵ : ⎕prompt 'DOMAIN ERROR'
 ⍵← ⍵, ⊂''
 ⍝      ⍵← 'you@a.com' 'Regarding' ['cc=them@b.org [&bcc=her@c.net]']
 «sendMail(_w.data[0], _w.data[1], _w.data[2], _a)»
 ⍝      ⍺← 'Your message'
}

stamp← {
 «_w.toSimpleString() + new Date().toString()» ↑⍨ 24+ ≢⍵
}
 
⍝  #Editingindicates another copy is down here, to avoid browser edit wiggle
⍝Defineupdateadded thisValues and thisNotes
⍝onLoadupdatethisValues and thisNotes using ⍳ rather than ∊
⍝goChecknewget user notes
⍝currentnewget data for goSave and goSend
⍝goSave    updateget config from thisValues and thisNotes, not HTML
⍝NB. This version gets VALUE ERROR
⍝myStore← (current ¨⎕join TAB)⎕join ';'
⍝goSendupdatedon't goSave, merge thisValues and thisNotes