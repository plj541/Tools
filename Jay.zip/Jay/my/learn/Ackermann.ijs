help=: {{)n
 Ackermann       NB. APL.js version
 timespacex '(i.4) ack/ i.4'
}}

Ackermann=: {{)n
ackermann← {
 ⍝ a classic recursive function
 here← ∆← 1
 ⍺ ({here← 0 {⍺} ∆← ⍵+ 1} ⍣ (0= ⍺)) ⍵
 ⍺ ({here← 0 {⍺} ∆← (⍺- 1) ackermann 1} ⍣ (here∧ 0= ⍵)) ⍵
 ⍺ ({∆← (⍺- 1) ackermann ⍺ ackermann ⍵- 1} ⍣ here) ⍵
 ∆
}

get_Ackermann← {
 (⍳4) ∘. ackermann ⍳5
}
}}

ack=: c1`c1`c2`c3 @. (#.@(,&*))"0
c1=: >:@]                        NB. if 0=x, 1+y
c2=: <:@[ ack 1:                 NB. if 0=y, (x-1) ack 1
c3=: <:@[ ack [ ack <:@]         NB. else,   (x-1) ack x ack y-1
ackm=: (c1`c1`c2`c3 @. (#.@(,&*))M.)"0