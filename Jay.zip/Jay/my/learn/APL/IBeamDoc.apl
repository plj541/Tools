﻿
    'ibe' FUNCTION :  The 'ibe' function is used in old mainframe code
    to replace the even older '⌶' (I-beam) system function.  '⌶' was
    used to generate various pieces of system information, depending on
    its argument.  Calls to 'ibe' can be replaced with direct calls to
    the appropriate modern system functions.  Although I have an unlocked
    version of 'ibe', it needs some conversion itself, and it is far less
    confusing to just use the modern system functions.  A list of
    equivalent expressions for the most common 'ibe' arguments is given
    below (all times are in 60ths of a second):

     '⌶ 19' = 'ibe 19' = '⌊⎕AI[1+⎕IO]÷60' (time 'keyboard has been
                                           unlocked' since sign-on. On
                                           PC, closest equivalent is
                                           time since session start)

     '⌶ 20' = 'ibe 20' = '⌊0.06× 0 60 60 1000 ⊥¯4↑⎕TS'     (time of day)

     '⌶ 21' = 'ibe 21' = Not Valid          (CPU time used on mainframe)

     '⌶ 22' = 'ibe 22' = '⎕WA'          (space available in WS in bytes)

     '⌶ 24' = 'ibe 24' = '⌊0.06× (0 60 60 1000 ⊥¯4↑⎕TS)-⎕AI[1+⎕IO]÷60'
                                                  (time session started)