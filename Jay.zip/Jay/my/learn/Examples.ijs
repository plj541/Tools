help=: {{)n
 Behavior                    NB. How Expressions behave
 ReduceArgs                  NB. With / in J and APL
 Spiral                      NB. Build a spiral by extending tacit
 (o.1) ~:Pi 10000000         NB. Calculate Pi (interesting but poor)
}}

Behavior=: {{)n
 NB. Replacement is done left to right
 'ABCDE' 0 1 2 1 4}'abcdef'  NB. Rightmost duplicate wins
 
 NB. Outer product has proper syntax
 rows +/ cols=. 10 20 30 40 [rows=. 3 5 7
 
 NB. Inner product does not imply Reduction
 (i. 2 3)+/ . * 10* i. 3 4
 
 NB. Scan is a Reduction of a Prefix
 +/ \ i. 2 5
}}

ReduceArgs=: {{)n
NB. _______ J _______

NB. Usage: x verb ForEach yCount yGroups
 y=. |., <"1 (-n) ]\ y
 >u~ &.>/ y, <x

 now=. 'now this cat ate fish'
 now Replace ForEach 2 'cat'; 'dog'; 'fish'; 'stew'; 'now'; 'then'
 
then this dog ate stew

NB. _______ APL2 _______
 
ForEach← {
 pairs← ⌽ (⊂⍤1) ((⍵⍵ ÷⍨ ≢⍵) ⍵⍵)⍴ ⍵
 ⊃⍺⍺⍨ / pairs, ⊂⍺
}

Replace← {
 ⎕← ⍵ ⋄ ⍞← ⍺ ⋄ ⍞
}

 now← 'now this cat ate fish'
 now Replace ForEach 2 ⊢'cat' 'dog' 'fish' 'stew' 'now' 'then'

 cat  dog 
now this dog ate fish
 fish  stew 
now this dog ate stew
 now  then 
then this dog ate stew
then this dog ate stew
}}

Pi=: {{+/ 8% */"1 ((y, 4)% 2)$ 1+ 2* i.y}}

Spiral=: {{)n
 NB. Ulam's Spiral in J, primes form diagonals
 isprime=: (1= #@q:)  NB. YouTube video builds spiral one part at a time
 spiral=: {{ (|.@|: ,~ >./@, + 1 +i.@#)^: y ,.1 }}
  
 ' X'{~ isprime spiral 64   NB. Note primes form diagonals
 
 load'viewmat'
 viewmat spiral
 viewmat isprime spiral 64  NB. Like ASCII ' X' above
 viewmat #@q: spiral 64     NB. Colors for how many factors
}}