help=: {{)n
NB. Two examples from documentation, and a compiled approach
 Ans=. *: y=. 2 7 1 8 2 8 1 8      NB. Using ~. to reduce cost of using expensive verb
 NUB=. {{u@~. +/ . * =}}           NB. https://www.jsoftware.com/help/dictionary/d221.htm
 NUb=. {{(i.~ { u@]) ~.}}          NB. https://code.jsoftware.com/wiki/Vocabulary/tildedot
                                   NB. I could not understand the examples,
 nub=. {{(y i. y){ u ~.y}}         NB. so I wrote an explicit verb
 Do 'Nub=:', Fx '(y i. y){ u ~.y'  NB. Fx provides tacit verbs, adverbs or conjunctions
 NB. Confirm they all get the correct answers
 (Ans-: *: NUB y), (Ans-: *: NUb y), (Ans-: *: nub y), (Ans-: *: Nub y)
}}

caution=: {{)n
*: Nub
NB. A compiled adverb or conjunction will return a tacit
NB. when just their inner argument(s) are provided.
}}

test=: {{)n
 big=:(10000, #big)$big=: 2 7 1 8 2 8 1 8
 100 timex '*: Nub"1 big'
 foo=. {{*: Nub"1 big}}
 foo parsex

 100 timex 'nubSquare"1 big'
 foo=. {{nubSquare"1 big}}
 foo parsex
}}