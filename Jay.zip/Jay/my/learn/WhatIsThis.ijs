
test=: {{
 Say 'y'; y
 if. y=0 do. return. end.
 $: y-1
}}

h=: {{ 
 u {{
  echo 5!:5<'u'
  u y
 }}
:
 u {{
  echo 5!:5<'u'
  x u y
 }}
}}

loop=: {{)n $:@<:^:* h@>: 3}}