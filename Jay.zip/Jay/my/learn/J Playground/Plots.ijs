load 'plot'

help=: {{)n
 rand=. ?50#1000
 plot rand
 'sbar' plot rand
 'line; title Random' plot rand

 plot 1 o. i: 4j10
 'surface' plot +/~ 1 o. i: 4j10
 'surface; title sin 3D' plot +/~ 1 o. i: 25j100
 
 'key sin, cos'plot (sin,: cos) 3.14+ i:3.14j89
}}
