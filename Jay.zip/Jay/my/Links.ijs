help=: {{)n
 Research ''       NB. Updates Links/Research.html
 Jelp ''           NB. Updates Links/Jelp.html
 Subscriptions ''  NB. Updates Links/Subscriptions.html
 Accounts ''       NB. Updates Links/Web/Accounts.html
}}

Jelp=: {{
 keep=: ''
 if. 0 0-: $msg=. Run~ 'data/Links/Jelp' do.
  (;keep, <LF, '</body></html>') File '~Links/Jelp.html'
 else. msg end.
}}

Research=: {{
 keep=: ''
 if. 0 0-: $msg=. Run~ 'data/Links/Research' do.
  (;keep, <LF, '</body></html>') File '~Home/Links/Research.html'
 else. msg end.
}}

Accounts=: {{
 NB. Page of links to multiple sites
 keep=: htmlHead
 Group 'Join'
 Group 'Far'
 Group 'Know'
 Keep htmlLink
 Keep htmlTail
 keep File '~Links/Web/Accounts.html'
}}

Subscriptions=: {{
 NB. Page of subscriptions to Comics, Politics and TV
 keep=: htmlHead Replace '<title>Accounts'; '<title>Subscriptions'
 Group 'Comics'
 Group 'Politics'
 Group 'TV'
 Keep htmlLink
 Keep htmlTail
 keep File '~Links/Subscriptions.html'
}}

Cell=: {{
 'name url plj bfj krj raj'=. 6{. y
 my=. htmlCell
 fix=.   '{NAME}'; name; '{URL}';url
 fix=. fix, '{PLJ}';plj; '{BFJ}';bfj
 fix=. fix, '{KRJ}';krj; '{RAJ}';raj
 cells=: cells, <my Replace ForEach 2 fix
}}

Group=: {{
 NB.  Render cells in y as html table
 try.
  cells=: '   <div style="background-color:LemonChiffon">', y, '</div>'
  cells=: <LF, cells, LF
  Run~ 'data/Accounts/group', y
 catch.
  Say 'Group ', y, ' saw ', dberm ''
 end.
 Keep Rows _
}}

Head=: {{
 head=: '">', LF, y, ' '
 if. 0= #keep do.
  keep=: <'<html><head><meta content="text/html; charset=UTF-8"></head><body>'
 else.
  keep=: keep, <LF, LF, '<hr>', LF
 end.
}}

Keep=: {{
 NB.  keep lines of characters
 keep=: keep, y
}}

Link=: {{
 'link href'=. y
 if. 0= #link do.
  return.
 end.
 keep=: keep, <;LF; '<a href="'; href; head; link; '</a></p>'
}}

Row=: {{
 NB.  Wrap each cell to form a row
 my=. ;WrapCell &.> y  
 <' <tr>', LF, my, ' </tr>', LF
}}

Rows=: {{
 NB.  Number of colums in each row
 col=. 5
 my=. Row"1 (col,~ >.col%~ #cells)$ cells, col$ <''
 cells=: ''
 ;my
}}

WrapCell=: {{
 NB.  Wrap one cell
 if. 0= #y do.
  '  <td width="200"></td>', LF
 else.
  '  <td width="200"><center>', y, '  </center></td>', LF
 end.
}}

htmlCell=: {{)n
<input type="button" value="{NAME}"
 onclick="handleChoice('{NAME}',
 '{URL}',
 '{PLJ}', '{BFJ}',
 '{KRJ}', '{RAJ}')">
}}

htmlHead=: {{)n
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<title>Accounts</title><script type="text/javascript">
var thisPLJ, thisURL, thisBFJ, thisArgs
var thisPJ, thisLink, thisBJ
var thisKRJ, thisRAJ
var thisKJ, thisRJ

function handleLoad(aLink, aPJ, aBJ, aKJ, aRJ) {
 thisPJ= aPJ
 thisLink= aLink
 thisBJ= aBJ
 thisKJ= aKJ
 thisRJ= aRJ
   
 flagEmpty(thisPJ, "")
 flagEmpty(thisBJ, "")
 flagEmpty(thisKJ, "")
 flagEmpty(thisRJ, "")
   
 thisPLJ= thisBFJ= thisKRJ= thisRAJ= " is set when you choose a destination!"
 thisPLJ= "PLJ" + thisPLJ
 thisBFJ= "BFJ" + thisBFJ
 thisKRJ= "KRJ" + thisKRJ
 thisRAJ= "RAJ" + thisRAJ
 thisURL= "home.html"

 thisArgs= window.location.href
 thisArgs= thisArgs.split("?")
 if (thisArgs.length == 2) {
  thisArgs= thisArgs[1]
 } else {
  thisArgs= ""
 }
}

function handleChoice(aLink, aURL, aPLJ, aBFJ, aKRJ, aRAJ) {
 thisLink.value= aLink
 thisURL= aURL
 thisPLJ= aPLJ
 thisBFJ= aBFJ
 thisKRJ= aKRJ
 thisRAJ= aRAJ

 flagEmpty(thisPJ, aPLJ)
 flagEmpty(thisBJ, aBFJ)
 flagEmpty(thisKJ, aKRJ)
 flagEmpty(thisRJ, aRAJ)
   
 if (thisArgs != "Immed=No") {
  handleLink(true)
 }
}

function flagEmpty(aField, aName) {
 if (aName.length == 0) {
  aField.style.backgroundColor = "LightPink"
 } else {
  aField.style.backgroundColor = "LightGreen"
 }
}

function handleFocus(aValue) {
 thisLink.focus()
 prompt("User Name", aValue)
}
 
function handleLink(aTbd) {
 if (aTbd) {
  window.open(thisURL)
 } else {
  window.open('Home.html')
 }
}
</script></head>

<body onload="handleLoad(formLinks.buttonLink,
  formLinks.textPLJ, formLinks.textBFJ,
  formLinks.textKRJ, formLinks.textRAJ)">
 <form name="formLinks" action=""><h2>
 <table border="1" cellspacing="2" cellpadding="6">
}}

htmlLink=: {{)n
<tr><td width="200"><center>
<input type="button" style="font-size:18px"
 name="textPLJ" value=" PLJ " onclick="handleFocus(thisPLJ)" />
</center></td><td width="200"><center>
<input type="button" onclick="handleLink(true)"
 name="buttonLink" value=" T.B.D. ">
</center></td><td width="200"><center>
<input type="button" style="font-size:18px"
 name="textBFJ" value=" BFJ " onclick="handleFocus(thisBFJ)" />
</center></td></tr>
<tr><td width="200"><center>
<input type="button" style="font-size:18px"
 name="textKRJ" value=" KRJ " onclick="handleFocus(thisKRJ)" />
</center></td><td width="200"><center>
<input type="button" onclick="handleLink(false)"
 name="buttonHome" value="Go to Home">
</center></td><td width="200"><center>
<input type="button" style="font-size:18px"
 name="textRAJ" value=" RAJ " onclick="handleFocus(thisRAJ)" />
</center></td></tr>
}}

htmlTail=: {{)n
</table></form></body></html>
}}
