Include '~Jay/PathFind'  NB. Get the public code

help=: help, {{)n     NB. Include my personal searches
 '~Home' PathFind '↗'
 '~Home/ToDo/Texts' PathFind 'KingSize'

 As JPhrase  NB. My suggested definition of Find
}}