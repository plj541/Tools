help=: {{)n
 ASCII                NB.  Display ASCII table 7 bit table
 Ucs 1024* 8          NB.  Display 16 by 64 characters starting at y
 u: 9014+i.2 35       NB.  APL ucs table
 APL ''               NB.  Create APL chars with APL.js style input
 Keyboard ''          NB.  Display APL.js keyboard
}}

Keyboard=: {{)m
 NB. APL.js keymap
 a=.     160  168  175   60 8804   61 8805   62 8800 8744 8743  247  215
 a=. a,  160 9077 8714 9076  126 8593 8595 9075 9675 9055 8592 8594 9024
 a=. a,   32 9082 8968 8970  160 8711 8710 8728  160 9109 8900  160   32
 a=. a,   32 8834 8835 8745 8746 8869 8868 8739 9066  160 9023   32   32
 NB.       0    1    2    3    4    5    6    7    8    9   10   11   12
 A=.    9064 8734 9025 9026 9056 8776 9016 9071 9059 9073 9074 8802 8801
 A=. A, 9017 9081 9079 9060 9069  160 8854 9080 9068 9021 8867 8866 9033
 A=. A,   32 9078  160  160  160 9042 9035 9053  160 9054 9070 9048   32
 A=. A,   32 8838 8839 8916 9062 9038 9045 9015  171  187 8599   32   32
 if. y-: _ do.  NB. Value for APL verb
  (a~: 32)# a=. a, A
 else.  NB. Display version of keymap
  s=. '`1234567890-=qwertyuiop[]\ asdfghjkl;''  zxcvbnm,./  '
  1 0 2|: 3 4 13$ (7 u: A), s, 7 u: a
 end.
}}

APL=: {{
 NB. (7 u: 'a← ⌹?(2⍴ ⍺)⍴ ⍵')-: APL 'a`[ `Q?(2`r `a)`r `w'
 s=.    '`1234567890-=qwertyuiop[]\asdfghjkl;''zxcvbnm,./'
 s=. s, '~!@#$%^&*()_+QWERTYUIOP{}|ASDFGHJKL:"ZXCVBNM<>?'
 if. y-: '' do. y=. Ask 'Prefix APL characters with `' end.
 char=. >:I. esc=. y= '`'
 (-.esc)# (7 u: (s i. char{ y){ Keyboard _) char} y
}}

ASCII=: 3 32$ 32}. a.
COLON=: '꞉'  NB. For : in filename

Ucs =: {{)m
 NB. Display 4 blocks 8 by 32 starting at y
 NB. APL characters are in block 8
 NB. 3 u: y  gives numeric value of usc characters
 u: y+ i. 4 8 32
}}
