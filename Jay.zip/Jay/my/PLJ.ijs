help=: {{)n
 NB. This menu is in help, which is displayed after each Load
 Help                         NB. Provides a base menu
 Lib '~Jay'                   NB. Lists generally useful applications  
 Lib ''                       NB. Lists personal applications
 Dr ''                        NB. Lists folders and files
}}