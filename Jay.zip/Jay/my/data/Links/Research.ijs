Head 'Mountain View'
Link 'City Center'; 'https://images.app.goo.gl/9GazFS6irJCtaQ5d9'

Head 'APL'
Link 'Language Design'; 'http://www.jsoftware.com/papers/APLDesignExercises.htm'
Link 'Functional Geekry'; 'https://www.functionalgeekery.com/episode-65-morten-kromberg/'

Head 'Google'
Link 'Search'; 'http://www.google.com/m?client=tablet-android-samsung&source=android-home'
Link 'Modify eMail Signature'; 'https://plus.google.com/+GoogleDevelopers/posts/SGSCgmQCBKX'
Link 'Android/Windows Common Interface(AWCI)'; 'https://sites.google.com/site/jjtseng93awci/intro/basics'

Head 'Windows 10'
Link 'Went Too Far on Agenda'; 'https://www.extremetech.com/computing/241587-microsoft-finally-admits-malware-style-get-windows-10-upgrade-campaign-went-far'
Link 'Local Login'; 'http://www.makeuseof.com/tag/delete-microsoft-account-create-local-windows-10-login/'
Link 'Recovery Options'; 'https://www.cnet.com/how-to/what-to-do-if-your-windows-10-pc-crashes/?ftag=COS-05-10-aa0a&linkId=25204547'
Link 'Turn Off Update Sharing'; 'https://www.cnet.com/how-to/stop-windows-10-from-using-your-pc-for-file-sharing/?ftag=CAD3c77551&bhid=26844496046119029213139088251683'

Link ''; ''