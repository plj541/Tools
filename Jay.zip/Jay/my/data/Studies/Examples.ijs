1000 '%. y ?@$ */y,4' timex 5000 NB. JKT's timing test

1000 '%. y ?@$ */y,4' timespacex 5000

namespacex 'lines' [lines=: 1000 $,:'   this is a test  '

lines ('result=: x Trim y' parsex) ' '

lines=: 1000 $,:'   this is a test  '

NB. Parsing tacit verbs
lines ('x Trim y' timex) ' '
lines ('result=: x Trim y' parsex) ' '
namespacex 'result'
lines ($@[ ; $@]) result

NB. Parsing explicit verbs
NB. Trim characters at the start
TrimStart=: (4 : 'x#~ -.*./\ x e. y') " 1
NB. Trim characters at the end
TrimEnd=: (4 : 'x#~ -.*./\. x e. y') " 1
NB. Trim characters at the start and end
Trim=: (4 : '(x TrimStart y) TrimEnd y') " 1
lines ('x Trim y' timex) ' '
lines ('result=: x Trim y' parsex) ' '
namespacex 'result'
lines ($@[ ; $@]) result
