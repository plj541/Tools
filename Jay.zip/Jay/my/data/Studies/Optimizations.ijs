NB. Jelp 'c'  NB. Vocabulary/SpecialCombinations

b=: a, 'cat', a, a, 'car', a, a, 'cat', a=: 10000# ' '
c=: 'cat'

'I. c E. b' timespacex _
'c I.@E. b' timespacex _

'+/ c E. b' timespacex _
'c +/@E. b' timespacex _

'a b c'=: ' '
