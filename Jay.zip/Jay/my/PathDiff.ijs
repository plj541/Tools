Include '~Jay/PathDiff'  NB. Get the public code

help=: help, {{)n
 PathDiff '~Jay/my/begin'; '~user'; '/config'  NB. Check backup of my config
 PathDiff '~Compare/@Keep/Jay'; '~Jay'; ''     NB. Jay vs previous stable version
}}