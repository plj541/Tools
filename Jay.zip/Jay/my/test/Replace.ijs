help=: {{)n
 NB. To see timing for just Replace
 NB. time tab OR win

 NB. To create timing tests
 NB. Copy output then   Save ''

 Load 'test/Replace/ForEach'
 Load 'test/Replace/FoldEach'
 Load 'test/Replace/Internal'
}}

time=: {{
 file=. File y
 line=.I. ']R='E. file  
 file=. file{~ line+"0 1 i.50
 file Replace '';~ LF, '   r cmp R'
}}

tab=: {{
 'test/Replace/Android', Name y
}}

win=: {{
 'test/Replace/Win', Name y
}}

Name=: {{
 name=. ;: 'ForEach  FoldEach Internal'
 ;'/', '.txt',~ ;name{~ y
}}