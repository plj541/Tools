help=: 0 Def
 test  NB. Examine significance of order in rplc
)

test=: 0 Def
NB. In rplc sometimes order of argument pairs is not important
t=. '(x<1){ &.> y'
o1=. <;._1 '|&|&amp;|<|&lt;|>|&gt'
[h=. t rplc o1  NB. (x&lt;1){ &amp;.&gt y

o2=. 2|. o1
h-: t rplc o2  NB. (x&lt;1){ &amp;.&gt y

ot=. |. o1
t-: h rplc ot  NB. (x<1){ &.> y

ot=. |. o2
t-: h rplc ot  NB. (x<1){ &.> y

NB. But order in the rplc pairs can matter
t=. 'this a is a a test. '
o=. <;._1 '|th|Th|his|andy| a | '
t rplc o  NB. This is a test.  

o=. <;._1 '|his|andy| a | |th|Th'
t rplc o  NB. tandy is a test. 
)