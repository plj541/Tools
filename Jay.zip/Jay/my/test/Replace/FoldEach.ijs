Copy 'test/Replace/ForEach'

ForEach=: {{
 NB. This hides ForEach_plj_
 NB. Usage: leftVerb ForEach eachSize multipleEachSizeArgs
 x ] F.. (u~) (-n)]\ y
}}

Save=: {{
 '~Down/FoldEach.txt' File~ 0 Del  NB. First copy screen
}}
