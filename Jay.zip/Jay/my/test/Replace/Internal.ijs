Copy 'test/Replace/ForEach'

Replace=: {{
 NB. This hides Replace_plj_
 NB.    Usage: text Replace old; new
 NB. Multiple: text Replace ;:'this that these those'
 if. 1= #$y do. y=. y$~ 2,~ 0.5* #y end.
 for_now. y do.
  'old new'=. now
  where=. x noOverlap_pj_ old
  if. #where do.
   if. 1 1-: #&> old; new do.
    x=. x where}~ {.new
   else.
    x=. ;(x{.~ {.where); (#old) new &,@}. &.> where indexCut_pj_ x
   end.
  end.
 end.
 x
}}

Save=: {{
 '~Down/Internal.txt' File~ 0 Del  NB. First copy screen
}}