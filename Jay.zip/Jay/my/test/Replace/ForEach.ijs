help=: {{)n
 Do &.> testOne; testMany
}}

cmp=: {{
 if. x< y do.
  '    rplc by ', 0j8": y% x
 else.
  ' Replace by ', 0j8": y%~ x
 end.
}}

copies=: {{ y $~ x*#y }}

testOne=: {{)n
NB. Four times focused on size of old and new
t=: 10000 copies 'this a is a a test. '
s=: <;._1 '| a |;' NB. Shorter new
(t rplc s)-: t Replace s
]r=. 10 timex 't rplc s'
]R=. 10 timex 't Replace s'
r cmp R

e=: <;._1 '| a |[A]' NB. Equal size new
(t rplc e)-: t Replace e
]r=. 10 timex 't rplc e'
]R=. 10 timex 't Replace e'
r cmp R

l=: <;._1 '| a |[ A ]' NB. Longer new
(t rplc l)-: t Replace l
]r=. 10 timex 't rplc l'
]R=. 10 timex 't Replace l'
r cmp R

un=: 'as' NB. Unboxed
(t rplc un)-: t Replace un
]r=. 10 timex 't rplc un'
]R=. 10 timex 't Replace un'
r cmp R
}}

testMany=: {{)n
NB. repl takes multple pairs, ForEach extends Replace instead
t=: 10000 copies 'this a is a a test. '
c=: <;._1 '|his|hanks| a | |t|T'
(t rplc c)-: t Replace ForEach 2 c
]r=. 10 timex 't rplc c'
]R=. 10 timex 't Replace ForEach 2 c'
r cmp R

un=: 'as _iI' NB. Unboxed
(t rplc un)-: t Replace ForEach 2 un
]r=. 10 timex 't rplc un'
]R=. 10 timex 't Replace ForEach 2 un'
r cmp R

NB. A contrived example, more like my real usage
NB. First convert to html
a=: 10000 copies '(now>:low)&(now<:hi)', LF
ca=: <;._1 '|&|&amp;|<|&lt;|>|&gt;|',LF,'|<br>'
(a rplc ca)-: a Replace ForEach 2 ca
]r=. 10 timex 'a rplc ca'
]R=. 10 timex 'a Replace ForEach 2 ca'
r cmp R

NB. Now convert from html
h=: a Replace ForEach 2 ca
ch=: |. ca  NB. Reversing the argument reverses the changes
(h rplc ch)-: h Replace ForEach 2 ch
]r=. 10 timex 'h rplc ch'
]R=. 10 timex 'h Replace ForEach 2 ch'
r cmp R

NB. Ensure reversing got back the original
(a-: h rplc ch), a-: h Replace ForEach 2 ch
}}

Save=: {{
 '~Down/ForEach.txt' File~ 0 Del  NB. First copy screen
}}
