help=: 0 Def
 Test trims    NB. Trim, TrimStart and TrimEnd
 Test replace  NB. Replace and ForEach
 Test split    NB. Split and Join
 Test starts   NB. StartsWith and EndsWith
)

Test=: 3 Def
 (3 def y) Say y
 'Test complete'
)

trims=: 0 Def
 ans=. 4 4$ 'this' [tst=. 4 6$ 'this  '
 assert. ans-:        tst Trim ' '
 assert. ans-:  4{."1 tst TrimStart ' '
 assert. ans-: _4{."1 tst TrimEnd ' '
)

replace=: 0 Def
 assert. Tools-: (Tools Replace 'in'; 'xxx') Replace 'xxx'; 'in'
 assert. Tools-:  Tools Replace ForEach 2 ;: 'in xxx xxx in'
 tst=. LF, 'X'
 assert. Tools-: (Tools Replace tst) Replace |.tst
 assert. Tools-:  Tools Replace ForEach 2 tst, |.tst
)

split=: 0 Def
 assert. Tools-: LF Join ~Tools Split LF
 assert. Tools-: 'Code' Join ~Tools Split 'Code'
)

starts=: 0 Def
 tst=. ' madam im adam '
 assert. 1-: tst StartsWith ' ' 
 assert. 0-: tst StartsWith 'm'
 assert. 1-: tst StartsWith ' mad'   
 assert. 0-: tst StartsWith ' md'
   
 assert. 1-: tst EndsWith ' '
 assert. 0-: tst EndsWith 'm'
 assert. 1-: tst EndsWith 'dam '
 assert. 0-: tst EndsWith 'dm '
)
   
