help=: {{)n
 111 Do test  NB. Test fileName_pj_ including deliberate errors
}}

test=: {{)n
 NB. Errors are deliberate, that is what we are testing
 my=. 'Load'
 my fileName_pj_ ''
 my fileName_pj_ 'now'
 my fileName_pj_ 'now.ijs'
 my fileName_pj_ 'now.txt'  NB. Error
 my fileName_pj_ 'now.htm'  NB. Error
 my fileName_pj_ '.now'
 my fileName_pj_ 'now.'     NB. Error

 my=. 'Note'
 my fileName_pj_ ''
 my fileName_pj_ 'now'
 my fileName_pj_ 'now.txt'
 my fileName_pj_ 'now.ijs'  NB. Error
 my fileName_pj_ 'now.htm'  NB. Error
 my fileName_pj_ '.now'
 my fileName_pj_ 'now.'     NB. Error

 my=. 'Edit'
 my fileName_pj_ ''
 my fileName_pj_ 'now'      NB. Error   
 my fileName_pj_ 'now.txt'
 my fileName_pj_ 'now.ijs'
 my fileName_pj_ 'now.htm'
 my fileName_pj_ '.now'     NB. Error
 my fileName_pj_ 'now.'     NB. Error
}}