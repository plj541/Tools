help=: 0 Def
 helpExamples  NB. Examples of typical usage
 test ''       NB. Begin by exploring the uses of Pax
)

helpExamples=: 0 Def
NB. Set and then use local nouns
 Names ''
 setLocals ''
 useLocals ''
 Names ''

NB. My typical usage before and after a noun saving test
 b4Test__PS=: ". Pax NL~ ''  NB. Get all nouns
 Save ''
 Reload ''
 a5Test__PS=: ". Pax NL~ ''  NB. Get current nouns
 b4Test__PS-: a5Test__PS    NB. Confirm they are identical, or
 (>}.b4Test__PS)#~ }. b4Test__PS~: a5Test__PS  NB. Find what changed
 
 NB. You can also get all global names, by replacing
 NB. ". Pax NL~ ''    with    DEF Pax NL~ ''
 NB. Other steps are the same except for finding what changed
 'b4Nouns__PS b4Verbs__PS'=: b4Test__PS  NB. See Defns for examples
)

Out=: 3 Def
 NB. modify y to avoid multiple quotes
 y Replace '´'; ''''  NB. Replace Acute with ASCII '
)

NB. Assign some global nouns
 'my off on'=: 1 2 3; (;:'fleas & ticks'); 2000+ i. 2 3
 'my1 o2'=: 1000+ i. 2  NB. Same names as some locals

test=: 3 Def
 NB. Pax example usage
 'my0 my1 o2 o3 mine'=. 100+ i. 5
 Say It ". Out ' ". Pax NL ´´      NB. Include all locals and their values'
 Say It ". Out ' ". Pax NL ´my´    NB. Include locals beginning my and their values'
 
 Say It ". Out '(". Pax NL)~ ´´    NB. Include all globals and their values'
 Say It ". Out '(". Pax NL)~ ´my´  NB. Include globals beginning my and their values'
)

setLocals=: 3 Def
 'myWas myNow myThis myThat man woman'=. 300+ i. 6 3 2
 keepApp__PS=: ". Pax NL 'my'
)

useLocals=: 3 Def
 (>{.keepApp__PS)=. }.keepApp__PS
 myThat; myWas
)
