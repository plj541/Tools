help=: 0 Def
 Do test
)

test=: 0 Def
 $utf8=. 'cb鲨a' 
 ]test1=: 2 5$ utf8
 
 a.i.": test1
 233 178 168{ a.
 233 178{ a.   
 <test1
 a.i.": <test1
 
 $utf8=. 'cఝa'
 ]test2=: 2 6$ utf8
 
 a.i.": test2
 a.i.": <test2
 
 $utf8=. 'a¡b'
 ]test3=: 2 5  $ utf8
 
 a.i.": test3
 a.i.": <test3
)

ae=: '⍺¡!'
aw=: '⍺¡⍵'

u_7=: 3 Def
 if. 2~: 3!:0 y do. y return. end.
 _ u_7"1 y
:
 y=. a. i. y
 4 u: ,y U_7 ;.1~ [1 (0)} y>: 192
)

U_7=: 3 Def
 if. ({.y)>: 2b11000000 do.
  count=. 2+ +/ ({.y)>: 2b11100000 2b11110000 2b11111000
  rest=. U_7 count}. y
  y=. count{. y
  if. +./ 128> }.y do. rest,~ 16bfffd return. end.
  if. +./ 192< }.y do. rest,~ 16bfffd return. end.
  select. count 
   case. 2 do. rest,~ 64#. y- 2b11000000 128
   case. 3 do. rest,~ 64#. y- 2b11100000 128 128
   case. 4 do. rest,~ 64#. y- 2b11110000 128 128 128
   case.   do. rest,~ 16bfffd
  end.
 else.
  16bfffd (I. y>127) } y
 end.
)