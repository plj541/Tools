br=. 3 Def
 NB. [Result]
 '[', ']',~ y
)

 a=:'   this  is   a  test  '
 br a Trim ' '
 br a TrimEnd ' '
 br a TrimStart ' '
 
 [mat=: >;._1 '/how is,  /that  One,  /there    '
 }.; (LF,. mat) <@TrimEnd"1 ' '
 (<"1 mat) TrimEnd&.> ' '

delmb=: ((#~ -.) '  '&E.)"1 
 <&delmb mat
 
dmb=: 3 Def"1
 NB. Delete Multiple Blanks
 y#~ -.'  'E. y
)
