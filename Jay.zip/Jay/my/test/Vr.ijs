t=: {{)a
 DEF 'a'
 Vr 'a'
}}

NB. Verbs
a=: {{
 a. i. y
}}
]t

a=: {{
 a. i. y
:
 x i. y
}}
]t

a=: {{
 x i. y
}}
]t

a=: +

NB. Adverb
a=: {{)a
 u / y
}}
]t
  
a=: {{)a
 u / y
:
 x u / y
}}
]t

a=: {{)a

 x u / y
}}
]t

a=: /

NB. Conjunctions
a=: {{)c
 u / y
}}
]t
  
a=: {{)c
 u / y
:
 x u / y
}}
]t

a=: {{)c
 x u / y
}}
]t

a=: "