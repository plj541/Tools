NB. Add Performance Measures not already in z

cocurrent 'z'
helpPM=: {{)n
 Iam ''                NB. What this locale can see
 timespacex '???'      NB. Space to execute sentence,~ timex results
 10 timex '???'        NB. Seconds to execute equation, repetition x gives average
 namespacex '???'      NB. Space taken by item named
 parsex '???'          NB. Number of times parser used
 Load 'code/PerfMeas'  NB. Saved examples of Performance Measuring
 Load 'code/PerfMon'   NB. Detailed Performance Monitoring
}}

Iam=: {{
 NB. Where am I, and what do I see?
 iSee=. iSee; <18!:2 [iSee=. 18!:5 ''
 if. #y do. yType=. y; type y
  if. 0~: 4!:0 <y do. iSee, <yType
  else. iSee, <yType, <datatype ".y end.
 else. iSee end.
}}

namespacex=: {{
 7!:5 }.'';y
}}

parsex=: {{
 NB. How many times was the line parsed
 be4=. 1+ 6!:4 ''
 u ''
 be4-~ 6!:4 ''
}}
cocurrent 'base'