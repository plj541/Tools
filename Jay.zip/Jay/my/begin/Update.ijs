'~config/apl385.ttf'  fwrite~ fread '/sdcard/Documents/Jay/my/begin/config/apl385.ttf'
'~config/display.css' fwrite~ fread '/sdcard/Documents/Jay/my/begin/config/display.css'
'~config/folders.cfg' fwrite~ fread '/sdcard/Documents/Jay/my/begin/config/folders.cfg'
'~config/startup.ijs' fwrite~ fread '/sdcard/Documents/Jay/my/begin/config/startup.ijs'
