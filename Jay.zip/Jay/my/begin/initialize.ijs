NB. Load my Tools into plj
 load '~Jay/Tools.ijs'                   NB. load the development code
 
NB. Set preferences
{{
 try.
  9!:7  '+++++++++|-'
  
  if. UNAME-: 'Android' do.
   wd 'setj smfont @apl385 18'
   load '~Jay/tools/Android.ijs'
  end.
  
  1!:44 jpath '~Jay/my'
 catch. Say dberm '' end.

 Say Load 'Start'
}} _
