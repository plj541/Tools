NB. Load my Tools into plj
 load 'pacman'                           NB. Page requires httpget_jpacman_
 load '~Jay/Tools.ijs'                   NB. load the development code
 
NB. Set preferences
{{
 try.
  9!:11 [6
  9!:37 [0 256 120 6
  9!:7  '+++++++++|-'

  if. UNAME-: 'Android' do. wd 'setj smfont @apl385 18'
   if. APILEVEL_ja_> 29 do.  NB. From Android 11 "am start" is not supported
    xedit_j_=: {{ Launch_plj_ y }}
    browse_j_=: {{ Launch_plj_ y,~ 'file://'#~ '/'= {.y }}
   end.
  end.
  
  1!:44 path_pj_ '~Jay/my'
 catch. Say dberm '' end.
 Include &> <;._2 {{)n
begin/]zTools
begin/]Extras
begin/]Cmds
}}
 Say Load 'PLJ'
}} _
