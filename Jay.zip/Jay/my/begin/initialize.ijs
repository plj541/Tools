NB. Load my Tools into plj
 load 'pacman'                           NB. Page requires httpget_jpacman_
 load '~Jay/Tools.ijs'                   NB. load the development code
 
NB. Set preferences
{{
 try.
  9!:11 [6
  9!:37 [0 256 120 6
  9!:7  '+++++++++|-'

  if. UNAME-: 'Android' do. wd 'setj smfont @apl385 18'
   if. APILEVEL_ja_> 29 do.  NB. From Android 11 "am start" is not supported
    xedit_j_=: {{ Launch_plj_ y }}
    browse_j_=: {{ Launch_plj_ y,~ 'file://'#~ '/'= {.y }}
    
    NB. Alternately, warn against using unsupported verbs
    NB. Tools_plj_=: Tools_plj_ Replace ForEach 2 <;._1 ';Code Note;C̶o̶d̶e̶ N̶o̶t̶e̶;Edit;E̶d̶i̶t̶;Browse;B̶r̶o̶w̶s̶e̶'
    NB. Say 'NB. Code, Note, Edit and Browse not supported in this Android version'
   end.
  end.
  
  1!:44 path_pj_ '~Jay/my'
 catch. Say dberm '' end.
 NB. Feel free not load any or all of these additional tools
 Include &> <;._2 {{)n
begin/]zTools
begin/]Extras
begin/]Cmds
}}
 Say Load 'PLJ'
}} _
