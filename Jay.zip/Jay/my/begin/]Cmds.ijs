{{)n
Everything here should be in _plj_, unless otherwise indicated
 ]io is the principal actor in this file:

Several things work as normal:
 Because it is running from a locale,
  normal input and output, Load, Copy, Save all without issue
 J syntax makes finding assignment easy
 ] at beginning of line indicates monadic verb with character argument
 Most screen output is actually results, so is captured in output log
 Input log is easily captured from output log

Some issues with use remain:
 Do (0!:101) creates output without returning values,
  so result isn't in output log
 Creating multiline values doesn't work
}}

cocurrent 'plj'
io=: {{
 u guard_pj_~ _  NB. Arguments without quotes
 LOG_pj_ fappend~ LF, '§ Session ', 6!:0 'YYYY/MM/DD hh:mm:ss'
 Ask=. {{y [LOG_pj_ fappend~ (LF,'¶ '), y=. ' 'Trim~ 1!:1 [1}}

 while. 1 do.try.
  select. tolower ;2{. part=. ;:ioLine_pj_=: line=. Ask ''
  case. '';,']'  do. Say ']q  NB. To leave, ]h to learn more'
  case. ']io' do. Say 'Already, io is'
  case. ']q' do. 'Done, are we' return.
  case. ']h' do. Say ioHelp_pj_
  case. ']debug' do. Say 'In here, cannot'
  case. ']nm';']names' do. Log Names ".(}.part) ioArg_pj_ line 
  case. ']lo';']load' do. Log Load (}.part) ioArg_pj_ line
  case. ']kp';']copy' do. Log Copy (}.part) ioArg_pj_ line
  case. ']li';']lib' do. Log Lib (}.part) ioArg_pj_ line
  case. ']lm';']libs' do. Log Libs ''
  case. ']ll';']wsid' do. Log fileName_pj_ 'Load'
  case. ']il' do. Log ioIn_pj_ (}.part) ioArg_pj_ line
  case. do.
   if. ']'= ;{.part do.  NB. For ], everything after verb is quoted
    Log ".line=. (;2{.part), ' ', quote(}.part)ioArg_pj_ line    
   elseif. '@'= ;{.part do. Log ioJA_pj_ }.line   NB. Help using TryAPL
   else.if. ({.}.part)e. '=.'; '=:' do. ".line    NB. Assignment doesn't display
        else. Log ".line end.end.                 NB. Others do display
  end.
 catch. Log {{}.(<./y i. ':', LF){.y}} 13!:12 '' end.end. 'Done, I am'
}}

Log=: {{
 NB. Say with append to today's log
 empty LOG_pj_ fappend~ LF, displayUnboxed_pj_ y
 if. #y do. y 1!:2 [2 end.
}}

LOG_pj_=: path_pj_ '~temp/io', 6!:0 '_YYMMDD.log'
INL_pj_=: path_pj_ '~temp/in.cmd'

ioHelp_pj_=: }:{{)n
 ]nm               NB. Names
 ]lo               NB. Load
 ]kp               NB. Copy
 ]li               NB. Lib
 ]lm               NB. Libs
 ]ll               NB. Last Load
 ]il               NB. Input Log (for today)
 ]anyVerb my word  NB. Evaluates:  anyVerb 'my word'
}}

ioArg_pj_=: {{ ' 'TrimStart~ y}.~ (#cmd)+ {.cmd I.@E. y [cmd=. ;{.x }}

ioIn_pj_=: {{
 NB. Return the unique input in today's log
 if. ''-: y do. log=. LOG_pj_
 else. log=. '.log',~ y,~ LOG_pj_}.~ -4+ #y end.
 log=. File log
 cmd=. I. log E.~ LF, '¶ '
 cmd=. (log, 234# LF){~ cmd+/ 4+i.230
 len=. cmd i."1 LF  NB. {{<x{. y}}
 cmd=. ~.ioIgnore_pj_, len ([:<{.) "0 1 cmd
 INL_pj_ File~ LF Join~ cmd=. |.cmd}.~ #ioIgnore_pj_
 LF Join~ cmd{.~ 12<. #cmd
}}

ioTest_pj_=: {{
  if. ''-: y do. 'Test'
  elseif. fexist 'Test.ijs' do. 'Test, there is .ijs'
  elseif. fexist y=. y, '.ijs' do. 'Test.ijs' File~ File y
  else. y end.
}}

ioIgnore_pj_=: <;._2 {{)n

]
]q
]h
]io
]in
}}

ioJA_pj_=: {{
 j=.    '=. =: _  x  y  m  u  n  v  #  $  e. i. {. }. *  %  ^  [  ]  ". ": #. #:'   
 a=.    '←  ←  ¯  ⍺  ⍵  ⍺⍺ ⍺⍺ ⍵⍵ ⍵⍵ ≢  ⍴  ∊  ⍳  ↑  ↓  ×  ÷  *  ⊣  ⊢  ⍎  ⍕  ⊥  ⊤ '  
 j=. j, '-: *. +. >: <: ~: -. *: +: >. <. E. I. o. ^. %. /: \: ,  ,. |. |: /  \  ~ " each'
 a=. a, '≡  ∧  ∨  ≥  ≤  ≠  ~  ⍲  ⍱  ⌈  ⌊  ⍷  ⍸  ○  ⊛  ⌹  ⍋  ⍒  ⍪  ,  ⊖  ⍉  ⌿  ⍀  ⍨ ⍤ ¨'
 (j=. ;: j),: a=.' 'Split~ a#~ -. a E.~'  ' [apl=. ;:y
 if. 'NB.'-: 3{.;{:apl do. apl=. (}:apl), <'⍝', 3}. ;{:apl end.
 for_i. i.#j do.
  apl=. apl (I. apl= i{j)}~ i{a
 end.
 apl Join ' '
}}

Args=: {{
 NB. Config file format:  names LF value1 LF value2 etc
 args=. <;._2 LF,~ File 'config/',y,'.cfg'
 if. (#args)~: >:#;:;{.args do. ^'File damaged' end.
:
 if. (#x=. }.0; x)= <:#args=. Args y do.
  (LF Join~ x,~ {.args) File 'config/', y, '.cfg' return. end.
 (quote y), ' Args~ ', '  NB. Press Enter after updating',~ '; ' Join~  quote &.>}.args
}}

guard_pj_=: {{)a
 NB. Guarded verbs should not be in a system locale
 if. (18!:5 '') e. ;:'plj pj z j' [y do. ^'Not in a system locale' end.
 if. (,']')-: 5!:5&<'u' do. m=. i.0 0 else. ^']command please' end.
:
 NB. Check for command prefix
 if. (,']')-: 5!:5&<'u' do. m=. i.0 0 [y else. ^']command please' end.
}}

cocurrent 'base'
