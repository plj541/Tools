cocurrent 'plj'

{{)n
 My personal toolkit loaded into _plj_
 Launch ''  NB. Needed on Android to make Edit and Browse work
 Libs ''    NB. Lib with several directories
 Lrc ''     NB. List files last used by several verbs
 How ''     NB. Notes on how to do things
 Iam ''     NB. What locals does name search utilize
}}

Launch=: {{
 NB. Send file name to DroidScript Launch
 wd 'clipcopy *', y [was=. wd 'clippaste'
 0 0$Say 'Start Android Launch app!'
 while. -.':*?'-: wd 'clippaste' do. 6!:3 [2 end.
 wd 'clipcopy *', was
}}

Libs=: {{
 NB. Look at my libraries
 line=. {{LF, '   ', y, LF, ".y}} 
 now=. line {{)nLib ''}}
 now=. now, line {{)nLib 'code'}}
 now=. now, line {{)nLib 'test'}}
 now=. now, line {{)nLib '../demos'}}
    }. now, line {{)nAcross '' Dirs 'data'}}
}}

Lrc=: {{
 NB. File names and who used them
 top=. 'Users'; 'Current File',~ ' '#~ 0>. _6+<.-: >./ #&> FILES_pj_
 Unbox top, VERBS_pj_,. }: FILES_pj_
}}

Folders=: {{
 Unbox UserFolders_j_
:
 Unbox SystemFolders_j_
}}

NB. Prepare for user interaction

Tools=: Tools, {{)n
   Code 'begin/]Extras'       NB. ]io Folders Iam Lrc
}}  

Help=: {{)n
 jpkg ''                      NB. Command line Package Manager
 Load '~Jay/tools/Build'      NB. Update Tools
 Load 'code/Rebuild'          NB. Which tells you how
 Load 'PathFind'              NB. Find files in path x containing y
 Load 'PathDiff'              NB. Find different files between paths x and y
}}

Def=: : 0                     NB. For old code

cocurrent 'base'
