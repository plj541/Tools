cocurrent 'plj'

{{)n
 My personal toolkit loaded into _plj_
 Launch ''  NB. Needed on Android to make Edit and Browse work
 Libs ''    NB. Lib with several directories
 Jelp 'n'   NB. Fast navigation to J help, see: o l r c m
 Lrc ''     NB. List files last used by several verbs
 How ''     NB. Notes on how to do things
 Iam ''     NB. What locals does name search utilize
 Jbr ''     NB. Direct session to browser, see: Links/Jay
 2 Base 42  NB. Provide J version of base numbers
}}

Launch=: {{
 NB. Send file name to DroidScript Launch
 wd 'clipcopy *', y [was=. wd 'clippaste'
 0 0$Say 'Start Android Launch app!'
 while. -.':*?'-: wd 'clippaste' do. 6!:3 [2 end.
 wd 'clipcopy *', was
}}

Libs=: {{
 NB. Look at my libraries
 line=. {{LF, '   ', y, LF, ".y}} 
 now=. line {{)nLib ''}}
 now=. now, line {{)nLib 'code'}}
 now=. now, line {{)nLib 'test'}}
 now=. now, line {{)nLib '../demos'}}
    }. now, line {{)nAcross '' Dirs 'data'}}
}}

Jelp=: {{
 Browse '~Links/Web/Jelp.html'
}}

Lrc=: {{
 NB. File names and who used them
 top=. 'Users'; 'Current File',~ ' '#~ 0>. _6+<.-: >./ #&> FILES_pj_
 Unbox top, VERBS_pj_,. }: FILES_pj_
}}

How=: {{
 NB. Document areas
 if. y-: 2 do. {{' How ''', '''',~ }. _4}.y}} &> '.txt' Files 'data/How2/_'
 else. File 'data/How2/_', y, '.txt' end.
:
 NB. Save a Last note  Last~'tests'
 'Sink' editFile_pj_ 'data/How2/_', (toupper {.y), }.y=. y, '.txt'
}}

Base=: {{
 NB. Numbers from characters
 _ "."1 y
:
 NB. Numbers to characters as base x, 2 thru 16
 num=. (' ', 'b',~ ":x),"1 x ('0123456789abcdef' {~ [ #.^:_1 ]) y
 if. ''-: $y do. num
 else. (,num)$~ (_2}.$num), */_2{.$num end.
}}

Folders=: {{
 Unbox UserFolders_j_
:
 Unbox SystemFolders_j_
}}

NB. Prepare for user interaction

NB. WIDTH_pj_=: 80

Tools=: Tools, {{)n
   Code 'begin/]Extras'       NB. ]io Base Folders Iam Jelp Lrc
}}  

Help=: {{)n
 jpkg ''                      NB. Command line Package Manager
 Load '~Jay/tools/Build'      NB. Update Tools
 Load 'code/Rebuild'          NB. Which tells you how
 Load 'PathFind'              NB. Find files in path x containing y
 Load 'PathDiff'              NB. Find different files between paths x and y
}}

Def=: : 0                     NB. For old code

cocurrent 'base'
