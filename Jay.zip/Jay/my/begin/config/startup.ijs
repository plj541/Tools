NB.  initialize and help debugging
INIT=: '~Jay/my/begin/initialize.ijs'

help=: {{)n

 help                    NB. To see this list again
 dbr 0                   NB. To end debugging in this session
 dberm ''                NB. To see the last error message 
 load INIT               NB. To begin debugging this session
}}

{{
 try. load INIT
 catch. echo LF, (dberm ''), help end.
}} _
