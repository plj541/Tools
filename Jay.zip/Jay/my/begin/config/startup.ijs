NB.  load initialize or prepare for debugging
INIT=: '~Jay/my/begin/initialize.ijs'

help=: {{)n
 help                 NB. To see this list again
 '~config/DebugNo' frename '~config/Debug'  NB. To stop future debugging
 dbr 0                   NB. To end debugging in this session
 dberm ''                NB. To see the last error message 
 load INIT               NB. To begin debugging this session
}}

{{
 if. y do. dbr 1 [help 1!:3 [2
 else. load INIT end.
}} fexist '~config/Debug'
