help=: {{)n
 NB. results contain every character in y
 (>Chars 'aeiouy'); (>Chars 'aeiouw'); (>Chars 'aeiouwy')
 NB. Each duplicate in an argument requires an additional duplicate in result
 (>Chars 'eeee'); (>Chars 'eeeee')
 Phrase 'noise'           NB. results contain the phrase in y
}}

Chars=: {{
 NB. Results contain every character in y
 unique=. ~.y
 found=. wordList#~ wordList ([:*./ e.)&> ~<unique
 if. unique-: y do. return. end.
 NB. Find duplicates
 duplicates=. unique#~ keep=. 1~: count=. +/y=/ unique
 countChars_pj_=. keep# count
 find=. 13 : '*./countChars_pj_<: +/x=/ y'
 found#~ found find&> <duplicates
}}

Phrase=: {{
 NB. results contain the phrase in y
 wordList#~ +./"1 wordList E.&>~ <y
}}

{{
 NB. Get the word list
 wordList=: <;._2 File 'data/Words/Words.txt'
}} ''