Loads=: {{
 NB. What scripts have been loaded
 >4!:3 ''
}}

Mkdir=: {{
 NB. Assumes x exists, those directory levels are not traversed
 mkdir=: [: 1!:5 <
 dirs=. dirs#~ a:~: dirs=. y Split '/' [x=. Path x
 try.
  for_dir. dirs do.
   x=. x, '/', >dir 
   if. 0= fexist x do.
    mkdir x
   end.
  end.
 catch. 'Unable to make ', x
 end.
}}

Move=: {{
 NB.  aFrom and aTo must be fully formed ending in /
 'aFrom aTo aSearch'=. y
 myFiles=. '' Files aFrom, aSearch
 if. ''-: myFiles do. '' return. end.
 (<2{. y) Move &> myFiles
:
 'aFrom aTo'=: x
 (aTo, y) frename aFrom, y
}}
