help=: {{)n
 NB. Create a noun with lines to be monitored
 NB. perfMonitor yourLines      NB. Will monitor entry and exit to named methods
 NB. perfLines yourLines        NB. Will also monitor lines within methods
 NB. perfMonitor~ or perfLines~     will not stop on errors in script
 perfTimes ''                   NB. See results of either test
}}

perfMonitor=: {{
 '' perfMonitor y               NB. Dyadic will not stop on error
:
 (6!:10) (40+56e6)$' '          NB. Performance Monitor Data, named methods
 y perfMon~ 111 101{~ x-: ''
}}

perfLines=: {{
 '' perfLines y                 NB. Dyadic will not stop on error
:
 1 0 (6!:10) (40+56e6)$' '      NB. Performance Monitor Data, including internal lines
 y perfMon~ 111 101{~ x-: ''
}}

perfMon=: {{
 (6!:12) 1                      NB. Turn on PM
 msg=. 'Done'
 NB. try.
 x Do y                    NB. Do user's lines
 NB. catch. msg=. dberm '' end.     NB. Do can also not stop for errors
 (6!:12) _1                     NB. Turn off PM
 msg
}}

perfTimes=: {{
 Say Unbox(;: 'lines toss max rec lost PM'),. <"0 (6!:13) ''
 'nameOf localeOf valenceOf lineOf spaceOf timeOf namesOf'=. i. 7
 names=.>>namesOf{ now=. 6!:11 ''
 names=. names{~ >nameOf{ now
 lines=. >lineOf{ now
 times=. ({.times)-~ times=. >timeOf{ now
 times=. (2 -~/\ ]) 0, times
 names,. 4 13j9": lines,. times
}}

timeUnpack=: {{)n
 Unpack the PM data, resulting in a boxed vector of data columns:
 0  name
 1  locale where name is found
 2  valence
 3  line number (_1 for entry; _2 for exit)
 4  space in use (bytes)
 5  time (seconds)
 6  list of names

 y are indices of the rows to be unpacked,
 where 0 is the oldest row (and _1 is the newest row).
 All rows are selected if y is the empty vector.
 Rows in the result are always arranged from oldest to newest
 and no row is selected more than once.
}}
