help=: {{)n
 Backup ''   NB.  Convert personal workspaces and files
 Public ''   NB.  Convert public workspaces and files
 Prelude ''  NB.  Convert prelude for inclusion into apl.js
}}

Backup=: {{
 aSet=. '' Files backup, 'Code '
 aSet backupencodeJSA &.> <backup; user
 aSet=. '' Files backup, 'File '
 aSet backupencodeJSA &.> <backup; user, 'File/'
 saved 'Config'
 'Done'
}}

backupencodeJSA=: {{
 'in out'=. y
 xType=. 5{. x
 xIn=. _4}. x
 xOut=. 5}. xIn
 js=. 'jsLoad("', xType, '", "', xOut, '", ', (encodeJS in, xIn), ')' 
 js File out, xOut, '.jsa' 
}}

encodeJS=: {{
 NB. Encode .apl into .js
 js=. File y, '.apl'
 js=. js Replace '\'; '\\'
 if. >/ CRLF e. js do.
  js=. js Replace ForEach 2 '"'; '\"'; CR; '\n'
 else.
  js=. js Replace ForEach 2 '"'; '\"'; LF; '\n'; CR; ''
 end.
 js=. '"', js, '"'
}}

Public=: {{
 now=. 'var _LIB_ = {}', LF
 now=. now, 'Dates' js public
 now=. now, 'Examples' js public
 now=. now, 'Host' js public
 now=. now, 'Html' js public
 now=. now, 'Numbers' js public
 now File release, 'NameSpaces.js'
 
 path=. public; release
 'Comparisons' jsa path
 'Config' jsa path
 'testHtml' jsa path
 'Probability' jsa path
 'Statistics' jsa path
 'XML' jsa path
 'RGraph' jsa path
 'Turtle' jsa path
 
 ferase release, 'Demo.jsa'
 (release, 'Demo.jsa') frename release, 'testHtml.jsa'
 'Done'
}}

saved=: {{
 js=. encodeJS backup, 'Saved ', y
 js=. 'jsLoad("Saved ", "', y, '", ', js, ')' 
 js File user, 'Saved ', y, '.jsa'
}}

backup=: '~Home/APL.js.User/Backup/'
public=: '~Home/APL.js.User/Public/'
release=: '~Home/APL.js/APL/'
user=: '~Home/APL.js.User/'

js=: {{)d
 NB. For inclusion in NameSpaces.js
 js=. '_LIB_["', x, '"] = ', (encodeJS y, x), LF
}}

jsa=: {{)d
 NB. For )fetch
 'in out'=. y
 js=. 'jsLoad("Code ", "', x, '", ', (encodeJS in, x), ')'
 js File out, x, '.jsa' 
}}

Prelude=: {{)m
 a=. encodeJS public, 'Prelude'
 a=. a Replace '\n\n'; '\n" + ', LF, '     "'
 a=. 'var _PRELUDE_ = ', a
 a File '~Down/Prelude.js'
 'Done'
}}
