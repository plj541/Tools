help=: {{)n
 Motion
 Triangle
 Rectangle
 Circle
}}

Motion=: {{)n
 NB. Rate Time Distance
 D=. R* T
}}

Triangle=: {{)n
 NB. Area Base Height
 A=. 0.5* B* H
 NB. Right angle A and B intersection
 (C^ 2)= (A^ 2)* B^ 2r 
}}

Circle=: {{)n
 NB. Radius Diameter Circumference Area
 C=. R * o.2
 D=. C % o.1
 A=. (R ^ 2) * o.1
}}