help=: {{)n
 Which ''   NB. Will be Run on Load
 Retool ''  NB. Create ~Compare/@Next/tools
 Simple ''  NB. Create ~Compare/@Next/Simple
}}

Copy 'code/FileTools'

Which=: {{
 NB. Get Build code and determine which verb to run
 build=: New '~Jay/tools/Build'
 if. #buildPax__PS do. ' Retool _  NB. Tools.ijs has changes'
 else. ' Simple _  NB. Tools.ijs has no changes' end.
}}

Retool=: {{
 NB. Create new tools files from Tools.ijs
 '~Compare' Mkdir '@Next/tools'
 '~Compare/@Next/tools/' saveTools File '~Jay/Tools.ijs'
}}

Simple=: {{
 NB. Create a new Simple folder for release
 '~Compare' Mkdir '@Next/Simple/tools'
 simple=. (File '~Jay/Tools.ijs') Replace ForEach 2 simplify
 simple File '~Compare/@Next/Simple/Tools.ijs'
 '~Compare/@Next/Simple/tools/' saveTools simple
}}

saveTools=: {{
 NB. Create files for tools folder 
 myNow=. toolsFiles__build y
 myNowName=. toolsNames__build myNow
 ferase&> '' Files x
 file=. [ File x, '.ijs',~ ]
 >myNow file&.> myNowName
}}

simplify=: LF Split~ {{)n
(<~.'plj'; 18!:2 <'base') 18!:2&> <"0 ;:'base pj'
(~.'plj'; 18!:2 <'base') 18!:2 <'base'
FILES=:
FILES__PLJ=:
_plj_

_pj_

_z_
}}

Do {{)n Which ''  NB. This creates the environment other Verbs require}}