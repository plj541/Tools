help=: {{)n
 helpPerfMeas      NB. Performance Measures
 HookFork          NB. How Hook and Fork are Called
 Studies           NB. Code analysis using the following
 Examples          NB. How to call the following
 Reports           NB. Extracted from ~Jay/my/tests
}}

Examples=: {{)n
 NB. JKT's SAM timing test
 50     timex  {{)n %. test ?@$ */test, 4}} [test=: 2# 50
 50 timespacex {{)n %. test ?@$ */test, 4}} [test=: 2# 50 
 
 namespacex 'test' [test=: 1000 $,:'   this is a test  '
 {{test Trim ' '}} parsex
 namespacex 'test' [test=: test Trim ' '
 
 test=:<;._1 ' ', ":1000?@$10000  
 50 timespacex {{)n test/:Keys test}}
 {{test/:Keys test}} parsex
 
 Load 'code/CSV'
 test=: File '~Down/CreditCard5.csv'
 timespacex {{)n get=: '",' CSV test}}
 timespacex {{)n out=: '",' csvFile get}}
 test-: out
}}

Studies=: {{)n
 Run 'data/Studies/Examples'
 Run 'data/Studies/Optimizations'
 Run 'data/Studies/Parsing'
}}

Reports=: {{)n
 NB. Copy report into Sheets for further analysis
 Load 'tests/Replace/Runs'  NB. To run timing tests
 Display |: 1 2 0 3{ Times 'Replace/Android'  NB. Replace Times
 Display |: (,0 1+/  2 4 0 6){ Times 'Replace/Win'  NB. Replace Times
}}

Times=: {{)m
 NB. Extract times from tests
 y=. 'tests/', y
 names=. _4}.&.> '.txt' Files y
 files=. File&.> '.txt' Files y, '/'
 parts=. files Split&.> <']R=.'
 fun=.3 : '1{ y Split LF'  
 names,. fun&> }.&>parts
}}

Down=: {{)m
 NB. Download test files
 times=. }. '!!!' Split~ 0 Del
 _ Down &> times
:
 'path name extn'=. pathNameExtn_pj_ ;{. LF Split~ 100{. y
 y File ;path; UNAME; '/'; name, '.txt'
}}
