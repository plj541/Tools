k0=:'                                 """""""""""""""##########"""""""abcdefghijklmnopqrstuvwxyz""""""abcdefghijklmnopqrstuvwxyz""""'
k1=: '000000000000000000000000000000000b3pqmv256lkg1ds0123456789efihjcu111111111111111111111111118t7n04000000000000000000000000009oar0'

help=: {{)n
 8 2 32$,(8 32$k0),. 8 32$k1  NB. Current Keys k0 and k0
This is how the Keys verb in Tools was created

To build a new sort key, do the following:
Create your version of the KEYS, which is in this file
 Note:  the columns capture spelling
 Note:  the rows distinguish between case of same spelling

Create the definition of the new verb
 Now=. SortKeys 'Keys'              NB. The release version
 
 Now=. myKEYS MatSortKeys 'myKeys'  NB. The same result as using my APL

Consider testing:
 Do~ Now  NB. to create the verb
 Across (/:myKeys);:'a1 Dr Dr. a12 a23 cat dr. a13 a4 a456 dr DR. DR Dog Dogs a cats dog dogs'

Display Now
 Copy the definition into a script
}}

SortKeys=: {{
 spell=. 33 94 129# ' "'                          NB. Middle defaults to other
 cases=. 128# '0'                                 NB. Default to first row
 spell=. spell (,65 97+/ i.26)}~ 52$ 26{. 97}. a.  NB. Both alphabets the same
 cases=. cases (65+ i.26)}~ '1'                    NB. Uppercase
 spell=. spell (48+ i.10)}~ '#'                    NB. Digits
 cases=. cases (48+ i.10)}~ '0123456789'           NB. Each digit in namesake row
 other=. '_-''"`()][{}!?.:;,=<>+*%^|#$~/\@&'       NB. My order for other,
 assert. *./other e.~ spell#~ spell= '"'           NB. should include every other
 cases=. cases (a.i. other)}~ '0123456789abcdefghijklmnopqrstuv' 
 Say (8 32$ spell),. ' ',. 8 32$ cases             NB. Show both translate tables
 translate=. ' keys=. ((', (quote spell), '{~ ]), ', (quote cases), '{~ ])'
 y, '=: {{', LF, translate, LF, ' ([:keys a.i. ])"1 >y', LF, '}}'
}}

MatSortKeys=: {{
 NB. How the Keys verb was created
 keys=. x KeySet ,. 96{. 32}. a.
 NB. Currently supports 32 columns to represent spelling
 NB. First five are: white space, enclose, punctuation, function, digits
 spell=. (32#' '), (128#''),~    ' (./5abcdefghijklmnopqrstuvwxyz'{~ {."1 keys
 NB. Currently supports 36 rows for differentiating race
 cases=. (32#'0'), (128#''),~ '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'{~ {:"1 keys
 Say (8 32$spell),. ' ',. 8 32$cases
 now=. ' keys=. ((', (quote spell), '{~ ]), ', (quote cases), '{~ ])'
 y, '=: {{', LF, now, LF, ' ([:keys a.i. ])"1 >y', LF, '}}'
}}

KeySet=: {{
 NB. Provide the right argument for Dictionary Sort
 if. ''-: y do. y return. end.
 if. x +.&(2 ~: #@$) y do. ^'Two matrices are required' end.
 (1 2* $y)$ ,0 2 1|: |."1 (0 1* $x)#: (<:*/ $x)<. (,x) i. y
}}

ascii=: {{)n
 !"#$%&'()*+,-./0123456789:;<=>?
@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_
`abcdefghijklmnopqrstuvwxyz{|}~
}}

KEYS=: >;._2 [{{)n
 _!=0abcdefghijklmnopqrstuvwxyz
 -?<1ABCDEFGHIJKLMNOPQRSTUVWXYZ
 '.>2
 ":+3
 `;*4
 (,%5
 ) ^6
 ] |7
 [ #8
 { $9
 } ~
   /
   \
   @
   &
}}
