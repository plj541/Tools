helpDates=: {{)n
 Calendar ''                  NB. Three months surrounding today
 Do myMiles                   NB. Keep track of mileage
 Do myDates                   NB. Identify past and upcoming dates
 Today 0                      NB. As three numbers, add y
}}

Days=: (3{. 6!:0 '')&$: : {{
 NB. Days between or Date when
 NB. y Days~ 3{. 6!:0 ''
 if. 3= #y do.  NB. Days from x to y
  (todayno y)- todayno x
 else.  NB. Date y days from x
  todate y+ todayno x
 end.
}}

myDates=: {{)n
 NB.Birthdays' and Conceived dates'
 NB.Days 144% 4            NB. Today's "Fluticasone Propionate 50 mcg" empty
 2022 10 30 Days Today 0   NB. How long since master toilet flush lever fix
 NB.2022 07 07             NB. Downstairs toilet seat previous fix
 2024 06 07 Days Today 0   NB. How long since fixing down and master toilet seat
}}

Birthdays=: {{
 days=. >1945 2 1; 1946 6 30; 1984 3 25; 1986 3 9  NB. Birthdays
 }."1 Unbox days; '    '; days Days _280         NB. Full term
}}

myMiles=: {{)n
 NB. Kayte Fit
 ]days=. 2023 12 19 Days 2024 2 13
 ]part=. days% 365
 ]mile=. 196120-~ 197455
 ]mile% part
 
 NB. Paul Camry
 ]days=. 2023 5 23 Days 2024 2 13
 ]part=. days% 365
 ]mile=. 55098-~ 57755
 ]mile% part
}}

Calendar=: {{
 NB. Months surrounding today
 if. ''-: y do. y=. 6!:0'' end.
 months=. ,calendar&> (<:i.3)+ year[ 'year month'=. 2{. y
 ":months{~ (month+ 10)+ i.3
}}