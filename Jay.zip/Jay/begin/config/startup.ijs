NB.  initialize and help debugging
INIT=: '~Jay/begin/initialize.ijs'

help=: {{)n

 dberm ''                NB. To see the last error message 
 dbr 1                   NB. To start debugging this session
 load INIT               NB. To begin a Jay session
}}

{{
 try. load INIT
 catch. echo LF, help,~ dberm '' end.
}} _
