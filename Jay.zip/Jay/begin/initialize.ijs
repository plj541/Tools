NB. Load my Tools into plj
 load 'pacman'                 NB. Page requires httpget_jpacman_
 load '~Jay/tools/Loader.ijs'  NB. load the development code
 
NB. Set preferences
{{
 try.
  (9!:11) 6
  (9!:37) 0 256 120 6
  (9!:7) ' ',~ 10{.16}.a.  NB. '+++++++++|-'
  
  if. UNAME-: 'Android' do.
   wd 'setj smfont @apl385 18'
   load '~Jay/begin/Android.ijs'
  end.
  
  1!:44 jpath '~Jay'
 catch. Say dberm '' end.

 Say Load 'Mine'
}} _
