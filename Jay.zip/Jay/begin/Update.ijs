'~config/apl385.ttf'  fwrite~ fread '~Jay/begin/config/apl385.ttf'
'~config/display.css' fwrite~ fread '~Jay/begin/config/display.css'
'~config/folders.cfg' fwrite~ fread '~Jay/begin/config/folders.cfg'
'~config/startup.ijs' fwrite~ fread '~Jay/begin/config/startup.ijs'
