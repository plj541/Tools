help=: {{)n
 helpAs                  NB. How to specify a Find verb
 '~Jay' PathFind 'File'  NB. Find files in x path containing y
}}

helpAs=: {{)n
 NB. As creates the Find verb, four nouns provide different definitions
 NB. Without NoCase, the search will be case sensitive
 As NoCase Chars          NB. Find files with characters in sequence
 As NoCase Phrase         NB. Find files with words in sequence
 As NoCase AllWords       NB. Find files with all the words
 As JPhrase               NB. Find files with J words in sequence, so case sensitive
}}

PathFind=: {{
 NB. Current Find verb looks for y in all files in x path
 NB. Then creates an html REPORT with the found lines in hidden text boxes
 NB. The focus is on hits in one line,
 NB. When y contains LF reports may not fully describe what was found
 files=. 'P' Paths x
 if. #EXT do.  NB. Keep only files with my text file extensions
  ext=. files (i: }.[)&.> '.'
  files=. (EXT e.~ IGNORE &.>ext)# files
 end.
 if. 0~: #files do.
  HEAD fwrite REPORT [Count=: 0
  files Find y
  View REPORT
 else. ' NB. No text files found in ', quote x end.
}}

Chars=: {{)n
 NB. A Find verb definition
 y Keep '[As Chars NB. Case sensitive'
 NB. Case sensitive y=. IGNORE y
 for_file. x do. look=. data=. withLF file=. ;file
  hits=. y E. look NB. Case sensitive=. IGNORE look
  if. +./hits do.
   Keep file; look; LF; hits; data
  end.
 end.
}}

Phrase=: {{)n
 NB. A Find verb definition
 y Keep '[As Phrase NB. Case sensitive'
 y=. FIX Words y NB. Case sensitive=. IGNORE y
 for_file. x do. look=. data=. withLF file=. ;file
  hits=. y E. look=. FIX Words look NB. Case sensitive=. IGNORE look
  if. +./hits do.
   Keep file; look; ELF; hits; data
  end.
 end.
}}

AllWords=: {{)n
 NB. A Find verb definition
 y Keep '[As AllWords  NB. Case sensitive'
 y=. y Replace a.{~10 32  NB. Including LF would find every line
 y=. FIX Words y NB. Case sensitive=. IGNORE y
 for_file. x do. look=. data=. withLF file=. ;file
  hits=. y e. look=. FIX Words look NB. Case sensitive=. IGNORE look
  if. *./hits do.
   hits=. look e. y
   Keep file; look; ELF; hits; data
  end.
 end.
}}

JPhrase=: {{)n
 NB. A Find verb definition
 y Keep '[As JPhrase  NB. Case always matters'
 y=. FIX Words y ['is FIX for Words' Keep~ FIX=. '"`'
 for_file. x do. look=. data=. withLF file=. ;file
  hits=. y E. look=. FIX Words look
  if. +./hits do.
   Keep file; look; ELF; hits; data
  end.
 end.
}}

Keep=: {{
 NB. Save file names into REPORT
 'file look ends hits data'=. y
 lines=. +./&> (look= ends)<;._2 hits
 now=. LB Replace ''; ":Count=: >:Count
 REPORT File~ ,:now, file, LA
 now=. now, '     ', file, LF2 [now=. DB Replace ''; ":Count
 REPORT File~ ,:now, DA,~ ;(<"1 ' | ',"1~ ":,. I. lines),. lines# <;.2 encHtml data
:
 REPORT File~ ,:'<p>', '</p>',~ '   NB.  PathFind ', (quote encHtml x), '  ', y
}}

encHtml=: {{
 y Replace ForEach 2 <;._1 '|&|&amp;|<|&lt;|>|&gt;'
}}

As=: {{
 NB. Create verb Find
 if. y StartsWith ' NB. A Find verb definition' do.
  Find=: 4 : y
   }.".; 4{ ;: y
 else.
  'As requires a definition for the Find verb', LF, helpAs
 end.
}}

NoCase=: {{
 NB. Modify verb y to ignore case
 y Replace ' NB. Case sensitive'; ''
}}

fixIt=: {{
 NB. Ensure blank output doesn't shrink
 (NB, y, NA) Replace '  '; 10$ '&nbsp'
}}

withLF=: {{
 NB. Surround with LF
 LF, LF,~ File y
}}

NB. Link Before and After
LB=: {{)n
&nbsp;&nbsp<a href="#" onclick="mDiv('mD')">
}}

LA=: {{)n
</a><p>
}}

NB. Div Before and After
DB=: {{)n
<div id= 'mD' hidden><textarea rows="7" cols="139" readOnly=true>
}}

DA=: {{)n
</textarea></div>
}}

HEAD=: {{)n
<html><head><meta charset="UTF-8">
<script>
function mDiv(aDiv) {
 var x = document.getElementById(aDiv)
 if (x.style.display === "block") {
  x.style.display = "none"
 } else {
  x.style.display = "block"
 }
}
</script>
</head><body>
}}

]{{)a
 NB. Create defaults
 ELF=: <,LF
 EXT=: <;.1 '.txt.csv.apl.c.c#.cpp.ini.ijs.ijt.java.js.jsa.htm.html.jhtml.cmd.cfg.css.xml'
 FIX=: '"`''NB.:'     NB. Looking for words in normal text
 IGNORE=: 0&(3!:12)  NB. Use tolower_z_
 REPORT=: '~Docs/PathFind.html'
 As Chars            NB. Provide default definition for Find
}}