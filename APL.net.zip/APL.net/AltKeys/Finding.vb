Imports System.Windows.Forms
Imports System.Drawing

Public Class Finding

  Private thisInput As RichTextBox
  Private thisKeyPage As KeyPages

  Public Sub New(ByVal anInput As RichTextBox)
    InitializeComponent()
    thisInput = anInput
    thisKeyPage = New KeyPages()
  End Sub

  Public Sub Finding(ByVal aPoint As Point)
    Me.Location = aPoint
    Me.Focus()
    textFind.Focus()
    Me.ShowDialog()
  End Sub

  Public Sub FindNext()
    If textFind.TextLength <> 0 Then
      Find()
    End If
  End Sub

#Region "Finding FormClosing"

  Private Sub Finding_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
    ' Don't really go away
    ' That way I'll know what you searched for last time
    e.Cancel = True
    Me.Hide()
  End Sub

#End Region

#Region "Handle buttonCancel.Click"

  Private Sub buttonCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonCancel.Click
    ' I've hidden this button to the right of the visable form
    ' But I've also bound it to the Escape key
    Me.Hide()
  End Sub

#End Region

#Region "Handle buttonFind.Click"

  Private Sub buttonFind_Click( _
    ByVal sender As System.Object, _
    ByVal e As System.EventArgs) _
    Handles buttonFind.Click
    Find()
    Me.Hide()
  End Sub

  Private Sub Find()
    Dim mySwitch As RichTextBoxFinds
    Dim myLocation As Integer

    myLocation = thisInput.SelectionStart
    If thisInput.SelectedText.ToLower.StartsWith(textFind.Text.ToLower) Then
      myLocation += 1
    End If

    If checkWhole.Checked Then
      mySwitch = mySwitch Or RichTextBoxFinds.WholeWord
    End If
    If checkCase.Checked Then
      mySwitch = mySwitch Or RichTextBoxFinds.MatchCase
    End If

    myLocation = thisInput.Find(textFind.Text, myLocation, mySwitch)
    If myLocation <> -1 Then
      thisInput.Focus()

    Else
      MessageBox.Show("Finished searching", "Searching", _
          MessageBoxButtons.OK, MessageBoxIcon.Warning)
    End If
  End Sub

#End Region

#Region "Handle textFind's .KeyDown and .TextChanged"

  Private Sub textFind_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles textFind.KeyDown
    Dim myChar As String

    If e.Alt Then
      myChar = thisKeyPage.KeyDown(e)
      If myChar IsNot Nothing Then
        textFind.SelectedText = myChar
      End If
    End If
  End Sub

  Private Sub textFind_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textFind.TextChanged
    buttonFind.Enabled = textFind.TextLength <> 0
  End Sub

#End Region

End Class