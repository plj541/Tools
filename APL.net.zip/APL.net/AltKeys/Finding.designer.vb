<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Finding
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Finding))
    Me.labelFind = New System.Windows.Forms.Label
    Me.textFind = New System.Windows.Forms.TextBox
    Me.checkWhole = New System.Windows.Forms.CheckBox
    Me.checkCase = New System.Windows.Forms.CheckBox
    Me.buttonFind = New System.Windows.Forms.Button
    Me.buttonCancel = New System.Windows.Forms.Button
    Me.SuspendLayout()
    '
    'labelFind
    '
    Me.labelFind.AutoSize = True
    Me.labelFind.Location = New System.Drawing.Point(12, 9)
    Me.labelFind.Name = "labelFind"
    Me.labelFind.Size = New System.Drawing.Size(69, 16)
    Me.labelFind.TabIndex = 0
    Me.labelFind.Text = "Fi&nd what:"
    '
    'textFind
    '
    Me.textFind.Font = New System.Drawing.Font("SImPL", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.textFind.Location = New System.Drawing.Point(80, 9)
    Me.textFind.Name = "textFind"
    Me.textFind.Size = New System.Drawing.Size(176, 25)
    Me.textFind.TabIndex = 1
    '
    'checkWhole
    '
    Me.checkWhole.AutoSize = True
    Me.checkWhole.Location = New System.Drawing.Point(15, 54)
    Me.checkWhole.Name = "checkWhole"
    Me.checkWhole.Size = New System.Drawing.Size(159, 20)
    Me.checkWhole.TabIndex = 2
    Me.checkWhole.Text = "Match &whole word only"
    Me.checkWhole.UseVisualStyleBackColor = True
    '
    'checkCase
    '
    Me.checkCase.AutoSize = True
    Me.checkCase.Location = New System.Drawing.Point(15, 80)
    Me.checkCase.Name = "checkCase"
    Me.checkCase.Size = New System.Drawing.Size(91, 20)
    Me.checkCase.TabIndex = 3
    Me.checkCase.Text = "Match &case"
    Me.checkCase.UseVisualStyleBackColor = True
    '
    'buttonFind
    '
    Me.buttonFind.Enabled = False
    Me.buttonFind.Location = New System.Drawing.Point(262, 9)
    Me.buttonFind.Name = "buttonFind"
    Me.buttonFind.Size = New System.Drawing.Size(82, 23)
    Me.buttonFind.TabIndex = 4
    Me.buttonFind.Text = "&Find Next"
    Me.buttonFind.UseVisualStyleBackColor = True
    '
    'buttonCancel
    '
    Me.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.buttonCancel.Location = New System.Drawing.Point(355, 51)
    Me.buttonCancel.Name = "buttonCancel"
    Me.buttonCancel.Size = New System.Drawing.Size(82, 23)
    Me.buttonCancel.TabIndex = 5
    Me.buttonCancel.Text = "Cancel"
    Me.buttonCancel.UseVisualStyleBackColor = True
    '
    'Finding
    '
    Me.AcceptButton = Me.buttonFind
    Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.CancelButton = Me.buttonCancel
    Me.ClientSize = New System.Drawing.Size(351, 107)
    Me.Controls.Add(Me.buttonCancel)
    Me.Controls.Add(Me.buttonFind)
    Me.Controls.Add(Me.checkCase)
    Me.Controls.Add(Me.checkWhole)
    Me.Controls.Add(Me.textFind)
    Me.Controls.Add(Me.labelFind)
    Me.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
    Me.Name = "Finding"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
    Me.Text = "Find"
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents labelFind As System.Windows.Forms.Label
  Friend WithEvents textFind As System.Windows.Forms.TextBox
  Friend WithEvents checkWhole As System.Windows.Forms.CheckBox
  Friend WithEvents checkCase As System.Windows.Forms.CheckBox
  Friend WithEvents buttonFind As System.Windows.Forms.Button
  Friend WithEvents buttonCancel As System.Windows.Forms.Button
End Class
