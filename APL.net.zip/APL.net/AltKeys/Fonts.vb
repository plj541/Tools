﻿Imports System.Drawing

Public Class Fonts

  Private thisBaseFont As New Font("Courier New", 15, FontStyle.Regular, GraphicsUnit.Point)
  Private thisAPLFont As New Font("SImPL", 15, FontStyle.Regular, GraphicsUnit.Point)

  Public Event BaseFontChanged(ByVal aFont As Font)
  Public Event APLFontChanged(ByVal aFont As Font)

#Region "BaseFont"

  Public Property BaseFont() As Font
    Get
      Return thisBaseFont
    End Get
    Set(ByVal aValue As Font)
      thisBaseFont = aValue
      RaiseEvent BaseFontChanged(thisBaseFont)
    End Set
  End Property

#End Region

#Region "APLFont"

  Public Property APLFont() As Font
    Get
      Return thisAPLFont
    End Get
    Set(ByVal aValue As Font)
      thisAPLFont = aValue
      RaiseEvent APLFontChanged(thisAPLFont)
    End Set
  End Property

#End Region

End Class
