﻿Imports System.Windows.Forms
Imports Tools

Public Class KeyPages

  Public Sub New()
    If thisChars Is Nothing Then
      Setup()
    End If
  End Sub

#Region "KeyDown"
  ''' <summary>
  ''' ' Caller ensure e.Alt and then
  '''   If myChar IsNot Nothing Then
  '''     nameOfSender.SelectedText = myChar
  '''   End If
  ''' </summary>
  Public Function KeyDown(ByVal e As System.Windows.Forms.KeyEventArgs) As String
    Dim myChar As String

    If e.KeyCode = Keys.Menu OrElse _
        e.KeyCode = Keys.ControlKey OrElse _
        e.KeyCode = Keys.ShiftKey Then
      Return Nothing
    End If
    myChar = e.KeyCode.ToString
    If myChar.StartsWith("F") AndAlso _
        myChar.Length <> 1 Then
      Return Nothing
    End If

    If e.Shift Then
      If e.KeyCode = Keys.X Then
        e.Handled = True
        Return Nothing
      End If
      myChar = thisPage(e.KeyCode + 256)
    Else
      myChar = thisPage(e.KeyCode)
    End If

    If myChar IsNot Nothing Then
      e.Handled = True
    End If
    
    Return myChar
  End Function

#End Region

#Region "Setup"

  Private Shared thisChars As String
  Private Shared thisKey As Integer()
  Private Shared thisPage(512) As Char
  Private Shared thisPages As String()

  Private Sub Setup()
    Dim myLength As Integer
    Dim myValues, myBad As String

    SetupChars()
    myValues = Names.Combine(Host.Program, "KeyPages.apl")
    If Names.IsFile(myValues) Then
      myValues = Files.Lines(myValues)
      myValues = myValues.Replace(ControlChars.Tab, " ")
      myValues = myValues.Replace(ControlChars.CrLf, ControlChars.Lf)
      myValues = myValues.Replace(ControlChars.Cr, ControlChars.Lf)
      thisPages = myValues.Split(ControlChars.Lf)

      If thisPages.Length > 2 Then
        myLength = thisPages(0).Length
        If myLength <> thisPages(1).Length OrElse _
            myLength <> thisPages(2).Length Then
          MessageBox.Show("The three lines must be the same length.", "Bad KeyPages.apl Configuration")
          DefaultPages()

        Else
          myBad = SetupKey()
          If myBad IsNot Nothing Then
            MessageBox.Show("The following keys are not defined: " & myBad, "Bad KeyPages.apl Configuration")
            DefaultPages()
          End If
        End If
      Else
        MessageBox.Show("There must be at least three lines in KeyPages.apl", "Bad KeyPages.apl Configuration")
        DefaultPages()
      End If
    Else
      DefaultPages()
    End If

    SetPage(0)
    SetPage(1)
  End Sub

#End Region

#Region "SetupKey"

  Public Function SetupKey() As String
    Dim myIndex, myPlace As Integer
    Dim myKeys, myItem, myBad As String

    myBad = Nothing
    myKeys = thisPages(0).ToUpper
    ReDim thisKey(300)
    For myIndex = 0 To myKeys.Length - 1
      myItem = myKeys(myIndex)
      myPlace = thisChars.IndexOf(myItem)
      If myPlace = -1 Then
        myBad &= " " & myItem
      End If
      thisKey(myIndex) = myPlace
    Next
    Return myBad
  End Function

#End Region

#Region "SetPage"

  Private Sub SetPage(ByVal aPage As Integer)
    Dim myKey As Integer
    Dim myPage As String
    Dim myItem As Char

    myPage = thisPages(aPage + 1)
    aPage *= 256
    For myKey = 0 To myPage.Length - 1
      myItem = myPage(myKey)
      thisPage(thisKey(myKey) + aPage) = myItem
    Next
  End Sub

#End Region

#Region "SetupChars and FillIn"

  Private Sub SetupChars()
    thisChars = StrDup(255, ControlChars.Tab)
    FillIn(48, "0123456789")
    FillIn(65, "ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    FillIn(186, ";+,-.?~")
    FillIn(219, "[|]""")
    FillIn(226, "\")
  End Sub

  Private Sub FillIn(ByVal aFrom As Integer, ByVal aString As String)
    ' N.B. Mid is Origin=1, all the new objects are Origin=0
    Mid(thisChars, aFrom + 1, aString.Length) = aString
  End Sub

#End Region

#Region "DefaultPages"

  Private Sub DefaultPages()
    thisPages = New String() { _
        "~1234567890-+QWERTYUIOP[]|ASDFGHJKL;ZXCVBNM,.?""", _
        "⍬¨¯<≤=≥>≠∨∧×÷⌹⍵∊⍴~↑↓⍳○*←→⍀⍺⌈⌊_∇∆∘⍞⎕⋄⊂⊃∩∪⊥⊤|⍪∙⌿¨", _
        "≠  × ÷∨∞⊛⍱⍲¯≡∎⍹⍷®⍫⍊⍑⍸⊖⌽⊣⊢⍉⍶  ⍙⍒⍋⍝ ⌷   ©∵⍎⍕⌶≤≥∴ "}
    ' N.B. Original looked more like APL
    '   "⋄¨¯<≤=≥>≠∨∧×÷?⍵∊⍴~↑↓⍳○*←→⊣⍺⌈⌊_∇∆∘⍞⎕⍎⊂⊃∩∪⊥⊤|⍝⍀⌿⍕", _
    '   "⍬  × ÷∨ ⊛⍱⍲¯≠⌹⍹⍷    ⍸ ⌽↖↘⍉⍶↗↙⍫⍒⍋⍙⍝⌷≡    ⍎⍕⌶≤≥ ¨"}
    SetupKey()
  End Sub

#End Region

End Class
