﻿Imports AltKeys
Imports PLJsAPL
Imports Tools

Public Class SessionLog

#Region "Handles Events Quotes, Notes and Shows"

  Private WithEvents thisContext As InputOutput = _Events
  Private thisOutput As APLRichText
  ''' <summary>
  ''' Quotes handles several tradition APL input and output requests.
  ''' Ignore this event only if you know the application does not make input requests.
  ''' </summary>
  ''' <param name="aPrompt">
  ''' A string of characters to output.
  ''' </param>
  ''' <param name="anInitial">
  ''' If anInitial Is Nothing Then 
  '''    ' this is just and output request.
  ''' If IsNot Nothing Then
  '''    ' this is the initial character string.
  ''' </param>
  ''' <param name="aResult">
  ''' Events don't return results, instead you
  ''' assign a value to this ByRef argument.
  ''' </param>
  Private Sub thisContext_Quotes(ByVal aPrompt As String, ByVal anInitial As String, ByRef aResult As String) Handles thisContext.Quotes
    thisOutput.AppendText(aPrompt)
    '  GetDown()
    If anInitial IsNot Nothing Then
      If anInitial.Length <> 0 Then
        thisOutput.AppendText("   " & anInitial & ControlChars.NewLine)
      End If
      aResult = InputBox(aPrompt, Me.Text, anInitial)
      If aResult.Length <> 0 AndAlso aResult <> anInitial Then
        thisOutput.AppendText("   " & aResult & ControlChars.NewLine)
      End If
      '   GetDown()
    End If
  End Sub

  ''' <summary>
  ''' Notes are for logging, feel free to ignore.
  ''' </summary>
  Private Sub thisContext_Notes(ByVal aNote As String) Handles thisContext.Notes
    thisOutput.AppendText("   " & aNote)
    '  GetDown()
  End Sub

  Public Sub GetDown()
    thisOutput.Focus()
    thisOutput.Select(thisOutput.TextLength, 0)
    textInput.Focus()
  End Sub

  ''' <summary>
  ''' Shows are only for debugging,
  ''' they should be ignored when not debugging.
  ''' </summary>
  Private Sub thisContext_Shows() Handles thisContext.Shows
    Dim myShell As New Shell

    myShell.ShellOutput.AppendText(thisOutput.Text)
    myShell.Viewing("current PLJsAPL session") = True
    myShell.ShowDialog()
  End Sub

#End Region

  Private Sub SessionLog_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    thisOutput = ShellOutput()
    Me.NoOpen = True
    Me.Viewing(Me.Text) = True
  End Sub

End Class
