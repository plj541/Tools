﻿Imports System.Drawing
Imports System.Windows.Forms

Public Class APLRichText
  Inherits System.Windows.Forms.RichTextBox

  Private thisAPLFont As New Font("SImPL", 15, FontStyle.Regular, GraphicsUnit.Point)
  Private thisKeys As New KeyPages

  Public Event AltKeys(ByRef aKey As String)

  Private Sub InitializeComponent()
    Me.SuspendLayout()
    Me.ResumeLayout(False)
  End Sub

#Region "Text"

  Public Overrides Property Text() As String
    Get
      Return MyBase.Text.Replace(ControlChars.Lf, ControlChars.NewLine)
    End Get
    Set(ByVal aValue As String)
      MyBase.Text = ""
      Me.AppendText(aValue)
      MyBase.SelectionStart = 0
    End Set
  End Property

#End Region

#Region "AppendText"

  Public Overloads Sub AppendText(ByVal aLine As String)
    Dim myLength As Integer

    myLength = MyBase.TextLength
    MyBase.AppendText(aLine)
    FormatAPL(myLength, aLine.Length, MyBase.TextLength)
  End Sub

#End Region

#Region "FormatAPL"

  Private Sub FormatAPL( _
      ByVal aStart As Integer, _
      ByVal aLength As Integer, _
      ByVal anEnd As Integer)
    MyBase.Select(aStart, aLength)
    MyBase.SelectionFont = thisAPLFont
    MyBase.Select(anEnd, 0)
  End Sub

#End Region

#Region "Handle KeyDown"

  Private Sub APLRichText_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
    Dim myChar As String

    If e.Control AndAlso e.KeyCode = Windows.Forms.Keys.V Then
      e.Handled = True
      myChar = Clipboard.GetText _
          .Replace(ControlChars.CrLf, ControlChars.Lf) _
          .Replace(ControlChars.Cr, ControlChars.Lf) _
          .Replace(ControlChars.Tab, " ")
      InsertChar(myChar)
      Return
    End If

    If e.Alt Then
      myChar = thisKeys.KeyDown(e)
      If myChar IsNot Nothing Then
        e.Handled = True
        RaiseEvent AltKeys(myChar)
        If myChar IsNot Nothing Then
          InsertChar(myChar)
        End If
      End If
    End If
  End Sub

  Private Sub InsertChar(ByVal aChar As String)
    Dim myStart As Integer

    myStart = MyBase.SelectionStart
    MyBase.SelectedText = aChar
    FormatAPL(myStart, aChar.Length, myStart + aChar.Length)
  End Sub

#End Region

#Region "APLFont"

  Public Property APLFont() As Font
    Get
      Return thisAPLFont
    End Get
    Set(ByVal aValue As Font)
      thisAPLFont = aValue
    End Set
  End Property

#End Region

End Class