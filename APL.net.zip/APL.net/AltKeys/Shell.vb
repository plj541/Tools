﻿Imports System.Drawing
Imports System.Windows.Forms
Imports Tools

Public Class Shell

  Private thisFile As String
  Private thisDirty As Boolean
  Private thisReadOnly As Boolean
  Private thisKeyPage As KeyPages

  Public Event RunScript()

#Region "Open and Save"

  ''' <summary>
  ''' Specify aFile to open
  ''' </summary>
  Public Sub Open(ByVal aFile As String)
    thisFile = aFile
    If thisFile IsNot Nothing Then
      Viewing(thisFile) = CBool(GetAttr(thisFile) And FileAttribute.ReadOnly)
      textOutput.Text = Files.Lines(thisFile)
      thisDirty = False
      If thisReadOnly Then
        thisFile = Nothing
      End If
    End If
  End Sub

  ''' <summary>
  ''' Save the contents, if appropriate
  ''' </summary>
  Private Sub Save()
    If thisDirty AndAlso Not thisReadOnly Then
      If thisFile Is Nothing Then
        thisFile = String.Format("Saved {0:ddd MMM d, yyyy} at {0:H mm ss}.apl", Now)
      End If

      Files.Lines(thisFile) = textOutput.Text
    End If

    thisDirty = False
  End Sub

#End Region

#Region "Viewing"

  ''' <summary>
  ''' Is the data Read Only, or set is so that
  ''' it will behave that way.
  ''' </summary>
  ''' <param name="aTitle">
  ''' Provide aTitle for the form.
  ''' </param>
  Public Property Viewing(ByVal aTitle As String) As Boolean
    Get
      Return thisReadOnly
    End Get

    Set(ByVal aValue As Boolean)
      thisReadOnly = aValue
      textOutput.ReadOnly = aValue

      If aValue Then
        If aTitle IsNot Nothing Then
          Me.Text = "Viewing  " & aTitle
        Else
          Me.Text = "View" & Me.Text.Substring(4)
        End If

      Else
        Me.Text = "Editing  " & aTitle
      End If
    End Set
  End Property

#End Region

#Region "NoOpen"

  Property NoOpen() As Boolean
    Get
      Return Not btnOpen.Visible
    End Get

    Set(ByVal aValue As Boolean)
      btnOpen.Visible = Not aValue
      btnRun.Visible = aValue
      btnRun.Enabled = aValue
    End Set
  End Property

#End Region

#Region "ShellOutput"

  Public Function ShellOutput() As APLRichText
    Return textOutput
  End Function

#End Region

#Region "ShellInput"

  Private thisInput As Boolean
  Public Function ShellInput() As APLRichText
    thisInput = True
    textOutput.Height -= textInput.Height + 6
    textInput.Focus()
    Return textInput
  End Function

  'Public Function KeyPage() As KeyPages
  '  Return thisKeyPage
  'End Function

#End Region

#Region "Shell's Load and FormClosing"

  Private Sub Shell_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
    If thisInput Then
      textInput.Focus()
    Else
      textOutput.Focus()
    End If
  End Sub

  Private Sub Shell_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    If Names.Path = Host.Program Then
      Names.Path = Host.Desktop
    End If
    thisKeyPage = New KeyPages()
  End Sub

  Private Sub Shell_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
    If Not thisNoSave Then
      Save()
    End If
  End Sub

  Private thisNoSave As Boolean
  Public Sub NoAutoSave()
    thisNoSave = True
  End Sub

#End Region

#Region "textResult's KeyDown TextChanged and MouseUp"

  Private Sub textOutput_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles textOutput.KeyDown
    If e.Control AndAlso e.KeyCode = Keys.F Then
      e.Handled = True
      thisPoint = New Point(Me.Left + 300, Me.Top + 2)
      menuEditFind()

    ElseIf e.KeyCode = Keys.F3 Then
      If e.Alt OrElse e.Control OrElse e.Shift Then
      Else
        e.Handled = True
        If thisFinding IsNot Nothing Then
          thisFinding.FindNext()
        End If
      End If
    End If
  End Sub

  Private Sub textOutput_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles textOutput.TextChanged
    thisDirty = True
  End Sub

  Private thisClick As ContextMenuStrip
  Private Sub textOutput_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles textOutput.MouseUp
    ' Someday I may display a ContextMenu
  End Sub

#End Region

#Region "File's Edit Read and Save"

  Private Sub menuFileOpen()
    Save()
    thisReadOnly = False
    Open(Names.OpenFileDialog("File to Edit", Host.Desktop))
  End Sub

  Private Sub menuFileRead()
    Viewing(thisFile) = True
  End Sub

  Private Sub menuFileSave()
    thisReadOnly = False
    thisDirty = True
    Save()
    Viewing(thisFile) = False
  End Sub

#End Region

#Region "Edit's Cut Copy Paste Undo Redo and Find"

  Private Sub menuEditCut()
    Dim myLine As String

    myLine = textOutput.SelectedText
    If myLine.Length <> 0 Then
      Clipboard.SetText(myLine)
      textOutput.SelectedText = ""
    End If
  End Sub

  Private Sub menuEditCopy()
    Dim myLine As String

    myLine = textOutput.SelectedText
    If myLine.Length <> 0 Then
      Clipboard.SetText(myLine)
    End If
  End Sub

  Private Sub menuEditPaste()
    Dim myLine As String

    myLine = Clipboard.GetText
    If myLine.Length <> 0 Then
      textOutput.SelectedText = myLine
    End If
  End Sub

  Private Sub menuEditUndo()
    textOutput.Focus()
    SendKeys.Send("^Z")
  End Sub

  Private Sub menuEditRedo()
    textOutput.Focus()
    SendKeys.Send("^Y")
  End Sub

  Private thisPoint As Point
  Private thisFinding As Finding
  Private Sub menuEditFind()
    If thisFinding Is Nothing Then
      thisFinding = New Finding(textOutput)
    End If

    thisFinding.Finding(thisPoint)
  End Sub

#End Region

#Region "Button Bar"

  Private Sub tbButtons_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tbButtons.ButtonClick
    Select Case e.Button.Name
      Case btnOpen.Name
        menuFileOpen()
      Case btnRead.Name
        menuFileRead()
      Case btnSave.Name
        menuFileSave()
      Case btnCut.Name
        menuEditCut()
      Case btnCopy.Name
        menuEditCopy()
      Case btnPaste.Name
        menuEditPaste()
      Case btnUndo.Name
        menuEditUndo()
      Case btnRedo.Name
        menuEditRedo()
      Case btnFind.Name
        thisPoint = New Point(Me.Left + 300, Me.Top + 2)
        menuEditFind()
      Case btnRun.Name
        btnRun.Enabled = False
        RaiseEvent RunScript()
      Case btnFold.Name
        SetFold(True)
      Case btnUnfold.Name
        SetFold(False)
    End Select
  End Sub

  Private Sub SetFold(ByVal aValue As Boolean)
    textOutput.WordWrap = aValue
    btnFold.Visible = Not aValue
    btnUnfold.Visible = aValue
    textOutput.BackColor = Color.White
  End Sub

#End Region

End Class