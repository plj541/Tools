﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Shell
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Shell))
    Me.imgList = New System.Windows.Forms.ImageList(Me.components)
    Me.tbButtons = New System.Windows.Forms.ToolBar
    Me.btnRun = New System.Windows.Forms.ToolBarButton
    Me.btnOpen = New System.Windows.Forms.ToolBarButton
    Me.btnRead = New System.Windows.Forms.ToolBarButton
    Me.btnSave = New System.Windows.Forms.ToolBarButton
    Me.sep1 = New System.Windows.Forms.ToolBarButton
    Me.btnPrint = New System.Windows.Forms.ToolBarButton
    Me.btnPreview = New System.Windows.Forms.ToolBarButton
    Me.sep2 = New System.Windows.Forms.ToolBarButton
    Me.btnCut = New System.Windows.Forms.ToolBarButton
    Me.btnCopy = New System.Windows.Forms.ToolBarButton
    Me.btnPaste = New System.Windows.Forms.ToolBarButton
    Me.sep3 = New System.Windows.Forms.ToolBarButton
    Me.btnUndo = New System.Windows.Forms.ToolBarButton
    Me.btnRedo = New System.Windows.Forms.ToolBarButton
    Me.btnFind = New System.Windows.Forms.ToolBarButton
    Me.sep4 = New System.Windows.Forms.ToolBarButton
    Me.btnFold = New System.Windows.Forms.ToolBarButton
    Me.btnUnfold = New System.Windows.Forms.ToolBarButton
    Me.textOutput = New AltKeys.APLRichText
    Me.textInput = New AltKeys.APLRichText
    Me.SuspendLayout()
    '
    'imgList
    '
    Me.imgList.ImageStream = CType(resources.GetObject("imgList.ImageStream"), System.Windows.Forms.ImageListStreamer)
    Me.imgList.TransparentColor = System.Drawing.Color.Transparent
    Me.imgList.Images.SetKeyName(0, "")
    Me.imgList.Images.SetKeyName(1, "")
    Me.imgList.Images.SetKeyName(2, "")
    Me.imgList.Images.SetKeyName(3, "")
    Me.imgList.Images.SetKeyName(4, "")
    Me.imgList.Images.SetKeyName(5, "")
    Me.imgList.Images.SetKeyName(6, "")
    Me.imgList.Images.SetKeyName(7, "")
    Me.imgList.Images.SetKeyName(8, "")
    Me.imgList.Images.SetKeyName(9, "")
    Me.imgList.Images.SetKeyName(10, "")
    Me.imgList.Images.SetKeyName(11, "")
    Me.imgList.Images.SetKeyName(12, "")
    Me.imgList.Images.SetKeyName(13, "")
    Me.imgList.Images.SetKeyName(14, "~00442.ico")
    Me.imgList.Images.SetKeyName(15, "NOTE15.ICO")
    Me.imgList.Images.SetKeyName(16, "NOTE14.ICO")
    Me.imgList.Images.SetKeyName(17, "~01172.ico")
    '
    'tbButtons
    '
    Me.tbButtons.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
    Me.tbButtons.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.btnRun, Me.btnOpen, Me.btnRead, Me.btnSave, Me.sep1, Me.btnPrint, Me.btnPreview, Me.sep2, Me.btnCut, Me.btnCopy, Me.btnPaste, Me.sep3, Me.btnUndo, Me.btnRedo, Me.btnFind, Me.sep4, Me.btnFold, Me.btnUnfold})
    Me.tbButtons.DropDownArrows = True
    Me.tbButtons.ImageList = Me.imgList
    Me.tbButtons.Location = New System.Drawing.Point(0, 0)
    Me.tbButtons.Margin = New System.Windows.Forms.Padding(4)
    Me.tbButtons.Name = "tbButtons"
    Me.tbButtons.ShowToolTips = True
    Me.tbButtons.Size = New System.Drawing.Size(892, 36)
    Me.tbButtons.TabIndex = 657
    '
    'btnRun
    '
    Me.btnRun.ImageIndex = 14
    Me.btnRun.Name = "btnRun"
    Me.btnRun.ToolTipText = "Run"
    Me.btnRun.Visible = False
    '
    'btnOpen
    '
    Me.btnOpen.ImageIndex = 13
    Me.btnOpen.Name = "btnOpen"
    Me.btnOpen.ToolTipText = "Open"
    '
    'btnRead
    '
    Me.btnRead.ImageIndex = 17
    Me.btnRead.Name = "btnRead"
    Me.btnRead.ToolTipText = "Read Only"
    '
    'btnSave
    '
    Me.btnSave.ImageIndex = 2
    Me.btnSave.Name = "btnSave"
    Me.btnSave.ToolTipText = "Save"
    '
    'sep1
    '
    Me.sep1.Name = "sep1"
    Me.sep1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
    '
    'btnPrint
    '
    Me.btnPrint.ImageIndex = 4
    Me.btnPrint.Name = "btnPrint"
    Me.btnPrint.ToolTipText = "Print"
    Me.btnPrint.Visible = False
    '
    'btnPreview
    '
    Me.btnPreview.ImageIndex = 3
    Me.btnPreview.Name = "btnPreview"
    Me.btnPreview.ToolTipText = "Print Preview"
    Me.btnPreview.Visible = False
    '
    'sep2
    '
    Me.sep2.Name = "sep2"
    Me.sep2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
    Me.sep2.Visible = False
    '
    'btnCut
    '
    Me.btnCut.ImageIndex = 5
    Me.btnCut.Name = "btnCut"
    Me.btnCut.ToolTipText = "Cut"
    '
    'btnCopy
    '
    Me.btnCopy.ImageIndex = 6
    Me.btnCopy.Name = "btnCopy"
    Me.btnCopy.ToolTipText = "Copy"
    '
    'btnPaste
    '
    Me.btnPaste.ImageIndex = 7
    Me.btnPaste.Name = "btnPaste"
    Me.btnPaste.ToolTipText = "Paste"
    '
    'sep3
    '
    Me.sep3.Name = "sep3"
    Me.sep3.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
    '
    'btnUndo
    '
    Me.btnUndo.ImageIndex = 8
    Me.btnUndo.Name = "btnUndo"
    Me.btnUndo.ToolTipText = "Undo"
    '
    'btnRedo
    '
    Me.btnRedo.ImageIndex = 9
    Me.btnRedo.Name = "btnRedo"
    Me.btnRedo.ToolTipText = "Redo"
    '
    'btnFind
    '
    Me.btnFind.ImageIndex = 10
    Me.btnFind.Name = "btnFind"
    Me.btnFind.ToolTipText = "Find"
    '
    'sep4
    '
    Me.sep4.Name = "sep4"
    Me.sep4.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
    '
    'btnFold
    '
    Me.btnFold.ImageIndex = 15
    Me.btnFold.Name = "btnFold"
    Me.btnFold.ToolTipText = "Fold"
    Me.btnFold.Visible = False
    '
    'btnUnfold
    '
    Me.btnUnfold.ImageIndex = 16
    Me.btnUnfold.Name = "btnUnfold"
    Me.btnUnfold.ToolTipText = "Unfold"
    '
    'textOutput
    '
    Me.textOutput.AcceptsTab = True
    Me.textOutput.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.textOutput.APLFont = New System.Drawing.Font("SImPL", 15.0!)
    Me.textOutput.Font = New System.Drawing.Font("Courier New", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.textOutput.Location = New System.Drawing.Point(0, 44)
    Me.textOutput.Margin = New System.Windows.Forms.Padding(4)
    Me.textOutput.Name = "textOutput"
    Me.textOutput.Size = New System.Drawing.Size(888, 508)
    Me.textOutput.TabIndex = 1
    Me.textOutput.Text = ""
    '
    'textInput
    '
    Me.textInput.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.textInput.APLFont = New System.Drawing.Font("SImPL", 15.0!)
    Me.textInput.Font = New System.Drawing.Font("Courier New", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.textInput.Location = New System.Drawing.Point(0, 489)
    Me.textInput.Margin = New System.Windows.Forms.Padding(4)
    Me.textInput.Name = "textInput"
    Me.textInput.Size = New System.Drawing.Size(888, 66)
    Me.textInput.TabIndex = 0
    Me.textInput.Text = ""
    '
    'Shell
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 18.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(892, 553)
    Me.Controls.Add(Me.tbButtons)
    Me.Controls.Add(Me.textOutput)
    Me.Controls.Add(Me.textInput)
    Me.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Margin = New System.Windows.Forms.Padding(4)
    Me.Name = "Shell"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "ShellAPL Session"
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents imgList As System.Windows.Forms.ImageList
  Friend WithEvents tbButtons As System.Windows.Forms.ToolBar
  Friend WithEvents btnOpen As System.Windows.Forms.ToolBarButton
  Friend WithEvents btnSave As System.Windows.Forms.ToolBarButton
  Friend WithEvents sep1 As System.Windows.Forms.ToolBarButton
  Friend WithEvents btnPrint As System.Windows.Forms.ToolBarButton
  Friend WithEvents btnPreview As System.Windows.Forms.ToolBarButton
  Friend WithEvents sep2 As System.Windows.Forms.ToolBarButton
  Friend WithEvents btnCut As System.Windows.Forms.ToolBarButton
  Friend WithEvents btnCopy As System.Windows.Forms.ToolBarButton
  Friend WithEvents btnPaste As System.Windows.Forms.ToolBarButton
  Friend WithEvents btnFind As System.Windows.Forms.ToolBarButton
  Friend WithEvents sep3 As System.Windows.Forms.ToolBarButton
  Friend WithEvents btnUndo As System.Windows.Forms.ToolBarButton
  Friend WithEvents btnRedo As System.Windows.Forms.ToolBarButton
  Friend WithEvents btnRead As System.Windows.Forms.ToolBarButton
  Friend WithEvents textOutput As AltKeys.APLRichText
  Friend WithEvents textInput As AltKeys.APLRichText
  Friend WithEvents btnRun As System.Windows.Forms.ToolBarButton
  Friend WithEvents sep4 As System.Windows.Forms.ToolBarButton
  Friend WithEvents btnFold As System.Windows.Forms.ToolBarButton
  Friend WithEvents btnUnfold As System.Windows.Forms.ToolBarButton
End Class
