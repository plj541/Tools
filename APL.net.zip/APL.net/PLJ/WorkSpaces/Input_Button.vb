﻿Imports System.Windows.Forms

Public Class Input_Button

#Region "Input"

  Public Function Input( _
     ByVal aMessage As Object, _
     ByVal aTitle As Object, _
     ByVal aPrompt As Object()) _
     As String

    labelMessage.Text = DirectCast(aMessage, String)
    Me.Text = DirectCast(aTitle, String)
    If aPrompt.Length <> 0 Then
      textInput.Text = DirectCast(aPrompt(0), String)
      textInput.SelectionStart = textInput.Text.Length
    End If
    textInput.Visible = True
    textInput.BringToFront()
    textInput.Focus()

    Me.ShowDialog()
    Return textInput.Text
  End Function

#End Region

#Region "Buttons"

  Private thisButton As Integer = -1
  Private thisButtons As String()
  Public Function Buttons( _
      ByVal aMessage As Object, _
      ByVal aTitle As Object, _
      ByVal aButtons As Object()) _
      As Integer

    Dim myIndex, myButton As Integer
    Dim myButtons() As Button = {button0, button1, button2}

    labelMessage.Text = DirectCast(aMessage, String)
    Me.Text = DirectCast(aTitle, String)

    If aButtons.Length = 0 Then
      button0.Visible = True
      thisButtons = New String() {"&OK"}

    Else
      If aButtons.Length = 3 Then
        myButton = 2
      End If

      ReDim thisButtons(aButtons.Length - 1)
      For myIndex = 0 To aButtons.Length - 1
        thisButtons(myIndex) = DirectCast(aButtons(myIndex), String)
        myButtons(myButton).Text = thisButtons(myIndex)
        myButtons(myButton).Visible = thisButtons(myIndex).Length <> 0
        myButton += 1
        myButton = myButton Mod 3
      Next
    End If

    Me.ShowDialog()
    Return thisButton
  End Function

#End Region

#Region "Handle Click from Button0 Button1 Button2"

  Private Sub buttons_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button0.Click, button1.Click, button2.Click
    thisButton = Array.IndexOf(thisButtons, DirectCast(sender, Button).Text)
    Me.Close()
  End Sub

#End Region

#Region "Handle textInput KeyDown"

  Private Sub textInput_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles textInput.KeyDown
    If e.KeyData = Keys.Enter Then
      e.Handled = True
      Me.Close()
    End If
  End Sub

#End Region

End Class
