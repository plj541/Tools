﻿Imports PLJsAPL
Imports CommandLine
Public Class Sample
Inherits WorkSpace
Private _x As New Evaluate("")

#Region "Adjacent"

Public ReadOnly Property  Adjacent () As OpMonadic
  Get
    Return New OpMonadic(AddressOf _Adjacent , AddressOf _Adjacent , True)
  End Get
End Property

Private Function _Adjacent (ByVal aMethod As Method, ByVal anIndex As APL, _
                    ByVal  _Omega  As APL) As APL
  Dim myShift As APL

  If  _Omega.Rank = 0 Then
    _Signal(ExceptionAPL.Is.Rank)
  End If
  If Array.ReferenceEquals(anIndex, _a.Empty) Then
    anIndex = _a.Value( _Omega.Rank)(_a.Minus, 1)
  End If 

  myShift = _a.Shape( _Omega )(_a.Times, 0)
  myShift.Sub(anIndex) = _a.Value(1)
  Return _a.Minus(myShift)(_a.Drop,  _Omega ) _
      (aMethod, myShift(_a.Drop,  _Omega ))
End Function

Private Function _Adjacent (ByVal  _Alpha  As APL, _
                    ByVal aMethod As Method, ByVal anIndex As APL, _
                    ByVal  _Omega  As APL) As APL
  ' Replace with your dyadic derived function definition
  _Signal(ExceptionAPL.Is.Nonce)
End Function

#End Region

#Region "FnsInLib"

Public ReadOnly Property  FnsInLib () As Method
  Get
    Return New Method(AddressOf _FnsInLib , AddressOf _FnsInLib )
  End Get
End Property

Private Function _FnsInLib (ByVal  _Omega  As APL) As APL
  Dim myLib As APL

  myLib = _a.Column(_x.Lib( _Omega ))
  myLib = myLib(_a.Comma, _a.Enclose( _Omega )(_x.Fns(_a.Each), myLib))
  Return _a.Comma(myLib) 
End Function

Private Function _FnsInLib (ByVal  _Alpha  As APL, ByVal  _Omega  As APL) As APL
  ' Your dyadic function definition
  _Signal(ExceptionAPL.Is.Nonce)
End Function

#End Region

#Region "Item"

Public Property  Item () As APL
  Get
    If thisItem Is Nothing Then
      thisItem = _a.Value("New")
    End If
    Return thisItem
  End Get
  Set(ByVal aValue As APL)
    If aValue.IsCharacter Then
      If aValue.Rank < 2 Then
        thisItem = aValue
      Else
        _Signal(ExceptionAPL.Is.Rank)
      End If
    Else
      _Signal(ExceptionAPL.Is.Domain)
    End If
  End Set
End Property

Private thisItem As APL

#End Region

#Region "OpDyadic"

Public ReadOnly Property  OpDyadic () As OpDyadic
  Get
    Return New OpDyadic(AddressOf _OpDyadic , AddressOf _OpDyadic , False)
  End Get
End Property

Private Function _OpDyadic (ByVal aLeft As Method, ByVal anIndex As APL, _
                    ByVal aRight As Method, ByVal  _Omega  As APL) As APL
  ' Replace with your monadic derived function definition
  _Signal(ExceptionAPL.Is.Nonce)
End Function

Private Function _OpDyadic (ByVal  _Alpha  As APL, _
                    ByVal aLeft As Method, ByVal anIndex As APL, _
                    ByVal aRight As Method, ByVal  _Omega  As APL) As APL
  ' Replace with your dyadic derived function definition
  _Signal(ExceptionAPL.Is.Nonce)
End Function

#End Region

#Region "OpMonadic"

Public ReadOnly Property  OpMonadic () As OpMonadic
  Get
    Return New OpMonadic(AddressOf _OpMonadic , AddressOf _OpMonadic , False)
  End Get
End Property

Private Function _OpMonadic (ByVal aMethod As Method, ByVal anIndex As APL, _
                    ByVal  _Omega  As APL) As APL
  ' Replace with your monadic derived function definition
  _Signal(ExceptionAPL.Is.Nonce)
End Function

Private Function _OpMonadic (ByVal  _Alpha  As APL, _
                    ByVal aMethod As Method, ByVal anIndex As APL, _
                    ByVal  _Omega  As APL) As APL
  ' Replace with your dyadic derived function definition
  _Signal(ExceptionAPL.Is.Nonce)
End Function

#End Region

#Region "Report"

Public ReadOnly Property  Report () As Method
  Get
    Return New Method(AddressOf _Report , AddressOf _Report )
  End Get
End Property

Private Function _Report (ByVal  _Omega  As APL) As APL
  Dim myTime, myLast As APL

  myTime = _a.QuadTS
  myLast = myTime.Sub(_a.Value(2))(_a.LessOrEqual, 15)
  myLast = myTime.Sub(_a.Value(1))(_a.Minus, myLast)
  Return  Report (myLast,  _Omega )
End Function

Private Function _Report (ByVal  _Alpha  As APL, ByVal  _Omega  As APL) As APL
  ' Produce a report from a matrix
  Dim myMonths, myItems, myTotal As APL

   _Alpha  =  _Alpha (_a.Minus, 1)
  myMonths = _a.Shape( _Omega ).Sub(_a.Value(1))
  myMonths = _a.Pivot( _Alpha (_a.Minus, _a.Index(myMonths)))
  myMonths = _a.Value( _
      "Jan", "Feb", "Mar", "Apr", "May", "Jun", _
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec").Sub(myMonths)
  myItems = _a.Shape( _Omega ).Sub(_a.Value(0))
  myItems = _a.Value(1)(_a.Plus, _a.Index(myItems))
  myItems = _a.Value("Total", "")(_a.Comma, myItems)
  myItems = _a.Value(1)(_a.Pivot, myItems)
  myItems = _a.Format(_a.Column(myItems))
  myTotal = _a.Plus(_a.Reduce.Sub(0))( _Omega )
  myTotal =  _Omega (_a.Comma.Sub(0), myTotal)
  myTotal = myMonths(_a.Comma.Sub(0), myTotal)
  myTotal = _a.Value(0, 2)(_a.Format, myTotal)
  Return myItems(_a.Comma, myTotal)
End Function

#End Region

End Class
