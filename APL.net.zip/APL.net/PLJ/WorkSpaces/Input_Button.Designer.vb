﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Input_Button
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.button2 = New System.Windows.Forms.Button
    Me.button0 = New System.Windows.Forms.Button
    Me.button1 = New System.Windows.Forms.Button
    Me.labelMessage = New System.Windows.Forms.Label
    Me.textInput = New System.Windows.Forms.RichTextBox
    Me.SuspendLayout()
    '
    'button2
    '
    Me.button2.BackColor = System.Drawing.SystemColors.Control
    Me.button2.Cursor = System.Windows.Forms.Cursors.Default
    Me.button2.Font = New System.Drawing.Font("SImPL", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.button2.ForeColor = System.Drawing.SystemColors.ControlText
    Me.button2.Location = New System.Drawing.Point(10, 158)
    Me.button2.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
    Me.button2.Name = "button2"
    Me.button2.RightToLeft = System.Windows.Forms.RightToLeft.No
    Me.button2.Size = New System.Drawing.Size(156, 37)
    Me.button2.TabIndex = 0
    Me.button2.Text = "(2)"
    Me.button2.UseVisualStyleBackColor = False
    Me.button2.Visible = False
    '
    'button0
    '
    Me.button0.BackColor = System.Drawing.SystemColors.Control
    Me.button0.Cursor = System.Windows.Forms.Cursors.Default
    Me.button0.Font = New System.Drawing.Font("SImPL", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.button0.ForeColor = System.Drawing.SystemColors.ControlText
    Me.button0.Location = New System.Drawing.Point(180, 158)
    Me.button0.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
    Me.button0.Name = "button0"
    Me.button0.RightToLeft = System.Windows.Forms.RightToLeft.No
    Me.button0.Size = New System.Drawing.Size(156, 37)
    Me.button0.TabIndex = 1
    Me.button0.Text = "&OK"
    Me.button0.UseVisualStyleBackColor = False
    Me.button0.Visible = False
    '
    'button1
    '
    Me.button1.BackColor = System.Drawing.SystemColors.Control
    Me.button1.Cursor = System.Windows.Forms.Cursors.Default
    Me.button1.Font = New System.Drawing.Font("SImPL", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.button1.ForeColor = System.Drawing.SystemColors.ControlText
    Me.button1.Location = New System.Drawing.Point(350, 158)
    Me.button1.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
    Me.button1.Name = "button1"
    Me.button1.RightToLeft = System.Windows.Forms.RightToLeft.No
    Me.button1.Size = New System.Drawing.Size(156, 37)
    Me.button1.TabIndex = 2
    Me.button1.Text = "(1)"
    Me.button1.UseVisualStyleBackColor = False
    Me.button1.Visible = False
    '
    'labelMessage
    '
    Me.labelMessage.Location = New System.Drawing.Point(7, 9)
    Me.labelMessage.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
    Me.labelMessage.Name = "labelMessage"
    Me.labelMessage.Size = New System.Drawing.Size(500, 128)
    Me.labelMessage.TabIndex = 4
    Me.labelMessage.Text = "Multiple" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Line" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Message" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Appears" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Here"
    Me.labelMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'textInput
    '
    Me.textInput.Location = New System.Drawing.Point(10, 154)
    Me.textInput.Name = "textInput"
    Me.textInput.Size = New System.Drawing.Size(496, 41)
    Me.textInput.TabIndex = 3
    Me.textInput.Text = ""
    Me.textInput.Visible = False
    '
    'Input_Button
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 20.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(517, 209)
    Me.Controls.Add(Me.button2)
    Me.Controls.Add(Me.button0)
    Me.Controls.Add(Me.button1)
    Me.Controls.Add(Me.labelMessage)
    Me.Controls.Add(Me.textInput)
    Me.Font = New System.Drawing.Font("SImPL", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.Margin = New System.Windows.Forms.Padding(7, 5, 7, 5)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "Input_Button"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "Input or Button"
    Me.ResumeLayout(False)

  End Sub
  Public WithEvents button2 As System.Windows.Forms.Button
  Public WithEvents button0 As System.Windows.Forms.Button
  Public WithEvents button1 As System.Windows.Forms.Button
  Friend WithEvents labelMessage As System.Windows.Forms.Label
  Friend WithEvents textInput As System.Windows.Forms.RichTextBox

End Class
