﻿Imports PLJsAPL
Imports CommandLine
Public Class Numbers
Inherits WorkSpace

#Region "My_Shell"

Private _x As New Evaluate("")

Public WriteOnly Property My_Shell()As Evaluate
Set (aValue As Evaluate)
 _x=aValue
End Set
End Property

#End Region

#Region "BigInt"

Public ReadOnly Property BigInt() As Method
 Get
 Return New Method(AddressOf _BigInt , Nothing)
 End Get
End Property

Private Function _BigInt(ByVal r_a As APL) As APL
Return _a.Value(Numerics.BigInteger.Parse( r_a.CharacterVector))
End Function

#End Region

#Region "Complex"

Public ReadOnly Property Complex() As Method
 Get
 Return New Method(AddressOf _Complex , Nothing)
 End Get
End Property

Private Function _Complex(ByVal r_a As APL) As APL
Dim myNums As Object()
 r_a =_a.Value(2)(_a.Take, r_a)
myNums= r_a.ValueVector
Return _a.Value(New Numerics.Complex(CType(myNums(0),Double),CType(myNums(1),Double)))
End Function

#End Region

#Region "Conjugate"

Public ReadOnly Property Conjugate() As Method
Get
'				 Monadic, Dyadic, Dyadic Inverse, Identity
Return New Method(AddressOf _Conjugate , Nothing, Nothing, 0)
End Get
End Property

Private Function _Conjugate(ByVal aRight As Object) As Object
If TypeOf aRight Is Numerics.Complex Then
Return Numerics.Complex.Conjugate(DirectCast(aRight, Numerics.Complex))
End If
Return aRight
End Function

#End Region

#Region "Factorial"

Public ReadOnly Property Factorial() As Method
 Get
 Return New Method(AddressOf _Factorial , Nothing)
 End Get
End Property

Private Function _Factorial(ByVal r_a As APL) As APL
Return _a.Times(_a.Reduce)(_a.Plus(_a.Scan)( r_a(_a.Shape,BigInt(_a.Value("1")))))
End Function

#End Region

#Region "Format"

Public ReadOnly Property Format() As Method
 Get
 Return New Method(AddressOf _Format , Nothing)
 End Get
End Property

Private Function _Format(ByVal r_a As APL) As APL
If r_a.IsCharacter Then
Return r_a 
End If
Return _a.Value("(","")(_x.Replace,_a.Value(")","")(_x.Replace,_a.Value(", ","J")(_x.Replace, r_a)))
End Function

#End Region

End Class
