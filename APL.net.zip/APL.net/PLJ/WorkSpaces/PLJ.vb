﻿Imports PLJsAPL
Imports CommandLine
Public Class PLJ
Inherits WorkSpace

#Region "My_Shell"

Private _x As New Evaluate("")

Public WriteOnly Property My_Shell()As Evaluate
Set (aValue As Evaluate)
 _x=aValue
End Set
End Property

#End Region

#Region "across"

Public ReadOnly Property across() As Method
 Get
 Return New Method(AddressOf _across , Nothing)
 End Get
End Property

Private Function _across(ByVal r_a As APL) As APL
Return _a.Comma(sort(_a.Disclose( r_a))(_a.Comma,_a.Value(" ")))
End Function

#End Region

#Region "ask"

Public ReadOnly Property ask() As Method
 Get
 Return New Method(AddressOf _ask , Nothing)
 End Get
End Property

Private Function _ask(ByVal r_a As APL) As APL
Dim myReply As APL
' ⍝ Ask a question, and return just the user's response.
' ⍝ Only the characters after a ⎕Tab will be returned.
' ⍝ If no ⎕Tab is present, everything will be returned.
 r_a =_a.Comma( r_a)
myReply=_a.Prompt( r_a(_a.Comma,_a.Value(3)(_a.Equal,_a.Value(4)(_a.Stile,_a.Shape( r_a)))(_a.Select,_a.Value(" "))(_a.Comma,_x.Tab)))
If(_x.Tab(_a.Element,myReply)).IsTrue Then
myReply=_a.Value(1)(_a.Plus,myReply(_a.Index,_x.Tab))(_a.Drop,myReply)
End If
Return myReply
End Function

#End Region

#Region "askButton"

Public ReadOnly Property askButton() As Method
 Get
 Return New Method(AddressOf _askButton , Nothing)
 End Get
End Property

Private Function _askButton(ByVal r_a As APL) As APL
Dim myButtons As APL
myButtons=_a.Value(2)(_a.Drop, r_a)
Try
 Dim myIB As New Input_Button
 Dim myMsg As Object()= r_a.ValueVector
 Return _a.Value(myIB.Buttons( _
 myMsg(0), myMsg(1), _
 myButtons.ValueVector))
Catch ex As Exception
 _Signal(ExceptionAPL.Is.Domain)
End Try
End Function

#End Region

#Region "askInput"

Public ReadOnly Property askInput() As Method
 Get
 Return New Method(AddressOf _askInput , Nothing)
 End Get
End Property

Private Function _askInput(ByVal r_a As APL) As APL
Dim myPrompt As APL
myPrompt=_a.Value(2)(_a.Drop, r_a)
Try
 Dim myIB As New Input_Button
 Dim myMsg As Object()= r_a.ValueVector
 Return _a.Value(myIB.Input( _
 myMsg(0), myMsg(1), _
 myPrompt.ValueVector))
Catch ex As Exception
 _Signal(ExceptionAPL.Is.Domain)
End Try
End Function

#End Region

#Region "beside"

Public ReadOnly Property beside() As Method
 Get
 Return New Method(AddressOf _beside , AddressOf _beside)
 End Get
End Property

Private Function _beside(ByVal r_a As APL) As APL
Return r_a 
End Function

Private Function _beside(ByVal l_a As APL, ByVal r_a As APL) As APL
Dim a,w,m As APL
' ⍝ Ensures both arguments are a matrix, then places l_a beside r_a 
 l_a =rows(_a.Disclose(_x.CrLf(_x.Split, l_a.ToString)))
 r_a =rows(_a.Disclose(_x.CrLf(_x.Split, r_a.ToString)))
a=_a.Shape( l_a)
w=_a.Shape( r_a)
m=a.Sub(_a.Value(0))(_a.Hi,w.Sub(_a.Value(0)))
a.Sub(_a.Value(0))=m
w.Sub(_a.Value(0))=m
Return a(_a.Take, l_a)(_a.Comma,w(_a.Take, r_a))
End Function

#End Region

#Region "boxed"

Public ReadOnly Property boxed() As Method
 Get
 Return New Method(AddressOf _boxed , Nothing)
 End Get
End Property

Private Function _boxed(ByVal r_a As APL) As APL
Dim left,right As APL
' ⍝ Box non scalars
If(_a.Value(0)(_a.Equal,_a.Shape(_a.Shape( r_a)))(_a.And, r_a(_a.Id,_a.Enclose( r_a)))).IsTrue Then
Return _a.Format( r_a)(_a.Comma,_a.Value(" "))
End If
 r_a =rows(_a.Disclose(_x.CrLf(_x.Split, r_a.ToString)))
left=_a.Value("┌")(_a.Comma,_a.Value(1)(_a.Take,_a.Shape( r_a))(_a.Shape,_a.Value("│"))(_a.Comma,_a.Value("└")))
right=_a.Value("┐")(_a.Comma,_a.Value(1)(_a.Take,_a.Shape( r_a))(_a.Shape,_a.Value("│"))(_a.Comma,_a.Value("┘")))
Return left(_a.Comma,_a.Value("─")(_a.Comma.Sub(0), r_a(_a.Comma.Sub(0),_a.Value("─")))(_a.Comma,right))
End Function

#End Region

#Region "cfh"

Public ReadOnly Property cfh() As Method
 Get
 Return New Method(AddressOf _cfh , Nothing)
 End Get
End Property

Private Function _cfh(ByVal r_a As APL) As APL
Dim myParts As APL
' ⍝ Turn hex pairs into ⎕av elements
myParts=_a.Disclose(_a.Value(" ")(_x.Split, r_a))
Return _a.QuadAV.Sub(_a.Value(16)(_a.Decoder,_a.Value("0123456789abcdef")(_a.Index,myParts)))
End Function

#End Region

#Region "cols"

Public ReadOnly Property cols() As Method
 Get
 Return New Method(AddressOf _cols , Nothing)
 End Get
End Property

Private Function _cols(ByVal r_a As APL) As APL
' ⍝ Provide a matrix, with at least one row
If(_a.Value(2)(_a.Greater,_a.Shape(_a.Shape( r_a)))).IsTrue Then
 r_a =_a.Comma.Sub(.5)( r_a)
End If
Return r_a 
End Function

#End Region

#Region "debug"

Public Property debug() As APL
 Get
Stop
Return _a.Value("Debugging")
 End Get
 Set(ByVal l_a As APL)
Stop
_debug = l_a 
 End Set
End Property

Private _debug As APL

#End Region

#Region "dedup"

Public ReadOnly Property dedup() As Method
 Get
 Return New Method(AddressOf _dedup , AddressOf _dedup)
 End Get
End Property

Private Function _dedup(ByVal r_a As APL) As APL
Return _a.Value(" ")( dedup , r_a)
End Function

Private Function _dedup(ByVal l_a As APL, ByVal r_a As APL) As APL
Dim z As APL
' ⍝ Remove all adjacent items of l_a in r_a 
z=_a.Not( r_a(_a.Element, l_a))
z=_a.Or(_a.Scan)(z)(_a.And,z(_a.Or,_a.Value(1)(_a.Drop,z(_a.Comma,_a.Value(0)))))
Return z(_a.Select, r_a)
End Function

#End Region

#Region "dfh"

Public ReadOnly Property dfh() As Method
 Get
 Return New Method(AddressOf _dfh , Nothing)
 End Get
End Property

Private Function _dfh(ByVal r_a As APL) As APL
Return _x.Fi(_a.Each)(_a.Enclose(_a.Value("&h"))(_a.Comma(_a.Each),_a.Value(" ")(_x.Split, r_a)))
End Function

#End Region

#Region "display"

Public ReadOnly Property display() As Method
 Get
 Return New Method(AddressOf _display , Nothing)
 End Get
End Property

Private Function _display(ByVal r_a As APL) As APL
Dim myOut,myCount As APL
Dim myIndex As Integer
If r_a.VectorLength = 0 Then
Return _a.Value("")
End If
 r_a =_a.Comma( r_a)
myOut=boxed(_a.Disclose( r_a.Sub(_a.Value(0))))
myCount=_a.Value(1)
For myIndex=1 To r_a.VectorLength-1
myOut=myOut(beside,boxed(_a.Disclose( r_a.Sub(myCount))))
myCount=myCount(_a.Plus,_a.Value(1))
Next
Return myOut
End Function

#End Region

#Region "dump"

Public ReadOnly Property dump() As Method
 Get
 Return New Method(AddressOf _dump , Nothing)
 End Get
End Property

Private Function _dump(ByVal r_a As APL) As APL
' ⍝ Display eight bit bytes as hex
 r_a =_a.Comma(_a.Transpose(_a.Value("0123456789abcdef").Sub(_a.Value(16,16)(_a.Encode,_a.QuadAV(_a.Index, r_a)))))
 r_a =_a.Value(64)(_a.Times,_a.Hi(_a.Value(.015625)(_a.Times,_a.Shape( r_a))))(_a.Take, r_a)
Return _a.Value(71)(_a.Shape,_a.Value(8,1)(_a.Select,_a.Value(1,0)))(_a.Expand,_a.Value(.015625)(_a.Times,_a.Shape( r_a))(_a.Comma,_a.Value(64))(_a.Shape, r_a))
End Function

#End Region

#Region "environment"

Public ReadOnly Property environment() As Method
Get
Return New Method(AddressOf _environment , Nothing)
End Get
End Property

Private Function _environment(ByVal r_a As APL) As APL
Try
Return _a.Comma(System.Environment.GetEnvironmentVariable(r_a.ToString))
Catch ex As Exception
Return _a.Value("")
End Try
End Function

#End Region

#Region "hfd"

Public ReadOnly Property hfd() As Method
Get
Return New Method(AddressOf _hfd , Nothing)
End Get
End Property

Private Function _hfd(ByVal r_a As APL) As APL
Dim myIndex As Integer
Dim myValues, myResults As Object()
Dim myResult As APL

myValues = r_a.CompareValues
ReDim myResults(myValues.Length - 1)

For myIndex = 0 To myValues.Length - 1
myResults(myIndex) = Conversion.Hex(myValues(myIndex)).PadLeft(8,"0"c)
Next

myResult = New APL(myResults)
myResult.Shape = r_a.Shape
Return myResult
End Function

#End Region

#Region "left"

Public ReadOnly Property left() As Method
 Get
 Return New Method(AddressOf _left , Nothing)
 End Get
End Property

Private Function _left(ByVal r_a As APL) As APL
Return _a.Disclose(Trim(_a.Each)(_a.Comma(_a.Reduce)(rows( r_a))))
End Function

#End Region

#Region "level"

Public ReadOnly Property level() As Method
 Get
 Return New Method(AddressOf _level , Nothing)
 End Get
End Property

Private Function _level(ByVal r_a As APL) As APL
Dim myQuote,myOpen,myClose,myNest,myLevels,myLines As APL
' ⍝ Indicate level of nesting in statement
myQuote=_a.Not(_a.NotEqual(_a.Scan)( r_a(_a.Equal,_a.Value(""""))))
' ⍝ Parens and Brackets open and close
' ⍝ but only outside quotes
myOpen=myQuote(_a.Times,_a.Value(1,1,0).Sub(_a.Value("([")(_a.Index, r_a)))
myClose=myQuote(_a.Times,_a.Value(1,1,0).Sub(_a.Value(")]")(_a.Index, r_a)))
' ⍝ The nesting levels
myNest=_a.Plus(_a.Scan)(_a.Value(-1)(_a.Drop,_a.Value(0)(_a.Comma,myOpen))(_a.Minus,myClose))
myLevels=_a.Value(1)(_a.Plus,_a.Hi(_a.Reduce)(myNest)(_a.Minus,_a.Low(_a.Reduce)(myNest)))
' ⍝ Turn r_a into a matrix, and pivot it
myLines=myLevels(_a.Comma,_a.Shape( r_a))(_a.Take,_a.Value(1)(_a.Comma,_a.Shape( r_a))(_a.Shape, r_a))
Return myLevels(_a.Minus,myNest)(_a.Pivot.Sub(0),myLines)
End Function

#End Region

#Region "line"

Public ReadOnly Property line() As Method
 Get
 Return New Method(Nothing, AddressOf _line)
 End Get
End Property

Private Function _line(ByVal l_a As APL, ByVal r_a As APL) As APL
Return _a.Comma.Sub(.5)(_x.CrLf(_x.Split, r_a).Sub( l_a))
End Function

#End Region

#Region "mfv"

Public ReadOnly Property mfv() As Method
 Get
 Return New Method(AddressOf _mfv , AddressOf _mfv)
 End Get
End Property

Private Function _mfv(ByVal r_a As APL) As APL
Return _x.CrLf( mfv , r_a)
End Function

Private Function _mfv(ByVal l_a As APL, ByVal r_a As APL) As APL
Return _a.Disclose( l_a(_x.Split, r_a))
End Function

#End Region

#Region "over"

Public ReadOnly Property over() As Method
 Get
 Return New Method(Nothing, AddressOf _over)
 End Get
End Property

Private Function _over(ByVal l_a As APL, ByVal r_a As APL) As APL
Dim a,w,m As APL
' ⍝ Ensures both arguments are a matrix, then places l_a over r_a 
 l_a =rows(_a.Disclose(_x.CrLf(_x.Split, l_a.ToString)))
 r_a =rows(_a.Disclose(_x.CrLf(_x.Split, r_a.ToString)))
a=_a.Shape( l_a)
w=_a.Shape( r_a)
m=a.Sub(_a.Value(1))(_a.Hi,w.Sub(_a.Value(1)))
a.Sub(_a.Value(1))=m
w.Sub(_a.Value(1))=m
Return a(_a.Take, l_a)(_a.Comma.Sub(0),w(_a.Take, r_a))
End Function

#End Region

#Region "PadLeft"

Public ReadOnly Property PadLeft() As Method
 Get
 Return New Method(Nothing, AddressOf _PadLeft)
 End Get
End Property

Private Function _PadLeft(ByVal l_a As APL, ByVal r_a As APL) As APL
Return _a.Comma( r_a.ToString.PadLeft( l_a.IntegerIndex))
End Function

#End Region

#Region "PadRight"

Public ReadOnly Property PadRight() As Method
 Get
 Return New Method(Nothing, AddressOf _PadRight)
 End Get
End Property

Private Function _PadRight(ByVal l_a As APL, ByVal r_a As APL) As APL
Return _a.Comma( r_a.ToString.PadRight( l_a.IntegerIndex))
End Function

#End Region

#Region "quotes"

Public ReadOnly Property quotes() As Method
 Get
 Return New Method(AddressOf _quotes , Nothing)
 End Get
End Property

Private Function _quotes(ByVal r_a As APL) As APL
Dim myQuote As APL
' ⍝ Prepare string for saving
myQuote=_a.Value(1)(_a.Plus, r_a(_a.Equal,_a.Value("""")))(_a.Select, r_a)
Return _a.Value("""")(_a.Comma,myQuote(_a.Comma,_a.Value("""")))
End Function

#End Region

#Region "right"

Public ReadOnly Property right() As Method
 Get
 Return New Method(AddressOf _right , Nothing)
 End Get
End Property

Private Function _right(ByVal r_a As APL) As APL
 r_a =Trim(_a.Each)(_a.Comma(_a.Reduce)(rows( r_a)))
Return _a.Disclose(_a.Hi(_a.Reduce)(_a.Comma(_a.Disclose(_a.Shape(_a.Each)( r_a))))(PadLeft(_a.Each), r_a))
End Function

#End Region

#Region "rows"

Public ReadOnly Property rows() As Method
 Get
 Return New Method(AddressOf _rows , Nothing)
 End Get
End Property

Private Function _rows(ByVal r_a As APL) As APL
' ⍝ Provide a matrix, with at least one row
If(_a.Value(2)(_a.Greater,_a.Shape(_a.Shape( r_a)))).IsTrue Then
 r_a =_a.Comma.Sub(-.5)( r_a)
End If
Return r_a 
End Function

#End Region

#Region "sort"

Public ReadOnly Property sort() As Method
 Get
 Return New Method(AddressOf _sort , AddressOf _sort)
 End Get
End Property

Private Function _sort(ByVal r_a As APL) As APL
Return SortOrder( sort , r_a)
End Function

Private Function _sort(ByVal l_a As APL, ByVal r_a As APL) As APL
Return r_a.Sub( l_a(_a.GradeUp, r_a),_a.Empty)
End Function

#End Region

#Region "SortOrder"

Public ReadOnly Property SortOrder() As APL
 Get
' ⍝ This is a Property! It behaves like a variable.
_SortOrder =_a.Value(10,26)(_a.Take,_a.QuadAV.Sub(_a.Value(97,65)(_a.Plus(_a.DotDot),_a.Index(_a.Value(26)))))
_SortOrder =_a.Value(10)(_a.Take,_a.QuadAV.Sub(_a.Value(32,160)))(_a.Comma,_a.Value("0123456789")(_a.Comma,_SortOrder(_a.Comma,_a.Value(10)(_a.Take,_a.Value("-,;:.!?")))))
Return _SortOrder 
 End Get
End Property

Private _SortOrder As APL

#End Region

#Region "thru"

Public ReadOnly Property thru() As Method
 Get
 Return New Method(Nothing, AddressOf _thru)
 End Get
End Property

Private Function _thru(ByVal l_a As APL, ByVal r_a As APL) As APL
Dim myDiff As APL
' ⍝ Ordered value thru value
' ⍝ note: 1 3 4 5 6 7 10 ←→ 1 3 thru 7 10
myDiff=_a.Value(1)(_a.Take, r_a)(_a.Minus,_a.Value(-1)(_a.Take, l_a))
Return l_a(_a.Comma,_a.Value(-1)(_a.Take, l_a)(_a.Plus,_a.Times(myDiff)(_a.Times,_a.Value(1)(_a.Plus,_a.Index(_a.Stile(myDiff)))))(_a.Comma,_a.Value(1)(_a.Drop, r_a)))
End Function

#End Region

#Region "ToLower"

Public ReadOnly Property ToLower() As Method
 Get
 Return New Method(AddressOf _ToLower , Nothing)
 End Get
End Property

Private Function _ToLower(ByVal r_a As APL) As APL
Return _a.Shape( r_a)(_a.Shape, r_a.CharacterVector.ToLower)
End Function

#End Region

#Region "top"

Public ReadOnly Property top() As Method
 Get
 Return New Method(AddressOf _top , Nothing)
 End Get
End Property

Private Function _top(ByVal r_a As APL) As APL
Return _a.Disclose(_x.CrLf(_x.Split, r_a.ToString.TrimEnd))
End Function

#End Region

#Region "ToUpper"

Public ReadOnly Property ToUpper() As Method
 Get
 Return New Method(AddressOf _ToUpper , Nothing)
 End Get
End Property

Private Function _ToUpper(ByVal r_a As APL) As APL
Return _a.Shape( r_a)(_a.Shape, r_a.CharacterVector.ToUpper)
End Function

#End Region

#Region "Trim"

Public ReadOnly Property Trim() As Method
 Get
 Return New Method(AddressOf _Trim , Nothing)
 End Get
End Property

Private Function _Trim(ByVal r_a As APL) As APL
Return _a.Comma( r_a.CharacterVector.Trim)
End Function

#End Region

#Region "TrimEnd"

Public ReadOnly Property TrimEnd() As Method
 Get
 Return New Method(AddressOf _TrimEnd , Nothing)
 End Get
End Property

Private Function _TrimEnd(ByVal r_a As APL) As APL
Return _a.Comma( r_a.ToString.TrimEnd)
End Function

#End Region

#Region "TrimStart"

Public ReadOnly Property TrimStart() As Method
 Get
 Return New Method(AddressOf _TrimStart , Nothing)
 End Get
End Property

Private Function _TrimStart(ByVal r_a As APL) As APL
Return _a.Comma( r_a.ToString.TrimStart)
End Function

#End Region

#Region "vfm"

Public ReadOnly Property vfm() As Method
 Get
 Return New Method(AddressOf _vfm , AddressOf _vfm)
 End Get
End Property

Private Function _vfm(ByVal r_a As APL) As APL
Return _x.CrLf( vfm , r_a)
End Function

Private Function _vfm(ByVal l_a As APL, ByVal r_a As APL) As APL
Return l_a(_x.Join,TrimEnd(_a.Each)(_a.Comma(_a.Reduce)(rows( r_a))))
End Function

#End Region

#Region "yes"

Public ReadOnly Property yes() As Method
 Get
 Return New Method(AddressOf _yes , Nothing)
 End Get
End Property

Private Function _yes(ByVal r_a As APL) As APL
Dim myReply,myAccept As APL
' ⍝ Ask a Yes or No question, and return true or false.
myAccept=_a.Value(" ")(_x.Split,_a.Value("n y no yes"))
Do
myReply=ask( r_a)
myReply=myAccept(_a.Index,_a.Enclose(ToLower(Trim(myReply))))
If(myReply(_a.NotEqual,_a.Value(4))).IsTrue Then
Exit Do
End If
 r_a =_a.Value("Please respond Yes or No:")
Loop
Return _a.Value(2)(_a.Stile,myReply)
End Function

#End Region

End Class
