﻿Imports PLJsAPL
Imports CommandLine
Public Class Samples
Inherits WorkSpace

#Region "My_Shell"

Private _x As New Evaluate("")

Public WriteOnly Property My_Shell()As Evaluate
Set (aValue As Evaluate)
 _x=aValue
End Set
End Property

#End Region

#Region "Adjacent"

Public ReadOnly Property Adjacent() As OpMonadic
 Get
 Return New OpMonadic(AddressOf _Adjacent , Nothing, True)
 End Get
End Property

Private Function _Adjacent( _
 ByVal l_f As Method, _
 ByVal a_x As APL, _
 ByVal r_a As APL) As APL
Dim myShift As APL
If r_a.Rank = 0 Then
 _Signal(ExceptionAPL.Is.Rank)
End If
If Array.ReferenceEquals( a_x , _a.Empty) Then
 a_x =_a.Value(-1)(_a.Plus,_a.Shape(_a.Shape( r_a)))
End If
myShift=_a.Value(0)(_a.Times,_a.Shape( r_a))
myShift.Sub( a_x)=_a.Value(1)
Return _a.Minus(myShift)(_a.Drop, r_a)( l_f ,myShift(_a.Drop, r_a))
End Function

#End Region

#Region "Debug"

Public ReadOnly Property Debug() As Method
 Get
 Return New Method(AddressOf _Debug , Nothing)
 End Get
End Property

Private Function _Debug(ByVal r_a As APL) As APL
Stop
Return _a.Value("Debugging")
End Function

#End Region

#Region "Report"

Public ReadOnly Property Report() As Method
 Get
 Return New Method(AddressOf _Report , AddressOf _Report)
 End Get
End Property

Private Function _Report(ByVal r_a As APL) As APL
Dim myTime,myLast As APL
myTime=_a.QuadTS
myLast=myTime.Sub(_a.Value(2))(_a.LessOrEqual,_a.Value(15))
myLast=myTime.Sub(_a.Value(1))(_a.Minus,myLast)
Return myLast( Report , r_a)
End Function

Private Function _Report(ByVal l_a As APL, ByVal r_a As APL) As APL
Dim myMonths,myItems,myTotal As APL
' Produce a report from a matrix
myMonths=_a.Pivot( l_a(_a.Minus,_a.Value(1))(_a.Minus,_a.Index(_a.Shape( r_a).Sub(_a.Value(1)))))
myMonths=_a.Value("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec").Sub(myMonths)
myItems=_a.Format(_a.Comma.Sub(.5)(_a.Value(1)(_a.Pivot,_a.Value("Total","")(_a.Comma,_a.Value(1)(_a.Plus,_a.Index(_a.Shape( r_a).Sub(_a.Value(0))))))))
myTotal=_a.Value(0,2)(_a.Format,myMonths(_a.Comma.Sub(0), r_a(_a.Comma.Sub(0),_a.Plus(_a.Reduce.Sub(0))( r_a))))
Return myItems(_a.Comma,myTotal)
End Function

#End Region

#Region "Value"

Public Property Value() As APL
 Get
Return _Value 
 End Get
 Set(ByVal l_a As APL)
_Value = l_a 
 End Set
End Property

Private _Value As APL

#End Region

End Class
