﻿Imports AltKeys
Imports Tools

Public Class EditAPL

  Private Sub EditAPL_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Dim myArgs As String()

    ShellOutput.TabIndex = 0
    If Names.Path = Host.Program Then
      Names.Path = Host.Desktop
    End If

    myArgs = Environment.GetCommandLineArgs
    If myArgs.Length = 2 Then
      Me.Open(myArgs(1))

    Else
      Viewing("will save in " & Names.Path) = False
    End If
  End Sub

End Class
