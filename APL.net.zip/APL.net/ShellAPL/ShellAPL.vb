﻿Imports System.Text
Imports AltKeys
Imports CommandLine
Imports Tools
Imports PLJsAPL

Partial Class ShellAPL

#Region "Private Properties"

  Private WithEvents thisInput As APLRichText
  Private WithEvents thisOutput As APLRichText
  Private WithEvents thisCommand As Commands
  Private thisCompile As Compile
  Private thisIndirect As Boolean
  Private thisLibPath, thisSessionPath, thisMapChar, thisPrevious As String
  Private thisLog As LinesOut
  Private thisScript As LinesIn
  Private thisCompilePath As String

#End Region

#Region "Handle thisContext's Events"

  Private WithEvents thisContext As InputOutput = _Events

  ''' <summary>
  ''' Outputs handles PLJsAPL output requests.
  ''' If your program just calls functions in a WorkSpace,
  ''' there is no requirement to handle this event.
  ''' </summary>
  ''' <param name="aPrompt"></param>
  ''' <remarks></remarks>
  Private Sub thisContext_Outputs(ByVal aPrompt As String) Handles thisContext.Outputs
    thisOutput.AppendText(aPrompt.Replace(ControlChars.NullChar, ChrW(&HA0)))
    GetDown()
  End Sub

  ''' <summary>
  ''' Inputs handles PLJsAPL input requests.
  ''' You man ignore this event if you are sure
  ''' the workspace does not make input requests.
  ''' </summary>
  ''' <param name="aPrompt">
  ''' A string of characters to output.
  ''' </param>
  ''' <param name="aResult">
  ''' Events don't return results, instead you
  ''' assign a value to this ByRef argument.
  ''' </param>
  Private Sub thisContext_Inputs(ByVal aPrompt As String, ByRef aResult As String) Handles thisContext.Inputs
    GetDown()
    aPrompt = aPrompt.Replace(ControlChars.NullChar, ChrW(&HA0))
    aResult = AwaitInput(aPrompt)

    If Not aResult.StartsWith(aPrompt) Then
      Output(aPrompt)
    End If
    AppendLog(aResult)
    Output(aResult)
    GetDown()
  End Sub

  Public Sub GetDown()
    thisOutput.Focus()
    thisOutput.Select(thisOutput.TextLength, 0)
    thisInput.Focus()
  End Sub

#End Region

#Region "Handle thisCommand's Events"

  Private Sub thisCommand_Inputs(ByVal aLine As String) Handles thisCommand.Inputs
    thisInput.Text = aLine
    thisInput.SelectionStart = thisInput.TextLength
  End Sub

  Private Sub thisCommand_Wsid(ByVal aWsid As String) Handles thisCommand.Wsid
    Me.Viewing(aWsid) = True
    If aWsid Is Nothing Then
      Me.Text = "Viewing Clear Workspace"
    End If
  End Sub

  Private Sub thisCommand_Restart(ByVal aWsid As String, ByVal aLoaded As Boolean) Handles thisCommand.Restart
    Dim myFile, myCompile As String

#If Not Debug Then
    If Not aLoaded Then
      Host.Launch(thisCompilePath)
      Return
    End If
#End If

      ' Save the session log
      myFile = Names.Combine(thisLibPath, "ToCompile.log")
      myCompile = thisOutput.Text.TrimEnd
      myCompile = myCompile.Remove(myCompile.LastIndexOf(")"))

      If aWsid Is Nothing Then
        myCompile &= ")Compile"
      Else
        myCompile &= ")Compile from " & aWsid
      End If
      Files.Lines(myFile) = myCompile

      ' Save Continue
      thisCommand.Continue()

      ' Restart ShellAPL
#If Not Debug Then
    myFile = Names.Combine(Host.Program, "ShellAPL.exe")
    Host.Launch(myFile, "Lib=""" & Names.JustFolder(thisLibPath) & """", False, ProcessWindowStyle.Normal)
#End If

    thisLibPath = Nothing
    ' There may another way to unload the User's DLL, but
    ' it is looking like a lot of work, and this is easy.
    Application.Exit()
  End Sub

  Private Sub thisCommand_Off(ByVal aFile As String) Handles thisCommand.Off
    thisCommand.Continue()
    thisLibPath = Nothing
    Try
      If aFile.Length <> 0 Then
        Files.Lines(aFile & ".apl") = thisOutput.Text
      End If
    Catch ex As Exception
    End Try
    Application.Exit()
  End Sub

#End Region

#Region "Handle Form's Events"

  Private Sub ShellAPL_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Dim myPLJ, myPath, myLib, myFile As String

    Names.Path = Host.Desktop
    SetupForm()
    CheckVersions()
    myPath = GetParm("lib")
    If myPath.Length = 0 Then
      myPLJ = Names.Combine(Host.MyDocuments, "PLJ")
      myPath = Names.Combine(myPLJ, "PLJsAPL")
      myLib = Names.Combine(myPath, "WorkSpaces")
      InstallLib(myPLJ, myLib)
    Else
      myLib = Names.Combine(myPath, "WorkSpaces")
    End If

    If Names.IsFolder(myLib) Then
      thisSessionPath = Names.Combine(myPath, "Sessions")
      SetupSession(True)
      thisCompile = New Compile

      ' N.B.  Don't assign early because shutdown checks this
      thisLibPath = myLib
      SetupCommands()

      ' Restore Continue, if present.
      myFile = "Continue"
      If Names.IsFile(Names.Combine(thisLibPath, myFile & ".aplws")) Then
        thisCommand.LoadCommand(myFile, "Load")
      End If

      ' Restore Log, if present.
      myFile = Names.Combine(thisLibPath, "ToCompile.log")
      If Names.IsFile(myFile) Then
#If Not WorkSpaces Then
        Host.Launch(thisCompilePath)
#End If
        Restore(myFile)

      Else
        myPath = GetParm("start")
        If myPath.Length <> 0 Then
          Me.Show()
          If Names.IsFile(myPath) Then
            RunsScript(myPath, False)
          Else
            Output("Start=Script does not exist")
            Output("      '" & myPath & "'")
          End If
        End If
      End If

    Else
      Application.Exit()
    End If
  End Sub

  Private Sub Restore(ByVal aFile As String)
    Dim myLog, myWsid, myTemp As String
    Dim myLast As Integer

    myLog = Files.Lines(aFile)
    myLast = myLog.LastIndexOf(ControlChars.Lf)
    myWsid = Nothing
    If myLast <> -1 Then
      myTemp = myLog.Substring(myLast).Trim
      If myTemp.StartsWith(")Compile from ") Then
        myWsid = myTemp.Substring(14)
      End If
    End If

    thisCommand.RestoreWsid(myWsid)
    Me.Show()
    thisOutput.Focus()
    Output(myLog)
    thisInput.Focus()
    Names.Erase(aFile)
  End Sub

  Private Sub ShellAPL_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
    thisInput.Focus()
  End Sub

  Private Sub ShellAPL_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
    thisAwaitInput = False
    If thisLibPath IsNot Nothing Then
      thisCommand.Continue()
    End If
    Indirect = thisIndirect
    CloseLog()
    If thisScript IsNot Nothing Then
      thisScript.Close()
      thisScript = Nothing
    End If
  End Sub

#End Region

#Region "GetParm"

  Private Function GetParm(ByVal aName As String) As String
    Dim myParms As String()
    Dim myIndex As Integer

    myParms = Environment.GetCommandLineArgs
    aName &= "="
    For myIndex = 1 To myParms.Length - 1
      If myParms(myIndex).ToLower.StartsWith(aName) Then
        Return myParms(myIndex).Substring(aName.Length)
      End If
    Next

    Return ""
  End Function

#End Region

#Region "RunScript"

  Private Sub ShellAPL_RunScript() Handles Me.RunScript
    Dim myScript, myPath As String
    If thisSessionPath IsNot Nothing Then
      myPath = Names.Path
      myScript = Names.OpenFileDialog("Choose a Script File", _
          thisSessionPath, True, "Scripts|*.apl|All Files|*")
      ' An open dialog moves the default path.
      ' This puts it back.
      Names.Path = myPath
      If myScript IsNot Nothing Then
        RunsScript(myScript, True)
      Else
        Me.NoOpen = True
      End If
    End If
  End Sub

  Private Sub RunsScript(ByVal aScript As String, ByVal aPause As Boolean)
    Dim myLine As String

    Try
      thisInput.Enabled = False

      AppendLog("' Running Script " & aScript)
      ' Just in case you choose today's Log
      CloseLog()

      thisScript = New LinesIn(aScript, System.Text.Encoding.Default)
      myLine = thisScript.Line
      Do Until myLine Is Nothing
        myLine = myLine.TrimStart
        If myLine.Length = 0 Then
          Output("")

        ElseIf myLine.StartsWith("'") Then
          If aPause Then
            If myLine.StartsWith("''") Then
              thisInput.Enabled = True
              thisInput.Focus()

              AwaitInput("Please press enter.")
              thisInput.Enabled = False
              If Not myLine.StartsWith("'''") Then
                Comment(myLine.Substring(1))
              End If
            Else
              Comment(myLine)
            End If
          Else
            Comment(myLine.TrimStart("'"c, " "c))
          End If

        Else
          Command(myLine)
        End If

        myLine = thisScript.Line
      Loop

      thisScript.Close()
      thisScript = Nothing

      SetupSession(False)
      AppendLog("' Script ended, resuming user input.")
      thisInput.Enabled = True
      thisInput.Focus()

    Catch ex As Exception
      Output("Access Error  '" & aScript & "'")
    End Try

    Me.NoOpen = True
  End Sub

#End Region

#Region "AwaitInput"

  Private thisAwaitInput As Boolean
  Private Function AwaitInput(ByVal aLine As String) As String
    thisAwaitInput = True
    thisInput.Text = aLine
    thisInput.SelectionStart = thisInput.TextLength

    Do While thisAwaitInput
      My.Application.DoEvents()
    Loop

    aLine = thisInput.Text
    Clear()
    Return aLine
  End Function

#End Region

#Region "CheckVersions"

  Private thisVersion As String
  Private Sub CheckVersions()
    Dim myVersions As String()
    Dim myVersion As Version

    myVersion = New Version("")
    thisVersion = myVersion.Version
    myVersions = myVersion.CheckVersions("PLJsAPL.dll", "CommandLine.dll", _
                                         "AltKeys.dll", "Tools.dll")
    If myVersions.Length <> 0 Then
      Output("Warning, versions do not match!")
      Output("ShellAPL.exe is " & thisVersion & " while ")
      Output(Join(myVersions, ControlChars.NewLine))
    End If
  End Sub

#End Region

#Region "SetupForm InstallLib"

  Private Sub SetupForm()
    thisOutput = ShellOutput()
    thisOutput.WordWrap = True
    Me.NoOpen = True
    Me.Viewing(Nothing) = True
    Me.Text = "Viewing Clear Workspace"

    thisInput = ShellInput()
    thisIndirect = Indirect
    SetColor()
    Clear()
  End Sub

  Public Sub InstallLib(ByVal aPath As String, ByVal aFolder As String)
    If Not Names.IsFolder(aFolder) Then
      If MessageBox.Show( _
          "The library does not exist!" & ControlChars.Lf & _
          "May I install it into My Documents?", _
          Me.Text, MessageBoxButtons.YesNo) _
          = Windows.Forms.DialogResult.Yes Then
        My.Computer.FileSystem.CopyDirectory( _
            Names.Combine(Host.Program, "PLJ"), aPath)
      End If
    End If
  End Sub

#End Region

#Region "SetupSession AppendLog CloseLog"

  Private Sub SetupSession(ByVal anInitial As Boolean)
    Dim myFile As String
    Dim myCount As Integer

    Try
      If Not Names.IsFolder(thisSessionPath) Then
        My.Computer.FileSystem.CreateDirectory(thisSessionPath)
      End If

      myCount = Diagnostics.Process.GetProcessesByName( _
                Diagnostics.Process.GetCurrentProcess.ProcessName).Length
      If myCount = 1 Then
        myFile = String.Format( _
            "Session {0:yyyy.MM.dd}.log", Now)
      Else
        myFile = String.Format( _
            "Session {0:yyyy.MM.dd} {0:HH.mm.ss}.{1}.log", Now, myCount)
      End If
      myFile = Names.Combine(thisSessionPath, myFile)

      ' N.B. Uncomment if you want logging
      ' thisLog = New LinesOut(myFile, True, Encoding.UTF8)
      ' thisLog.AutoFlush = True

      If anInitial Then
        myFile = "' Session started " & Now
        AppendLog(myFile)
        Comment(myFile)
      End If

    Catch ex As Exception
      Comment("' No log for this session.")
    End Try
  End Sub

  Private Sub AppendLog(ByVal aLine As String)
    If thisLog IsNot Nothing AndAlso aLine.Length <> 0 Then
      thisLog.Line = aLine
    End If
  End Sub

  Private Sub CloseLog()
    If thisLog IsNot Nothing Then
      thisLog.Close()
      thisLog = Nothing
    End If
  End Sub

#End Region

#Region "SetupCommands"

  Private Sub SetupCommands()
    Dim myDll As String

    thisCompilePath = Names.Combine(thisLibPath, "WorkSpaces.vbproj")
    myDll = Names.Combine(thisLibPath, "bin")
    myDll = Names.Combine(myDll, "Debug")
    myDll = Names.Combine(myDll, "WorkSpaces.dll")
    thisCommand = New Commands(thisLibPath, thisCompilePath, myDll)
  End Sub

#End Region

#Region "thisInput's AltKeys and KeyDown"

  Private Sub thisInput_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles thisInput.KeyDown
    Dim myLine As String

    If thisAwaitInput Then
      If e.KeyCode = Keys.Enter Then
        e.Handled = True
        thisAwaitInput = False
        Return
      End If
    End If

    If e.KeyCode = Keys.F1 AndAlso e.Shift Then
      e.Handled = True
      thisIndirect = Not thisIndirect
      SetColor()

    ElseIf e.KeyCode = Keys.Enter Then
      e.Handled = True
      myLine = thisInput.Text.TrimStart
      Clear()
      AppendLog(myLine)
      If IsVersion(myLine) Then
        Return
      End If
      Command(myLine)
    End If
  End Sub

  Private Function IsVersion(ByVal aLine As String) As Boolean
    Dim myLine As String

    myLine = aLine.TrimStart
    If myLine.StartsWith(")") Then
      myLine = myLine.Substring(1).ToLower.Trim
      If myLine = "version" Then
        Output("   " & aLine)
        Output("The version is " & thisVersion)
        Output("To check for updates, click on the following link.")
        Output("http://Check_PLJsAPL_Version")
        Return True
      End If
    End If
  End Function

  Private Sub Clear()
    thisInput.Text = "  "
    thisInput.SelectionStart = 2
    thisInput.Refresh()
  End Sub

  Private Sub Comment(ByVal aLine As String)
    If Not aLine.StartsWith("'") Then
      aLine = "' " & aLine
    End If
    thisOutput.AppendText("   " & aLine & ControlChars.NewLine)
  End Sub

  Private Sub SetColor()
    If thisIndirect Then
      thisInput.BackColor = Color.Yellow
    Else
      thisInput.BackColor = Color.White
    End If
  End Sub

  ' N.B.  Usage of MapKeys.vb is discontinued!
  '       To restore, include in project and uncomment
  '       thisInput_AltKeys and thisInput_KeyPress
  '
  'Private Sub thisInput_AltKeys(ByRef aKey As String) Handles thisInput.AltKeys
  '  If thisIndirect Then
  '    aKey = MapAlt(aKey)
  '  End If
  'End Sub

  'Private Sub thisInput_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles thisInput.KeyPress
  '  Dim myChar As String
  '
  '  If thisIndirect Then
  '    myChar = MapNormal(e.KeyChar)
  '    If myChar IsNot Nothing Then
  '      e.Handled = True
  '      thisInput.SelectedText = myChar
  '    End If
  '  End If
  'End Sub

#End Region

#Region "Command"

  Private Sub Command(ByVal aLine As String)
    thisCommand.InputAPL(aLine, thisIndirect)
  End Sub

#End Region

#Region "thisOutput's LinkClicked"

  Private Sub thisOutput_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles thisOutput.GotFocus
    thisOutput.BackColor = Color.White
  End Sub

  Private Sub thisOutput_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles thisOutput.KeyDown
    Select Case e.KeyCode
      Case Keys.ControlKey
        Clipboard.Clear()
      Case Keys.Enter
        e.Handled = True
        thisInput.SelectedText = thisOutput.SelectedText.Trim(ControlChars.Lf)
        thisOutput.SelectionLength = 0
        thisInput.Focus()
    End Select
  End Sub

  Private Sub thisOutput_LinkClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.LinkClickedEventArgs) Handles thisOutput.LinkClicked
    Dim myFile, myVersion As String

    Try
      If e.LinkText = "http://Check_PLJsAPL_Version" Then
        myFile = "http://home.comcast.net/~paul.l.jackson/PLJsAPL/Version4.0.txt"
        myVersion = Host.WebPage(myFile).Trim
        If thisVersion = myVersion Then
          Output("You have the latest version.")
        Else
          Output("The latest version is " & myVersion)
          Output("To get a copy, click on the line below.")
          Output("http://home.comcast.net/~paul.l.jackson/PLJsAPL/PLJsAPL.zip")
          Output("Be sure to stop using all copies of PLJsAPL before you install.")
        End If
      Else
        Host.Launch(e.LinkText)
      End If
    Catch ex As Exception
    End Try
  End Sub

#End Region

#Region "Output"

  Private Sub Output(ByVal aLine As String)
    thisOutput.AppendText(aLine & ControlChars.NewLine)
    thisOutput.Refresh()
  End Sub

#End Region

#Region "Indirect"

  Private Property Indirect() As Boolean
    Get
      Dim myConfig As Config

      myConfig = New Config(Microsoft.Win32.Registry.CurrentUser, "Software\Enlightened Solutions")
      Return myConfig.Value("ShellAPL", "Indirect", "False") = "True"
    End Get
    Set(ByVal aValue As Boolean)
      Dim myConfig As Config

      myConfig = New Config(Microsoft.Win32.Registry.CurrentUser, "Software\Enlightened Solutions")
      myConfig.Value("ShellAPL", "Indirect") = aValue.ToString
    End Set
  End Property

#End Region

End Class