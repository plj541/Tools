﻿Imports System.Diagnostics.FileVersionInfo
Imports Tools

Public Class Version
  Private thisLocation As String

  Public Sub New(ByVal Reflection_Assembly_GetExecutingAssembly_Location As String)
    If Reflection_Assembly_GetExecutingAssembly_Location.Length = 0 Then
      thisLocation = Reflection.Assembly.GetExecutingAssembly.Location()

    Else
      thisLocation = Reflection_Assembly_GetExecutingAssembly_Location
    End If
  End Sub

  Public Function Version() As String
    Return GetVersionInfo(thisLocation).FileVersion
  End Function

  Public Function CheckVersions(ByVal ParamArray aFile As String()) As String()
    Dim myResult As String()
    Dim myFile, myPath, myFullName, myVersion, myOther As String
    Dim myIndex, myItems As Integer

    myVersion = Version()
    myPath = Host.Program
    ReDim myResult(aFile.Length - 1)
    For myIndex = 0 To myResult.Length - 1
      myFile = aFile(myIndex)
      myFullName = Names.Combine(myPath, myFile)
      myOther = New Version(myFullName).Version
      If myVersion <> myOther Then
        myResult(myItems) = myFile & " is " & myOther
        myItems += 1
      End If
    Next

    ReDim Preserve myResult(myItems - 1)
    Return myResult
  End Function

End Class
