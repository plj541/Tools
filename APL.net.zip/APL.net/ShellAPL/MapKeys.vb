﻿Partial Class ShellAPL

#Region "MapAlt"

  Private Function MapAlt(ByVal aChar As String) As String
    If NotQuoted() Then
      thisMapChar = ""
      Select Case aChar
        '   22C4 25C7 25CA 2662
        Case "⋄", "◇", "◊", "♢" ' SImPL has several diamonds
          ' Not supported by ShellAPL
          ' It could be:
          ' thisMapChar = " : "
        Case "¨"
          If thisPrevious.EndsWith("(") Then
            thisMapChar = "_a.Each)"
          Else
            thisMapChar = "(_a.Each)"
          End If
        Case "¯"
          FoundConstant("-")
          If thisMapChar.Length = 0 Then
            thisMapChar = "-"
          End If
          '  "<" see MapNormal
        Case "≤"
          Map("a.LessOrEqual", "a.LessOrEqual")
          '  "=" see MapNormal
        Case "≥"
          Map("a.GreaterOrEqual", "a.GreaterOrEqual")
          '  ">" see MapNormal
        Case "≠"
          Map("a.NotEqual", "a.NotEqual")
        Case "∨"
          Map("a.Or", "a.Or")
        Case "∧" ' for "^" see MapNormal
          Map("a.And", "a.And")
        Case "×"
          Map("a.Times", "a.Times")
        Case "÷"
          Map("a.Divide", "a.Divide")

        Case "⍵"
          thisMapChar = "⍵"
        Case "∊"
          Map("a.Element", "a.Element")
        Case "⍴"
          Map("a.Shape", "a.Shape")
          '  "~" see MapNormal
        Case "↑"
          Map("a.Take", "a.Take")
        Case "↓"
          Map("a.Drop", "a.Drop")
        Case "⍳"
          Map("a.Index", "a.Index")
        Case "○"
          Map("a.Circle", "a.Circle")
          '  "*" see MapNormal
        Case "←"
          If Not thisPrevious.EndsWith("(") Then
            thisMapChar = "="
          End If
        Case "→"
          ' Not supported.
        Case "⊣"
          '  This is Left or Right, neither of which PLJsAPL needs.

        Case "⍺"
          thisMapChar = "⍺"
        Case "⌈"
          Map("a.Hi", "a.Hi")
        Case "⌊"
          Map("a.Low", "a.Low")
          '  "_" see MapNormal
        Case "∇"
          thisMapChar = "∇"
        Case "∆"
          thisMapChar = "∆"
        Case "∙"
          Map("a.Dot", "a.Dot")
        Case "∘"
          thisMapChar = "(_a.DotDot)"
        Case "⍞"
          ' Return ""
          If thisPrevious.EndsWith("(") Then
            thisMapChar = "_a.Quote,"
          ElseIf thisPrevious.EndsWith(",") Then
            thisMapChar = "_a.Quote)"
          Else
            thisMapChar = "_Quote"
          End If
        Case "⎕"
          thisMapChar = "_a.Quad"
        Case "⍎"
          Map("a.Execute", "")
        Case "⊂"
          Map("a.Enclose", "a.Enclose")
        Case "⊃"
          Map("a.Disclose", "a.Disclose")
        Case "∩"    ' I don't know a definition.
        Case "∪"    ' I don't know a definition.
        Case "⊤"
          Map("a.Encode", "a.Encode")
        Case "⊥"
          Map("a.Decode", "a.Decode")
          '  "|" see MapNormal
        Case "⍝"
          thisMapChar = "' "
        Case "⍕"
          Map("a.Format", "a.Format")

        Case "⍬"
          thisMapChar = "_a.Value()"
        Case "⍱", "⊽"  ' SImPL has two Nor characters
          Map("a.Nor", "a.Nor")
        Case "⍲", "⊼" ' SImPL has two Nand characters
          Map("a.Nand", "a.Nand")

        Case "⌹"
          Map("a.Matrix", "a.Matrix")
        Case "⌽"
          Map("a.Pivot", "a.Pivot")
        Case "⊛"
          Map("a.Log", "a.Log")
        Case "⍉"
          Map("a.Transpose", "a.Transpose")

        Case "⍒"
          Map("a.GradeDown", "a.GradeDown")
        Case "⍋"
          Map("a.GradeUp", "a.GradeUp")
        Case "≡"
          Map("a.Id", "a.Id")
        Case "⌶"
          'thisMapChar = ""

        Case Else
          MapANormal(aChar)
      End Select
      Return thisMapChar

    Else
      Return aChar
    End If
  End Function

#End Region

#Region "MapNormal"

  Private Function MapNormal(ByVal aChar As String) As String
    If Asc(aChar) < 33 Then
      Return Nothing
    End If

    If NotQuoted() Then
      thisMapChar = Nothing
      MapANormal(aChar)
      Return thisMapChar

    Else
      Return Nothing
    End If
  End Function

  Private Sub MapANormal(ByVal aChar As String)
    If "0123456789""".Contains(aChar) Then
      FoundConstant(aChar)
      Return
    End If

    Select Case aChar
      Case ";"
        If thisPrevious.EndsWith(",") OrElse _
           thisPrevious.EndsWith("(") Then
          thisMapChar = "_a.Empty,"
        ElseIf "0123456789.""".Contains(LastOne) Then
          thisMapChar = "),"
        Else
          thisMapChar = ","
        End If
      Case "["
        thisMapChar = ".Sub("
      Case "]"
        If thisPrevious.EndsWith(",") Then
          thisMapChar = "_a.Empty)"
        ElseIf "0123456789.""".Contains(LastOne) Then
          thisMapChar = "))"
        Else
          thisMapChar = ")"
        End If
      Case "!"
        Map("a.Exclaim", "a.Exclaim")
      Case "@"
        thisMapChar = "_x.LinkTo("""
      Case "#"
        thisMapChar = "_x."
      Case "$"
        thisMapChar = "_a.Column("
      Case "%"
        thisMapChar = ""
      Case "^"
        Map("a.And", "a.And")
      Case "*"
        Map("a.Power", "a.Power")
      Case "_"
        thisMapChar = "_"
      Case "-"
        Map("a.Minus", "a.Minus")
      Case "+"
        Map("a.Plus", "a.Plus")
      Case "="
        Map("a.Equal", "a.Equal")
      Case "<"
        Map("a.Less", "a.Less")
      Case ","
        Map("a.Comma", "a.Comma")
      Case ">"
        Map("a.Greater", "a.Greater")
      Case "~"
        Map("a.Not", "a.Not")
      Case "`"
        thisMapChar = ""
      Case "|"
        Map("a.Stile", "a.Stile")
      Case "?"
        Map("a.Random", "a.Random")
      Case "/"
        Map("a.Reduce", "a.Select")
        If thisMapChar.EndsWith("(") Then
          thisMapChar = "_a.Reduce)("
        End If
      Case "\"
        Map("a.Scan", "a.Expand")
        If thisMapChar.EndsWith("(") Then
          thisMapChar = "_a.Scan)("
        End If
    End Select
  End Sub

#End Region

#Region "FoundConstant"

  Private Sub FoundConstant(ByVal aChar As String)
    Dim myIndex As Integer
    Dim myLast As String

    myLast = LastOne()
    If "abcdefghijklmnopqrstuvwxyz0123456789.-".Contains(myLast) Then
      ' Still forming a name or constant
    ElseIf thisPrevious.EndsWith(")") Then
      thisMapChar = ",_a.Value(" & aChar
    ElseIf thisPrevious.EndsWith("),") Then
      thisMapChar = "_a.Value(" & aChar
    ElseIf thisPrevious.EndsWith("_a.value(") OrElse _
        thisPrevious.EndsWith("_a.index(") OrElse _
        thisPrevious.EndsWith("_x.string(") Then
      ' Just starting
    ElseIf "=(".Contains(myLast) Then
      thisMapChar = "_a.Value(" & aChar
    ElseIf thisPrevious.Contains("_a.value(") Then
      myIndex = thisPrevious.LastIndexOf("_a.value(")
      If thisPrevious.Substring(myIndex + 9).Contains("(") Then
        thisMapChar = "_a.Value(" & aChar
      ElseIf Not thisPrevious.TrimEnd.EndsWith(",") Then
        thisMapChar = "," & aChar
      End If
    Else
      thisMapChar = "_a.Value(" & aChar
    End If
  End Sub
#End Region

#Region "Map"

  Private Sub Map(ByVal aMonad As String, ByVal aDyad As String)
    Dim myPrev As String

    If thisPrevious.EndsWith("(") Then
      If PreviousFunction() Then
        If aMonad.Length <> 0 Then
          thisMapChar = "_" & aMonad & "("
        End If
      Else
        If aDyad.Length <> 0 Then
          thisMapChar = "_" & aDyad & ","
        End If
      End If

    ElseIf thisPrevious.EndsWith("_a.dot,") Then
      If aDyad.Length <> 0 Then
        thisMapChar = "_" & aDyad & "),"
      End If

    ElseIf thisPrevious.EndsWith(")") Then
      If aDyad.Length <> 0 Then
        thisMapChar = "(_" & aDyad & ","
      End If

    ElseIf ".""".Contains(LastOne) Then
      If aDyad.Length <> 0 Then
        thisMapChar = ")(_" & aDyad & ","
      End If

    ElseIf thisPrevious.TrimEnd.Length = 0 OrElse ",=".Contains(LastOne) Then
      If aMonad.Length <> 0 Then
        thisMapChar = "_" & aMonad & "("
      End If

    Else
      myPrev = thisPrevious.TrimEnd.Replace("=", " ").Replace(",", " ").Replace("(", " ")
      myPrev = myPrev.Substring(myPrev.LastIndexOf(" ") + 1, 1)
      If "0123456789-".Contains(myPrev) Then
        If aDyad.Length <> 0 Then
          thisMapChar = ")(_" & aDyad & ","
        End If
      Else
        If aDyad.Length <> 0 Then
          thisMapChar = "(_" & aDyad & ","
        End If
      End If
    End If
  End Sub

#End Region

#Region "PreviousFunction and PreviousValue"

  Private Function PreviousFunction() As Boolean
    Dim myLine As String
    Dim myIndex As Integer

    If thisPrevious.EndsWith(".sub(") Then
      Return True
    End If
    If thisPrevious.EndsWith("⍺(") OrElse _
       thisPrevious.EndsWith("⍵(") Then
      Return False
    End If
    If thisPrevious.EndsWith("_a.reduce)(") OrElse _
       thisPrevious.EndsWith("_a.scan)(") Then
      Return True
    End If

    If PreviousValue() Then
      Return False
    End If

    myIndex = thisPrevious.LastIndexOf("_")
    If myIndex <> -1 Then
      myLine = thisPrevious.Substring(myIndex)
      If myLine.StartsWith("_x.") OrElse _
         myLine.Contains(")") Then
        Return False
      End If

      If myLine.StartsWith("_a.") OrElse _
         myLine.StartsWith("_r.") OrElse _
         myLine.StartsWith("_c.") Then
        Return True
      End If
    End If
  End Function

  Private Function PreviousValue() As Boolean
    Dim myIndex As Integer
    Dim myPart As String

    myIndex = thisPrevious.Remove(thisPrevious.Length - 1).LastIndexOf("(")
    If myIndex = -1 Then
      Return False

    Else
      myPart = thisPrevious.Substring(myIndex + 1)
      Return CommandLine.Utils.IsAlpha(myPart)
    End If
  End Function

#End Region

#Region "NotQuoted and LastOne"

  Private Function NotQuoted() As Boolean
    Dim myLine As String

    If thisInput.SelectionStart = 0 Then
      thisPrevious = "  "
      Return True
    Else
      myLine = thisInput.Text.Substring(0, thisInput.SelectionStart)
      If (myLine.Split(""""c).Length Mod 2) = 0 Then
        Return False
      End If

      thisPrevious = "  " & thisCompile.NonQuotes(myLine.ToLower.Split(""""c))
      Return True
    End If
  End Function

  Private Function LastOne() As String
    Return thisPrevious(thisPrevious.Length - 1)
  End Function

#End Region

End Class
