﻿Public Class Indexing

#Region "Properties"

  Private thisElements As Elements()
  Private thisShape As Integer()

#End Region

#Region "New"

  ''' <summary>
  ''' Creates indexing for all elements of aShape.
  ''' </summary>
  ''' <param name="aShape">A shape vector for an array provides
  ''' indexing for that array, useing the most compressed form for
  ''' each dimension.</param>
  ''' <remarks>
  ''' Once established, any dimension may be ReDone with
  '''   ReIndex   for any indexing operator or function
  '''   RePivot   for _a.Pivot
  '''   RePose    for _a.Transpose
  '''   ReSelect  for _a.Select and _a.Expand
  '''   ReTake    for _a.Take
  '''   ReDrop    for _a.Drop
  '''   ReCat     for _a.Comma
  ''' </remarks>
  Public Sub New(ByVal aShape As Integer())
    Dim myIndex, myLength, myMult As Integer

    myMult = 1
    ReDim thisElements(aShape.Length - 1)
    For myIndex = thisElements.Length - 1 To 0 Step -1
      myLength = aShape(myIndex)
      thisElements(myIndex) = New Elements(myLength, myMult)
      myMult *= myLength
    Next
    thisShape = aShape
  End Sub

  ''' <summary>
  ''' Creates indexing for elements of aShape as specified by aSub.
  ''' </summary>
  ''' <param name="aShape">Provides the shape of the value to be indexed.</param>
  ''' <param name="aSub">Provides a vector of APL objects, each of which
  ''' must contain proper indexes of the associated dimension.
  ''' Any dimension which is _Empty will be taken as a request for
  ''' ⍳ aShape[aDimension]</param>
  Public Sub New( _
      ByVal aShape As Integer(), _
      ByVal ParamArray aSub As APL())
    Dim myShapes As Integer()
    Dim myIndex, myLength, myMult, _
        myShapeIndex, myRanks As Integer

    If aShape.Length = 0 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If
    If aShape.Length <> aSub.Length Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Length)
    End If

    For myIndex = 0 To aSub.Length - 1
      myRanks += aSub(myIndex).Rank
    Next
    myRanks -= 1
    ReDim thisShape(myRanks)
    ReDim thisElements(aShape.Length - 1)

    myMult = 1
    For myIndex = aSub.Length - 1 To 0 Step -1
      myLength = aShape(myIndex)
      If Array.ReferenceEquals(aSub(myIndex), _APL._Empty) Then
        thisElements(myIndex) = New Elements(myLength, myMult)
        thisShape(myRanks) = myLength
        myRanks -= 1

      Else
        thisElements(myIndex) = New Elements(aSub(myIndex).SubscriptVector, myLength, myMult)
        myShapes = aSub(myIndex).Shape
        For myShapeIndex = myShapes.Length - 1 To 0 Step -1
          thisShape(myRanks) = myShapes(myShapeIndex)
          myRanks -= 1
        Next
      End If

      myMult *= myLength
    Next
  End Sub

#End Region

#Region "Next and IncrementSkip"

  ''' <summary>
  ''' Next provides the next index.  It's behavior varies,
  ''' based on the previous callers.
  ''' N.B.  A negative result is an indication that
  ''' a filler value should be provided,
  ''' In APL, this is typically 0 or blank.
  ''' </summary>
  Public ReadOnly Property [Next]() As Integer
    Get
      Dim myResult, myItem As Integer
      Dim myElements As Elements

      myResult = thisStartValue
      For Each myElements In thisElements.Reverse
        myItem = myElements.Current
        If myItem < 0 Then
          myResult = myItem
          Exit For
        End If
        myResult += myItem
      Next

      For Each myElements In thisElements.Reverse
        If Not myElements.Next Then
          Return myResult
        End If
      Next

      Return myResult
    End Get
  End Property

  Private thisStartValue As Integer
  ''' <summary>
  ''' Only user is NextLoopAndSkip in Elements to increment indexing!
  ''' Used to produce ReCat behavior for both left and right arguments.
  ''' </summary>
  Private Sub IncrementSkip(ByVal aSkip As Integer)
    thisStartValue += aSkip
  End Sub

#End Region

#Region "ResultShape"

  ''' <summary>
  ''' ResultShape returns the expected shape of the result
  ''' based on indexing previously provided.
  ''' N.B. Some calls to ReDoes do not recalculate ResultShape
  ''' because many changes to indexing do not imply changes to
  ''' the result shape.  These differences are left to the caller
  ''' to calculate.
  ''' </summary>
  Public Property ResultShape() As Integer()
    Get
      If thisShape Is Nothing Then
        Dim myIndex As Integer

        ReDim thisShape(thisElements.Length - 1)
        For myIndex = 0 To thisShape.Length
          thisShape(myIndex) = thisElements(myIndex).Length
        Next
      End If

      Return DirectCast(thisShape.Clone, Integer())
    End Get

    Set(ByVal aValue As Integer())
      thisShape = aValue
    End Set
  End Property

#End Region

#Region "ReDoes"

#Region "ReIndex"
  ''' <summary>
  ''' Reorders indexing elements so that anIndex increments fastest.
  ''' ResultShape is NOT modified. 
  ''' </summary>
  Public Sub ReIndex( _
      ByVal anIndex As Integer, _
      ByVal aReverse As Boolean)
    Dim myIndex, myItem As Integer
    Dim myElements As Elements()

    If anIndex < 0 OrElse anIndex >= thisElements.Length Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Index)
    End If

    If aReverse Then
      thisElements(anIndex).Reverse()
    End If

    If anIndex <> thisElements.Length - 1 Then
      ReDim myElements(thisElements.Length - 1)
      myElements(myElements.Length - 1) = thisElements(anIndex)
      For myIndex = 0 To myElements.Length - 1
        If myIndex <> anIndex Then
          myElements(myItem) = thisElements(myIndex)
          myItem += 1
        End If
      Next

      thisElements = myElements
    End If
  End Sub

#End Region

#Region "RePivot"

  ''' <summary>
  ''' RePivot prepares indexing for _a.Pivot
  ''' specified by aPivot.
  ''' </summary>
  ''' <param name="anIndex">
  ''' an index of which dimension to pivot.
  ''' </param>
  ''' <param name="aPivot">
  ''' Rules and results are the same as
  ''' APL's left argument to Pivot.
  '''</param>
  Public Sub RePivot( _
      ByVal anIndex As Integer, _
      ByVal aPivot As Integer())
    Dim myIndex, myLength, myLast As Integer
    Dim myPivot As Integer()

    myLength = thisElements(anIndex).Length
    ReDim myPivot(aPivot.Length - 1)
    For myIndex = 0 To myPivot.Length - 1
      myPivot(myIndex) = UtilsShape.Residue(myLength, aPivot(myIndex))
    Next

    myLast = thisElements.Length - 1
    If anIndex = myLast Then
      thisElements(anIndex).PrePivotLast(myPivot)

    Else
      If anIndex = 0 Then
        thisElements(myLast).PrePivot(myPivot, myLength, _
          thisElements(anIndex).Step)
        thisElements = New Elements() {thisElements(myLast)}
      Else
        ExceptionAPL.Signal(ExceptionAPL.Is.Nonce)
      End If
    End If
  End Sub

#End Region

#Region "RePose"

  ''' <summary>
  ''' RePose prepares indexing for _a.Transpose based on anOrder.
  ''' </summary>
  ''' <param name="anOrder">Rules and results are the same as
  ''' APL's left argument to Transpose.</param>
  Public Sub RePose(ByVal anOrder As Integer())
    Dim myIndex, myItem, myMax As Integer
    Dim myElements As Elements()
    Dim myElement As Elements

    ReDim myElements(thisElements.Length - 1)
    For myIndex = 0 To anOrder.Length - 1
      myItem = anOrder(myIndex)
      If myItem < 0 OrElse myItem >= thisElements.Length Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Index)
      End If

      myMax = Math.Max(myMax, myItem)
      myElement = thisElements(myIndex)
      If myElements(myItem) Is Nothing Then
        myElements(myItem) = myElement

      Else
        myElements(myItem).PrePose(myElement)
      End If
    Next

    ReDim Preserve myElements(myMax)
    thisElements = myElements

    ReDim thisShape(myMax)
    For myIndex = 0 To myMax
      myElement = thisElements(myIndex)
      If myElements(myItem) Is Nothing Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End If
      thisShape(myIndex) = myElement.Length
    Next
  End Sub

#End Region

#Region "ReSelect"

  ''' <summary>
  ''' ReSelect property has two uses:
  '''    .ReSelect(anIndex)  ' returns the indexes of anIndex's dimension.
  '''    .ReSelect = aValue  ' resets the indexes for anIndex's dimension.
  ''' N.B.  Once reset, anIndex's dimension may not be further modified.
  ''' </summary>
  Private thisSelected As Integer
  Public ReadOnly Property ReSelect(ByVal anIndex As Integer) As Integer()
    Get
      thisSelected = anIndex
      Return thisElements(anIndex).PreSelect
    End Get
  End Property

  Public WriteOnly Property ReSelect() As Integer()
    Set(ByVal aValue As Integer())
      thisElements(thisSelected).PreSelect = aValue
    End Set
  End Property

#End Region

#Region "ReTake and ReDrop"

  ''' <summary>
  ''' ReTake modifies indexing for _a.Take based on aTakes.
  ''' </summary>
  ''' <param name="aTakes">Rules and results are the same as
  ''' APL's left argument to Take.</param>
  Public Sub ReTake(ByVal aTakes As Integer())
    Dim myIndex As Integer

    If thisShape.Length <> aTakes.Length Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Length)
    End If

    For myIndex = 0 To thisElements.Length - 1
      thisShape(myIndex) = _
          thisElements(myIndex).PreTake(aTakes(myIndex))
    Next
  End Sub

  ''' <summary>
  ''' ReDrop modifies indexing for _a.Drop based on aDrops.
  ''' </summary>
  ''' <param name="aDrops">Rules and results are the same as
  ''' APL's left argument to Drop.</param>
  Public Sub ReDrop(ByVal aDrops As Integer())
    Dim myIndex As Integer

    If thisShape.Length <> aDrops.Length Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Length)
    End If

    For myIndex = 0 To thisElements.Length - 1
      thisShape(myIndex) = _
          thisElements(myIndex).PreDrop(aDrops(myIndex))
    Next
  End Sub

#End Region

#Region "ReCat and ReCatRight"

  ''' <summary>
  ''' ReCat is used by Content.Catenate to determine where to put results
  '''    result[LeftIndexes] = LeftValues
  '''    result[RightIndexes] = RightValues
  ''' </summary>
  ''' <param name="anIndex">which dimension to catenate along</param>
  ''' <param name="aRight">the right hand value to catenate with,
  ''' note that the left hand argument is implied.</param>
  Public Sub ReCat( _
      ByVal anIndex As Integer, _
      ByVal aRight As Indexing)
    thisElements(anIndex).PreCat(Me, Skips(aRight, anIndex))
    aRight.ReCatRight(Me, anIndex)
  End Sub

  ''' <summary>
  ''' Called by ReCat to inform the right hand value's indexing to update
  ''' for a catenate.
  ''' </summary>
  Private Sub ReCatRight( _
      ByVal aLeft As Indexing, _
      ByVal anIndex As Integer)
    Dim mySkip As Integer

    mySkip = Skips(aLeft, anIndex)
    thisElements(anIndex).PreCat(Me, mySkip)
    thisStartValue = mySkip
  End Sub

  Private Function Skips( _
      ByVal aValue As Indexing, _
      ByVal anIndex As Integer) _
      As Integer
    Dim myShape As Integer()
    Dim myIndex, myResult As Integer

    myShape = aValue.ResultShape

    myResult = myShape(anIndex)
    For myIndex = anIndex + 1 To myShape.Length - 1
      myResult *= myShape(myIndex)
    Next

    Return myResult
  End Function

#End Region

#End Region

#Region "Reverse"

  Public Sub Reverse(ByVal anIndex As Integer)
    thisElements(anIndex).Reverse()
  End Sub

#End Region

  Private Class Elements

#Region "Properties"

    Private thisCurrent As Integer
    Private thisLength As Integer
    Private Delegate Function NextElement() As Boolean
    Private thisNextElement As NextElement

    ' For NextSimple from APL.Sub[;], 
    ' and after ReSelect as in a/ or a\
    Private thisIndexes As Integer()
    Private thisIndex As Integer

    ' For all NextLoops
    Private thisStart As Integer
    Private thisEnd As Integer
    Private thisStep As Integer

    ' For NextLoopAndFill
    Private thisFilling, thisFillFirst As Boolean
    Private thisFill As Integer

    ' For NextLoopSkip
    Private thisSkip As Integer
    Private thisSkipping As Indexing

    ' For NextPivot
    Private thisPivotCurrent As Integer
    Private thisPivotLength As Integer
    Private thisPivotStep As Integer
    Private thisRow As Integer
    Private thisPivot As Integer()

    ' For NextLoopTwice
    Private thisLoopedTwice As Boolean
    Private thisFullEnd As Integer

    ' For NextCat
    Private thisCat As Elements
    Private thisOffset As Integer

#End Region

#Region "New"

    ''' <summary>
    ''' Create a For style triple for Indexing.Empty
    ''' </summary>
    ''' <param name="aLength">the length of this dimension</param>
    ''' <param name="aMult">the multiplier for this dimension</param>
    ''' <remarks>N.B. indexes created here can be modified!</remarks>
    Public Sub New( _
        ByVal aLength As Integer, _
        ByVal aMult As Integer)
      thisNextElement = AddressOf NextLoopOnce
      thisLength = aLength

      thisStart = 0
      thisEnd = aMult * (thisLength - 1)
      thisStep = aMult
    End Sub

    ''' <summary>
    ''' Create thisIndexes adjusted for negatives
    ''' </summary>
    ''' <param name="aVector">a vector of indexes</param>
    ''' <param name="aLength">the length of this dimension</param>
    ''' <param name="aMult">the multiplier for this dimension</param>
    ''' <remarks>N.B. indexes created here cannot be further modified!</remarks>
    Public Sub New( _
        ByVal aVector As Integer(), _
        ByVal aLength As Integer, _
        ByVal aMult As Integer)
      Dim myIndex, myItem As Integer

      thisLength = aLength
      thisNextElement = AddressOf NextSimple
      thisIndexes = aVector
      For myIndex = 0 To thisIndexes.Length - 1
        myItem = thisIndexes(myIndex)

        If myItem < 0 Then
          ' Adjust negative items
          myItem = aLength + myItem
          If myItem < 0 Then
            ExceptionAPL.Signal(ExceptionAPL.Is.Index)
          End If
        End If

        If myItem >= aLength Then
          ExceptionAPL.Signal(ExceptionAPL.Is.Index)
        End If

        thisIndexes(myIndex) = myItem * aMult
      Next

      If thisIndexes.Length <> 0 Then
        thisCurrent = thisIndexes(0)
      End If
    End Sub

#End Region

#Region "Current Length and Step"

    ''' <summary>
    ''' Returns the current index of this dimension
    ''' </summary>
    Public ReadOnly Property Current() As Integer
      Get
        Return thisCurrent
      End Get
    End Property

    ''' <summary>
    ''' Returns the length of this dimension
    ''' </summary>
    Public ReadOnly Property Length() As Integer
      Get
        Return thisLength
      End Get
    End Property

    ''' <summary>
    ''' Returns the Step increment for this dimension
    ''' </summary>
    Public ReadOnly Property [Step]() As Integer
      Get
        Return thisStep
      End Get
    End Property

#End Region

#Region "Reverse and Swap"

    ''' <summary>
    ''' Reverse the order elements are returned for this dimension
    ''' </summary>
    Public Sub Reverse()
      Swap(thisStart, thisEnd)
      thisCurrent = thisStart
      thisStep = -thisStep
    End Sub

    Private Sub Swap(ByRef aLeft As Integer, ByRef aRight As Integer)
      Dim mySwap As Integer

      mySwap = aLeft
      aLeft = aRight
      aRight = mySwap
    End Sub

#End Region

#Region "Pre setups for ReDoes"

#Region "PrePose"

    ''' <summary>
    ''' PrePose prepares for RePose
    ''' </summary>
    Public Sub PrePose(ByVal anOther As Elements)
      thisLength = Math.Min(thisLength, anOther.Length)
      thisStep += anOther.Step
      thisEnd = thisStep * (thisLength - 1)
    End Sub

#End Region

#Region "PrePivot and PrePivotLast"

    ''' <summary>
    ''' PrePivot prepares for RePivot
    ''' </summary>
    Public Sub PrePivot( _
        ByVal aPivot As Integer(), _
        ByVal aLength As Integer, _
        ByVal aStep As Integer)
      thisPivot = aPivot
      thisPivotStep = aStep
      thisEnd = aStep - 1
      thisPivotLength = aLength
      thisPivotCurrent = thisCurrent
      PivotNextItem()
      thisNextElement = AddressOf NextLoopPivot
    End Sub

    ''' <summary>
    ''' PrePivotLast prepares for RePivot
    ''' </summary>
    Public Sub PrePivotLast(ByVal aPivot As Integer())
      thisPivot = aPivot
      thisFullEnd = thisEnd
      PivotLastNext()
      thisNextElement = AddressOf NextLoopTwice
    End Sub

#End Region

#Region "PreSelect"

    ''' <summary>
    ''' PreSelect prepares for ReSelect
    ''' After reassignment, these indexes cannot be further modified!
    ''' </summary>
    Public Property PreSelect() As Integer()
      Get
        Dim myResult As Integer()
        Dim myIndex, myItem As Integer

        ConfirmNotSimple()
        ReDim myResult(thisLength - 1)
        For myItem = thisStart To thisEnd Step thisStep
          myResult(myIndex) = myItem
          myIndex += 1
        Next
        Return myResult
      End Get

      Set(ByVal aValue As Integer())
        thisIndexes = aValue
        thisCurrent = thisIndexes(0)
        thisNextElement = AddressOf NextSimple
      End Set
    End Property

#End Region

#Region "PreTake"

    ''' <summary>
    ''' PreTake prepares for ReTake
    ''' </summary>
    Public Function PreTake(ByVal aTake As Integer) As Integer
      Dim mySize As Integer

      ConfirmNotSimple()
      If aTake = 0 Then
        Return 0
      End If

      mySize = Math.Abs(aTake)
      thisFill = thisLength - mySize
      If thisFill < 0 Then
        If thisLength = 0 Then
          thisNextElement = AddressOf NextFill
          thisCurrent = thisFill
          Return Math.Abs(thisFill)
        End If

        thisNextElement = AddressOf NextLoopAndFill
      End If

      If aTake > 0 Then
        If thisFill > 0 Then
          thisEnd = thisStep * (mySize - 1)
        End If

      ElseIf aTake < 0 Then
        If thisFill > 0 Then
          thisStart = thisStep * thisFill
          thisCurrent = thisStart
        Else
          thisFilling = True
          thisFillFirst = True
          thisCurrent = thisFill
        End If
      End If

      Return mySize
    End Function

#End Region

#Region "PreDrop"

    ''' <summary>
    ''' PreDrop prepares for ReDrop
    ''' </summary>
    Public Function PreDrop(ByVal aDrop As Integer) As Integer
      Dim mySize As Integer

      ConfirmNotSimple()
      mySize = thisLength - Math.Abs(aDrop)
      If mySize <= 0 Then
        Return 0
      End If

      If aDrop > 0 Then
        thisStart = thisStep * aDrop
        thisCurrent = thisStart
      ElseIf aDrop < 0 Then
        thisEnd = thisStep * (mySize - 1)
      End If

      Return mySize
    End Function

#End Region

#Region "PreCat"

    ''' <summary>
    ''' PreCat prepares for ReCat
    ''' </summary>
    Public Sub PreCat( _
        ByVal aSkipping As Indexing, _
        ByVal aSkip As Integer)
      thisSkipping = aSkipping
      thisSkip = aSkip
      thisNextElement = AddressOf NextLoopAndSkip
    End Sub

#End Region

#End Region

#Region "Nexts"

    Public ReadOnly Property [Next]() As Boolean
      Get
        Return thisNextElement.Invoke
      End Get
    End Property

#Region "NextSimple"

    ''' <summary>
    ''' NextSimple is for APL.Sub or PreSelect
    ''' </summary>
    Private Function NextSimple() As Boolean
      Dim myDone As Boolean

      thisIndex += 1
      If thisIndex = thisIndexes.Length Then
        thisIndex = 0
        myDone = True
      End If

      thisCurrent = thisIndexes(thisIndex)
      Return myDone
    End Function

#End Region

#Region "NextLoopOnce"

    ''' <summary>
    ''' NextLoopOnce is for _Empty dimensions
    ''' and other Next varients
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function NextLoopOnce() As Boolean
      If thisCurrent = thisEnd Then
        thisCurrent = thisStart
        Return True

      Else
        thisCurrent += thisStep
        Return False
      End If
    End Function

#End Region

#Region "NextLoopTwice"

    ''' <summary>
    ''' NextLoopTwice is for RePivot
    ''' </summary>
    Private Function NextLoopTwice() As Boolean
      If NextLoopOnce() Then
        If thisLoopedTwice Then
          PivotLastLoop()
          Return True

        Else
          thisLoopedTwice = True
          thisEnd = thisStart - thisStep
          thisStart = 0
          thisCurrent = 0
          Return False
        End If
      End If
    End Function

    Private Sub PivotLastLoop()
      If thisPivot.Length <> 1 Then
        thisIndex += 1
        If thisIndex >= thisPivot.Length Then
          thisIndex = 0
        End If
      End If
      PivotLastNext()
    End Sub

    Private Sub PivotLastNext()
      Dim myPivot As Integer

      myPivot = thisPivot(thisIndex)
      thisLoopedTwice = myPivot = 0

      ' thisStep does not change
      If thisLoopedTwice Then
        ' When myPivot = 0 we only need to loop once
        thisStart = 0
        thisEnd = thisFullEnd

      Else
        ' Prepare for two loops
        thisStart = myPivot * thisStep
        thisEnd = thisFullEnd

        ' SecondStart is always 0
        ' SecondEnd   is thisStart - thisStep
      End If

      thisCurrent = thisStart
    End Sub

#End Region

#Region "NextLoopPivot"

    ''' <summary>
    ''' NextLoopPivot is for RePivot
    ''' when anIndex IsNot Rank - 1
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function NextLoopPivot() As Boolean
      thisCurrent = thisPivotCurrent
      Return PivotNext(NextLoopOnce)
    End Function

    Private Function PivotNext(ByVal aNewRow As Boolean) As Boolean
      thisPivotCurrent = thisCurrent

      If aNewRow Then
        thisRow += 1
        If thisRow >= thisPivotLength Then
          thisRow = 0
        End If
      End If

      If thisPivot.Length <> 1 Then
        thisIndex += 1
        If thisIndex >= thisPivot.Length Then
          thisIndex = 0
        End If
      End If

      PivotNextItem()
      Return aNewRow
    End Function

    Private Sub PivotNextItem()
      Dim myItem As Integer

      myItem = (thisPivot(thisIndex) + thisRow) Mod thisPivotLength
      myItem *= thisPivotStep
      thisCurrent += myItem
    End Sub

#End Region

#Region "NextLoopAndFill and NextFill"

    ''' <summary>
    ''' NextLoopAndFill is for ReTake, when you need to fill
    ''' </summary>
    Private Function NextLoopAndFill() As Boolean
      If thisFilling Then
        thisCurrent += 1
        If thisCurrent = 0 Then
          ' Filling is complete
          thisFilling = False
          thisCurrent = thisStart
          Return Not thisFillFirst
        End If

      Else
        If NextLoopOnce() Then
          ' Looping is complete
          thisFilling = True
          thisCurrent = thisFill
          Return thisFillFirst
        End If
      End If

      Return False
    End Function

    ''' <summary>
    ''' NextFill is for ReTake, when thisLength is 0
    ''' </summary>
    Private Function NextFill() As Boolean
      thisCurrent += 1
      If thisCurrent = 0 Then
        thisCurrent = thisFill
        Return True
      End If
    End Function

#End Region

#Region "NextLoopAndSkip"

    ''' <summary>
    ''' NextLoopAndSkip is for ReCat
    ''' </summary>
    Public Function NextLoopAndSkip() As Boolean
      If NextLoopOnce() Then
        thisSkipping.IncrementSkip(thisSkip)
        Return True
      End If
    End Function

#End Region

#End Region

#Region "ConfirmNotSimple"

    Private Sub ConfirmNotSimple()
      If thisIndexes IsNot Nothing Then
        ExceptionAPL.Signal(ExceptionAPL.Is.System)
      End If
    End Sub

#End Region

  End Class

End Class
