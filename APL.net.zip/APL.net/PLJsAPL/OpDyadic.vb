﻿Public Class OpDyadic

#Region "Properties"

  Private thisLeftFn As Method
  Private thisRightFn As Method

  Private thisMonadicCall As MonadicCall
  Private thisDyadicCall As DyadicCall
  Private thisIndex As APL

#End Region

#Region "Delegates"

  Public Delegate Function MonadicCall( _
      ByVal aLeftFn As Method, _
      ByVal anIndex As APL, _
      ByVal aRightFn As Method, _
      ByVal aRight As APL) _
      As APL

  Public Delegate Function DyadicCall( _
      ByVal aLeft As APL, _
      ByVal aLeftFn As Method, _
      ByVal anIndex As APL, _
      ByVal aRightFn As Method, _
      ByVal aRight As APL) _
      As APL

#End Region

#Region "New and Arguments"

  ''' <summary>
  ''' Support of Dyadic operators 
  ''' </summary>
  Public Sub New( _
      ByVal aMonadicCall As MonadicCall, _
      ByVal aDyadicCall As DyadicCall, _
      ByVal anIndex As Boolean)
    thisMonadicCall = aMonadicCall
    thisDyadicCall = aDyadicCall
    If anIndex Then
      thisIndex = _APL._Empty
    End If
  End Sub

  ''' <summary>
  ''' Remember the left and right methods
  ''' </summary>
  Public Sub Arguments(ByVal aLeft As Method, ByVal aRight As Method)
    If aLeft Is Nothing OrElse aRight Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Syntax)
    End If

    thisLeftFn = aLeft
    thisRightFn = aRight
  End Sub

#End Region

#Region "Sub"

  Public Function [Sub](ByVal ParamArray anIndex() As Object) As OpDyadic
    If thisIndex Is Nothing Then
      ' When thisIndex wasn't set by this Op
      ExceptionAPL.Signal(ExceptionAPL.Is.Axis)
    End If
    thisIndex = New APL(anIndex)
    Return Me
  End Function

  Public Function [Sub](ByVal anIndex As APL) As OpDyadic
    If thisIndex Is Nothing Then
      ' When thisIndex wasn't set by this Op
      ExceptionAPL.Signal(ExceptionAPL.Is.Axis)
    End If
    UtilsShape.CheckValue(anIndex)
    thisIndex = anIndex
    Return Me
  End Function

#End Region

#Region "Derived"

  Public Function Derived( _
      ByVal aRight As APL) _
      As APL
    If thisMonadicCall Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Valence)
    End If

    Return thisMonadicCall.Invoke(thisLeftFn, thisIndex, thisRightFn, aRight)
  End Function

  Public Function Derived( _
      ByVal aLeft As APL, _
      ByVal aRight As APL) _
      As APL
    If thisDyadicCall Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Valence)
    End If

    Return thisDyadicCall.Invoke(aLeft, thisLeftFn, thisIndex, thisRightFn, aRight)
  End Function

#End Region

End Class
