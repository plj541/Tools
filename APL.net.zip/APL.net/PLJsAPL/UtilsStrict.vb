﻿Option Strict Off

Public Class UtilsStrict

#Region "IsBool"

  Private Shared thisIntBools As Integer() = {0, 1}
  Private Shared thisDblBools As Double() = {0, 1}

  Public Shared Function IsBool( _
      ByVal aBoolean As Object) _
      As Integer
    Dim myResult As Integer

    If TypeOf aBoolean Is Integer Then
      myResult = Array.IndexOf(thisIntBools, _
          DirectCast(aBoolean, Integer))

    Else
      myResult = Array.IndexOf(thisDblBools, _
          Math.Round(CDbl(aBoolean), 9))
    End If

    If myResult <> -1 Then
      Return myResult

    Else
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If
  End Function

#End Region

#Region "Chars"

  Public Shared Function Chars(ByVal aLine As String) As Char()
    Return aLine
  End Function

  Public Shared Function Chars(ByVal aLine As Char()) As String
    Return aLine
  End Function

#End Region

#Region "Fill"

  Public Shared Function Fill(ByVal aLength As Integer, ByVal aFill As Object) As Object()
    Dim myIndex As Integer
    Dim myValues As Object()

    ReDim myValues(aLength - 1)
    For myIndex = 0 To aLength - 1
      myValues(myIndex) = aFill
    Next

    Return myValues
  End Function

#End Region

#Region "Integers"

  Public Shared Function Integers(ByVal aVector As Object()) As Integer()
    Dim myResult As Integer()
    Dim myIndex As Integer

    ReDim myResult(aVector.Length - 1)

    For myIndex = 0 To myResult.Length - 1
      myResult(myIndex) = AnInteger(aVector(myIndex))
    Next

    Return myResult
  End Function

  Public Shared Function AnInteger(ByVal aValue As Object) As Integer
    Dim myItem As Integer

    If TypeOf aValue Is Integer Then
      myItem = DirectCast(aValue, Integer)

    Else
      myItem = CType(aValue, Integer)
      If myItem <> Math.Round(aValue, 9) Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End If
    End If

    Return myItem
  End Function

#End Region

#Region "Decoder"

  Public Shared Function Decoder(ByVal aLeft As APL, ByVal aSize As Integer) As Object()
    Dim myResult As Object()
    Dim myValue, myItem As Object
    Dim myIndex As Integer

    If aLeft.Rank > 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If
    If aLeft.IsCharacter Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If

    myValue = 1
    myResult = aLeft.ValueVector
    If myResult.Length = 1 AndAlso aSize <> 1 Then
      myItem = myResult(0)
      ReDim myResult(aSize - 1)

      For myIndex = myResult.Length - 1 To 0 Step -1
        myResult(myIndex) = myValue
        myValue *= myItem
      Next

    Else
      For myIndex = myResult.Length - 1 To 0 Step -1
        myItem = myResult(myIndex)
        myResult(myIndex) = myValue
        myValue *= myItem
      Next
    End If

    Return myResult
  End Function

#End Region

#Region "ToDouble"

  ''' <summary>
  ''' ToArray returns Double array of an appropriate number of dimensions.
  ''' </summary>
  ''' <remarks>
  ''' Only one thru three dimensions are supported.
  ''' </remarks>
  Public Shared Function ToDouble( _
      ByVal aValues As APL) _
      As Object
    Dim myValues As Object()
    Dim myShape As Integer()
    Dim myIndex, myPlane, myRow, myCol As Integer

    myValues = aValues.CompareValues
    myShape = aValues.Shape

    If myShape.Length = 1 Then
      Dim myResult As Double()
      ReDim myResult(myShape(0) - 1)
      For myIndex = 0 To myResult.GetUpperBound(0)
        myResult(myIndex) = myValues(myIndex)
      Next
      Return myResult

    ElseIf myShape.Length = 2 Then
      Dim myResult As Double(,)
      ReDim myResult(myShape(0) - 1, myShape(1) - 1)
      For myRow = 0 To myResult.GetUpperBound(0)
        For myCol = 0 To myResult.GetUpperBound(1)
          myResult(myRow, myCol) = myValues(myIndex)
          myIndex += 1
        Next
      Next
      Return myResult

    ElseIf myShape.Length = 3 Then
      Dim myResult As Double(,,)
      ReDim myResult(myShape(0) - 1, myShape(1) - 1, myShape(2) - 1)
      For myPlane = 0 To myResult.GetUpperBound(0)
        For myRow = 0 To myResult.GetUpperBound(1)
          For myCol = 0 To myResult.GetUpperBound(2)
            myResult(myPlane, myRow, myCol) = myValues(myIndex)
            myIndex += 1
          Next
        Next
      Next
      Return myResult

    Else
      Return _Signal(ExceptionAPL.Is.Rank)
    End If
  End Function

#End Region

#Region "FromDouble"

  ''' <summary>
  ''' FromDouble returns an APL version of the Double.
  ''' </summary>
  ''' <remarks>
  ''' Only one thru three dimensions are currently supported.
  ''' </remarks>
  Public Shared Function FromDouble(ByVal aValue As Object) As APL
    Dim myType As String
    Dim myValues As Object()
    Dim myShape As Integer()
    Dim myIndex, myPlane, myRow, myCol As Integer
    Dim myResult As APL

    myType = TypeName(aValue)
    If myType = "Double()" Then
      Dim myDoubles As Double()
      myDoubles = DirectCast(aValue, Double())
      ReDim myShape(0)
      myShape(0) = myDoubles.Length

      ReDim myValues(myDoubles.Length - 1)
      For myIndex = 0 To myDoubles.Length - 1
        myValues(myIndex) = myDoubles(myIndex)
      Next

    ElseIf myType = "Double(,)" Then
      Dim myDoubles As Double(,)
      myDoubles = DirectCast(aValue, Double(,))
      ReDim myShape(1)
      myShape(0) = myDoubles.GetUpperBound(0) + 1
      myShape(1) = myDoubles.GetUpperBound(1) + 1

      ReDim myValues(UtilsShape.TimesReduce(myShape) - 1)
      For myRow = 0 To myShape(0) - 1
        For myCol = 0 To myShape(1) - 1
          myValues(myIndex) = myDoubles(myRow, myCol)
          myIndex += 1
        Next
      Next

    ElseIf myType = "Double(,,)" Then
      Dim myDoubles As Double(,,)
      myDoubles = DirectCast(aValue, Double(,,))
      ReDim myShape(2)
      myShape(0) = myDoubles.GetUpperBound(0) + 1
      myShape(1) = myDoubles.GetUpperBound(1) + 1
      myShape(2) = myDoubles.GetUpperBound(2) + 1

      ReDim myValues(UtilsShape.TimesReduce(myShape) - 1)
      For myPlane = 0 To myShape(0) - 1
        For myRow = 0 To myShape(1) - 1
          For myCol = 0 To myShape(2) - 1
            myValues(myIndex) = myDoubles(myPlane, myRow, myCol)
            myIndex += 1
          Next
        Next
      Next

    Else
      _Signal(ExceptionAPL.Is.Nonce, myType)
      myShape = Nothing
      myValues = Nothing
    End If

    myResult = New APL(myValues)
    myResult.Shape = myShape
    Return myResult
  End Function

#End Region

End Class
