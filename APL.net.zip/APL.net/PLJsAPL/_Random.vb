﻿Partial Class _APL

#Region "Random Link"

  Private thisRL As New Random()

  ''' <summary>
  ''' Assigning _a.QuadRL should behave like APL.
  ''' </summary>
  Public Property QuadRL() As APL
    Get
      Return New APL(New Object() {thisRL.Next})
    End Get

    Set(ByVal aValue As APL)
      UtilsShape.CheckValue(aValue)
      thisRL = New Random(aValue.IntegerIndex)
      thisRL.Next()
    End Set
  End Property

  Private Function RandomNumber(ByVal aMaxNumber As Integer) As Integer
    Return thisRL.Next(0, aMaxNumber)
  End Function

#End Region

#Region "?	Roll,Deal"

  Public ReadOnly Property Random() As Method
    Get
      Return New Method(AddressOf Roll, AddressOf Deal)
    End Get
  End Property

  Private Function Roll(ByVal aRight As Object) As Object
    Dim myNumber As Integer

    myNumber = CType(aRight, Integer)
    If myNumber < 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If
    Return RandomNumber(myNumber)
  End Function

  Private Function Deal(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Dim myResult As Object()
    Dim mySwap As Object
    Dim myLeft, myRight, myIndex, myNext As Integer

    myLeft = aLeft.IntegerIndex
    myRight = aRight.IntegerIndex

    If myLeft < 0 OrElse myRight < 1 OrElse myLeft > myRight Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If

    ReDim myResult(myRight - 1)
    For myIndex = 0 To myRight - 1
      myResult(myIndex) = myIndex
    Next

    For myIndex = 0 To myLeft - 1
      myNext = RandomNumber(myRight)
      myRight -= 1
      If myNext <> 0 Then
        mySwap = myResult(myIndex)
        myResult(myIndex) = myResult(myNext + myIndex)
        myResult(myNext + myIndex) = mySwap
      End If
    Next

    ReDim Preserve myResult(myLeft - 1)
    Return New APL(myResult)
  End Function

#End Region

End Class
