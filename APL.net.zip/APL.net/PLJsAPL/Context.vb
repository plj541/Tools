﻿Imports System.Text

#Region "Context Class"

Public Class Context

#Region "Private Properties"

  Private thisAPL As _APL
  Private thisCaller As Object
  Private thisLast As String

#End Region

#Region "New"

  Public Sub New( _
      ByVal _a As _APL, _
      ByVal aCaller As Object)
    If _a Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Value)
    End If
    thisAPL = _a
    thisCaller = aCaller
  End Sub

#End Region

#Region "_x"

  Public ReadOnly Property _x() As Object
    Get
      Return thisCaller
    End Get
  End Property

#End Region

#Region "_a"

  ''' <summary>
  ''' Points to most functions and operators.
  ''' </summary>
  Public ReadOnly Property _a() As _APL
    Get
      Return thisAPL
    End Get
  End Property

#End Region

#Region "_Last"
  ''' <summary>
  ''' No Execute actually runs without a Context.
  ''' Execute assigns _Last.
  ''' </summary>
  Public Property _Last() As String
    Get
      Return thisLast
    End Get
    Set(ByVal aValue As String)
      thisLast = aValue
    End Set
  End Property
#End Region

End Class

#End Region

Public Module Quad

#Region "Private Properties"

  Private thisIO As New InputOutput
  Private thisLastQuote As Boolean

#End Region

#Region "_Events"

  ''' <summary>
  ''' In order to see output, someone must handle these _Events
  ''' AltKeys.SessionLog will do it for you.
  ''' </summary>
  Public ReadOnly Property _Events() As InputOutput
    Get
      Return thisIO
    End Get
  End Property

#End Region

#Region "_Out"

  ''' <summary>
  ''' ⎕ ← aValue
  ''' </summary>

  Public WriteOnly Property _Out() As Object
    Set(ByVal aValue As Object)
      Dim myString As String = Nothing

      thisLastQuote = False
      If aValue Is Nothing Then
        thisIO.Output = Nothing
        Return
      ElseIf TypeOf aValue Is APL Then
        myString = DirectCast(aValue, APL).ToString
      ElseIf TypeOf aValue Is String Then
        myString = DirectCast(aValue, String)
      Else
        _Signal(ExceptionAPL.Is.Domain)
      End If
      thisIO.Output = myString & ControlChars.NewLine
    End Set
  End Property

#End Region

#Region "_Quote"

  ''' <summary>
  ''' Get:  Return ⍞
  ''' Set:  ⍞ ← aValue
  ''' </summary>
  Public Property _Quote() As APL
    Get
      thisLastQuote = False
      Return New APL(thisIO.Input(""))
    End Get
    Set(ByVal aValue As APL)
      thisLastQuote = True
      UtilsShape.CheckValue(aValue)
      thisIO.Output = aValue.ToString
    End Set
  End Property

  ''' <summary>
  ''' ⍞ ← aPrompt ⋄
  ''' Return ⍞
  ''' </summary>
  Public ReadOnly Property _Quote( _
      ByVal aPrompt As APL) _
      As APL
    Get
      thisLastQuote = False
      UtilsShape.CheckValue(aPrompt)
      Return New APL(thisIO.Input(aPrompt.ToString))
    End Get
  End Property

#End Region

#Region "_Signal"

  ''' <summary>
  ''' Throw an ExceptionAPL of a predefined type.
  ''' </summary>
  ''' <param name="anEvent">One of the enum ExceptionAPL.Is.</param>
  Public Function _Signal(ByVal anEvent As ExceptionAPL.Is) As Object
    Return ExceptionAPL.Signal(anEvent)
  End Function

  ''' <summary>
  ''' Throw an ExceptionAPL with user provided aMessage
  ''' </summary>
  Public Function _Signal(ByVal anEvent As ExceptionAPL.Is, ByVal aMessage As String) As Object
    Return ExceptionAPL.Signal(anEvent, aMessage)
  End Function

#End Region

#Region "InputOutput Class"

  Public Class InputOutput

#Region "Input"

    Public Event Inputs( _
        ByVal aPrompt As String, _
        ByRef aResult As String)

    ''' <summary>
    ''' Will RaiseEvent Inputs
    ''' </summary>
    Public ReadOnly Property Input( _
        ByVal aPrompt As String) _
        As String
      Get
        Dim myResult As String = Nothing

        RaiseEvent Inputs(MustHave(aPrompt), myResult)
        Return myResult
      End Get
    End Property

#End Region

#Region "Output"

    Public Event Outputs( _
      ByVal aPrompt As String)

    ''' <summary>
    ''' Will RaiseEvent Outputs
    ''' </summary>
    Public WriteOnly Property Output() As String
      Set(ByVal aValue As String)
        RaiseEvent Outputs(MustHave(aValue))
      End Set
    End Property

#End Region

#Region "MustHave"

    Public Function MustHave(ByVal aValue As String) As String
      If aValue Is Nothing Then
        Return ""
      Else
        Return aValue
      End If
    End Function

#End Region

  End Class

#End Region

End Module
