﻿Imports System.Text

Public Class Compile

#Region "Private Properties"

  Private thisMethod As CompileVB
  Private thisCommand As String
  Private thisQuotes As String()

#End Region

#Region "Execute"

  ''' <summary>
  ''' Execute an expession in context
  ''' </summary>
  ''' <param name="aCommand">
  ''' A string expression to evaluate
  ''' </param>
  ''' <returns>The object result of the evaluated command</returns>
  ''' <remarks>Vulnerable to injection attacks.</remarks>
  Public Function Execute( _
      ByVal aCommand As String, _
      ByVal aContext As Context) _
      As Object
    If aContext Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Value)
    End If

    If aCommand.Contains(ControlChars.Cr) OrElse _
        aCommand.Contains(ControlChars.Lf) OrElse _
        aCommand.Contains(ControlChars.Tab) OrElse _
        aCommand.Contains(ControlChars.NullChar) Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Syntax)
    End If

    aCommand = aCommand.Trim
    If aCommand.Length = 0 Then
      Return Nothing
    End If

    aCommand = LocalizeCommand(aCommand)
    If thisMethod Is Nothing OrElse _
        (thisCommand IsNot Nothing AndAlso _
         thisCommand <> aCommand) Then
      thisCommand = aCommand
      thisMethod = Nothing

      aContext._Last = aCommand
      thisMethod = New CompileVB(aCommand)
    End If

    Return thisMethod.Invoke(aContext)
  End Function

#End Region

#Region "Private LocalizeCommand"

  Private Function LocalizeCommand(ByVal aLine As String) As String
    aLine = RemoveQuotes(aLine)
    If aLine Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Syntax)
    End If
    Return VBStatement(aLine.Replace("_", "_x._"))
  End Function

#End Region

#Region "VBStatement with Assign"

  Public Function VBStatement(ByVal aLine As String) As String
    Dim myPart, myLower As String

    If thisQuotes Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.System)
    End If
    If aLine Is Nothing Then
      Return Nothing
    End If

    myPart = aLine
    aLine = aLine.Replace("(", " (")
    aLine = aLine.Replace(")", ") ")
    myLower = aLine.ToLower & " "
    If myLower.StartsWith("dim ") OrElse _
       myLower.StartsWith("return ") OrElse _
       myLower.StartsWith("if ") OrElse _
       myLower.StartsWith("else ") OrElse _
       myLower.StartsWith("elseif ") OrElse _
       myLower.StartsWith("do ") OrElse _
       myLower.StartsWith("loop ") OrElse _
       myLower.StartsWith("select ") OrElse _
       myLower.StartsWith("case ") OrElse _
       myLower.StartsWith("for ") OrElse _
       myLower.StartsWith("next ") OrElse _
       myLower.StartsWith("goto ") OrElse _
       myLower.StartsWith("with ") OrElse _
       myLower.StartsWith("addressof ") OrElse _
       myLower.StartsWith("end ") OrElse _
       myLower.StartsWith("endif ") Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Syntax)
    Else
      myPart = Assign(aLine)
    End If
    Return RestoreQuotes(RemoveExtras(myPart))
  End Function

  Private Function Assign(ByVal aLine As String) As String
    aLine = aLine.Trim
    If aLine.Length = 0 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Syntax)
    End If

    If aLine.Contains("=") Then
      aLine &= ControlChars.NewLine & "Return Nothing"
    Else
      aLine = "Return " & aLine
    End If
    Return aLine
  End Function

  Private Function RemoveExtras( _
      ByVal aLine As String) _
      As String
    Return aLine.Replace(" (", "(").Replace(") ", ")")
  End Function

#End Region

#Region "RemoveQuotes"

  Public Function RemoveQuotes(ByVal aLine As String) As String
    Dim myLine As String

    thisQuotes = aLine.Split(""""c)
    myLine = NonQuotes(thisQuotes)
    If (thisQuotes.Length Mod 2) = 1 Then
      Return myLine

    Else
      Return Nothing
    End If
  End Function

#End Region

#Region "RestoreQuotes and WithoutQuotes"

  Public Function RestoreQuotes(ByVal aLine As String) As String
    If aLine IsNot Nothing Then
      aLine = WithoutQuotes(aLine)
    End If
    thisQuotes = Nothing
    Return aLine
  End Function

  Public Function WithoutQuotes(ByVal aLine As String) As String
    Dim myParts, myResult As String()
    Dim myIndex As Integer

    myParts = aLine.Split(""""c)
    ReDim myResult(myParts.Length - 1)
    For myIndex = 0 To myResult.Length - 1 Step 2
      myResult(myIndex) = myParts(myIndex)
    Next

    For myIndex = 1 To myResult.Length - 1 Step 2
      myResult(myIndex) = thisQuotes(myIndex)
    Next
    Return Join(myResult, """")
  End Function

#End Region

#Region "NonQuotes"

  Public Function NonQuotes(ByVal aQuotes As String()) As String
    Dim myParts As String()
    Dim myIndex As Integer

    ReDim myParts(aQuotes.Length - 1)
    For myIndex = 0 To myParts.Length - 1 Step 2
      myParts(myIndex) = aQuotes(myIndex)
    Next
    Return Join(myParts, """")
  End Function

#End Region

End Class
