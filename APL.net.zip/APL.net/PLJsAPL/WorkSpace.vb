﻿Imports System.Text

Public Class WorkSpace

#Region "Properties"

  Private thisAPL As _APL

#End Region

#Region "New"

  Public Sub New()
    thisAPL = New _APL

    thisAPL.ExecuteContext = New Context(_a, Me)
  End Sub

#End Region

#Region "_a"

  ''' <summary>
  ''' Points to most functions and operators.
  ''' </summary>
  Public ReadOnly Property _a() As _APL
    Get
      Return thisAPL
    End Get
  End Property

#End Region

#Region "QuadLX     ⍝ Latent eXpression"

  ''' <summary>
  ''' ⎕LX ⍝ Override to supply user defined entry point.
  ''' </summary>
  Public Overridable Sub QuadLX()
    ' Override for initial entry point
    _Out = "No user QuadLX provided"
  End Sub

#End Region

End Class
