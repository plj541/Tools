﻿Option Strict Off

Partial Public Class _APL

#Region "+	Conjugate,Plus,0"

  Private Function _Plus(ByVal aRight As Object) As Object
    Return +aRight
  End Function

  Private Function _Plus(ByVal aLeft As Object, ByVal aRight As Object) As Object
    If TypeOf aLeft Is String OrElse TypeOf aLeft Is Char OrElse _
        TypeOf aRight Is String OrElse TypeOf aRight Is Char Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If
    Return aLeft + aRight
  End Function

  Private thisPlus As Method
  Public ReadOnly Property Plus() As Method
    Get
      If thisPlus Is Nothing Then
        thisPlus = New Method(AddressOf _Plus, _
          AddressOf _Plus, AddressOf _Plus, 0)
      End If

      Return thisPlus
    End Get
  End Property

#End Region

#Region "-	Negative,Minus,0"

  Private Function _Minus(ByVal aRight As Object) As Object
    Return -aRight
  End Function

  Private Function _Minus(ByVal aLeft As Object, ByVal aRight As Object) As Object
    Return aLeft - aRight
  End Function

  Private thisMinus As Method
  Public ReadOnly Property Minus() As Method
    Get
      If thisMinus Is Nothing Then
        thisMinus = New Method(AddressOf _Minus, _
            AddressOf _Minus, AddressOf _Plus, 0)
      End If

      Return thisMinus
    End Get
  End Property

#End Region

#Region "×	SignOf,Times,1"

  Private Function _Times(ByVal aRight As Object) As Object
    Return Math.Sign(aRight)
  End Function

  Private Function _Times(ByVal aLeft As Object, ByVal aRight As Object) As Object
    Return aLeft * aRight
  End Function

  Private thisTimes As Method
  Public ReadOnly Property Times() As Method
    Get
      If thisTimes Is Nothing Then
        thisTimes = New Method(AddressOf _Times, _
            AddressOf _Times, AddressOf _Times, 1)
      End If

      Return thisTimes
    End Get
  End Property

#End Region

#Region "÷	Reciprocal,Divide,1"

  Private Function _Divide(ByVal aRight As Object) As Object
    If aRight = 0 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If
    Return 1 / aRight
  End Function

  Private Function _Divide(ByVal aLeft As Object, ByVal aRight As Object) As Object
    If aRight = 0 Then
      If aLeft = 0 Then
        Return 1
      End If
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If

    Return aLeft / aRight
  End Function

  Private thisDivide As Method
  Public ReadOnly Property Divide() As Method
    Get
      If thisDivide Is Nothing Then
        thisDivide = New Method(AddressOf _Divide, _
            AddressOf _Divide, AddressOf _Times, 1)
      End If

      Return thisDivide

    End Get
  End Property

#End Region

#Region "*	Exponent,PowerOf,1"

  Private Function _Exponent(ByVal aRight As Object) As Object
    Return Math.Pow(Math.E, aRight)
  End Function

  Private Function _PowerOf(ByVal aLeft As Object, ByVal aRight As Object) As Object
    Return Math.Pow(aLeft, aRight)
  End Function

  Private thisPowerOf As Method
  Public Function Power() As Method
    If thisPowerOf Is Nothing Then
      thisPowerOf = New Method(AddressOf _Exponent, _
          AddressOf _PowerOf, Nothing, 1)
    End If

    Return thisPowerOf
  End Function

#End Region

#Region "⊛	NaturalLog,LogOf,-"

  Private Function _NaturalLog(ByVal aRight As Object) As Object
    Return Math.Log(aRight)
  End Function

  Private Function _LogOf(ByVal aLeft As Object, ByVal aRight As Object) As Object
    Return Math.Log(aRight, aLeft)
  End Function

  Private thisLogOf As Method
  Public Function Log() As Method
    If thisLogOf Is Nothing Then
      thisLogOf = New Method(AddressOf _NaturalLog, _
          AddressOf _LogOf, Nothing, Nothing)
    End If

    Return thisLogOf
  End Function

#End Region

#Region "|	Magnitude,Residue,0"

  Private Function _Magnitude(ByVal aRight As Object) As Object
    Return Math.Abs(aRight)
  End Function

  Private thisResidue As Method
  Public Function Stile() As Method
    If thisResidue Is Nothing Then
      thisResidue = New Method(AddressOf _Magnitude, _
          AddressOf _Residue, Nothing, 0)
    End If

    Return thisResidue
  End Function

#End Region

#Region "⌈	,Maximum,¯"

  Private Function _Maximum(ByVal aLeft As Object, ByVal aRight As Object) As Object
    Return Math.Max(aLeft, aRight)
  End Function

  Private thisMaximum As Method
  Public Function Hi() As Method
    If thisMaximum Is Nothing Then
      thisMaximum = New Method(AddressOf _Ceiling, _
          AddressOf _Maximum, AddressOf _Maximum, _
          Double.NegativeInfinity)
    End If

    Return thisMaximum
  End Function

#End Region

#Region "⌊ ,Minimum,_"

  Private Function _Minimum(ByVal aLeft As Object, ByVal aRight As Object) As Object
    Return Math.Min(aLeft, aRight)
  End Function

  Private thisMinimum As Method
  Public Function Low() As Method
    If thisMinimum Is Nothing Then
      thisMinimum = New Method(AddressOf _Floor, _
          AddressOf _Minimum, AddressOf _Minimum, _
          Double.PositiveInfinity)
    End If

    Return thisMinimum
  End Function
#End Region

#Region "!	Factorial,Combinations,1"

  Private Function _Factorial(ByVal aRight As Object) As Object
    ' Fractions and Negatives are still Nonce
    Dim myResult, myTurn As Double

    If Math.Sign(aRight) <> -1 AndAlso Fix(aRight) = aRight Then
      If aRight = 0 Then
        Return 1

      Else
        myResult = 1
        For myTurn = aRight To 2 Step -1
          myResult *= myTurn
        Next

        Return myResult
      End If

    Else
      Return UtilsGamma.Gamma(aRight + 1)
    End If
  End Function

  Private Function _Combinations(ByVal aLeft As Object, ByVal aRight As Object) As Object
    ' Value is negative integer;   Expression to calculate
    '	⍺	⍵	⍵-⍺		⍺ ! ⍵
    '	0	0	0		(!⍵)÷(!⍺)×!⍵-⍺
    '	0	0	1		0
    '	0	1	0		Domain Error
    '	0	1	1		(¯1*⍺)×⍺!⍺-⍵+1
    '	1	0	0		0
    '	1	0	1		Cannot arise
    '	1	1	0		(¯1*⍵-⍺)×(|⍵+1)!(|⍺+1)
    '	1	1	1		0
    If aLeft = 0 Then
      Return 1
    End If
    Select Case Cond(aLeft) & Cond(aRight) & Cond(aRight - aLeft)
      Case "000"
        '	0	0	0		(!⍵)÷(!⍺)×!⍵-⍺
        If TypeOf aLeft Is Integer AndAlso TypeOf aRight Is Integer Then
          Dim myIndex, myFact As Double

          myFact = aRight
          For myIndex = aRight - 1 To aRight - (aLeft - 1) Step -1
            myFact *= myIndex
          Next

          Return myFact / _Factorial(aLeft)

        Else
          Return _Factorial(aRight) / (_Factorial(aLeft) * _Factorial(aRight - aLeft))
        End If
      Case "001"
        Return 0
      Case "010"
        Return ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      Case "011"
        '	0	1	1		(¯1*⍺)×⍺!⍺-⍵+1
        Return ((-1) ^ aLeft) * Combs(aLeft, aLeft - (aRight + 1))
      Case "100"
        Return 0
      Case "101"
        Return ExceptionAPL.Signal(ExceptionAPL.Is.System)
      Case "110"
        '	1	1	0		(¯1*⍵-⍺)×(|⍵+1)!(|⍺+1)
        Return ((-1) ^ (aRight - aLeft)) * Combs(Math.Abs(aRight + 1), Math.Abs(aLeft + 1))
      Case "111"
        Return 0
      Case Else
        Return Nothing
    End Select
  End Function

  Private Function Combs(ByVal aLeft As Object, ByVal aRight As Object) As Object
    Return _Factorial(aRight) / (_Factorial(aLeft) * _Factorial(aRight - aLeft))
  End Function

  Private Function Cond(ByVal aValue As Object) As String
    If aValue <> Int(aValue) Then
      Return "0"
    End If

    If aValue < 0 Then
      Return "1"
    Else
      Return "0"
    End If
  End Function

  Private thisCombinations As Method
  Public Function Exclaim() As Method
    If thisCombinations Is Nothing Then
      thisCombinations = New Method(AddressOf _Factorial, _
          AddressOf _Combinations, Nothing, Nothing)
    End If

    Return thisCombinations
  End Function

#End Region

#Region "○	PiTimes,Circle,-"

  Private Function _PiTimes(ByVal aRight As Object) As Object
    Return Math.PI * aRight
  End Function

  Private Function _Circle(ByVal aLeft As Object, ByVal aRight As Object) As Object
    ' ⍺ ○ ⍵
    ' 0	  (1-(⍵*2))*0.5
    ' 1	  sin(⍵)  			arcsin(⍵)
    ' 2	  cos(⍵)			  arccos(⍵)
    ' 3	  tan(⍵)			  arctan(⍵)
    ' 4	  ((⍵*2)+1)*0.5	((⍵*2)-1)*0.5
    ' 5	  sinh(⍵)			  arcsinh(⍵)
    ' 6	  cosh(⍵)			  arccosh(⍵)
    ' 7	  tanh(⍵)			  arctanh(⍵)
    Select Case aLeft
      Case 0
        Return (1 - (aRight ^ 2)) ^ 0.5
      Case 1
        Return Math.Sin(aRight)
      Case -1
        Return Math.Asin(aRight)
      Case 2
        Return Math.Cos(aRight)
      Case -2
        Return Math.Acos(aRight)
      Case 3
        Return Math.Tan(aRight)
      Case -3
        Return Math.Atan(aRight)
      Case 4
        Return ((aRight ^ 2) + 1) ^ 0.5
      Case -4
        Return ((aRight ^ 2) - 1) ^ 0.5
      Case 5
        Return Math.Sinh(aRight)
      Case -5
        ' ArcSinH     Log(z+sqrt(1+z*2))
        Return Math.Log(aRight + Math.Sqrt(1 + aRight ^ 2))

      Case 6
        Return Math.Cosh(aRight)
      Case -6
        ' ArcCosH     Log(z+(z+1) x sqrt((z-1)/z+1))
        Return Math.Log(aRight + (aRight + 1) * Math.Sqrt((aRight - 1) / (aRight + 1)))
      Case 7
        Return Math.Tanh(aRight)
      Case -7
        If -1 < aRight AndAlso 1 > aRight Then
          ' http://www.itl.nist.gov/div898/software/dataplot/refman2/ch7/arctanh.pdf
          ' ArcTanH     Log((1+z)/(1-z))/2
          Return Math.Log((1 + aRight) / (1 - aRight)) / 2
        Else
          ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
          ' This appears to require complex numbers
          ' http://www.cs.cmu.edu/Groups/AI/html/cltl/clm/node128.html
          ' ArcTanH     Log((1+z) x sqrt(1/(1-(z*2)))
          Return Math.Log((1 + aRight) * Math.Sqrt(1 / (1 - (aRight * 2))))
        End If
      Case Else
        Return ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End Select
  End Function

  Private thisCircle As Method
  Public Function Circle() As Method
    If thisCircle Is Nothing Then
      thisCircle = New Method(AddressOf _PiTimes, _
          AddressOf _Circle, Nothing, Nothing)
    End If

    Return thisCircle
  End Function

#End Region

End Class
