﻿Public Class OpMonadic

#Region "Properties"

  Private thisLeftFn As Method

  Private thisMonadicCall As MonadicCall
  Private thisDyadicCall As DyadicCall
  Private thisIndex As APL

#End Region

#Region "Delegates"

  Public Delegate Function MonadicCall( _
      ByVal aLeftFn As Method, _
      ByVal anIndex As APL, _
      ByVal aRight As APL) _
      As APL

  Public Delegate Function DyadicCall( _
      ByVal aLeft As APL, _
      ByVal aLeftFn As Method, _
      ByVal anIndex As APL, _
      ByVal aRight As APL) _
      As APL

#End Region

#Region "New and Arguments"

  ''' <summary>
  ''' Support of Monadic operators 
  ''' </summary>
  Public Sub New( _
      ByVal aMonadicCall As MonadicCall, _
      ByVal aDyadicCall As DyadicCall, _
      ByVal anIndex As Boolean)
    thisMonadicCall = aMonadicCall
    thisDyadicCall = aDyadicCall
    If anIndex Then
      thisIndex = _APL._Empty
    End If
  End Sub

  ''' <summary>
  ''' Remember the left method
  ''' </summary>
  Public Sub Arguments(ByVal aLeft As Method)
    If aLeft Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Syntax)
    End If

    thisLeftFn = aLeft
  End Sub

#End Region

#Region "Sub"

  Public Function [Sub](ByVal ParamArray anIndex() As Object) As OpMonadic
    If thisIndex Is Nothing Then
      ' When thisIndex wasn't set by this Op
      ExceptionAPL.Signal(ExceptionAPL.Is.Axis)
    End If
    thisIndex = New APL(anIndex)
    Return Me
  End Function

  Public Function [Sub](ByVal anIndex As APL) As OpMonadic
    If thisIndex Is Nothing Then
      ' When thisIndex wasn't set by this Op
      ExceptionAPL.Signal(ExceptionAPL.Is.Axis)
    End If
    UtilsShape.CheckValue(anIndex)
    thisIndex = anIndex
    Return Me
  End Function

#End Region

#Region "Derived"

  Public Function Derived( _
      ByVal aRight As APL) _
      As APL
    If thisMonadicCall Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Valence)
    End If

    Return thisMonadicCall.Invoke(thisLeftFn, thisIndex, aRight)
  End Function

  Public Function Derived( _
      ByVal aLeft As APL, _
      ByVal aRight As APL) _
      As APL
    If thisDyadicCall Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Valence)
    End If

    Return thisDyadicCall.Invoke(aLeft, thisLeftFn, thisIndex, aRight)
  End Function

#End Region

End Class
