﻿Public Class Method

#Region "Delegates"

  Public Delegate Function MonadicAPL( _
    ByVal aRight As APL) _
    As APL
  Public Delegate Function DyadicAPL( _
      ByVal aLeft As APL, _
      ByVal aRight As APL) _
      As APL

  Public Delegate Function MonadicIndexAPL( _
      ByVal anIndex As APL, _
      ByVal aRight As APL) _
      As APL
  Public Delegate Function DyadicIndexAPL( _
    ByVal aLeft As APL, _
    ByVal anIndex As APL, _
    ByVal aLeft As APL) _
    As APL

  Public Delegate Function MonadicScalar( _
    ByVal aRight As Object) _
    As Object
  Public Delegate Function DyadicScalar( _
    ByVal aLeft As Object, _
    ByVal aRight As Object) _
    As Object

#End Region

#Region "Instance Values"

  Private thisMonadic As MonadicAPL
  Private thisDyadic As DyadicAPL
  Private thisIndex As APL

  Private thisMonadicAPL As MonadicAPL
  Private thisMonadicIndexAPL As MonadicIndexAPL
  Private thisMonadicScalar As MonadicScalar

  Private thisDyadicAPL As DyadicAPL
  Private thisDyadicIndexAPL As DyadicIndexAPL
  Private thisDyadicScalar As DyadicScalar

  Private thisInverse As DyadicScalar
  Private thisEmptyValue As Object
  Private thisHandlesChars As Boolean
  Private thisNotBothChars As Integer

#End Region

#Region "New for ScalarFns"

  Public Sub New( _
      ByVal aMonadic As MonadicScalar, _
      ByVal aDyadic As DyadicScalar, _
      ByVal anInverse As DyadicScalar, _
      ByVal anEmptyValue As Object, _
      Optional ByVal aNotBothChars As Integer = -541)
    thisMonadic = AddressOf HandleMonadicScalar
    thisDyadic = AddressOf HandleDyadicScalar

    thisMonadicScalar = aMonadic
    thisDyadicScalar = aDyadic
    thisInverse = anInverse
    thisEmptyValue = anEmptyValue

    If aNotBothChars <> -541 Then
      thisHandlesChars = True
      thisNotBothChars = aNotBothChars
    End If
  End Sub

#End Region

#Region "ScalarFns Properties Monadic Dyadic Inverse EmptyValue HandlesChars and NotBothChars"

  Public ReadOnly Property Monadic() As MonadicScalar
    Get
      If thisMonadicScalar Is Nothing Then
        Return AddressOf (New OpScalar(Me)).Derived
      End If
      Return thisMonadicScalar
    End Get
  End Property

  Public ReadOnly Property Dyadic() As DyadicScalar
    Get
      If thisDyadicScalar Is Nothing Then
        Return AddressOf (New OpScalar(Me)).Derived
      End If
      Return thisDyadicScalar
    End Get
  End Property

  Public ReadOnly Property Inverse() As DyadicScalar
    Get
      Return thisInverse
    End Get
  End Property

  Public ReadOnly Property EmptyValue() As Object
    Get
      If thisEmptyValue Is Nothing Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End If
      Return thisEmptyValue
    End Get
  End Property

  Public ReadOnly Property HandlesChars() As Boolean
    Get
      Return thisHandlesChars
    End Get
  End Property

  Public ReadOnly Property NotBothChars() As Integer
    Get
      Return thisNotBothChars
    End Get
  End Property

#End Region

#Region "HandleMonadicScalar and HandleDyadicScalar"

  Private Function HandleMonadicScalar( _
      ByVal aRight As APL) _
      As APL
    Dim myValues As Object()
    Dim myResult As APL
    Dim myIndex As Integer

    If thisMonadicScalar Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Valence)
    ElseIf aRight.IsCharacter Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If
    myValues = aRight.ValueVector

    Try
      For myIndex = 0 To myValues.Length - 1
        myValues(myIndex) = thisMonadicScalar.Invoke(myValues(myIndex))
      Next
    Catch ex As Exception
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End Try

    myResult = New APL(myValues)
    myResult.Shape = aRight.Shape
    Return myResult
  End Function

  Private Function HandleDyadicScalar( _
      ByVal aLeft As APL, _
      ByVal aRight As APL) _
      As APL
    Dim myResults, myRights As Object()
    Dim mySingle As Object
    Dim myIndex As Integer
    Dim myShape As Integer()
    Dim myResult As APL

    If thisDyadicScalar Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Valence)
    ElseIf (aLeft.IsCharacter OrElse aRight.IsCharacter) AndAlso _
          Not thisHandlesChars Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If

    myResults = Nothing
    myShape = aRight.Shape
    If aLeft.SameShape(myShape) Then
      ' The two values have the same shape
      myResults = aLeft.ValueVector
      myRights = aRight.CompareValues
      Try
        For myIndex = 0 To myResults.Length - 1
          myResults(myIndex) = thisDyadicScalar.Invoke(myResults(myIndex), myRights(myIndex))
        Next
      Catch ex As Exception
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End Try

    ElseIf aLeft.VectorLength = 1 AndAlso aRight.VectorLength = 1 Then
      ' Both values are singletons
      If aLeft.Rank > aRight.Rank Then
        myShape = aLeft.Shape
      End If

      ReDim myResults(0)
      Try
        myResults(0) = thisDyadicScalar.Invoke( _
            aLeft.ValueVector(0), aRight.ValueVector(0))
      Catch ex As Exception
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End Try

    ElseIf aRight.VectorLength = 1 Then
      ' The right value is a singleton
      myShape = aLeft.Shape
      myResults = aLeft.ValueVector
      mySingle = aRight.ValueVector(0)
      Try
        For myIndex = 0 To myResults.Length - 1
          myResults(myIndex) = thisDyadicScalar.Invoke(myResults(myIndex), mySingle)
        Next
      Catch ex As Exception
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End Try

    ElseIf aLeft.VectorLength = 1 Then
      ' The left value is a singleton
      myShape = aRight.Shape
      mySingle = aLeft.ValueVector(0)
      myResults = aRight.ValueVector
      Try
        For myIndex = 0 To myResults.Length - 1
          myResults(myIndex) = thisDyadicScalar.Invoke(mySingle, myResults(myIndex))
        Next
      Catch ex As Exception
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End Try

    ElseIf aLeft.Rank = aRight.Rank Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Length)

    Else
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If

    myResult = New APL(myResults)
    myResult.Shape = myShape
    Return myResult
  End Function

#End Region

#Region "New for Roll and Deal"

  Public Sub New( _
      ByVal aMonadic As MonadicScalar, _
      ByVal aDyadic As DyadicAPL)
    thisMonadic = AddressOf HandleMonadicScalar
    thisDyadic = AddressOf HandleDyadicAPL

    thisMonadicScalar = aMonadic
    thisDyadicAPL = aDyadic
  End Sub

#End Region

#Region "New for APLFns"

  ''' <summary>
  ''' Support of APL functions 
  ''' </summary>
  Public Sub New( _
      ByVal aMonadic As MonadicAPL, _
      ByVal aDyadic As DyadicAPL)
    thisMonadic = AddressOf HandleMonadicAPL
    thisDyadic = AddressOf HandleDyadicAPL

    thisHandlesChars = True
    thisMonadicAPL = aMonadic
    thisDyadicAPL = aDyadic
  End Sub

#End Region

#Region "HandleMonadicAPL and HandleDyadicAPL"

  Private Function HandleMonadicAPL(ByVal aRight As APL) As APL
    If thisMonadicAPL Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Valence)
    End If
    Return thisMonadicAPL.Invoke(aRight)
  End Function

  Private Function HandleDyadicAPL(ByVal aLeft As APL, ByVal aRight As APL) As APL
    If thisDyadicAPL Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Valence)
    End If
    Return thisDyadicAPL.Invoke(aLeft, aRight)
  End Function

#End Region

#Region "Default Calls"

  Default Public ReadOnly Property Eval( _
      ByVal aRight As APL) _
      As APL
    Get
      Try
        UtilsShape.CheckValue(aRight)
        Return thisMonadic(aRight)
      Catch ex As Exception
        ReThrow(ex)
        Return Nothing
      End Try
    End Get
  End Property

  Private Sub ReThrow(ByVal anEx As Exception)
    If anEx.Message.StartsWith("Function does not accept") Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    Else
      ExceptionAPL.Signal(ExceptionAPL.Is.User, anEx.Message)
    End If
  End Sub

  Default Public ReadOnly Property Eval( _
      ByVal aRight As Object) _
      As APL
    Get
      Dim myRight As APL

      If TypeOf aRight Is APL Then
        myRight = DirectCast(aRight, APL)
      Else
        myRight = New APL(New Object() {aRight})
      End If
      Return thisMonadic(myRight)
    End Get
  End Property

  Default Public ReadOnly Property Eval( _
      ByVal aRight As String) _
      As APL
    Get
      UtilsShape.CheckValue(aRight)
      Return thisMonadic(New APL(aRight))
    End Get
  End Property

  Default Public ReadOnly Property Eval( _
      ByVal aLeft As APL, _
      ByVal aRight As APL) _
      As APL
    Get
      Try
        UtilsShape.CheckValue(aRight)
        Return thisDyadic(aLeft, aRight)
      Catch ex As Exception
        ReThrow(ex)
        Return Nothing
      End Try
    End Get
  End Property

#End Region

#Region "New for IndexAPLFns"

  ''' <summary>
  ''' Support of IndexAPL functions 
  ''' </summary>
  Public Sub New( _
      ByVal aMonadic As MonadicIndexAPL, _
      ByVal aDyadic As DyadicIndexAPL)
    thisMonadic = AddressOf HandleMonadicIndexAPL
    thisDyadic = AddressOf HandleDyadicIndexAPL
    thisIndex = _APL._Empty

    thisHandlesChars = True
    thisMonadicIndexAPL = aMonadic
    thisDyadicIndexAPL = aDyadic
  End Sub

#End Region

#Region "HandleMonadicIndexAPL and HandleDyadicIndexAPL"

  Private Function HandleMonadicIndexAPL(ByVal aRight As APL) As APL
    If thisMonadicIndexAPL Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Valence)
    End If
    UtilsShape.CheckValue(aRight)
    Return thisMonadicIndexAPL.Invoke(thisIndex, aRight)
  End Function

  Private Function HandleDyadicIndexAPL(ByVal aLeft As APL, ByVal aRight As APL) As APL
    If thisDyadicIndexAPL Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Valence)
    End If
    UtilsShape.CheckValue(aRight)
    Return thisDyadicIndexAPL.Invoke(aLeft, thisIndex, aRight)
  End Function

#End Region

#Region "Sub for IndexAPLFns"

  Public Function [Sub](ByVal anIndex As APL) As Method
    If thisIndex Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Axis)
    End If

    thisIndex = anIndex
    Return Me
  End Function

  Public Function [Sub](ByVal anIndex As Object) As Method
    If anIndex Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Axis)
    End If
    Return [Sub](New APL(New Object() {anIndex}))
  End Function

#End Region

#Region "Eval OpMonadic"

  Default Public ReadOnly Property Eval( _
      ByVal anOp As OpMonadic) _
      As Method
    Get
      anOp.Arguments(Me)
      Return New Method(AddressOf anOp.Derived, AddressOf anOp.Derived)
    End Get
  End Property

#End Region

#Region "Eval OpDyadic"

  Default Public ReadOnly Property Eval( _
      ByVal anOp As OpDyadic, _
      ByVal aRightFn As Method) _
      As Method
    Get
      anOp.Arguments(Me, aRightFn)
      Return New Method(AddressOf anOp.Derived, AddressOf anOp.Derived)
    End Get
  End Property

#End Region

#Region "Eval OpScalar"

  Default Public ReadOnly Property Eval( _
      ByVal anOp As OpScalar) _
      As Method
    Get
      anOp.Arguments(Me)
      Return New Method(AddressOf anOp.Derived, AddressOf anOp.Derived, _
                        Nothing, Nothing)
    End Get
  End Property

#End Region

End Class
