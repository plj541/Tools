﻿Partial Class _APL

#Region "Scalar"

  Public Function Scalar() As OpScalar
    Return New OpScalar
  End Function

#End Region

#Region "Each"

  Public Function [Each]() As OpMonadic
    Return New OpMonadic(AddressOf _Each, AddressOf _Each, False)
  End Function

  Private Function _Each( _
      ByVal aMethod As Method, _
      ByVal anIndex As APL, _
      ByVal aRight As APL) _
      As APL
    Dim myValues, myResult As Object()
    Dim myIndex As Integer

    If aRight.Rank = 0 Then
      Return Enclose(aMethod(Disclose(aRight)))
    End If

    myValues = aRight.ValueVector
    ReDim myResult(myValues.Length - 1)
    For myIndex = 0 To myResult.Length - 1
      myResult(myIndex) = EachItem(aMethod(EachValue(myValues(myIndex))))
    Next
    Return EachResult(aRight, myResult)
  End Function

  Private Function _Each( _
      ByVal aLeft As APL, _
      ByVal aMethod As Method, _
      ByVal anIndex As APL, _
      ByVal aRight As APL) _
      As APL
    Dim myLeftItem, myRightItem As APL
    Dim myLeft, myRight, myResult As Object()
    Dim myIndex As Integer

    If aLeft.Rank = 0 AndAlso aRight.Rank = 0 Then
      Return Enclose(aMethod(Disclose(aLeft), Disclose(aRight)))
    End If

    myLeft = aLeft.ValueVector
    myRight = aRight.ValueVector

    If aLeft.SameShape(aRight.Shape) Then
      ReDim myResult(myRight.Length - 1)
      For myIndex = 0 To myLeft.Length - 1
        myLeftItem = EachValue(myLeft(myIndex))
        myRightItem = EachValue(myRight(myIndex))
        myResult(myIndex) = EachItem(aMethod(myLeftItem, myRightItem))
      Next
      Return EachResult(aLeft, myResult)

    ElseIf myLeft.Length = 1 AndAlso myRight.Length = 1 Then
      ReDim myResult(0)
      myLeftItem = EachValue(myLeft(0))
      myRightItem = EachValue(myRight(0))
      myResult(myIndex) = EachItem(aMethod(myLeftItem, myRightItem))

      If aLeft.Rank > aRight.Rank Then
        Return EachResult(aLeft, myResult)
      Else
        Return EachResult(aRight, myResult)
      End If

    ElseIf myLeft.Length = 1 Then
      ReDim myResult(myRight.Length - 1)
      myLeftItem = EachValue(myLeft(0))
      For myIndex = 0 To myRight.Length - 1
        myRightItem = EachValue(myRight(myIndex))
        myResult(myIndex) = EachItem(aMethod(myLeftItem, myRightItem))
      Next
      Return EachResult(aRight, myResult)

    ElseIf myRight.Length = 1 Then
      ReDim myResult(myLeft.Length - 1)
      myRightItem = EachValue(myRight(0))
      For myIndex = 0 To myLeft.Length - 1
        myLeftItem = EachValue(myLeft(myIndex))
        myResult(myIndex) = EachItem(aMethod(myLeftItem, myRightItem))
      Next
      Return EachResult(aLeft, myResult)

    Else
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
      Return Nothing
    End If
  End Function

  Private Function EachValue(ByVal aValue As Object) As APL
    If TypeOf aValue Is APL Then
      Return DirectCast(aValue, APL)
    ElseIf TypeOf aValue Is Char Then
      Return New APL(aValue.ToString)
    ElseIf TypeOf aValue Is String Then
      Return New APL(DirectCast(aValue, String), False)
    Else
      Return New APL(New Object() {aValue})
    End If
  End Function

  Private Function EachResult( _
      ByVal aShape As APL, _
      ByVal aResult As Object()) _
      As APL
    Return Shape(aShape)(Shape, New APL(aResult))
  End Function

  Private Function EachItem(ByVal anItem As APL) As Object
    If anItem.Rank = 0 Then
      Dim myItem As Object

      myItem = anItem.ValueVector(0)
      If TypeOf myItem Is Integer OrElse _
          TypeOf myItem Is Double OrElse _
          TypeOf myItem Is Char Then
        Return myItem
      End If
      Return anItem
    Else
      Return anItem
    End If
  End Function

#End Region

#Region "Select"

  ''' <summary>
  ''' Select provides:
  '''   selectVector / anArray
  '''   selectVector /[anIndex] anArray
  ''' </summary>
  Public Function [Select]() As Method
    Return New Method(Nothing, AddressOf _Select)
  End Function

  Private Function _Select( _
      ByVal aLeft As APL, _
      ByVal anIndex As APL, _
      ByVal aRight As APL) _
      As APL
    If Array.ReferenceEquals(anIndex, Empty) Then
      Return _Select(aLeft, Math.Max(0, aRight.Rank - 1), aRight)
    Else
      Return _Select(aLeft, anIndex.IntegerIndex, aRight)
    End If
  End Function

  Private Function _Select( _
      ByVal aLeft As APL, _
      ByVal anIndex As Integer, _
      ByVal aRight As APL) _
      As APL
    Dim myRightValues, myResultValues As Object()
    Dim myRightChars As String
    Dim myResultChars As Char()
    Dim myResult As APL
    Dim myLeftSelects, myShape, myOld, myNew As Integer()
    Dim myIndex, myItem, myReps, mySize As Integer
    Dim myIndexing As Indexing

    UtilsShape.CheckIndex(anIndex, aRight)
    If aLeft.Rank > 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If
    myLeftSelects = aLeft.IntegerVector

    myShape = aRight.Shape
    If myShape.Length = 0 Then
      mySize = UtilsShape.PlusReduce(myLeftSelects)
      If aRight.IsCharacter Then
        Return New APL(StrDup(mySize, aRight.CharacterVector(0)))
      Else
        Return New APL(UtilsStrict.Fill(mySize, aRight.ValueVector(0)))
      End If

    ElseIf myLeftSelects.Length = 1 Then
      myShape(anIndex) = myLeftSelects(0) * myShape(anIndex)
    ElseIf myLeftSelects.Length = myShape(anIndex) Then
      myShape(anIndex) = UtilsShape.PlusReduce(myLeftSelects)
    Else
      ExceptionAPL.Signal(ExceptionAPL.Is.Length)
    End If

    mySize = UtilsShape.TimesReduce(myShape)
    If mySize = 0 Then
      If aRight.IsCharacter Then
        myResult = New APL("")
      Else
        myResult = New APL(New Object() {})
      End If

    Else
      myIndexing = IndexItems(aRight)
      myOld = myIndexing.ReSelect(anIndex)
      ReDim myNew(myShape(anIndex) - 1)

      For myIndex = 0 To myOld.Length - 1
        If myLeftSelects.Length = 1 Then
          myReps = myLeftSelects(0)
        Else
          myReps = myLeftSelects(myIndex)
        End If

        For myReps = 1 To myReps
          myNew(myItem) = myOld(myIndex)
          myItem += 1
        Next
      Next

      myIndexing.ReSelect = myNew

      If aRight.IsCharacter Then
        myRightChars = aRight.CharacterVector
        ReDim myResultChars(mySize - 1)

        For myIndex = 0 To myResultChars.Length - 1
          myResultChars(myIndex) = myRightChars(myIndexing.Next)
        Next
        myResult = New APL(myResultChars)

      Else
        myRightValues = aRight.ValueVector
        ReDim myResultValues(mySize - 1)

        For myIndex = 0 To myResultValues.Length - 1
          myResultValues(myIndex) = myRightValues(myIndexing.Next)
        Next
        myResult = New APL(myResultValues)
      End If
    End If

    myResult.Shape = myShape
    Return myResult
  End Function

  Private Function IndexItems(ByVal aRight As APL) As Indexing
    If aRight.Rank = 0 Then
      Return New Indexing(New Integer() {1})
    Else
      Return New Indexing(aRight.Shape)
    End If
  End Function

#End Region

#Region "Reduce"

  ''' <summary>
  ''' Reduce provides:
  '''   DyadicFunction / anArray
  '''   DyadicFunction /[anIndex] anArray
  ''' </summary>
  Public ReadOnly Property Reduce() As OpMonadic
    Get
      Return New OpMonadic(AddressOf _Reduce, Nothing, True)
    End Get
  End Property

  Private Function _Reduce( _
      ByVal aFunction As Method, _
      ByVal anIndex As APL, _
      ByVal aRight As APL) _
      As APL
    If aRight.Rank = 0 Then
      Return aRight
    End If

    Try
      If Array.ReferenceEquals(anIndex, Empty) Then
        Return _Reduce(aFunction, aRight.Rank - 1, aRight)
      Else
        Return _Reduce(aFunction, anIndex.IntegerIndex, aRight)
      End If

    Catch ex As ExceptionAPL
      ExceptionAPL.Signal(ex.Event)
    Catch ex As Exception
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End Try
  End Function

  ''' <summary>
  '''   DyadicFunction /[anIndex] anArray
  ''' </summary>
  Private Function _Reduce( _
      ByVal aFunction As Method, _
      ByVal anIndex As Integer, _
      ByVal aRight As APL) _
      As APL
    Dim myMethod As Method.DyadicScalar
    Dim myRightValues, myValues As Object()
    Dim myValue As Object
    Dim myRightShape, myShape As Integer()
    Dim myResult As APL
    Dim myOne, myStep, myIndex As Integer
    Dim myIndexing As Indexing

    UtilsShape.CheckIndex(anIndex, aRight)
    myMethod = aFunction.Dyadic
    myRightValues = aRight.ValueVector
    myRightShape = aRight.Shape

    If myRightShape.Length = 0 Then
      Return (aRight.Clone)

    Else
      myStep = myRightShape(anIndex)
      myShape = UtilsShape.Remove(anIndex, myRightShape)
      ReDim myValues(UtilsShape.TimesReduce(myShape) - 1)

      If myValues.Length = 0 Then
        ' myValues is done

      ElseIf myStep = 0 Then
        myValues = UtilsStrict.Fill(myValues.Length, aFunction.EmptyValue)

      Else
        myStep -= 1
        myIndexing = New Indexing(aRight.Shape)
        myIndexing.ReIndex(anIndex, True)

        For myIndex = 0 To myValues.Length - 1
          myValue = myRightValues(myIndexing.Next)

          For myOne = 1 To myStep
            myValue = myMethod.Invoke(myRightValues(myIndexing.Next), myValue)
          Next

          myValues(myIndex) = myValue
        Next
      End If
    End If

    myResult = New APL(myValues)
    myResult.Shape = myShape
    Return myResult
  End Function

#End Region

#Region "Expand"

  ''' <summary>
  ''' Expand provides:
  '''   expandVector / anArray
  '''   expandVector /[anIndex] anArray
  ''' </summary>
  Public Function Expand() As Method
    Return New Method(Nothing, AddressOf _Expand)
  End Function

  Private Function _Expand( _
    ByVal aLeft As APL, _
    ByVal anIndex As APL, _
    ByVal aRight As APL) _
    As APL
    If Array.ReferenceEquals(anIndex, Empty) Then
      Return _Expand(aLeft, Math.Max(0, aRight.Rank - 1), aRight)
    Else
      Return _Expand(aLeft, anIndex.IntegerIndex, aRight)
    End If
  End Function

  Private Function _Expand( _
      ByVal aLeft As APL, _
      ByVal anIndex As Integer, _
      ByVal aRight As APL) _
      As APL
    Dim myRightValues, myResultValues As Object()
    Dim myRightChars As String
    Dim myResultChars As Char()
    Dim myResult As APL
    Dim myLeftSelects, myShape, myOld, myNew As Integer()
    Dim myIndex, myItem, myOldItem, myNewItem, myReps, mySize As Integer
    Dim myIndexing As Indexing

    UtilsShape.CheckIndex(anIndex, aRight)
    If aLeft.Rank > 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If
    myLeftSelects = aLeft.IntegerVector

    myShape = aRight.Shape
    If myShape.Length = 0 Then
      ReDim myShape(0)
      mySize = UtilsShape.PlusReduceCount0(myLeftSelects)
      myShape(anIndex) = mySize
    ElseIf UtilsShape.PlusReduce(myLeftSelects) <> myShape(anIndex) Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Length)
    Else
      myShape(anIndex) = UtilsShape.PlusReduceCount0(myLeftSelects)
      mySize = UtilsShape.TimesReduce(myShape)
    End If

    If mySize = 0 Then
      If aRight.IsCharacter Then
        myResult = New APL("")

      Else
        myResult = New APL(New Object() {})
      End If

    Else
      myIndexing = IndexItems(aRight)
      myOld = myIndexing.ReSelect(anIndex)
      ReDim myNew(myShape(anIndex) - 1)

      If aRight.Rank = 0 Then
        myItem = myOld(0)
      Else
        myItem = -1
      End If

      For myIndex = 0 To myLeftSelects.Length - 1
        myReps = myLeftSelects(myIndex)

        If myReps = 0 Then
          myNew(myNewItem) = -1
          myNewItem += 1

        Else
          For myReps = 1 To myReps
            If myItem = -1 Then
              myNew(myNewItem) = myOld(myOldItem)
              myOldItem += 1
            Else
              myNew(myNewItem) = myItem
            End If
            myNewItem += 1
          Next
        End If
      Next
      myIndexing.ReSelect = myNew

      If aRight.IsCharacter Then
        myRightChars = aRight.CharacterVector
        ReDim myResultChars(mySize - 1)

        For myIndex = 0 To myResultChars.Length - 1
          myItem = myIndexing.Next
          If myItem < 0 Then
            myResultChars(myIndex) = " "c

          Else
            myResultChars(myIndex) = myRightChars(myItem)
          End If
        Next
        myResult = New APL(myResultChars)

      Else
        myRightValues = aRight.ValueVector
        ReDim myResultValues(mySize - 1)

        For myIndex = 0 To myResultValues.Length - 1
          myItem = myIndexing.Next
          If myItem < 0 Then
            myResultValues(myIndex) = 0

          Else
            myResultValues(myIndex) = myRightValues(myItem)
          End If
        Next
        myResult = New APL(myResultValues)
      End If
    End If

    myResult.Shape = myShape
    Return myResult
  End Function

#End Region

#Region "Scan"

  ''' <summary>
  ''' Scan provides:
  '''   DyadicFunction \ anArray
  '''   DyadicFunction \[anIndex] anArray
  ''' </summary>
  Public ReadOnly Property Scan() As OpMonadic
    Get
      Return New OpMonadic(AddressOf _Scan, Nothing, True)
    End Get
  End Property

  ''' <summary>
  '''   DyadicFunction \[anIndex] anArray
  ''' </summary>
  Public Function _Scan( _
      ByVal aFunction As Method, _
      ByVal anIndex As APL, _
      ByVal aRight As APL) _
      As APL
    If aRight.Rank = 0 Then
      Return aRight
    End If

    Try
      If Array.ReferenceEquals(anIndex, Empty) Then
        Return _Scan(aFunction, aRight.Rank - 1, aRight)
      Else
        Return _Scan(aFunction, anIndex.IntegerIndex, aRight)
      End If

    Catch ex As ExceptionAPL
      ExceptionAPL.Signal(ex.Event)
    Catch ex As Exception
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End Try
  End Function

  ''' <summary>
  '''   DyadicFunction \[anIndex] anArray
  ''' </summary>
  Public Function _Scan( _
      ByVal aFunction As Method, _
      ByVal anIndex As Integer, _
      ByVal aRight As APL) _
      As APL
    Dim myMethod, myInverse, myCurrent As Method.DyadicScalar
    Dim myRightValues, myValues As Object()
    Dim myValue As Object
    Dim myShape, myIndexes As Integer()
    Dim myResult As APL
    Dim myStart, myLast, myStep, myIndex, myItem As Integer
    Dim myIndexing As Indexing

    UtilsShape.CheckIndex(anIndex, aRight)
    myMethod = aFunction.Dyadic
    myRightValues = aRight.ValueVector
    myShape = aRight.Shape

    If myShape.Length = 0 Then
      Return (aRight.Clone)

    Else
      myStep = myShape(anIndex)
      ReDim myValues(myRightValues.Length - 1)

      If myStep = 0 Then
        myValues = UtilsStrict.Fill(myRightValues.Length, aFunction.EmptyValue)

      Else
        myIndexing = New Indexing(aRight.Shape)
        myIndexing.ReIndex(anIndex, False)

        myInverse = aFunction.Inverse
        If myInverse IsNot Nothing Then
          myValue = 0
          myStart = 0

          myCurrent = myMethod
          For myItem = 1 To myRightValues.Length
            myIndex = myIndexing.Next
            If myStart = 0 Then
              myValue = myRightValues(myIndex)
              myValues(myIndex) = myValue
              If myStep <> 1 Then
                myStart = 1
                myCurrent = myMethod
              End If

            Else
              myValue = myCurrent.Invoke(myValue, myRightValues(myIndex))
              myValues(myIndex) = myValue
              myStart = (myStart + 1) Mod myStep
              If 0 = myStart Mod 2 Then
                myCurrent = myInverse

              Else
                myCurrent = myMethod
              End If
            End If
          Next

        Else
          ReDim myIndexes(myStep - 1)
          For myStart = 0 To myValues.Length - 1 Step myStep
            For myItem = 0 To myStep - 1
              myIndexes(myItem) = myIndexing.Next
            Next

            myValues(myIndexes(0)) = myRightValues(myIndexes(0))
            For myLast = myStep - 1 To 1 Step -1
              myValue = myRightValues(myIndexes(myLast))
              For myItem = myLast - 1 To 0 Step -1
                myValue = myMethod.Invoke( _
                    myRightValues(myIndexes(myItem)), myValue)
              Next
              myValues(myIndexes(myLast)) = myValue
            Next
          Next
        End If
      End If
    End If

    myResult = New APL(myValues)
    myResult.Shape = myShape
    Return myResult
  End Function

#End Region

#Region "Dot"

  ''' <summary>
  ''' aValue aMethod .Dot aMethod aValue
  ''' </summary>
  Public ReadOnly Property Dot() As OpDyadic
    Get
      Return New OpDyadic(Nothing, AddressOf Inner, False)
    End Get
  End Property

  Private Function Inner( _
      ByVal aLeft As APL, _
      ByVal aLeftContext As Method, _
      ByVal anIndex As APL, _
      ByVal aRightContext As Method, _
      ByVal aRight As APL) _
      As APL
    Dim myValues As Object()
    Dim myLeftShape, myRightShape, myShape As Integer()
    Dim myLeftInner, myRightInner, myInner As Integer
    Dim myLeftSingle, myRightSingle As Boolean
    Dim myResult As APL
    Dim myIndexing As Indexing

    myLeftShape = aLeft.Shape
    myRightShape = aRight.Shape
    myLeftInner = ShapeOf(myLeftShape, myLeftShape.Length - 1)
    myRightInner = ShapeOf(myRightShape, 0)
    If myLeftInner = myRightInner Then
      myInner = myLeftInner
    Else
      ' If either Inner is 0, myInner remains 0, so a non-empty result
      ' will be filled with aLeftContext.EmptyValue below
      If myLeftInner <> 0 AndAlso myRightInner <> 0 Then
        If myLeftInner = 1 Then
          myLeftSingle = True
          myInner = myRightInner
          ' N.B.  This starts fetching the first left below
          myLeftInner = 0

        ElseIf myRightInner = 1 AndAlso myLeftInner <> 0 Then
          myRightSingle = True
          myInner = myLeftInner
        Else
          ExceptionAPL.Signal(ExceptionAPL.Is.Length)
        End If
      End If
    End If

    myLeftShape = UtilsShape.Remove(myLeftShape.Length - 1, myLeftShape)
    myRightShape = UtilsShape.Remove(0, myRightShape)
    myShape = UtilsShape.Catenate(myLeftShape, myRightShape)
    ReDim myValues(UtilsShape.TimesReduce(myShape) - 1)
    If myValues.Length <> 0 Then
      If myInner = 0 Then
        myValues = UtilsStrict.Fill(myValues.Length, aLeftContext.EmptyValue)

      Else
        If aRight.Rank = 0 Then
          myIndexing = New Indexing(New Integer() {1})
        Else
          myIndexing = New Indexing(aRight.Shape)
          myIndexing.ReIndex(0, True)
        End If

        Try
          myValues = Inner(myValues, aLeft, aLeftContext, aRightContext, aRight, _
            myLeftShape, myRightShape, myIndexing, myInner, _
            myLeftSingle, myRightSingle, myLeftInner, myRightInner)

        Catch ex As ExceptionAPL
          ExceptionAPL.Signal(ex.Event)
        Catch ex As Exception
          ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
        End Try
      End If
    End If

    myResult = New APL(myValues)
    myResult.Shape = myShape
    Return myResult
  End Function

  Private Function Inner(ByVal myValues As Object(), _
      ByVal aLeft As APL, ByVal aLeftContext As Method, _
      ByVal aRightContext As Method, ByVal aRight As APL, _
      ByVal myLeftShape As Integer(), ByVal myRightShape As Integer(), _
      ByVal myIndexing As Indexing, ByVal myInner As Integer, _
      ByVal myLeftSingle As Boolean, ByVal myRightSingle As Boolean, _
      ByVal myLeftInner As Integer, ByVal myRightInner As Integer) _
      As Object()
    Dim myLeftValue, myRightValue As Object
    Dim myIndex, myOuterLoop, myInnerLoop, _
        myInnerStart, myInnerStop, myInnerIndex, myInnerSize As Integer
    Dim myLeftMethod, myRightMethod As Method.DyadicScalar
    Dim myLeftValues, myRightValues As Object()
    Dim myValue As Object

    myLeftMethod = aLeftContext.Dyadic
    myLeftValues = aLeft.ValueVector
    myRightMethod = aRightContext.Dyadic
    myRightValues = aRight.ValueVector

    myInnerSize = UtilsShape.TimesReduce(myRightShape)
    myInnerStart = myInner - 1
    For myOuterLoop = 1 To UtilsShape.TimesReduce(myLeftShape)
      For myInnerLoop = 1 To myInnerSize
        If myLeftSingle Then
          myLeftValue = myLeftValues(myLeftInner)
          'myLeftInner += 1

        Else
          myLeftValue = myLeftValues(myInnerStart)
        End If

        myRightValue = myRightValues(myIndexing.Next)
        myValue = myRightMethod.Invoke(myLeftValue, myRightValue)

        For myInnerIndex = myInnerStart - 1 To myInnerStop Step -1
          If myLeftSingle Then
            myRightValue = myRightValues(myIndexing.Next)

          ElseIf myRightSingle Then
            myLeftValue = myLeftValues(myInnerIndex)

          Else
            myLeftValue = myLeftValues(myInnerIndex)
            myRightValue = myRightValues(myIndexing.Next)
          End If

          myValue = myLeftMethod.Invoke( _
                    myRightMethod.Invoke(myLeftValue, myRightValue), _
                    myValue)
        Next

        myValues(myIndex) = myValue
        myIndex += 1
      Next

      If myLeftSingle Then
        myLeftInner += 1
      End If

      myInnerStart += myInner
      myInnerStop += myInner
    Next

    Return myValues
  End Function

  Private Function ShapeOf(ByVal aShape As Integer(), ByVal anIndex As Integer) As Integer
    If aShape.Length = 0 Then
      Return 1

    Else
      Return aShape(anIndex)
    End If
  End Function

#End Region

#Region "DotDot"

  ''' <summary>
  ''' aValue aMethod .Outer aValue
  ''' </summary>
  Public ReadOnly Property DotDot() As OpMonadic
    Get
      Return New OpMonadic(Nothing, AddressOf _Outer, False)
    End Get
  End Property

  Private Function _Outer( _
      ByVal aLeft As APL, _
      ByVal aMethod As Method, _
      ByVal anIndex As APL, _
      ByVal aRight As APL) _
      As APL
    Dim myMethod As Method.DyadicScalar
    Dim myLeftValues, myRightValues, myValues As Object()
    Dim myValue As Object
    Dim myResult As APL
    Dim myLeftShape, myRightShape, myShape As Integer()
    Dim myLeftIndex, myRightIndex, myIndex As Integer

    myMethod = aMethod.Dyadic
    myRightShape = aRight.Shape
    ' aRight scaler would loop in the code below.
    If myRightShape.Length = 0 Then
      Return aLeft(aMethod, aRight)
    End If

    myLeftShape = aLeft.Shape
    myLeftValues = aLeft.ValueVector
    myRightValues = aRight.ValueVector
    myShape = UtilsShape.Catenate(myLeftShape, myRightShape)
    ReDim myValues(UtilsShape.TimesReduce(myShape) - 1)

    Try
      ' Empty results would work without this test
      ' But run slow if the left argument is the large one
      If myValues.Length <> 0 Then
        For myLeftIndex = 0 To myLeftValues.Length - 1
          myValue = myLeftValues(myLeftIndex)
          For myRightIndex = 0 To myRightValues.Length - 1
            myValues(myIndex) = myMethod.Invoke(myValue, myRightValues(myRightIndex))
            myIndex += 1
          Next
        Next
      End If

    Catch ex As ExceptionAPL
      ExceptionAPL.Signal(ex.Event)
    Catch ex As Exception
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End Try

    myResult = New APL(myValues)
    myResult.Shape = myShape
    Return myResult
  End Function

#End Region

End Class
