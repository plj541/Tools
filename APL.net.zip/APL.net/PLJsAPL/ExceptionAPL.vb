﻿Public Class ExceptionAPL
  Inherits Exception

#Region "Is"

  Private thisType As [Is]
  ''' <summary>
  ''' The Event for ExceptionAPL to Throw.
  ''' </summary>
  Public Enum [Is]
    ' I don't know that anyone cares
    ' But these are from IPSA's ⎕TRAP
    Axis = 18
    Domain = 11
    Index = 3
    Length = 5
    Nonce = 16
    Rank = 4
    System = 86
    Syntax = 2
    User = 541
    Valence = 17
    Value = 6
  End Enum

#End Region

#Region "Signal"

  ''' <summary>
  ''' Throw New ExceptionAPL(Exception.Is.Event)
  ''' </summary>
  ''' <param name="anEvent">Returned by .Event</param>
  Public Shared Function Signal( _
      ByVal anEvent As [Is]) _
      As APL
    Throw New ExceptionAPL(anEvent)
    Return Nothing
  End Function

  Private Sub New(ByVal anEvent As [Is])
    MyBase.New(anEvent.ToString & " Error")
    thisType = anEvent
  End Sub

  ''' <summary>
  ''' Throw New ExceptionAPL(Exception.Is.Event, "User Message")
  ''' </summary>
  ''' <param name="anEvent">Returned by .Event</param>
  ''' <param name="aMessage">Returned by .Message</param>
  Public Shared Function Signal( _
      ByVal anEvent As [Is], _
      ByVal aMessage As String) _
      As APL
    Throw New ExceptionAPL(anEvent, aMessage)
    Return Nothing
  End Function

  Private Sub New(ByVal anEvent As [Is], ByVal aMessage As String)
    MyBase.New(NewMessage(anEvent, aMessage))
    thisType = anEvent
  End Sub

  Private Shared Function NewMessage(ByVal anEvent As [Is], ByVal aMessage As String) As String
    If anEvent = [Is].User Then
      Return aMessage
    Else
      Return anEvent.ToString & " Error  " & aMessage
    End If
  End Function

#End Region

#Region "Event"

  ''' <summary>
  ''' Returns the ExceptionAPL.Is.
  ''' </summary>
  Public ReadOnly Property [Event]() As [Is]
    Get
      Return thisType
    End Get
  End Property

#End Region

#Region "Where"

  ''' <summary>
  ''' Returns the function and line number where
  ''' this exception occurred for an ExceptionAPL.
  ''' </summary>
  Public Function Where() As String
    Return Where(StackTrace)
  End Function

  ''' <summary>
  ''' Where returns the function and line number 
  ''' where the exception occurred for anException.
  ''' </summary>
  Public Shared Function Where(ByVal anException As Exception) As String
    Return Where(anException.StackTrace)
  End Function

  Private Shared Function Where(ByVal aStackTrace As String) As String
    Return aStackTrace.Substring( _
        1 + aStackTrace.LastIndexOf("\"c))
  End Function

#End Region

End Class