﻿Partial Class _APL

  '   ⌹   Matrix

  Public ReadOnly Property Matrix() As Method
    Get
      Return New Method(AddressOf MatrixInverse, AddressOf MatrixDivide)
    End Get
  End Property

#Region "MatrixInverse"

  Private Function MatrixInverse(ByVal aRight As APL) As APL
    Dim myShape As Integer()
    Dim myMatrix As Double(,)

    If aRight.IsCharacter Then
      _Signal(ExceptionAPL.Is.Domain)
    ElseIf aRight.Rank = 2 Then
      ' This is why we are here.
    ElseIf aRight.Rank > 2 Then
      _Signal(ExceptionAPL.Is.Rank)
    ElseIf aRight.Rank = 0 Then
      Dim myValues(0) As Object
      myValues(0) = 1 / CType(aRight.ValueVector(0), Double)
      Return New APL(myValues)
    Else
      _Signal(ExceptionAPL.Is.Nonce)
    End If

    myShape = aRight.Shape
    If myShape(0) < myShape(1) Then
      _Signal(ExceptionAPL.Is.Length)
    ElseIf myShape(0) <> myShape(1) Then
      _Signal(ExceptionAPL.Is.Nonce)
    End If

    myMatrix = DirectCast(UtilsStrict.ToDouble(aRight), Double(,))
    myMatrix = Inverse(myMatrix)
    Return UtilsStrict.FromDouble(myMatrix)
  End Function

#End Region

#Region "MatrixDivide"

  Private Function MatrixDivide(ByVal aLeft As APL, ByVal aRight As APL) As APL
    If aLeft.IsCharacter OrElse aRight.IsCharacter Then
      _Signal(ExceptionAPL.Is.Domain)
    End If
    If aLeft.Rank > 2 Then
      _Signal(ExceptionAPL.Is.Rank)
    End If
    If aRight.Rank = 2 Then
      If aLeft.Rank <> 1 AndAlso _
          aLeft.Shape(0) <> aRight.Shape(0) Then
        _Signal(ExceptionAPL.Is.Length)
      End If
      Return MatrixInverse(aRight)(Plus(Dot, Times), aLeft)

    ElseIf aLeft.Rank = 0 AndAlso aRight.Rank = 0 Then
      Dim myValues(0) As Object
      myValues(0) = CType(aLeft.ValueVector(0), Double) / _
                    CType(aRight.ValueVector(0), Double)
      Return New APL(myValues)

    Else
      _Signal(ExceptionAPL.Is.Nonce)
      Return Nothing
    End If
  End Function

#End Region

#Region "Inverse"

  ''' <summary>
  ''' Inverse of a matrix.
  ''' </summary>
  ''' <remarks>
  ''' This code only supports a square.
  ''' </remarks>
  Private Function Inverse( _
      ByVal aMatrix As Double(,)) _
      As Double(,)
    Dim myResult As Double(,)
    Dim myVal As Double
    Dim myItem, myCol, myRowA, myRowB, myMax As Integer

    If Determinant(aMatrix) = 0 Then
      _Signal(ExceptionAPL.Is.Domain)
    End If

    Try
      myMax = aMatrix.GetUpperBound(0)
      ReDim myResult(myMax, myMax)

      For myItem = 0 To myMax
        myResult(myItem, myItem) = 1
      Next

      For myItem = 0 To myMax
        If Math.Abs(aMatrix(myItem, myItem)) < 0.0000000001 Then
          For myCol = myItem + 1 To myMax
            If myCol <> myItem Then
              If Math.Abs(aMatrix(myItem, myCol)) > 0.0000000001 Then
                For myRowA = 0 To myMax
                  aMatrix(myRowA, myItem) = aMatrix(myRowA, myItem) + _
                                            aMatrix(myRowA, myCol)
                  myResult(myRowA, myItem) = myResult(myRowA, myItem) + _
                                             myResult(myRowA, myCol)
                Next
                Exit For
              End If
            End If
          Next
        End If

        myVal = 1 / aMatrix(myItem, myItem)
        For myRowA = 0 To myMax
          aMatrix(myRowA, myItem) = myVal * aMatrix(myRowA, myItem)
          myResult(myRowA, myItem) = myVal * myResult(myRowA, myItem)
        Next

        For myRowA = 0 To myMax
          If myRowA <> myItem Then
            myVal = aMatrix(myItem, myRowA)
            For myRowB = 0 To myMax
              aMatrix(myRowB, myRowA) = aMatrix(myRowB, myRowA) - _
                                myVal * aMatrix(myRowB, myItem)
              myResult(myRowB, myRowA) = myResult(myRowB, myRowA) - _
                                 myVal * myResult(myRowB, myItem)
            Next
          End If
        Next
      Next

      Return myResult

    Catch ex As Exception
      _Signal(ExceptionAPL.Is.Domain)
      Return Nothing
    End Try
  End Function

#End Region

#Region "Determinant"

  ''' <summary>
  ''' Determinant of a matrix.
  ''' </summary>
  ''' <remarks>
  ''' This code only supports a square.
  ''' </remarks>
  Private Function Determinant( _
      ByVal aMatrix As Double(,)) _
      As Double
    Dim myMatrix As Double(,)
    Dim myResult, mySwap, myKeep As Double
    Dim myItem, myRow, myCol, myMax As Integer

    Try
      myResult = 1
      myMax = aMatrix.GetUpperBound(0)
      myMatrix = DirectCast(aMatrix.Clone, Double(,))

      For myItem = 0 To myMax
        If myMatrix(myItem, myItem) = 0 Then
          myCol = myItem
          Do While myCol < myMax AndAlso myMatrix(myItem, myCol) = 0
            myCol = myCol + 1
          Loop

          If myMatrix(myItem, myCol) = 0 Then
            Return 0
          Else
            For myRow = myItem To myMax
              mySwap = myMatrix(myRow, myCol)
              myMatrix(myRow, myCol) = myMatrix(myRow, myItem)
              myMatrix(myRow, myItem) = mySwap
            Next myRow
          End If
          myResult = -myResult
        End If

        myKeep = myMatrix(myItem, myItem)
        myResult = myResult * myKeep
        If myItem < myMax Then
          For myRow = myItem + 1 To myMax
            For myCol = myItem + 1 To myMax
              myMatrix(myRow, myCol) = myMatrix(myRow, myCol) - _
                  myMatrix(myRow, myItem) * (myMatrix(myItem, myCol) / myKeep)
            Next myCol
          Next myRow
        End If
      Next

      Return myResult

    Catch ex As Exception
      _Signal(ExceptionAPL.Is.Domain)
    End Try
  End Function

#End Region

End Class
