﻿Imports System.CodeDom
Imports System.CodeDom.Compiler
Imports Microsoft.VisualBasic
Imports System.Text
Imports System.Reflection
Imports PLJsAPL

Public Class CompileVB

  Private thisCompiled As Object

#Region "New"

  Public Sub New(ByVal aCommand As String)
    Dim myComp As VBCodeProvider
    Dim myParms As CompilerParameters
    Dim mySource As New StringBuilder
    Dim myCompile As CompilerResults
    Dim myAsm As Assembly

    myComp = New VBCodeProvider
    myParms = New CompilerParameters
    myParms.ReferencedAssemblies.Add("System.dll")
    myParms.GenerateExecutable = False
    myParms.GenerateInMemory = True

    mySource = New StringBuilder
    mySource.AppendLine("Imports System")
    mySource.AppendLine("NameSpace PLJsNS")
    mySource.AppendLine("Public Class _Compiled")
    mySource.AppendLine( _
        "Public Function _Execute(ByVal _x As Object) As Object")
    mySource.AppendLine("Try")
    mySource.AppendLine(aCommand)
    mySource.AppendLine("Catch ex As System.Exception")
    mySource.AppendLine("Return ex")
    mySource.AppendLine("End Try")
    mySource.AppendLine("End Function")
    mySource.AppendLine("End Class")
    mySource.AppendLine("End NameSpace")

    myCompile = myComp.CompileAssemblyFromSource(myParms, mySource.ToString)
    If (myCompile.Errors.HasErrors) Then
      Dim myErrors As New StringBuilder
      Dim myError As CompilerError

      For Each myError In myCompile.Errors
        If myError.ErrorText.StartsWith("Overload resolution failed ") Then
          ExceptionAPL.Signal(ExceptionAPL.Is.Syntax)
        End If
        myErrors.AppendLine(myError.ErrorText)
      Next

      ExceptionAPL.Signal(ExceptionAPL.Is.Syntax, myErrors.ToString)
    End If

    myAsm = myCompile.CompiledAssembly
    thisCompiled = myAsm.CreateInstance("PLJsNS._Compiled")
  End Sub

#End Region

#Region "Invoke"

  Public Function Invoke( _
      ByVal ParamArray aContext As Context()) _
      As Object
    Return Invoke("_Execute", aContext)
  End Function

  Public Function Invoke( _
      ByVal aName As String, _
      ByVal ParamArray aContext As Context()) _
      As Object
    Dim myInfo As MethodInfo
    Dim myResult As Object

    myInfo = thisCompiled.GetType.GetMethod(aName)
    If myInfo Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Value)
    End If

    myResult = myInfo.Invoke(thisCompiled, aContext)
    If myResult Is Nothing Then
      Return Nothing
    ElseIf TypeOf myResult Is ExceptionAPL Then
      Throw DirectCast(myResult, ExceptionAPL)
    ElseIf TypeOf myResult Is Exception Then
      MapExceptions(DirectCast(myResult, Exception).Message)
    End If
    Return myResult
  End Function

  Private Sub MapExceptions(ByVal aMessage As String)
    Dim myParts As String()
    Dim myType As String

    If aMessage.StartsWith("Method invocation failed ") Then
      myParts = Split(aMessage, "Argument matching parameter '")
      If myParts.Length > 1 Then
        aMessage = myParts(1).Split("'"c)(0).Substring(1)
        If aMessage = "NewValue" Then
          aMessage = "attempted assignment was not a Value."
        ElseIf aMessage = "Subscript" Then
          aMessage = "subscript was not a Value."
        Else
          aMessage &= "argument is not a Value."
        End If
      End If
    ElseIf aMessage.StartsWith("Overload resolution failed because no Public '") Then
      myParts = aMessage.Split("'"c)
      If myParts.Length > 1 AndAlso myParts(1) <> "Eval" Then
        aMessage = "with " & myParts(1)
      Else
        ExceptionAPL.Signal(ExceptionAPL.Is.Syntax)
      End If
    ElseIf aMessage.StartsWith("Public member '") AndAlso _
        aMessage.EndsWith("' not found.") Then
      myParts = aMessage.Split("'"c)
      myType = myParts(myParts.Length - 2)
      aMessage = myParts(1)

      If myType = "_APL" Then
        aMessage = "_a." & aMessage
      End If
    End If

    ExceptionAPL.Signal(ExceptionAPL.Is.Domain, aMessage)
  End Sub

#End Region

End Class
