﻿Partial Class _APL

#Region "⊂ Enclose"

  Public ReadOnly Property Enclose() As Method
    Get
      Return New Method(AddressOf _Enclose, AddressOf _Enclose)
    End Get
  End Property

  Private Function _Enclose(ByVal anItem As APL) As APL
    If anItem.IsCharacter Then
      If anItem.Rank = 0 Then
        Return anItem.Clone
      ElseIf anItem.Rank = 1 Then
        Return New APL(New Object() {anItem.CharacterVector})
      Else
        Return Value(anItem.Clone)
      End If
    ElseIf anItem.Rank = 0 Then
      Dim myItem As Object = anItem.ValueVector(0)
      If TypeOf myItem Is APL OrElse TypeOf myItem Is String Then
        Return Value(anItem.Clone)
      Else
        Return anItem.Clone
      End If
    Else
      Return Value(anItem.Clone)
    End If
  End Function

  Private Function _Enclose(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Return Extended(True)
  End Function

#End Region

#Region "⊃ Disclose"

  Public ReadOnly Property Disclose() As Method
    Get
      Return New Method(AddressOf _Disclose, AddressOf _Disclose)
    End Get
  End Property

  Private Function _Disclose(ByVal aRight As APL) As APL
    Dim myValue As Object
    Dim myValues, myResult As Object()
    Dim myResults As Text.StringBuilder
    Dim myString As String
    Dim myAPL, myShape, myNewShape As APL
    Dim myHasValues, myHasScalars, myHasEnclosed As Boolean
    Dim mySize, myOffset, myRank As Integer

    If aRight.IsCharacter Then
      Return aRight.Clone

    ElseIf aRight.Rank = 0 Then
      myValue = aRight.ValueVector(0)
      If TypeOf myValue Is APL Then
        Return DirectCast(myValue, APL)
      ElseIf TypeOf myValue Is String Then
        Return New APL(DirectCast(myValue, String))
      Else
        Return aRight.Clone
      End If

    Else
      myValues = aRight.ValueVector
      If myValues.Length = 0 Then
        Return aRight.Clone
      End If

      myShape = Nothing
      myResult = Nothing
      myResults = Nothing
      For Each myValue In myValues
        If TypeOf myValue Is String Then
          myHasEnclosed = True
          myString = DirectCast(myValue, String)
          If myString.Length <> 1 Then
            If myShape Is Nothing Then
              myShape = Comma(Value(myString.Length))
              myRank = 1
            ElseIf myShape.Rank = 1 Then
              myShape = myShape(Hi, Value(myString.Length))
            Else
              ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
            End If
          Else
            myHasScalars = True
          End If
        ElseIf TypeOf myValue Is Char Then
          myHasEnclosed = True
          myHasScalars = True
        ElseIf TypeOf myValue Is APL Then
          myHasEnclosed = True
          myAPL = DirectCast(myValue, APL)
          If Not myAPL.IsCharacter Then
            myHasValues = True
          End If
          If myAPL.Rank <> 0 Then
            If myShape Is Nothing Then
              myShape = Shape(myAPL)
              myRank = myAPL.Rank
            ElseIf myRank = myAPL.Rank Then
              myShape = myShape(Hi, Shape(myAPL))
            Else
              ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
            End If
          Else
            myHasScalars = True
          End If
        Else
          myHasValues = True
          myHasScalars = True
        End If
      Next

      If Not myHasEnclosed Then
        Return aRight.Clone
      End If

      If myShape Is Nothing Then
        myNewShape = Shape(aRight)
        If myHasValues Then
          ReDim myResult(myValues.Length - 1)
          For Each myValue In myValues
            If TypeOf myValue Is APL Then
              myResult(myOffset) = DirectCast(myValue, APL).ValueVector(0)
            Else
              myResult(myOffset) = myValue
            End If
            myOffset += 1
          Next
          Return myNewShape(Shape, New APL(myResult))
        Else
          myResults = New Text.StringBuilder
          For Each myValue In myValues
            myResults.Append(myValue.ToString)
          Next
          Return myNewShape(Shape, New APL(myResults.ToString))
        End If

      Else
        If myHasScalars Then
          myShape = myShape(Hi, 1)
        End If
        myNewShape = Shape(aRight)(Comma, myShape)
      End If

      If myHasValues Then
        mySize = Times(Reduce)(myShape).IntegerIndex
        ReDim myResult(Times(Reduce)(myNewShape).IntegerIndex - 1)
        For Each myValue In myValues
          If TypeOf myValue Is APL Then
            myValues = myShape(Take, DirectCast(myValue, APL)).ValueVector
          Else
            myValues = myShape(Take, Value(myValue)).ValueVector
          End If
          Array.ConstrainedCopy(myValues, 0, myResult, myOffset, myValues.Length)
          myOffset += mySize
        Next
        Return myNewShape(Shape, New APL(myResult))

      ElseIf myShape.VectorLength = 1 Then
        mySize = myShape.IntegerIndex
        myResults = New Text.StringBuilder
        For Each myValue In myValues
          If TypeOf myValue Is Char Then
            myString = DirectCast(myValue, Char)
          ElseIf TypeOf myValue Is String Then
            myString = DirectCast(myValue, String)
          ElseIf TypeOf myValue Is APL Then
            myString = DirectCast(myValue, APL).CharacterVector
          Else
            ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
          End If
          myResults.Append(myString)
          myResults.Append(Space(mySize - myString.Length))
        Next
        Return myNewShape(Shape, New APL(myResults.ToString))

      Else
        myResults = New Text.StringBuilder
        For Each myValue In myValues
          If TypeOf myValue Is APL Then
            myAPL = DirectCast(myValue, APL)
          Else
            myAPL = New APL(DirectCast(myValue, Char))
          End If
          myResults.Append(myShape(Take, myAPL).CharacterVector)
        Next
        Return myNewShape(Shape, New APL(myResults.ToString))
      End If
    End If
  End Function

  Private Function _Disclose(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Return Extended(True)
  End Function

#End Region

#Region "⍳	Index"

  Public ReadOnly Property Index() As Method
    Get
      Return New Method(AddressOf _Index, AddressOf IndexOf)
    End Get
  End Property

  Public Function _Index(ByVal aRight As APL) As APL
    Return _Index(aRight.IntegerIndex)
  End Function

  Private Function _Index(ByVal anIndex As Integer) As APL
    Dim myIndex As Integer
    Dim myIndexes As Object()

    ReDim myIndexes(Math.Abs(anIndex) - 1)

    If anIndex >= 0 Then
      For myIndex = 0 To anIndex - 1
        myIndexes(myIndex) = myIndex
      Next

    Else
      For myIndex = 0 To myIndexes.Length - 1
        myIndexes(myIndex) = anIndex
        anIndex += 1
      Next
    End If

    Return New APL(myIndexes, False)
  End Function

#End Region

#Region "⍴	Shape,Reshape"

  Public ReadOnly Property Shape() As Method
    Get
      Return New Method(AddressOf _Shape, AddressOf Reshape)
    End Get
  End Property

  Private Function _Shape(ByVal aRight As APL) As APL
    Return New APL(UtilsShape.CopyShape(aRight.Shape), False)
  End Function

  Private Function Reshape(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Dim myNew As APL

    myNew = aRight.Clone
    myNew.Shape = aLeft.IntegerVector
    Return myNew
  End Function

#End Region

#Region ",	Ravel,Catenate"

  Public ReadOnly Property Comma() As Method
    Get
      Return New Method(AddressOf Ravel, AddressOf Catenate)
    End Get
  End Property

  Private Function Ravel( _
      ByVal anIndex As APL, _
      ByVal aRight As APL) _
      As APL
    Dim myResult As APL
    Dim myReal As Double
    Dim myAxis, myIndex, myItem As Integer
    Dim myShape, myRavel As Integer()

    If Not Array.ReferenceEquals(anIndex, _APL._Empty) Then
      myReal = anIndex.DoubleIndex
      myAxis = CType(Math.Ceiling(myReal), Integer)
      If myAxis < 0 OrElse myAxis > aRight.Rank Then
        If myReal <> myAxis AndAlso aRight.Rank = 0 Then
          Return HandleScalar(aRight)
        End If
        ExceptionAPL.Signal(ExceptionAPL.Is.Axis)
      End If
    End If

    myResult = aRight.Clone
    If myReal = myAxis Then
      myResult.Shape = New Integer() {aRight.VectorLength}
    Else
      If aRight.Rank = 0 Then
        Return HandleScalar(aRight)
      End If
      myShape = aRight.Shape
      ReDim myRavel(myShape.Length)
      For myIndex = 0 To myShape.Length
        If myIndex = myAxis Then
          myRavel(myIndex) = 1
        Else
          myRavel(myIndex) = myShape(myItem)
          myItem += 1
        End If
      Next

      myResult.Shape = myRavel
    End If

    Return myResult
  End Function

  Private Function HandleScalar(ByVal aRight As APL) As APL
    Dim myResult As APL

    myResult = aRight.Clone
    myResult.Shape = New Integer() {1, 1}
    Return myResult
  End Function

  Private Function Catenate( _
      ByVal aLeft As APL, _
      ByVal anIndex As APL, _
      ByVal aRight As APL) _
      As APL
    Return Catenate(aLeft, _
        DoubleAxis(aLeft, anIndex, aRight), _
        aRight)
  End Function

  Private Function Catenate( _
      ByVal aLeft As APL, _
      ByVal anIndex As Double, _
      ByVal aRight As APL) _
      As APL
    Dim myIndex, myWhich As Integer
    Dim myLeftShape, myRightShape As Integer()

    myIndex = CType(Math.Ceiling(anIndex), Integer)
    myLeftShape = aLeft.Shape
    myRightShape = aRight.Shape

    If myLeftShape.Length = 0 AndAlso myRightShape.Length = 0 Then
      If myIndex <> 0 Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Axis)
      End If

    Else
      If myIndex < 0 OrElse _
          myIndex > Math.Max(aLeft.Rank, aRight.Rank) Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Axis)
      End If
      myWhich = myLeftShape.Length - myRightShape.Length

      If myIndex <> anIndex Then
        If myWhich <> 0 Then
          If myLeftShape.Length = 0 Then
            myLeftShape = myRightShape
            aLeft.Shape = myLeftShape
          ElseIf myRightShape.Length = 0 Then
            myRightShape = myLeftShape
            aRight.Shape = myRightShape
          Else
            ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
          End If
        ElseIf Not UtilsShape.SameShape(myLeftShape, myRightShape) Then
          ExceptionAPL.Signal(ExceptionAPL.Is.Length)
        End If

        myLeftShape = UtilsShape.InsertOne(myIndex, myLeftShape)
        myRightShape = UtilsShape.InsertOne(myIndex, myRightShape)

      Else
        If myLeftShape.Length = 0 OrElse _
            myRightShape.Length = 0 Then
          ' Scalars here are always OK!

        ElseIf myWhich = 0 Then
          ' They are the same rank, ignore myIndex for both
          SameShape(UtilsShape.Remove(myIndex, myLeftShape), _
                    UtilsShape.Remove(myIndex, myRightShape))

        ElseIf myWhich = 1 Then
          ' aLeft is one rank larger, ignore its myIndex
          SameShape(UtilsShape.Remove(myIndex, myLeftShape), myRightShape)
          myRightShape = UtilsShape.InsertOne(myIndex, myRightShape)

        ElseIf myWhich = -1 Then
          ' aRight is one rank larger, ignore its myIndex
          SameShape(myLeftShape, UtilsShape.Remove(myIndex, myRightShape))
          myLeftShape = UtilsShape.InsertOne(myIndex, myLeftShape)

        Else
          ExceptionAPL.Signal(ExceptionAPL.Is.Axis)
        End If
      End If
    End If

    If aLeft.IsCharacter AndAlso aRight.IsCharacter Then
      Return Catenate(myLeftShape, aLeft.CharacterVector, _
          myIndex, myRightShape, aRight.CharacterVector)
    
    Else
      Return Catenate(myLeftShape, aLeft.ValueVector, _
          myIndex, myRightShape, aRight.ValueVector)
    End If
  End Function

#Region "Catenate for ValueVector and String"

  Private Function Catenate( _
      ByVal aLeftShape As Integer(), _
      ByVal aLeft As Object(), _
      ByVal anIndex As Integer, _
      ByVal aRightShape As Integer(), _
      ByVal aRight As Object()) _
      As APL
    Dim myIndex, myItem As Integer
    Dim myValues As Object()
    Dim myValue As Object
    Dim myLeft, myRight As Indexing
    Dim myShape As Integer()
    Dim myResult As APL

    If aLeftShape.Length < 2 AndAlso aRightShape.Length < 2 Then
      If anIndex <> 0 Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Index)
      End If

      ReDim myValues(aLeft.Length + aRight.Length - 1)
      For myIndex = 0 To aLeft.Length - 1
        myValues(myIndex) = aLeft(myIndex)
      Next

      myItem = myIndex
      For myIndex = 0 To aRight.Length - 1
        myValues(myItem) = aRight(myIndex)
        myItem += 1
      Next

      Return New APL(myValues, False)

    Else
      myShape = CatShape(aLeftShape, anIndex, aRightShape)
      ReDim myValues(UtilsShape.TimesReduce(myShape) - 1)
      myLeft = New Indexing(aLeftShape)
      myRight = New Indexing(aRightShape)
      myLeft.ReCat(anIndex, myRight)

      If aLeft.Length = 1 Then
        myValue = aLeft(0)
        For myIndex = 0 To UtilsShape.TimesReduce(aLeftShape) - 1
          myValues(myLeft.Next) = myValue
        Next

      Else
        For myIndex = 0 To aLeft.Length - 1
          myValues(myLeft.Next) = aLeft(myIndex)
        Next
      End If

      If aRight.Length = 1 Then
        myValue = aRight(0)
        For myIndex = 0 To UtilsShape.TimesReduce(aRightShape) - 1
          myValues(myRight.Next) = myValue
        Next

      Else
        For myIndex = 0 To aRight.Length - 1
          myValues(myRight.Next) = aRight(myIndex)
        Next
      End If

      myResult = New APL(myValues)
      myResult.Shape = myShape
      Return myResult
    End If
  End Function

  Private Function Catenate( _
      ByVal aLeftShape As Integer(), _
      ByVal aLeft As String, _
      ByVal anIndex As Integer, _
      ByVal aRightShape As Integer(), _
      ByVal aRight As String) _
      As APL
    Dim myIndex As Integer
    Dim myValues As Char()
    Dim myValue As Char
    Dim myRight, myLeft As Indexing
    Dim myShape As Integer()
    Dim myResult As APL

    If aLeftShape.Length < 2 AndAlso aRightShape.Length < 2 Then
      If anIndex <> 0 Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Index)
      End If
      Return New APL(aLeft & aRight, False)

    Else
      myShape = CatShape(aLeftShape, anIndex, aRightShape)
      ReDim myValues(UtilsShape.TimesReduce(myShape) - 1)
      myLeft = New Indexing(aLeftShape)
      myRight = New Indexing(aRightShape)
      myLeft.ReCat(anIndex, myRight)

      If aLeft.Length = 1 Then
        myValue = aLeft(0)
        For myIndex = 0 To UtilsShape.TimesReduce(aLeftShape) - 1
          myValues(myLeft.Next) = myValue
        Next

      Else
        For myIndex = 0 To aLeft.Length - 1
          myValues(myLeft.Next) = aLeft(myIndex)
        Next
      End If

      If aRight.Length = 1 Then
        myValue = aRight(0)
        For myIndex = 0 To UtilsShape.TimesReduce(aRightShape) - 1
          myValues(myRight.Next) = myValue
        Next

      Else
        For myIndex = 0 To aRight.Length - 1
          myValues(myRight.Next) = aRight(myIndex)
        Next
      End If

      myResult = New APL(myValues)
      myResult.Shape = myShape
      Return myResult
    End If
  End Function

#End Region

#Region "CatShape and SameShape"

  Private Function CatShape( _
      ByRef aLeftShape As Integer(), _
      ByVal anIndex As Integer, _
      ByRef aRightShape As Integer()) _
      As Integer()
    Dim myResult As Integer()

    If aLeftShape.Length = 0 Then
      aLeftShape = DirectCast(aRightShape.Clone, Integer())
      aLeftShape(anIndex) = 1
    ElseIf aRightShape.Length = 0 Then
      aRightShape = DirectCast(aLeftShape.Clone, Integer())
      aRightShape(anIndex) = 1
    End If

    myResult = DirectCast(aLeftShape.Clone, Integer())
    myResult(anIndex) += aRightShape(anIndex)
    Return myResult
  End Function

  Private Sub SameShape( _
      ByVal aLeft As Integer(), _
      ByVal aRight As Integer())
    If Not UtilsShape.SameShape(aLeft, aRight) Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Length)
    End If
  End Sub

#End Region

#End Region

#Region "DoubleAxis IntegerAxis"

  Private Function DoubleAxis( _
    ByVal aLeft As APL, _
    ByVal anIndex As APL, _
    ByVal aRight As APL) _
    As Double
    Dim myLeft, myRight As Integer

    If Array.ReferenceEquals(anIndex, _Empty) Then
      myLeft = aLeft.Rank
      myRight = aRight.Rank
      If myLeft > myRight Then myRight = myLeft
      If myRight <> 0 Then myRight -= 1
      Return myRight
    Else
      Return anIndex.DoubleIndex
    End If
  End Function

  Private Function IntegerAxis( _
    ByVal anIndex As APL, _
    ByVal aRight As APL) _
    As Integer
    Dim myRight As Integer

    If Array.ReferenceEquals(anIndex, _Empty) Then
      myRight = aRight.Rank
      If myRight <> 0 Then myRight -= 1
      Return myRight
    Else
      Return anIndex.IntegerIndex
    End If
  End Function

#End Region

#Region "⌽	Reverse,Pivot"

  Public ReadOnly Property Pivot() As Method
    Get
      Return New Method(AddressOf _Reverse, AddressOf _Pivot)
    End Get
  End Property

  Private Function _Reverse( _
      ByVal anIndex As APL, _
      ByVal aRight As APL) _
      As APL
    Return _Reverse( _
        IntegerAxis(anIndex, aRight), _
        aRight)
  End Function

  Private Function _Reverse( _
      ByVal anIndex As Integer, _
      ByVal aRight As APL) _
      As APL
    Dim myIndex As Integer
    Dim myIndexing As Indexing
    Dim myValues, myRightValues As Object()
    Dim myRightChars As String
    Dim myChars As Char()
    Dim myResult As APL

    If aRight.Rank = 0 Then
      Return aRight.Clone
    End If
    myIndexing = New Indexing(aRight.Shape)
    myIndexing.Reverse(anIndex)

    If aRight.IsCharacter Then
      myRightChars = aRight.CharacterVector
      ReDim myChars(myRightChars.Length - 1)
      For myIndex = 0 To myChars.Length - 1
        myChars(myIndex) = myRightChars(myIndexing.Next)
      Next

      myResult = New APL(myChars)
    Else
      myRightValues = aRight.ValueVector
      ReDim myValues(myRightValues.Length - 1)
      For myIndex = 0 To myValues.Length - 1
        myValues(myIndex) = myRightValues(myIndexing.Next)
      Next
      myResult = New APL(myValues)
    End If

    myResult.Shape = aRight.Shape
    Return myResult
  End Function

  Private Function _Pivot( _
      ByVal aLeft As APL, _
      ByVal anIndex As APL, _
      ByVal aRight As APL) _
      As APL
    Return _Pivot(aLeft, _
        IntegerAxis(anIndex, aRight), _
        aRight)
  End Function

  Private Function _Pivot( _
      ByVal aLeft As APL, _
      ByVal anAxis As Integer, _
      ByVal aRight As APL) _
      As APL
    Dim myRank, myAxis, myIndex As Integer
    Dim myTran As Integer()
    Dim myResult As APL

    myRank = aRight.Rank
    If aLeft.VectorLength <> 1 Then
      If aLeft.Rank = myRank - 1 Then
        If Not UtilsShape.SameShape(aLeft.Shape, _
            UtilsShape.Remove(anAxis, aRight.Shape)) Then
          ExceptionAPL.Signal(ExceptionAPL.Is.Length)
        End If

      Else
        ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
      End If
    End If

    If aRight.Rank = 0 Then Return aRight.Clone

    If myRank < 3 OrElse anAxis = 0 OrElse anAxis = myRank - 1 Then
      Return _PivotSimple(aLeft, anAxis, aRight)
    Else
      ' N.B. This code is needed because 
      '   Indexing.RePivot
      ' only supports ⊖ and ⌽
      ReDim myTran(myRank - 1)

      myTran(0) = anAxis
      For myIndex = 0 To myRank - 1
        If myIndex <> anAxis Then
          myAxis += 1
          myTran(myAxis) = myIndex
        End If
      Next
      myResult = _Transpose(myTran, aRight)

      myResult = _PivotSimple(aLeft, 0, myResult)

      myTran(anAxis) = 0
      myAxis = 0
      For myIndex = 0 To myRank - 1
        If myIndex <> anAxis Then
          myAxis += 1
          myTran(myIndex) = myAxis
        End If
      Next
      Return _Transpose(myTran, myResult)
    End If
  End Function

  Private Function _PivotSimple( _
      ByVal aLeft As APL, _
      ByVal anIndex As Integer, _
      ByVal aRight As APL) _
      As APL
    Dim myIndex As Integer
    Dim myIndexing As Indexing
    Dim myValues, myRightValues As Object()
    Dim myRightChars As String
    Dim myChars As Char()
    Dim myShape As Integer()
    Dim myResult As APL

    myShape = aRight.Shape
    myIndexing = New Indexing(myShape)
    myIndexing.RePivot(anIndex, aLeft.SubscriptVector)

    If aRight.IsCharacter Then
      myRightChars = aRight.CharacterVector
      ReDim myChars(myRightChars.Length - 1)
      For myIndex = 0 To myChars.Length - 1
        myChars(myIndex) = myRightChars(myIndexing.Next)
      Next
      myResult = New APL(myChars)

    Else
      myRightValues = aRight.ValueVector
      ReDim myValues(myRightValues.Length - 1)
      For myIndex = 0 To myValues.Length - 1
        myValues(myIndex) = myRightValues(myIndexing.Next) ' Mod myRightValues.Length)
      Next
      myResult = New APL(myValues)
    End If

    myResult.Shape = aRight.Shape
    Return myResult
  End Function

#End Region

#Region "⍉	Transpose,Transpose"

  Public ReadOnly Property Transpose() As Method
    Get
      Return New Method(AddressOf _Transpose, AddressOf _Transpose)
    End Get
  End Property

  Private Function _Transpose( _
      ByVal aRight As APL) _
      As APL
    Dim myLeft As Integer()
    Dim myIndex, mySize As Integer

    mySize = aRight.Rank - 1
    If mySize = -1 Then
      Return aRight.Clone
    End If
    ReDim myLeft(mySize)
    For myIndex = 0 To myLeft.Length - 1
      myLeft(myIndex) = mySize - myIndex
    Next
    Return _Transpose(myLeft, aRight)
  End Function

  Private Function _Transpose( _
      ByVal aLeft As APL, _
      ByVal aRight As APL) _
      As APL
    Return _Transpose(aLeft.IntegerVector, aRight)
  End Function

  Private Function _Transpose( _
      ByVal aLeft As Integer(), _
      ByVal aRight As APL) _
      As APL
    Dim myIndexing As Indexing
    Dim myResult As APL

    If aLeft.Length <> aRight.Rank Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Length)
    ElseIf aLeft.Length < 2 Then
      If aLeft.Length = 1 AndAlso aLeft(0) <> 0 Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End If
      Return aRight.Clone
    End If

    myIndexing = New Indexing(aRight.Shape)
    myIndexing.RePose(aLeft)

    If aRight.IsCharacter Then
      myResult = _Transpose(myIndexing, aRight.CharacterVector)
    Else
      myResult = _Transpose(myIndexing, aRight.ValueVector)
    End If

    myResult.Shape = myIndexing.ResultShape
    Return myResult
  End Function

#Region "Transpose ValueVector and CharacterVector"

  Private Function _Transpose( _
      ByVal anIndexing As Indexing, _
      ByVal aRight As Object()) _
      As APL
    Dim myIndex As Integer
    Dim myResult As Object()

    ReDim myResult(UtilsShape.TimesReduce(anIndexing.ResultShape) - 1)
    If myResult.Length <> 0 Then
      For myIndex = 0 To myResult.Length - 1
        myResult(myIndex) = aRight(anIndexing.Next)
      Next
    End If

    Return New APL(myResult)
  End Function

  Private Function _Transpose( _
      ByVal anIndexing As Indexing, _
      ByVal aRight As String) _
      As APL
    Dim myIndex As Integer
    Dim myResult As Char()

    ReDim myResult(UtilsShape.TimesReduce(anIndexing.ResultShape) - 1)
    If myResult.Length <> 0 Then
      For myIndex = 0 To myResult.Length - 1
        myResult(myIndex) = aRight(anIndexing.Next)
      Next
    End If

    Return New APL(myResult)
  End Function

#End Region

#End Region

#Region "↑	First,Take"

  Public ReadOnly Property Take() As Method
    Get
      Return New Method(AddressOf _First, AddressOf _Take)
    End Get
  End Property

  ''' <summary>
  ''' ⊃''⍴1↑,⍵
  ''' </summary>
  Private Function _First(ByVal aRight As APL) As APL
    Dim myValue As Object

    Extended(False)

    If aRight.VectorLength <> 0 Then
      If aRight.IsCharacter Then
        Return Value(aRight.CharacterVector(0))
      Else
        myValue = aRight.ValueVector(0)
        If TypeOf myValue Is APL Then
          Return DirectCast(myValue, APL)
        ElseIf TypeOf myValue Is String Then
          Return New APL(DirectCast(myValue, String))
        Else
          Return Value(myValue)
        End If
      End If

    Else
      If aRight.IsCharacter Then
        Return New APL(" ")
      Else
        Return Value(0)
      End If
    End If
  End Function

  Private Function _Take(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Dim myTakes, myShape As Integer()

    If ReturnRight(aLeft, aRight) Then
      Return aRight.Clone
    End If

    myTakes = aLeft.IntegerVector
    myShape = TakeOnes(myTakes, aRight)

    If aRight.IsCharacter Then
      If myTakes.Length = 1 Then
        Return TakeVector(myTakes(0), aRight.CharacterVector)
      Else
        Return TakeArray(myTakes, myShape, aRight.CharacterVector)
      End If

    Else
      Return TakeArray(myTakes, myShape, aRight.ValueVector)
    End If
  End Function

  Private Function TakeOnes(ByVal aTakes As Integer(), ByVal aRight As APL) As Integer()
    Dim myResult As Integer()
    Dim myIndex As Integer

    myResult = aRight.Shape
    If myResult.Length = 0 Then
      ReDim myResult(aTakes.Length - 1)
      For myIndex = 0 To myResult.Length - 1
        myResult(myIndex) = 1
      Next

    ElseIf aTakes.Length <> myResult.Length Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Length)
    End If

    Return myResult
  End Function

#Region "TakeArray"

  Private Function TakeArray( _
      ByVal aTakes As Integer(), _
      ByVal aShape As Integer(), _
      ByVal aValues As String) _
      As APL
    Dim myIndexing As Indexing
    Dim myIndex, myItem As Integer
    Dim myValues As Char()
    Dim myResult As APL

    myIndexing = New Indexing(aShape)
    myIndexing.ReTake(aTakes)

    ReDim myValues(UtilsShape.TimesReduce(myIndexing.ResultShape) - 1)
    For myIndex = 0 To myValues.Length - 1
      myItem = myIndexing.Next
      If myItem < 0 Then
        myValues(myIndex) = " "c

      Else
        myValues(myIndex) = aValues(myItem)
      End If
    Next

    myResult = New APL(myValues)
    myResult.Shape = myIndexing.ResultShape
    Return myResult
  End Function

  Private Function TakeArray( _
      ByVal aTakes As Integer(), _
      ByVal aShape As Integer(), _
      ByVal aValues As Object()) _
      As APL
    Dim myIndexing As Indexing
    Dim myIndex, myItem As Integer
    Dim myValues As Object()
    Dim myValue As Object
    Dim myDefault As Object
    Dim myResult As APL

    If aValues.Length = 0 Then
      myDefault = 0
    Else
      myValue = aValues(0)
      If TypeOf myValue Is String OrElse TypeOf myValue Is Char OrElse _
          (TypeOf myValue Is APL AndAlso DirectCast(myValue, APL).IsCharacter) Then
        myDefault = " "c
      Else
        myDefault = 0
      End If
    End If
    myIndexing = New Indexing(aShape)
    myIndexing.ReTake(aTakes)

    ReDim myValues(UtilsShape.TimesReduce(myIndexing.ResultShape) - 1)
    For myIndex = 0 To myValues.Length - 1
      myItem = myIndexing.Next
      If myItem < 0 Then
        myValues(myIndex) = myDefault

      Else
        myValues(myIndex) = aValues(myItem)
      End If
    Next

    myResult = New APL(myValues)
    myResult.Shape = myIndexing.ResultShape
    Return myResult
  End Function

#End Region

#Region "TakeVector"

  Private Function TakeVector( _
      ByVal aTake As Integer, _
      ByVal aRight As String) _
      As APL
    Dim myResult As String

    If aTake > 0 Then
      If aTake < aRight.Length Then
        myResult = aRight.Substring(0, aTake)
      Else
        myResult = aRight & Space(aTake - aRight.Length)
      End If
      Return New APL(myResult, False)

    ElseIf aTake < 0 Then
      aTake = Math.Abs(aTake)
      If aTake <= aRight.Length Then
        myResult = aRight.Substring(aRight.Length - aTake)
      Else
        myResult = Space(aTake - aRight.Length) & aRight
      End If
      Return New APL(myResult, False)

    Else
      Return New APL("")
    End If
  End Function

#End Region

#End Region

#Region "ReturnRight"

  Private Function ReturnRight(ByVal aLeft As APL, ByVal aRight As APL) As Boolean
    If aLeft.Rank > 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If
    If aLeft.VectorLength = 0 Then
      If aRight.Rank = 0 Then
        Return True
      Else
        ExceptionAPL.Signal(ExceptionAPL.Is.Length)
      End If
    End If
  End Function

#End Region

#Region "↓	,Drop"

  Public ReadOnly Property Drop() As Method
    Get
      Return New Method(Nothing, AddressOf _Drop)
    End Get
  End Property

  Private Function _Drop(ByVal aLeft As APL, ByVal aRight As APL) As APL
    If ReturnRight(aLeft, aRight) Then
      Return aRight.Clone
    End If

    If aRight.IsCharacter Then
      If aRight.Rank < 2 Then
        Return DropVector(aLeft.IntegerIndex, aRight.CharacterVector)
      Else
        Return DropArray(aLeft.IntegerVector, aRight.Shape, aRight.CharacterVector)
      End If

    Else
      If aRight.Rank < 2 Then
        Return DropVector(aLeft.IntegerIndex, aRight.ValueVector)
      Else
        Return DropArray(aLeft.IntegerVector, aRight.Shape, aRight.ValueVector)
      End If
    End If
  End Function

#Region "DropArray"

  Private Function DropArray( _
      ByVal aDrops As Integer(), _
      ByVal aShape As Integer(), _
      ByVal aValues As String) _
      As APL
    Dim myIndexing As Indexing
    Dim myIndex, myItem As Integer
    Dim myValues As Char()
    Dim myResult As APL

    myIndexing = New Indexing(aShape)
    myIndexing.ReDrop(aDrops)

    ReDim myValues(UtilsShape.TimesReduce(myIndexing.ResultShape))
    For myIndex = 0 To myValues.Length - 1
      myItem = myIndexing.Next
      If myItem < 0 Then
        myValues(myIndex) = " "c

      Else
        myValues(myIndex) = aValues(myItem)
      End If
    Next

    myResult = New APL(myValues)
    myResult.Shape = myIndexing.ResultShape
    Return myResult
  End Function

  Private Function DropArray( _
      ByVal aDrops As Integer(), _
      ByVal aShape As Integer(), _
      ByVal aValues As Object()) _
      As APL
    Dim myIndexing As Indexing
    Dim myIndex, myItem As Integer
    Dim myValues As Object()
    Dim myResult As APL

    myIndexing = New Indexing(aShape)
    myIndexing.ReDrop(aDrops)

    ReDim myValues(UtilsShape.TimesReduce(myIndexing.ResultShape))
    For myIndex = 0 To myValues.Length - 1
      myItem = myIndexing.Next
      If myItem < 0 Then
        myValues(myIndex) = 0

      Else
        myValues(myIndex) = aValues(myItem)
      End If
    Next

    myResult = New APL(myValues)
    myResult.Shape = myIndexing.ResultShape
    Return myResult
  End Function

#End Region

#Region "DropVector"

  Private Function DropVector(ByVal aDrop As Integer, ByVal aRight As String) As APL
    Dim myResult As String

    If aDrop > 0 Then
      If aDrop < aRight.Length Then
        myResult = aRight.Substring(aDrop)
      Else
        myResult = ""
      End If
      Return New APL(myResult, False)

    ElseIf aDrop < 0 Then
      aDrop = Math.Abs(aDrop)
      If aDrop < aRight.Length Then
        myResult = aRight.Substring(0, _
            aRight.Length - aDrop)
      Else
        myResult = ""
      End If
      Return New APL(myResult, False)

    Else
      Return New APL(aRight, False)
    End If
  End Function

  Private Function DropVector(ByVal aDrop As Integer, ByVal aRight As Object()) As APL
    Dim myResult As Object()
    Dim myIndex, myItem As Integer

    If aDrop > 0 Then
      ReDim myResult(Math.Max(-1, aRight.Length - aDrop - 1))
      For myIndex = aDrop To aRight.Length - 1
        myResult(myItem) = aRight(myIndex)
        myItem += 1
      Next
      Return New APL(myResult, False)

    ElseIf aDrop < 0 Then
      aDrop = Math.Abs(aDrop)

      ReDim Preserve aRight(Math.Max(-1, aRight.Length - aDrop - 1))
      Return New APL(aRight, False)

    Else
      Return New APL(aRight, False)
    End If
  End Function

#End Region

#End Region

#Region "⌷ ,Sub"

  Public ReadOnly Property [Sub]() As Method
    Get
      Return New Method(Nothing, AddressOf _Sub)
    End Get
  End Property

  Private Function _Sub(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Dim mySub As APL()
    Dim myIndex As Integer
    Dim myItems As Object()

    myIndex = aLeft.VectorLength
    If myIndex <> aRight.Rank OrElse aLeft.Rank > 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If
    If myIndex = 0 Then
      Return aRight.Clone
    End If

    myItems = aLeft.ValueVector
    ReDim mySub(myItems.Length - 1)

    For myIndex = 0 To myItems.Length - 1
      If TypeOf myItems(myIndex) Is APL Then
        mySub(myIndex) = DirectCast(myItems(myIndex), APL)
      Else
        mySub(myIndex) = New APL(New Object() {myItems(myIndex)})
      End If
    Next
    Return aRight.Sub(mySub)
  End Function

#End Region

#Region "⍋	GradeUp,GradeUp"

  Public ReadOnly Property GradeUp() As Method
    Get
      Return New Method(AddressOf _GradeUp, AddressOf _GradeUp)
    End Get
  End Property

  Private Function _GradeUp(ByVal aValues As APL) As APL
    Return Grade(True, aValues)
  End Function

  Private Function _GradeUp(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Return Grades(True, aLeft, aRight)
  End Function

#End Region

#Region "⍒	GradeDown,GradeDown"

  Public ReadOnly Property GradeDown() As Method
    Get
      Return New Method(AddressOf _GradeDown, AddressOf _GradeDown)
    End Get
  End Property

  Private Function _GradeDown(ByVal aValues As APL) As APL
    Return Grade(False, aValues)
  End Function

  Private Function _GradeDown(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Return Grades(False, aLeft, aRight)
  End Function

#End Region

#Region "⊤	,Encode"

  Public ReadOnly Property Encode() As Method
    Get
      Return New Method(Nothing, AddressOf _Encode)
    End Get
  End Property

  Private Function _Encode(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Dim myReTran As Integer()
    Dim myIndex, myItem As Integer
    Dim myResult As APL

    If aLeft.IsCharacter OrElse aRight.IsCharacter Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If

    myResult = Encoder(aLeft, aRight)
    If myResult.Rank < 2 Then
      Return myResult
    End If

    ReDim myReTran(myResult.Rank - 1)
    For myItem = 1 To myReTran.Length - 1
      myReTran(myIndex) = myItem
      myIndex += 1
    Next

    Return _Transpose(myReTran, myResult)
  End Function

  Public ReadOnly Property Encoder() As Method
    Get
      Return New Method(Nothing, AddressOf _Encoder)
    End Get
  End Property

  Private Function _Encoder(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Dim myCodes, myResults, myRight As Object()
    Dim myItem As Object
    Dim myCodesI As Integer()
    Dim myCodesD As Double()
    Dim myIndex, myOffset, mySize As Integer
    Dim myResult As APL

    If aLeft.IsCharacter OrElse aRight.IsCharacter Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If

    myCodes = aLeft.ValueVector
    mySize = myCodes.Length
    myRight = aRight.ValueVector
    ReDim myResults(myRight.Length * myCodes.Length - 1)

    ReDim myCodesD(myCodes.Length - 1)
    For myIndex = 0 To myCodes.Length - 1
      myCodesD(myIndex) = CDbl(myCodes(myIndex))
    Next

    If AllInteger(myCodes) Then
      ReDim myCodesI(myCodes.Length - 1)
      For myIndex = 0 To myCodes.Length - 1
        myCodesI(myIndex) = DirectCast(myCodes(myIndex), Integer)
      Next

      For myIndex = 0 To myRight.Length - 1
        myItem = myRight(myIndex)
        If TypeOf myItem Is Integer Then
          _Encoder(myResults, myOffset, myCodesI, DirectCast(myItem, Integer))
        Else
          _Encoder(myResults, myOffset, myCodesD, CDbl(myItem))
        End If
        myOffset += mySize
      Next

    Else
      For myIndex = 0 To myRight.Length - 1
        _Encoder(myResults, myOffset, myCodesD, CDbl(myRight(myIndex)))
        myOffset += mySize
      Next
    End If

    myResult = New APL(myResults)
    myResult.Shape = UtilsShape.Catenate(aRight.Shape, aLeft.Shape)
    Return myResult
  End Function

  Private Sub _Encoder( _
      ByVal aResult As Object(), _
      ByVal anOffset As Integer, _
      ByVal aCodes As Integer(), _
      ByVal aNext As Integer)
    Dim myCode, myIndex, myCodesIndex, myRest As Integer

    myIndex = anOffset + aCodes.Length - 1
    For myCodesIndex = aCodes.Length - 1 To 0 Step -1
      myCode = aCodes(myCodesIndex)
      If myCode = 0 Then
        aResult(myIndex) = aNext
        For myRest = myCodesIndex - 1 To 0 Step -1
          myIndex -= 1
          aResult(myIndex) = 0
        Next
        Return

      Else
        aResult(myIndex) = _Residue(myCode, aNext)
        myIndex -= 1
        If aNext < 0 Then
          aNext -= myCode
        End If
        aNext \= myCode
      End If
    Next
  End Sub

  Private Sub _Encoder( _
      ByVal aResult As Object(), _
      ByVal anOffset As Integer, _
      ByVal aCodes As Double(), _
      ByVal aNext As Double)
    Dim myIndex, myCodesIndex, myRest As Integer
    Dim myCode As Double

    myIndex = anOffset + aCodes.Length - 1
    For myCodesIndex = aCodes.Length - 1 To 0 Step -1
      myCode = aCodes(myCodesIndex)
      If myCode = 0 Then
        aResult(myIndex) = aNext
        For myRest = myCodesIndex - 1 To 0 Step -1
          myIndex -= 1
          aResult(myIndex) = 0
        Next
        Return

      Else
        aResult(myIndex) = _Residue(myCode, aNext)
        myIndex -= 1
        If aNext < 0 Then
          aNext -= myCode
        End If
        aNext = Fix(aNext / myCode)
      End If
    Next
  End Sub

  Private Function AllInteger(ByVal aCodes As Object()) As Boolean
    Dim myItem As Object

    For Each myItem In aCodes
      If Not TypeOf myItem Is Integer Then
        Return False
      End If
    Next

    Return True
  End Function

#End Region

#Region "⊥	,Decode"

  Public ReadOnly Property Decode() As Method
    Get
      Return New Method(Nothing, AddressOf _Decode)
    End Get
  End Property

  Private Function _Decode( _
      ByVal aLeft As APL, _
      ByVal aRight As APL) _
      As APL
    Dim mySize As Integer

    mySize = 1
    If aRight.Rank > 0 Then
      mySize = aRight.Shape(0)
    End If
    Dim myDecode As APL
    myDecode = New APL(UtilsStrict.Decoder(aLeft, mySize))
    myDecode = myDecode(Plus(Dot, Times), aRight)
    Return myDecode
  End Function

  Public ReadOnly Property Decoder() As Method
    Get
      Return New Method(Nothing, AddressOf _Decoder)
    End Get
  End Property

  Private Function _Decoder( _
      ByVal aLeft As APL, _
      ByVal aRight As APL) _
      As APL
    Dim mySize As Integer

    mySize = 1
    If aRight.Rank > 0 Then
      mySize = aRight.Shape(aRight.Rank - 1)
    End If
    Return aRight(Plus(Dot, Times), _
        New APL(UtilsStrict.Decoder(aLeft, mySize)))
  End Function

#End Region

#Region "⍎	Execute [,Context]"

#Region "Execute with default Context"

  Public ReadOnly Property Execute() As Method
    Get
      Return New Method(AddressOf _Execute, Nothing)
    End Get
  End Property

  ''' <summary>
  ''' Execute an expession without context
  ''' </summary>
  Private Function _Execute(ByVal aCommand As APL) As APL
    If aCommand.Rank > 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If
    If Not aCommand.IsCharacter Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If
    Return Executes(aCommand.CharacterVector, thisContext)
  End Function

#End Region

#Region "Executes with provided Context"

  ''' <summary>
  ''' Executes an expession in context
  ''' </summary>
  ''' <param name="aCommand">
  ''' A string expression to evaluate
  ''' </param>
  ''' <returns>An APL result of the evaluated command</returns>
  Public Function Executes( _
      ByVal aCommand As String, _
      ByVal aContext As Context) _
      As APL
    Dim myResult As Object

    myResult = _Executes(aCommand, aContext)
    If myResult Is Nothing Then
      Return Nothing
    ElseIf TypeOf myResult Is APL Then
      Return DirectCast(myResult, APL)
    ElseIf TypeOf myResult Is String Then
      Return New APL(DirectCast(myResult, String))
    ElseIf TypeOf myResult Is Char Then
      Return New APL(myResult.ToString)
    Else
      Return Value(myResult)
    End If
  End Function

#End Region

#Region "_Executes"

  Private thisCompile As Compile
  Private Function _Executes( _
      ByVal aCommand As String, _
      ByVal aContext As Context) _
      As Object
    If thisCompile Is Nothing Then
      thisCompile = New Compile
    End If
    Return thisCompile.Execute(aCommand, aContext)
  End Function

#End Region

#Region "Context and ExecuteContext"

  Private thisContext As Context
  Public ReadOnly Property Context() As Context
    Get
      Return thisContext
    End Get
  End Property

  ''' <summary>
  ''' Only used by WorkSpace to establish thisContext
  ''' </summary>
  Friend WriteOnly Property ExecuteContext() As Context
    Set(ByVal aValue As Context)
      thisContext = aValue
    End Set
  End Property

#End Region

#End Region

#Region "⍕	Display,Format"

  Public ReadOnly Property Format() As Method
    Get
      Return New Method(AddressOf _Display, AddressOf _Format)
    End Get
  End Property

  ''' <summary>
  ''' Turn a Value into a character array
  ''' </summary>
  ''' <param name="aRight"></param>
  ''' <returns></returns>
  ''' <remarks></remarks>
  Friend Shared Function _Display(ByVal aRight As APL) As APL
    Dim myValues As Object()
    Dim myValue As Object
    Dim myResults, myParts As String()
    Dim myPart As String
    Dim mySize, myDecimal, myChars, myShape As Integer()
    Dim myIndex, myCol, myCols As Integer
    Dim myPrev As Boolean
    Dim myResult As APL
    Dim myRank As Integer

    If aRight.IsCharacter Then
      Return aRight
    End If

    myShape = aRight.Shape
    myValues = aRight.ValueVector
    ReDim myResults(myValues.Length - 1)

    If myResults.Length = 0 Then
      Return New APL("")
    End If

    If myShape.Length < 2 Then
      myPart = ""
      For myIndex = 0 To myValues.Length - 1
        myValue = myValues(myIndex)
        If myValue IsNot Nothing Then
          If TypeOf myValue Is APL Then
            myResult = DirectCast(myValue, APL)
            If myResult.Rank = 0 Then
              myPart = myResult.ToString
              myPrev = True

            ElseIf myResult.Rank = 1 Then
              myPart = " " & myResult.ToString
              myPrev = True

            Else
              If myPrev Then
                myPrev = False
                myPart = ControlChars.NewLine
              Else
                myPart = ControlChars.Back
              End If
              myPart &= ControlChars.NewLine & myResult.ToString & _
                   ControlChars.NewLine & ControlChars.NewLine
            End If
            myResults(myIndex) = myPart
          ElseIf TypeOf myValue Is String OrElse TypeOf myValue Is Char Then
            myResults(myIndex) = myValue.ToString
          Else
            If myPart.StartsWith(" ") Then
              myResults(myIndex) = " " & RepairSigns(myValue.ToString)
              myPart = ""
            Else
              myResults(myIndex) = RepairSigns(myValue.ToString)
            End If
            myPrev = True
          End If
        Else
            myResults(myIndex) = "Nothing"
            myPrev = True
          End If
      Next
      Return New APL(Join(myResults, " ").Replace(" " & ControlChars.Back, ""))

    Else
      myCols = myShape(myShape.Length - 1)
      ReDim mySize(myCols - 1)
      ReDim myDecimal(myCols - 1)
      ReDim myChars(myCols - 1)

      ' Format each item
      ' and remember how large each column was
      For myIndex = 0 To myValues.Length - 1
        myValue = myValues(myIndex)
        If myValue IsNot Nothing Then
          If TypeOf myValue Is APL Then
            myRank = DirectCast(myValue, APL).Rank
            If myRank < 2 Then
              myPart = myValue.ToString
              myParts = New String() {myPart, ""}
            Else
              myPart = "'" & myRank.ToString & "=⍴⍴"
            End If
          ElseIf TypeOf myValue Is String Then
            myPart = "'" & DirectCast(myValue, String)
          ElseIf TypeOf myValue Is Char Then
            myPart = "'" & DirectCast(myValue, Char)
          Else
            myPart = RepairSigns(myValue.ToString)
            myParts = myPart.Split("."c)
          End If
        Else
          myPart = "'Nothing"
        End If

        myResults(myIndex) = myPart
        If myPart.StartsWith("'") Then
          myChars(myCol) = Math.Max(myChars(myCol), myPart.Length - 1)
        Else
          mySize(myCol) = Math.Max(mySize(myCol), myParts(0).Length)
          If myParts.Length = 2 Then
            myDecimal(myCol) = Math.Max(myDecimal(myCol), myParts(1).Length)
          End If
        End If
        myCol = (myCol + 1) Mod myCols
      Next

      ' Calculate the real size and shape
      myCol = 0
      For myIndex = 0 To myCols - 1
        If myDecimal(myIndex) <> 0 Then
          mySize(myIndex) += myDecimal(myIndex) + 1
        End If
        mySize(myIndex) = Math.Max(mySize(myIndex), myChars(myIndex))
        myCol += mySize(myIndex) + 1
      Next
      myShape(myShape.Length - 1) = myCol

      ' Rework each item to be the proper size
      myCol = 0
      For myIndex = 0 To myResults.Length - 1
        myPart = myResults(myIndex)
        'If Not IsNumeric(myPart) Then
        If myPart.StartsWith("'") Then
          myResults(myIndex) = myPart.Substring(1).PadRight(mySize(myCol))

        ElseIf myDecimal(myCol) = 0 Then
          myResults(myIndex) = myPart.PadLeft(mySize(myCol))

        Else
          myParts = myPart.Split("."c)
          If myParts.Length = 1 Then
            myResults(myIndex) = (myParts(0) & Space(myDecimal(myCol) + 1)) _
                                  .PadLeft(mySize(myCol))
          Else
            myResults(myIndex) = (myParts(0) & "." & _
                                  myParts(1).PadRight(myDecimal(myCol))) _
                                  .PadLeft(mySize(myCol))
          End If
        End If
        myCol = (myCol + 1) Mod myCols
      Next

      myResults(0) = " " & myResults(0)
      myResult = New APL(Join(myResults, " "))
      myResult.Shape = myShape
      Return myResult
    End If
  End Function

  Private thisOverflow As Boolean
  ''' <summary>
  ''' Does not support character arguments!
  ''' </summary>
  ''' <remarks>
  ''' I wrote 
  '''   character Left argument
  ''' thorn at IPSA, I don't want to learn it again.
  ''' Use _x.Format instead.
  ''' 
  ''' I designed a meaning for 
  '''   character Right argument
  ''' while at DCCCD.  However, modern text editors
  ''' don't need line breaks to ensure proper output.
  ''' </remarks>
  Private Function _Format(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Dim myValues As Object()
    Dim myResults, myFormats As String()
    Dim myPart As String
    Dim myFormat, mySize, myShape As Integer()
    Dim myIndex, myCol, myCols, myLast, myZero As Integer
    Dim myResult As APL

    If aLeft.Rank > 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If
    If aLeft.IsCharacter Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Nonce)
    End If
    If aRight.IsCharacter Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If

    myFormat = aLeft.IntegerVector
    If myFormat.Length = 1 Then
      ReDim Preserve myFormat(1)
      myFormat(1) = myFormat(0)
      myFormat(0) = 0
    ElseIf myFormat.Length = 0 OrElse 0 <> myFormat.Length Mod 2 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Length)
    End If

    myFormats = BuildFormats(myFormat)
    myShape = aRight.Shape
    If myShape.Length = 0 Then
      myCols = 1
      myShape = New Integer() {1}
    Else
      myCols = myShape(myShape.Length - 1)
    End If

    ReDim mySize(myCols - 1)
    If myFormat.Length = 2 Then
      ReDim Preserve myFormats(myCols - 1)
      For myIndex = 0 To mySize.Length - 1
        mySize(myIndex) = myFormat(0)
        myFormats(myIndex) = myFormats(0)
      Next
      If myFormat(0) = 0 Then
        myZero = myCols
      Else
        myLast = myCols * myFormat(0)
      End If
    Else
      If myCols <> myFormats.Length Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Length)
      End If

      myCol = 0
      For myIndex = 0 To myFormat.Length - 1 Step 2
        mySize(myCol) = myFormat(myIndex)
        myCol += 1
        If myFormat(myIndex) = 0 Then
          myZero += 1
        Else
          myLast += myFormat(myIndex)
        End If
      Next
    End If

    ' N.B.  If mySize.Contains(0) Then
    '       myLast will have to be recalculated
    myShape(myShape.Length - 1) = myLast
    myValues = aRight.ValueVector
    If myValues.Length = 0 Then
      myResult = New APL("")
      myResult.Shape = myShape
      Return myResult
    End If
    ReDim myResults(myValues.Length - 1)

    myCol = 0
    For myIndex = 0 To myResults.Length - 1
      myPart = String.Format(myFormats(myCol), myValues(myIndex))
      myPart = RepairSigns(myPart)
      If mySize(myCol) <> 0 AndAlso myPart.Length > mySize(myCol) Then
        If thisOverflow Then
          ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
        Else
          myPart = StrDup(mySize(myCol), "*")
        End If
      End If
      ' ToDo: Test that the padding in no longer required!
      myResults(myIndex) = myPart
      myCol = (myCol + 1) Mod myCols
    Next

    If myZero <> 0 Then
      AdjustZero(myZero, mySize, myCols, myResults)
      myShape(myShape.Length - 1) = UtilsShape.PlusReduce(mySize)
    End If

    myResult = New APL(Join(myResults, ""))
    myResult.Shape = myShape
    Return myResult
  End Function

  Private Shared Function RepairSigns(ByVal aNumber As String) As String
    Dim myNumber As String

    myNumber = aNumber.Replace("-", "¯").Replace("Infinity", "∞")
    If myNumber.Contains("E") Then
      myNumber = myNumber.Replace("+", "")
      Return myNumber.PadRight(aNumber.Length)
    Else
      Return myNumber
    End If
  End Function

  Private Function BuildFormats( _
      ByVal aFormat As Integer()) _
      As String()
    Dim myPart As String
    Dim myIndex, myCol, myWidth, myFraction As Integer
    Dim myResult As String()

    ReDim myResult((aFormat.Length \ 2) - 1)
    For myIndex = 0 To aFormat.Length - 1 Step 2
      myWidth = aFormat(myIndex)
      myFraction = aFormat(myIndex + 1)

      If myFraction = 0 Then
        ' 11 0 ⍕ ⍵
        '  _Of("{0,11: 0;-0}")(_x.Format,b)
        If Math.Abs(myWidth) < 1 Then
          myResult(myCol) = "{0:0}"
        Else
          myResult(myCol) = "{0," & myWidth.ToString & ":0}"
        End If

      ElseIf myFraction > 0 Then
        ' 11 2 ⍕ ⍵
        '  _Of("{0,11: 0.00;¯0.00}")(_x.Format,b)
        myPart = StrDup(myFraction, "0"c)
        myResult(myCol) = FormatWidth(myWidth, myFraction, 2) & _
            ": 0." & myPart & _
            ";¯0." & myPart & "}"

      Else
        ' 11 ¯4 ⍕ ⍵
        '  _Of("{0,11: 0.000E+000;¯0.000E+000}")(_x.Format,a)
        myPart = StrDup((-1) - myFraction, "0"c)
        If myFraction <> -1 Then
          myPart = "." & myPart
        End If
        myResult(myCol) = FormatWidth(myWidth, myFraction, 7) & _
            ": 0" & myPart & "E+000" & _
            ";¯0" & myPart & "E+000}"
      End If
      myCol += 1
    Next

    Return myResult
  End Function

  Private Function FormatWidth( _
      ByVal aWidth As Integer, _
      ByVal aFraction As Integer, _
      ByVal aMinimum As Integer) _
      As String
    If aWidth = 0 Then
      Return "{0"
    Else
      If ((Math.Abs(aWidth) - Math.Abs(aFraction)) < aMinimum) Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End If

      Return "{0," & aWidth.ToString
    End If
  End Function

  Private Sub AdjustZero( _
      ByVal aZero As Integer, _
      ByRef aSize As Integer(), _
      ByVal aColumns As Integer, _
      ByRef aResults As String())
    Dim myIndexes As Integer()
    Dim myIndex, myItem, myRow, myCol As Integer

    ReDim myIndexes(aZero - 1)
    myCol = 0
    For myIndex = 0 To aSize.Length - 1
      If aSize(myIndex) = 0 Then
        myIndexes(myCol) = myIndex
        myCol += 1
      End If
    Next

    myItem = 0
    For myRow = 1 To aResults.Length \ aColumns
      For myCol = 0 To myIndexes.Length - 1
        myIndex = myIndexes(myCol)
        aSize(myIndex) = Math.Max(aSize(myIndex), _
            1 + aResults(myItem + myIndex).TrimStart.Length)
      Next
      myItem += aSize.Length
    Next

    myItem = 0
    For myRow = 1 To aResults.Length \ aColumns
      For myCol = 0 To myIndexes.Length - 1
        myIndex = myItem + myIndexes(myCol)
        aResults(myIndex) = aResults(myIndex). _
            PadLeft(aSize(myIndexes(myCol)))
      Next
      myItem += aSize.Length
    Next
  End Sub

#End Region

#Region "⊣ ,Left"

  Public ReadOnly Property Left() As Method
    Get
      Return New Method(AddressOf _Left, AddressOf _Left)
    End Get
  End Property

  Private Function _Left(ByVal aRight As APL) As APL
    Return aRight.Clone
  End Function

  Private Function _Left(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Return aLeft.Clone
  End Function

#End Region

#Region "⊢ ,Right"

  Public ReadOnly Property Right() As Method
    Get
      Return New Method(AddressOf _Right, AddressOf _Right)
    End Get
  End Property

  Private Function _Right(ByVal aRight As APL) As APL
    Return aRight.Clone
  End Function

  Private Function _Right(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Return aRight.Clone
  End Function

#End Region

End Class