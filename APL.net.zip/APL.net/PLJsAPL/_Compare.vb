﻿Option Strict Off

Partial Class _APL

#Region "QuadCT"

  Private thisCT As Double = 0.00000000000001
  Private thisExtend As Boolean

  ''' <summary>
  ''' This is much more forgiving than traditional APL's.
  ''' However, I do throw an error if the assignment is illegal.
  ''' </summary>
  Public Property QuadCT() As APL
    Get
      Return New APL(New Object() {thisCT})
    End Get

    Set(ByVal aValue As APL)
      Dim myValue As Object()
      Dim myTol As Double

      UtilsShape.CheckValue(aValue)
      If aValue.IsCharacter Then
        ' This is a trick to test extended (but not released) features
        If aValue.Rank = 1 AndAlso aValue.CharacterVector = "Extend" Then
          thisExtend = True
          Return
        End If
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End If

      myValue = aValue.ValueVector
      ' Don't know traditional limits
      If myValue.Length <> 1 Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Length)
      End If
      myTol = CDbl(myValue(0))
      If myTol < 0 OrElse myTol > 0.005 Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End If
      thisCT = myTol
    End Set
  End Property

  Private Function Extended(ByVal anUnimplemented As Boolean) As APL
    If anUnimplemented OrElse Not thisExtend Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Nonce)
    End If
    Return Nothing
  End Function

#End Region

#Region "TolerantEqual and TolerantFloor"

  ''' <summary>
  ''' Per PCB's APL manual page 122
  ''' </summary>
  Private Function TolerantEqual(ByVal aLeft As Object, ByVal aRight As Object) As Boolean
    If thisCT = 0 Then
      Return aLeft.Equals(aRight)
    ElseIf TypeOf aLeft Is Double OrElse TypeOf aRight Is Double Then
      Return Math.Abs(aLeft - aRight) <= thisCT
    Else
      Return aLeft.Equals(aRight)
    End If
  End Function

  ''' <summary>
  ''' Per PCB's APL manual page 123
  ''' </summary>
  ''' <remarks>
  ''' N.B.  Only call when thisCT is not 0
  ''' </remarks>
  Private Function TolerantFloor(ByVal aRight As Object) As Object
    Dim myNearest, myError, myPermissible As Double

    myPermissible = Math.Abs(aRight)
    myNearest = Math.Sign(aRight) * Math.Floor(0.5 + myPermissible)
    myError = myNearest - aRight
    myPermissible = thisCT * Math.Max(1, myPermissible)
    Return myNearest + (myError > myPermissible)
  End Function

#End Region

#Region "TolerantEquals"

  ''' <summary>
  ''' A second version for those functions which
  ''' permit comparison of equality.
  ''' </summary>
  ''' <remarks>
  ''' The test for TypeOf APL is the responsiblity
  ''' of the calling function.
  ''' </remarks>
  Private Function TolerantEquals(ByVal aLeft As Object, ByVal aRight As Object) As Boolean
    Dim myLeftType, myRightType As Boolean

    myLeftType = TypeOf aLeft Is String
    myRightType = TypeOf aRight Is String
    If myLeftType OrElse myRightType Then
      If myLeftType AndAlso myRightType Then
        Return aRight.Equals(aLeft)
      End If

    Else
      myLeftType = TypeOf aLeft Is Char
      myRightType = TypeOf aRight Is Char
      If myLeftType OrElse myRightType Then
        If myLeftType AndAlso myRightType Then
          Return aRight.Equals(aLeft)
        End If

      Else
        Return TolerantEqual(aLeft, aRight)
      End If
    End If
  End Function

#End Region

#Region "JustNumbers Bool"

  Private Sub JustNumbers(ByVal aLeft As Object, ByVal aRight As Object)
    If TypeOf aLeft Is APL OrElse TypeOf aRight Is APL OrElse _
        TypeOf aLeft Is String OrElse TypeOf aRight Is String OrElse _
        TypeOf aLeft Is Char OrElse TypeOf aRight Is Char Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If
  End Sub

  Private Function Bool(ByVal aResult As Boolean) As Integer
    If aResult Then
      Return 1
    Else
      Return 0
    End If
  End Function

#End Region

  ''' <summary>
  ''' Equal and NotEqual work on Characters as well as Values
  ''' </summary>

#Region "=	,Equal,1"

  Private Function _Equal(ByVal aLeft As Object, ByVal aRight As Object) As Object
    If TypeOf aLeft Is APL OrElse TypeOf aRight Is APL Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If

    Return Bool(TolerantEquals(aLeft, aRight))
  End Function

  Private thisEqual As Method
  Public ReadOnly Property Equal() As Method
    Get
      If thisEqual Is Nothing Then
        thisEqual = New Method(Nothing, _
            AddressOf _Equal, AddressOf _Equal, 1, 0)
      End If

      Return thisEqual
    End Get
  End Property

#End Region

#Region "≠	,NotEqual,0"

  Private Function _NotEqual(ByVal aLeft As Object, ByVal aRight As Object) As Object
    Return 1 - _Equal(aLeft, aRight)
  End Function

  Private thisNotEqual As Method
  Public ReadOnly Property NotEqual() As Method
    Get
      If thisNotEqual Is Nothing Then
        thisNotEqual = New Method(Nothing, _
            AddressOf _NotEqual, AddressOf _NotEqual, 0, 1)
      End If

      Return thisNotEqual
    End Get
  End Property

#End Region

  ''' <summary>
  ''' N.B.  Inequalities are NOT defined on Characters values
  ''' </summary>
  ''' 

#Region "<	,Less,0"

  Private Function _Less(ByVal aLeft As Object, ByVal aRight As Object) As Object
    JustNumbers(aLeft, aRight)
    Return Bool(aLeft < aRight AndAlso Not TolerantEqual(aLeft, aRight))
  End Function

  Private thisLess As Method
  Public ReadOnly Property Less() As Method
    Get
      If thisLess Is Nothing Then
        thisLess = New Method(Nothing, _
            AddressOf _Less, Nothing, 0)
      End If

      Return thisLess
    End Get
  End Property

#End Region

#Region "≤	,LessOrEqual,1"

  Private Function _LessOrEqual(ByVal aLeft As Object, ByVal aRight As Object) As Object
    JustNumbers(aLeft, aRight)
    Return Bool(aLeft <= aRight OrElse TolerantEqual(aLeft, aRight))
  End Function

  Private thisLessOrEqual As Method
  Public ReadOnly Property LessOrEqual() As Method
    Get
      If thisLessOrEqual Is Nothing Then
        thisLessOrEqual = New Method(Nothing, _
            AddressOf _LessOrEqual, Nothing, 1)
      End If

      Return thisLessOrEqual
    End Get
  End Property

#End Region

#Region "≥	,GreaterOrEqual,1"

  Private Function _GreaterOrEqual(ByVal aLeft As Object, ByVal aRight As Object) As Object
    JustNumbers(aLeft, aRight)
    Return Bool(aLeft >= aRight OrElse TolerantEqual(aLeft, aRight))
  End Function

  Private thisGreaterOrEqual As Method
  Public ReadOnly Property GreaterOrEqual() As Method
    Get
      If thisGreaterOrEqual Is Nothing Then
        thisGreaterOrEqual = New Method(Nothing, _
            AddressOf _GreaterOrEqual, Nothing, 1)
      End If

      Return thisGreaterOrEqual
    End Get
  End Property

#End Region

#Region ">	,Greater,0"

  Private Function _Greater(ByVal aLeft As Object, ByVal aRight As Object) As Object
    JustNumbers(aLeft, aRight)
    Return Bool(aLeft > aRight AndAlso Not TolerantEqual(aLeft, aRight))
  End Function

  Private thisGreater As Method
  Public ReadOnly Property Greater() As Method
    Get
      If thisGreater Is Nothing Then
        thisGreater = New Method(Nothing, _
            AddressOf _Greater, Nothing, 0)
      End If

      Return thisGreater
    End Get
  End Property

#End Region

#Region "⌈	Ceiling,"

  Private Function _Ceiling(ByVal aRight As Object) As Object
    If thisCT = 0 Then
      Return Math.Ceiling(aRight)
    End If
    Return -TolerantFloor(-aRight)
  End Function

#End Region

#Region "⌊	Floor,"

  Private Function _Floor(ByVal aRight As Object) As Object
    If thisCT = 0 Then
      Return Math.Floor(aRight)
    End If
    Return TolerantFloor(aRight)
  End Function

#End Region

#Region "|	,Residue,0"

  Private Function _Residue(ByVal aLeft As Object, ByVal aRight As Object) As Object
    JustNumbers(aLeft, aRight)
    If aLeft = 0 Then
      Return aRight
    End If

    If TolerantEqual(aLeft, aRight) Then
      Return 0

    Else
      Return aRight - (aLeft * TolerantFloor(aRight / aLeft))
    End If
  End Function

#End Region

#Region "⍳	,IndexOf"

  Private Function IndexOf(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Dim myLeftChar, myRightChar As String
    Dim myLeftValues, myRightValues As Object()
    Dim myItems As Object()
    Dim myItem, myIndex As Integer
    Dim myResult As APL

    If aLeft.Rank <> 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If

    If aLeft.IsCharacter AndAlso aRight.IsCharacter Then
      myLeftChar = aLeft.CharacterVector
      myRightChar = aRight.CharacterVector

      ReDim myItems(myRightChar.Length - 1)
      If Array.ReferenceEquals(aLeft, QuadAV) Then
        For myIndex = 0 To myItems.Length - 1
          myItems(myIndex) = AscW(myRightChar(myIndex))
        Next

      Else
        For myIndex = 0 To myItems.Length - 1
          myItem = myLeftChar.IndexOf(myRightChar(myIndex))
          If myItem = -1 Then
            myItems(myIndex) = myLeftChar.Length

          Else
            myItems(myIndex) = myItem
          End If
        Next
      End If

    Else
      myLeftValues = aLeft.CompareValues
      myRightValues = aRight.CompareValues

      ReDim myItems(myRightValues.Length - 1)
      For myIndex = 0 To myRightValues.Length - 1
        If TypeOf myRightValues(myIndex) Is APL Then
          myItems(myIndex) = TolerantIndexOf(myLeftValues, myRightValues(myIndex))

        Else
          myItem = Array.IndexOf(myLeftValues, myRightValues(myIndex))
          If myItem = -1 Then
            myItems(myIndex) = myLeftValues.Length
          Else
            myItems(myIndex) = myItem
          End If
        End If
      Next

      If Not (aLeft.IsCharacter OrElse _
          aRight.IsCharacter OrElse thisCT = 0) Then
        For myIndex = 0 To myItems.Length - 1
          If Not TypeOf myRightValues(myIndex) Is APL Then
            myItems(myIndex) = TolerantIndexOf(myLeftValues, myRightValues(myIndex), myItems(myIndex))
          End If
        Next
      End If
    End If

    myResult = New APL(myItems)
    myResult.Shape = aRight.Shape
    Return myResult
  End Function

  Private Function TolerantIndexOf( _
      ByVal aLeft As Object(), _
      ByVal aRight As Object, _
      ByVal aMax As Integer) _
      As Object
    Dim myIndex As Integer
    Dim myLeft As Object

    For myIndex = 0 To aMax - 1
      myLeft = aLeft(myIndex)
      If Not (TypeOf myLeft Is APL OrElse _
          TypeOf myLeft Is String OrElse _
          TypeOf myLeft Is Char) Then
        If TolerantEquals(aLeft(myIndex), aRight) Then
          Return myIndex
        End If
      End If
    Next
    Return aMax
  End Function

  Private Function TolerantIndexOf( _
      ByVal aLeft As Object(), _
      ByVal aRight As Object) _
      As Object
    Dim myIndex As Integer

    For myIndex = 0 To aLeft.Length - 1
      If TypeOf aLeft(myIndex) Is APL AndAlso _
          TolerantIdentical(aLeft(myIndex), aRight) Then
        Return myIndex
      End If
    Next

    Return aLeft.Length
  End Function

#End Region

#Region "∊	,Element"

  Public ReadOnly Property Element() As Method
    Get
      Return New Method(AddressOf _Enlist, AddressOf _ElementOf)
    End Get
  End Property

  Private Function _Enlist(ByVal aRight As APL) As APL
    Return Extended(True)
  End Function

  Private Function _ElementOf(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Dim myLeftChar, myRightChar As String
    Dim myLeftValues, myRightValues As Object()
    Dim myItems As Object()
    Dim myIndex As Integer
    Dim myResult As APL

    If aLeft.IsCharacter AndAlso aRight.IsCharacter Then
      myLeftChar = aLeft.CharacterVector
      myRightChar = aRight.CharacterVector

      ReDim myItems(myLeftChar.Length - 1)
      For myIndex = 0 To myItems.Length - 1
        If myRightChar.Contains(myLeftChar(myIndex)) Then
          myItems(myIndex) = 1
        Else
          myItems(myIndex) = 0
        End If
      Next

    Else
      myLeftValues = aLeft.CompareValues
      myRightValues = aRight.CompareValues

      ReDim myItems(myLeftValues.Length - 1)
      For myIndex = 0 To myItems.Length - 1
        If myRightValues.Contains(myLeftValues(myIndex)) Then
          myItems(myIndex) = 1
        Else
          myItems(myIndex) = 0
        End If
      Next

      If thisCT <> 0 Then
        For myIndex = 0 To myItems.Length - 1
          If myItems(myIndex) = 0 Then
            myItems(myIndex) = TolerantElementOf(myLeftValues(myIndex), myRightValues)
          End If
        Next
      End If
    End If

    myResult = New APL(myItems)
    myResult.Shape = aLeft.Shape
    Return myResult
  End Function

  Private Function TolerantElementOf( _
      ByVal aLeft As Object, _
      ByVal aRight As Object()) _
      As Object
    Dim myIndex As Integer

    For myIndex = 0 To aRight.Length - 1
      If TolerantEquals(aLeft, aRight(myIndex)) Then
        Return 1
      End If
    Next
    Return 0
  End Function

#End Region

#Region "≡	,Id"

  Public ReadOnly Property Id() As Method
    Get
      Return New Method(AddressOf _Depth, AddressOf _Identical)
    End Get
  End Property

  Private Function _Depth(ByVal aRight As APL) As APL
    Return Extended(True)
  End Function

  Private Function _Identical(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Dim myResult As Integer
    Dim myLeftChar, myRightChar As Boolean

    If Array.ReferenceEquals(aLeft, aRight) Then
      ' When pointers to each value are the same
      myResult = 1

    ElseIf Array.ReferenceEquals(aLeft, Empty) OrElse _
        Array.ReferenceEquals(aRight, Empty) Then
      ' Ensures _a.Empty doesn't match anything else

    ElseIf aLeft.SameShape(aRight.Shape) Then
      myLeftChar = aLeft.IsCharacter
      myRightChar = aRight.IsCharacter
      If myLeftChar AndAlso myRightChar Then
        myResult = Bool(aLeft.CharacterVector = aRight.CharacterVector)

      ElseIf Not (myLeftChar OrElse myRightChar) Then
        myResult = TolerantIdentical(aLeft, aRight)
      End If
    End If

    Return New APL(New Object() {myResult})
  End Function

  Private Function TolerantIdentical(ByVal aLeft As APL, ByVal aRight As APL) As Integer
    Dim myLeft, myRight As Object
    Dim myLefts, myRights As Object()
    Dim myIndex As Integer
    Dim myLeftType, myRightType As Boolean

    myLefts = aLeft.CompareValues
    myRights = aRight.CompareValues

    For myIndex = 0 To myLefts.Length - 1
      myLeft = myLefts(myIndex)
      myRight = myRights(myIndex)

      myLeftType = TypeOf myLeft Is APL
      myRightType = TypeOf myRight Is APL
      If myLeftType AndAlso myRightType Then
        If _Identical(myLeft, myRight).IsFalse Then
          Return 0
        End If

      ElseIf myLeftType OrElse myRightType Then
        Return 0

      Else
        myLeftType = TypeOf myLeft Is String
        myRightType = TypeOf myRight Is String
        If myLeftType AndAlso myRightType Then
          If myRight <> myLeft Then
            Return 0
          End If
        ElseIf myLeftType OrElse myRightType Then
          Return 0
        Else
          myLeftType = TypeOf myLeft Is Char
          myRightType = TypeOf myRight Is Char
          If myLeftType AndAlso myRightType Then
            If myRight <> myLeft Then
              Return 0
            End If
          ElseIf myLeftType OrElse myRightType Then
            Return 0
          ElseIf Not TolerantEqual(myLeft, myRight) Then
            Return 0
          End If
        End If
      End If
    Next

    Return 1
  End Function

#End Region

End Class
