﻿Partial Class _APL

#Region "Value"

  Public Function Value(ByVal aValue As String) As APL
    Return New APL(aValue)
  End Function

  Public Function Value(ByVal aValue As Object) As APL
    Return New APL(New Object() {aValue})
  End Function

  Public Function Value(ByVal ParamArray aValue As Object()) As APL
    Dim myObject As Object
    Dim myAPL As APL
    Dim myIndex As Integer

    For myIndex = 0 To aValue.Length - 1
      myObject = aValue(myIndex)
      If TypeOf myObject Is String AndAlso _
          DirectCast(myObject, String).Length = 1 Then
        aValue(myIndex) = CType(myObject, Char)
      ElseIf TypeOf myObject Is APL Then
        myAPL = DirectCast(myObject, APL)
        If myAPL.IsCharacter Then
          If myAPL.Rank = 0 Then
            aValue(myIndex) = myAPL.ValueVector(0)
          ElseIf myAPL.Rank = 1 Then
            aValue(myIndex) = myAPL.CharacterVector
          End If

        ElseIf myAPL.Rank = 0 Then
          myObject = myAPL.ValueVector(0)
          If Not TypeOf myObject Is APL Then
            aValue(myIndex) = myObject
          End If
        Else
          aValue(myIndex) = myAPL.Clone
        End If
      End If
    Next

    Return New APL(aValue)
  End Function

#End Region

#Region "Empty"

  Private Shared thisEmpty As APL
  ''' <summary>
  ''' A special value, for use in identifying indexes the user
  ''' wants filled with:  ⍳(⍴aValue)[aDimension]
  ''' </summary>
  Public ReadOnly Property Empty() As APL
    Get
      Return _Empty
    End Get
  End Property

  Public Shared ReadOnly Property _Empty() As APL
    Get
      If thisEmpty Is Nothing Then
        thisEmpty = New APL("")
      End If

      Return thisEmpty
    End Get
  End Property

#End Region

#Region "Prompt is somewhat like QuoteQuad"

  Public Function Prompt(ByVal aPrompt As APL) As APL
    Return _Quote(aPrompt)
  End Function

#End Region

#Region "Quad"

  Public WriteOnly Property Quad() As APL
    Set(ByVal aValue As APL)
      _Out = aValue
    End Set
  End Property

#End Region

#Region "QuadAV"

  Private Shared thisAV As APL
  ''' <summary>
  ''' The Atomic Vector represents all possible characters.
  '''   _a.QuadAV.Sub(_a.Value(97))
  '''   _a.QuadAV(_a.Index,_a.Value("a"))
  ''' </summary>
  Public ReadOnly Property QuadAV() As APL
    Get
      Dim myIndex As Integer
      Dim myChars As Char()
      Dim myString As String

      If thisAV Is Nothing Then
        ReDim myChars(65535)
        For myIndex = 0 To 65535
          myChars(myIndex) = ChrW(myIndex)
        Next
        myString = myChars
        thisAV = New APL(myString)
      End If

      Return thisAV
    End Get
  End Property

#End Region

#Region "QuadTS"

  ''' <summary>
  ''' A seven element time stamp.
  ''' </summary>
  Public ReadOnly Property QuadTS() As APL
    Get
      Dim myNow As Date
      Dim myTime As Object()

      myNow = Now
      ReDim myTime(6)
      myTime(0) = myNow.Year
      myTime(1) = myNow.Month
      myTime(2) = myNow.Day
      myTime(3) = myNow.Hour
      myTime(4) = myNow.Minute
      myTime(5) = myNow.Second
      myTime(6) = myNow.Millisecond

      Return New APL(myTime)
    End Get
  End Property

#End Region

End Class
