﻿Option Strict Off

Partial Class _APL

#Region "Grade"

  Private Function Grade(ByVal anUpgrade As Boolean, ByVal aValues As APL) As APL
    Dim myValues, myIndexes As Object()
    Dim myShape As Integer()
    Dim mySize As Integer
    Dim myComparer As ValueComparer

    If aValues.Rank = 0 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If
    myShape = aValues.Shape
    mySize = UtilsShape.TimesReduce(UtilsShape.Remove(0, myShape))

    myValues = aValues.CompareValues
    If myValues.Length = 0 Then
      Return GradeEmpty(myShape(0))
    End If

    myComparer = New ValueComparer(anUpgrade, mySize)
    myIndexes = myComparer.SortKeys(myValues)

    Array.Sort(myIndexes, myComparer)
    Return New APL(myIndexes, False)

  End Function

#End Region

#Region "Grades"

  Private Function Grades( _
      ByVal anUpgrade As Boolean, _
      ByVal aLeft As APL, _
      ByVal aValues As APL) _
      As APL
    Dim myIndexes As Object()
    Dim mySize As Integer
    Dim myShape As Integer()
    Dim myComparer As CharacterComparer

    If aLeft.Rank = 0 OrElse aValues.Rank = 0 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If

    myShape = aValues.Shape
    If aLeft.Rank > 2 Then
      ' A transpose is needed if rank>2
      ExceptionAPL.Signal(ExceptionAPL.Is.Nonce)
    End If
    If Not aValues.IsCharacter AndAlso aValues.Rank <> 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If

    myShape = aValues.Shape
    mySize = UtilsShape.TimesReduce(UtilsShape.Remove(0, myShape))

    If UtilsShape.TimesReduce(myShape) = 0 Then
      Return GradeEmpty(myShape(0))
    End If

    myComparer = New CharacterComparer(anUpgrade, aLeft.CharacterVector, aLeft.Shape(aLeft.Rank - 1))
    If aValues.IsCharacter Then
      myIndexes = myComparer.SortKeys(aValues.CharacterVector, myShape(0), mySize)
    Else ' aValues.Rank = 1
      myIndexes = myComparer.SortValues(aValues.ValueVector, myShape(0), mySize)
    End If

    Array.Sort(myIndexes, myComparer)
    Return New APL(myIndexes, False)
  End Function

#End Region

#Region "GradeEmpty"

  Private Function GradeEmpty( _
      ByVal aSize As Integer) _
      As APL
    Dim myResult As Object()
    Dim myIndex As Integer

    ReDim myResult(aSize - 1)
    For myIndex = 0 To aSize - 1
      myResult(myIndex) = myIndex
    Next
    Return New APL(myResult, False)
  End Function

#End Region

End Class

#Region "ValueComparer Class"

Public Class ValueComparer
  Implements IComparer

  Private thisValues As Object()
  Private thisUpgrade As Boolean
  Private thisColumns As Integer
  Private thisIndexes As Integer()

  Public Sub New( _
      ByVal anUpgrade As Boolean, _
      ByVal aCol As Integer)

    thisUpgrade = True
    thisColumns = aCol
  End Sub

  Public Function Compare( _
      ByVal aLeft As Object, _
      ByVal aRight As Object) _
      As Integer Implements IComparer.Compare
    Dim myLeft, myRight, myFirst, mySecond, myIndex, myResult As Integer
    Dim myFirsts, mySeconds As Object

    myLeft = DirectCast(aLeft, Integer)
    myRight = DirectCast(aRight, Integer)

    If myLeft = myRight Then
      ' The same row, no point in another compare
      Return 0
    End If

    If thisUpgrade Then
      myFirst = thisIndexes(myLeft)
      mySecond = thisIndexes(myRight)
    Else
      myFirst = thisIndexes(myRight)
      mySecond = thisIndexes(myLeft)
    End If

    For myIndex = 0 To thisColumns - 1
      myFirsts = thisValues(myFirst + myIndex)
      mySeconds = thisValues(mySecond + myIndex)

      If TypeOf myFirsts Is String Then
        If TypeOf mySeconds Is String Then
          myResult = Comparer.Default.Compare(myFirsts, mySeconds)
        Else
          Return 1
        End If
      ElseIf TypeOf mySeconds Is String Then
        Return -1
      Else
        Try
          myResult = Math.Sign(myFirsts - mySeconds)
        Catch ex As Exception
          ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
        End Try
      End If

      If myResult <> 0 Then
        Return myResult
      End If
    Next

    ' The rows are the same, which row came first
    ' N.B. This is not sensative to UpGrade vs DownGrade
    Return myLeft - myRight
  End Function

  Public Function SortKeys(ByVal aValues As Object()) As Object()
    Dim myResult As Object()
    Dim myIndex, myRow As Integer

    thisValues = aValues
    ReDim thisIndexes((aValues.Length \ thisColumns) - 1)
    ReDim myResult(thisIndexes.Length - 1)

    For myIndex = 0 To thisIndexes.Length - 1
      myResult(myIndex) = myIndex
      thisIndexes(myIndex) = myRow
      myRow += thisColumns
    Next

    Return myResult
  End Function

End Class

#End Region

#Region "CharacterComparer Class"

Public Class CharacterComparer
  Implements IComparer

  Private thisKeys As String()
  Private thisUpgrade As Boolean
  Private thisOrder As String
  Private thisColumns As Integer

  Public Sub New( _
    ByVal anUpgrade As Boolean, _
    ByVal anOrder As String, _
    ByVal aColumns As Integer)

    thisUpgrade = anUpgrade
    thisOrder = anOrder
    thisColumns = aColumns
  End Sub

  Public Function Compare( _
      ByVal aLeft As Object, _
      ByVal aRight As Object) _
      As Integer Implements IComparer.Compare
    Dim myLeft, myRight As Integer
    Dim myFirst, mySecond As String

    myLeft = DirectCast(aLeft, Integer)
    myRight = DirectCast(aRight, Integer)

    If myLeft = myRight Then
      ' The same row, no point in another compare
      Return 0
    End If

    If thisUpgrade Then
      myFirst = thisKeys(myLeft)
      mySecond = thisKeys(myRight)
    Else
      myFirst = thisKeys(myRight)
      mySecond = thisKeys(myLeft)
    End If

    If myFirst < mySecond Then
      Return -1
    ElseIf myFirst > mySecond Then
      Return 1
    Else
      ' The rows are the same, which row came first
      ' N.B. This is not sensative to UpGrade vs DownGrade
      Return myLeft - myRight
    End If
  End Function

  Public Function SortKeys( _
      ByVal aKeys As String, _
      ByVal aRows As Integer, _
      ByVal aCols As Integer) _
      As Object()
    Dim myResult As Object()
    Dim myRow, myCol As Char()
    Dim myKey As String
    Dim myItem, myIndex, myOffset, myChar As Integer

    ReDim myResult(aRows - 1)
    ReDim thisKeys(aRows - 1)
    For myItem = 0 To aRows - 1
      myKey = aKeys.Substring(myOffset, aCols)
      myOffset += aCols

      ReDim myRow(aCols - 1)
      ReDim myCol(aCols)

      For myIndex = 0 To aCols - 1
        myChar = thisOrder.IndexOf(myKey(myIndex))
        If myChar = -1 Then
          myRow(myIndex) = ChrW(-1)
          myCol(myIndex) = ChrW(-1)
        Else
          myRow(myIndex) = ChrW(1 + myChar \ thisColumns)
          myCol(myIndex) = ChrW(1 + myChar Mod thisColumns)
        End If
      Next

      myCol(aCols) = ChrW(0)
      thisKeys(myItem) = myCol & myRow
      myResult(myItem) = myItem
    Next
    Return myResult
  End Function

  Public Function SortValues( _
      ByVal aValues As Object(), _
      ByVal aRows As Integer, _
      ByVal aCols As Integer) _
      As Object()
    Dim myResult As Object()
    Dim myRow, myCol As Char()
    Dim myKey As String
    Dim myItem, myIndex, myChar As Integer

    ReDim myResult(aRows - 1)
    ReDim thisKeys(aRows - 1)
    For myItem = 0 To aRows - 1 Step aCols
      If Not TypeOf aValues(myItem) Is String Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End If

      myKey = DirectCast(aValues(myItem), String)
      ReDim myRow(myKey.Length - 1)
      ReDim myCol(myKey.Length)

      For myIndex = 0 To myKey.Length - 1
        myChar = thisOrder.IndexOf(myKey(myIndex))
        If myChar = -1 Then
          myRow(myIndex) = ChrW(-1)
          myCol(myIndex) = ChrW(-1)
        Else
          myRow(myIndex) = ChrW(1 + myChar \ thisColumns)
          myCol(myIndex) = ChrW(1 + myChar Mod thisColumns)
        End If
      Next

      myCol(myCol.Length - 1) = ChrW(0)
      thisKeys(myItem) = myCol & myRow
      myResult(myItem) = myItem
    Next
    Return myResult
  End Function

End Class

#End Region
