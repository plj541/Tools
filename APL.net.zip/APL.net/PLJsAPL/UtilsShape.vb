﻿Public Class UtilsShape

#Region "TimesReduce"

  Public Shared Function TimesReduce(ByVal aShape As Integer()) As Integer
    Dim myShape, myItem As Integer

    myShape = 1
    For Each myItem In aShape
      If myItem < 0 Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End If
      myShape *= myItem
      If myShape = 0 Then
        Return 0
      End If
    Next
    Return myShape
  End Function

#End Region

#Region "PlusReduce"

  Public Shared Function PlusReduce(ByVal aShape As Integer()) As Integer
    Dim myShape, myItem As Integer

    myShape = 0
    For Each myItem In aShape
      If myItem < 0 Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End If
      myShape += myItem
    Next

    Return myShape
  End Function

  Public Shared Function PlusReduceCount0(ByVal aShape As Integer()) As Integer
    Dim myShape, myItem As Integer

    myShape = 0
    For Each myItem In aShape
      If myItem < 0 Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      ElseIf myItem = 0 Then
        myShape += 1
      Else
        myShape += myItem
      End If
    Next

    Return myShape
  End Function

#End Region

#Region "Catenate"

  Public Shared Function Catenate(ByVal aShapeLeft As Integer(), ByVal aShapeRight As Integer()) As Integer()
    Dim myindex, myItem As Integer
    Dim myShape As Integer()

    myItem = aShapeLeft.Length
    myShape = aShapeLeft
    ReDim Preserve myShape(aShapeLeft.Length + aShapeRight.Length - 1)
    For myindex = 0 To aShapeRight.Length - 1
      myShape(myItem) = aShapeRight(myindex)
      myItem += 1
    Next

    Return myShape
  End Function

#End Region

#Region "Remove"

  Public Shared Function Remove(ByVal anIndex As Integer, ByVal aShape As Integer()) As Integer()
    Dim myResult As Integer()
    Dim myShapeIndex, myResultIndex As Integer

    If aShape.Length = 0 Then
      Return aShape

    Else
      ReDim myResult(aShape.Length - 2)
      For myShapeIndex = 0 To aShape.Length - 1
        If myShapeIndex <> anIndex Then
          myResult(myResultIndex) = aShape(myShapeIndex)
          myResultIndex += 1
        End If
      Next

      Return myResult
    End If
  End Function

#End Region

#Region "CopyShape"

  Public Shared Function CopyShape(ByVal aShape As Integer()) As Object()
    Dim myResult As Object()
    Dim myIndex As Integer

    ReDim myResult(aShape.Length - 1)
    For myIndex = 0 To myResult.Length - 1
      myResult(myIndex) = aShape(myIndex)
    Next
    Return myResult
  End Function

#End Region

#Region "RankOnes"

  Public Shared Function RankOnes(ByVal aRank As Integer, ByVal aShape As Integer()) As Integer()
    Dim myIndex As Integer

    If aShape.Length = 0 Then
      ReDim aShape(aRank - 1)
      For myIndex = 0 To aShape.Length - 1
        aShape(myIndex) = 1
      Next
    End If

    Return aShape
  End Function

#End Region

#Region "InsertOne"

  Public Shared Function InsertOne( _
      ByVal anIndex As Integer, _
      ByVal aShape As Integer()) _
      As Integer()
    Dim myShape As Integer()
    Dim myIndex, myItem As Integer

    ReDim myShape(aShape.Length)
    For myIndex = 0 To myShape.Length - 1
      If myIndex = anIndex Then
        myShape(myIndex) = 1

      Else
        myShape(myIndex) = aShape(myItem)
        myItem += 1
      End If
    Next
    Return myShape
  End Function

#End Region

#Region "CheckValue"

  Public Shared Sub CheckValue(ByVal ParamArray aValue As APL())
    Dim myIndex As Integer

    For myIndex = 0 To aValue.Length - 1
      If aValue(myIndex) Is Nothing Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Value)
      End If
    Next
  End Sub

  Public Shared Sub CheckValue(ByVal ParamArray aValue As String())
    Dim myIndex As Integer

    For myIndex = 0 To aValue.Length - 1
      If aValue(myIndex) Is Nothing Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Value)
      End If
    Next
  End Sub

#End Region

#Region "CheckIndex"

  Public Shared Sub CheckIndex(ByVal anIndex As Integer, ByVal aRight As APL)
    If aRight.Rank = 0 Then
      If anIndex <> 0 Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Index)
      End If
    ElseIf anIndex < 0 OrElse anIndex >= aRight.Rank Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Index)
    End If
  End Sub

#End Region

#Region "SameShape"

  Public Shared Function SameShape( _
      ByVal aLeft As Integer(), _
      ByVal aRight As Integer()) _
      As Boolean
    Dim myIndex As Integer

    For myIndex = 0 To aLeft.Length - 1
      If aLeft(myIndex) <> aRight(myIndex) Then
        Return False
      End If
    Next

    Return True
  End Function

#End Region

#Region "RemoveDups"

  Public Shared Function RemoveDups(ByVal aLine As String, ByVal aSep As String) As String
    Dim myLength As Integer
    Dim myDup As String

    aLine = aLine.Trim
    myDup = aSep & aSep
    Do
      myLength = aLine.Length
      aLine = aLine.Replace(myDup, aSep)
    Loop While myLength <> aLine.Length

    Return aLine
  End Function

#End Region

#Region "Residue"

  Public Shared Function Residue(ByVal aLeft As Integer, ByVal aRight As Integer) As Integer
    ' .Net's Mod returns negative values, unlike APL's Residue
    Dim myMod As Integer

    myMod = aRight Mod aLeft
    If myMod < 0 Then
      Return aLeft + myMod
    End If
    Return myMod
  End Function

#End Region

End Class