﻿Partial Class _APL

#Region "^	,And,1"

  Private Function _And(ByVal aLeft As Object, ByVal aRight As Object) As Object
    Return UtilsStrict.IsBool(aLeft) And UtilsStrict.IsBool(aRight)
  End Function

  Private thisAnd As Method
  Public ReadOnly Property [And]() As Method
    Get
      If thisAnd Is Nothing Then
        thisAnd = New Method(Nothing, _
            AddressOf _And, AddressOf _And, 1)
      End If

      Return thisAnd
    End Get
  End Property

#End Region

#Region "∨	,Or,0"

  Private Function _Or(ByVal aLeft As Object, ByVal aRight As Object) As Object
    Return UtilsStrict.IsBool(aLeft) Or UtilsStrict.IsBool(aRight)
  End Function

  Private thisOr As Method
  Public ReadOnly Property [Or]() As Method
    Get
      If thisOr Is Nothing Then
        thisOr = New Method(Nothing, _
            AddressOf _Or, AddressOf _Or, 0)
      End If

      Return thisOr
    End Get
  End Property

#End Region

#Region "⍲	,Nand,-"

  Private Function _Nand(ByVal aLeft As Object, ByVal aRight As Object) As Object
    Return 1 - (UtilsStrict.IsBool(aLeft) And UtilsStrict.IsBool(aRight))
  End Function

  Private thisNand As Method
  Public ReadOnly Property [Nand]() As Method
    Get
      If thisNand Is Nothing Then
        thisNand = New Method(Nothing, _
            AddressOf _Nand, AddressOf _Nand, Nothing)
      End If

      Return thisNand

    End Get
  End Property

#End Region

#Region "⍱	,Nor,-"

  Private Function _Nor(ByVal aLeft As Object, ByVal aRight As Object) As Object
    Return 1 - (UtilsStrict.IsBool(aLeft) Or UtilsStrict.IsBool(aRight))
  End Function

  Private thisNor As Method
  Public ReadOnly Property [Nor]() As Method
    Get
      If thisNor Is Nothing Then
        thisNor = New Method(Nothing, _
            AddressOf _Nor, AddressOf _Nor, Nothing)
      End If

      Return thisNor
    End Get
  End Property

#End Region

#Region "~	Not"

  Private Function _Not(ByVal aRight As Object) As Object
    Return 1 - UtilsStrict.IsBool(aRight)
  End Function

  Private thisNot As Method
  Public ReadOnly Property [Not]() As Method
    Get
      If thisNot Is Nothing Then
        thisNot = New Method(AddressOf _Not, _
            Nothing, Nothing, Nothing)
      End If

      Return thisNot
    End Get
  End Property

#End Region

End Class
