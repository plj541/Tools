﻿Public Class UtilsGamma
  ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
  'Cephes Math Library Release 2.8:  June, 2000
  'Copyright by Stephen L. Moshier
  '
  'Contributors:
  '    * Sergey Bochkanov (ALGLIB project). Translation from C to
  '      pseudocode.
  '
  'See subroutines comments for additional copyrights.
  '
  '>>> SOURCE LICENSE >>>
  'This program is free software; you can redistribute it and/or modify
  'it under the terms of the GNU General Public License as published by
  'the Free Software Foundation (www.fsf.org); either version 2 of the 
  'License, or (at your option) any later version.
  '
  'This program is distributed in the hope that it will be useful,
  'but WITHOUT ANY WARRANTY; without even the implied warranty of
  'MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  'GNU General Public License for more details.
  '
  'A copy of the GNU General Public License is available at
  'http://www.fsf.org/licensing/licenses
  '
  '>>> END OF LICENSE >>>
  ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
  'Routines
  ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
  'Gamma function
  '
  'Input parameters:
  '    X   -   argument
  '
  'Domain:
  '    0 < X < 171.6
  '    -170 < X < 0, X is not an integer.
  '
  'Relative error:
  ' arithmetic   domain       trials      peak         rms
  '    IEEE    -170,-33      20000       2.3e-15     3.3e-16
  '    IEEE     -33,  33     20000       9.4e-16     2.2e-16
  '    IEEE      33, 171.6   20000       2.3e-15     3.2e-16
  '
  'Cephes Math Library Release 2.8:  June, 2000
  'Original copyright 1984, 1987, 1989, 1992, 2000 by Stephen L. Moshier
  'Translated to AlgoPascal by Bochkanov Sergey (2005, 2006, 2007).
  '
  ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
  Public Shared Function Gamma(ByVal x As Double) As Double
    Dim p As Double
    Dim PP As Double
    Dim q As Double
    Dim QQ As Double
    Dim z As Double
    Dim i As Double
    Dim SgnGam As Double

    SgnGam = 1.0
    q = Math.Abs(x)
    If q > 33.0 Then
      If x < 0.0 Then
        p = Int(q)
        i = Math.Round(p)
        If i Mod 2.0 = 0.0 Then
          SgnGam = -1.0
        End If
        z = q - p
        If z > 0.5 Then
          p = p + 1.0
          z = q - p
        End If
        z = q * Math.Sin(Math.PI * z)
        z = Math.Abs(z)
        z = Math.PI / (z * GammaStirF(q))
      Else
        z = GammaStirF(x)
      End If
      Return SgnGam * z
    End If
    z = 1.0
    Do While x >= 3.0
      x = x - 1.0
      z = z * x
    Loop
    Do While x < 0.0
      If x > -0.000000001 Then
        Return z / ((1.0 + 0.57721566490153287 * x) * x)
      End If
      z = z / x
      x = x + 1.0
    Loop
    Do While x < 2.0
      If x < 0.000000001 Then
        Return z / ((1.0 + 0.57721566490153287 * x) * x)
      End If
      z = z / x
      x = x + 1.0
    Loop
    If x = 2.0 Then
      Return z
    End If
    x = x - 2.0
    PP = 0.00016011952247675185
    PP = 0.0011913514700658638 + x * PP
    PP = 0.010421379756176158 + x * PP
    PP = 0.047636780045713721 + x * PP
    PP = 0.20744822764843598 + x * PP
    PP = 0.49421482680149709 + x * PP
    PP = 1.0 + x * PP
    QQ = -0.000023158187332412014
    QQ = 0.00053960558049330335 + x * QQ
    QQ = -0.0044564191385179728 + x * QQ
    QQ = 0.011813978522206043 + x * QQ
    QQ = 0.035823639860549865 + x * QQ
    QQ = -0.23459179571824335 + x * QQ
    QQ = 0.0714304917030273 + x * QQ
    QQ = 1.0 + x * QQ
    Return z * PP / QQ
  End Function

  Private Shared Function GammaStirF(ByVal X As Double) As Double
    Dim y, w, v, Stir As Double

    w = 1.0 / X
    Stir = 0.00078731139579309368
    Stir = -0.00022954996161337813 + w * Stir
    Stir = -0.0026813261780578124 + w * Stir
    Stir = 0.0034722222160545866 + w * Stir
    Stir = 0.08333333333334822 + w * Stir
    w = 1.0 + w * Stir
    y = Math.Exp(X)
    If X > 143.01608 Then
      v = Math.Pow(X, 0.5 * X - 0.25)
      y = v * (v / y)
    Else
      y = Math.Pow(X, X - 0.5) / y
    End If
    Return 2.5066282746310007 * y * w
  End Function

End Class
