﻿Public Class OpScalar

#Region "Properties"

  Private thisLeftFn As Method

#End Region

#Region "New and Arguments"

  Public Sub New()
    ' Nothing to do
  End Sub

  ''' <summary>
  ''' Create a scalar environment for non scalar functions
  ''' </summary>
  Public Sub New(ByVal aLeft As Method)
    Arguments(aLeft)
  End Sub

  ''' <summary>
  ''' Remember the left method 
  ''' </summary>
  Public Sub Arguments(ByVal aLeft As Method)
    If aLeft Is Nothing Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Syntax)
    End If

    thisLeftFn = aLeft
  End Sub

#End Region

#Region "Derived"

  Public Function Derived( _
      ByVal aRight As Object) _
      As Object
    Return ScalarResult(thisLeftFn(ScalarValue(aRight)))
  End Function

  Public Function Derived( _
      ByVal aLeft As Object, _
      ByVal aRight As Object) _
      As Object
    Return ScalarResult(thisLeftFn(ScalarValue(aLeft), ScalarValue(aRight)))
  End Function

#End Region

#Region "ScalarValue"

  Private Function ScalarValue(ByVal aValue As Object) As APL
    If TypeOf aValue Is APL Then
      Return DirectCast(aValue, APL)
    ElseIf TypeOf aValue Is Char Then
      Return New APL(aValue.ToString)
    ElseIf TypeOf aValue Is String Then
      Return New APL(aValue.ToString, False)
    End If
    Return New APL(New Object() {aValue})
  End Function

#End Region

#Region "ScalarResult"

  Private Function ScalarResult(ByVal anItem As APL) As Object
    If anItem.IsCharacter Then
      If anItem.Rank = 0 Then
        Return anItem.ValueVector(0)
      ElseIf anItem.Rank = 1 Then
        Return anItem.CharacterVector
      Else
        Return anItem
      End If

    ElseIf anItem.Rank = 0 Then
      Dim myItem As Object = anItem.ValueVector(0)
      If TypeOf myItem Is APL OrElse TypeOf myItem Is String Then
        Return anItem
      End If
      Return myItem

    Else
      Return anItem
    End If
  End Function

#End Region

End Class
