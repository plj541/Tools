﻿Imports System.Text

Public Class APL

#Region "Private Properties"

  Private thisCharacters As String
  Private thisStringBuilder As StringBuilder
  Private thisValues As Object()
  Private thisShape As Integer()

#End Region

#Region "New"

  Public Sub New( _
      ByVal aValue As String, _
      Optional ByVal aReshape As Boolean = True)
    thisCharacters = aValue
    NewShape(aReshape, aValue.Length)
  End Sub

  Public Sub New( _
      ByVal aValue As Object(), _
      Optional ByVal aReshape As Boolean = True)
    thisValues = aValue
    NewShape(aReshape, aValue.Length)
  End Sub

  Private Sub NewShape( _
      ByVal aReshape As Boolean, _
      ByVal aLength As Integer)
    If aReshape AndAlso aLength = 1 Then
      thisShape = New Integer() {}
    Else
      thisShape = New Integer() {aLength}
    End If
  End Sub

#End Region

#Region "Eval   aValue(aFn)   and   aValue(aFn, aNother)"

#Region "Monadic Functions"

  ''' <summary>
  ''' Invoking:   aValue(aFunction)   
  ''' Was key to evaluating scalar functions in the previous version.
  ''' While not still required, I've kept it because I like the syntax.
  ''' </summary>
  Default Public ReadOnly Property Eval( _
      ByVal aMethod As Method) _
      As APL
    Get
      Return aMethod(Me)
    End Get
  End Property

#End Region

#Region "Dyadic Functions"

  ''' <summary>
  ''' Invoking:   aValue(aFunction, anotherValue)
  ''' Presents the expression in the same sequence as APL.
  ''' </summary>
  Default Public ReadOnly Property Eval( _
      ByVal aMethod As Method, _
      ByVal aRight As APL) _
      As APL
    Get
      UtilsShape.CheckValue(aRight)
      Return aMethod(Me, aRight)
    End Get
  End Property

  Default Public ReadOnly Property Eval( _
      ByVal aMethod As Method, _
      ByVal aRight As Object) _
      As APL
    Get
      Dim myRight As APL

      If aRight Is Nothing Then
        _Signal(ExceptionAPL.Is.Value)
      End If
      If TypeOf aRight Is APL Then
        myRight = DirectCast(aRight, APL)
      Else
        myRight = New APL(New Object() {aRight})
      End If
      Return aMethod(Me, myRight)
    End Get
  End Property

  Default Public ReadOnly Property Eval( _
      ByVal aMethod As Method, _
      ByVal aRight As String) _
      As APL
    Get
      Return aMethod(Me, New APL(aRight))
    End Get
  End Property

#End Region

#End Region

#Region "Sub[;]"

  ''' <summary>
  ''' Make it easy to specify a single item from a vector.
  ''' Provides a means to subscript values, and reassign same.
  ''' </summary>
  Public Property [Sub](ByVal anItem As Object) As APL
    Get
      Return [Sub](New APL(New Object() {anItem}))
    End Get
    Set(ByVal aValue As APL)
      [Sub](New APL(New Object() {anItem})) = aValue
    End Set
  End Property

  ''' <summary>
  ''' Provides a means to subscript values, and reassign same.
  ''' </summary>
  Public Property [Sub](ByVal ParamArray aSubscript As APL()) As APL
    Get
      Dim myValue, myValues As Object()
      Dim myResult As APL
      Dim myIndex, mySize As Integer
      Dim myIndexing As Indexing

      UtilsShape.CheckValue(aSubscript)
      myIndexing = New Indexing(Shape, aSubscript)
      mySize = UtilsShape.TimesReduce(myIndexing.ResultShape) - 1

      If IsCharacter Then
        myResult = New APL(SubString(mySize, myIndexing))

      Else
        ReDim myValue(mySize)
        myValues = ValueVector
        For myIndex = 0 To myValue.Length - 1
          myValue(myIndex) = myValues(myIndexing.Next)
        Next

        If myValue.Length = 1 AndAlso TypeOf myValue(0) Is Char Then
          ' Char is a character Scalar
          myResult = New APL(CType(myValue(0), String))
        Else
          myResult = New APL(myValue)
        End If
      End If

      myResult.Shape = myIndexing.ResultShape
      Return myResult
    End Get

    Set(ByVal aValue As APL)
      Dim myIndex, mySize As Integer
      Dim myValue As Object
      Dim myChars As Char()
      Dim myValues As Object()
      Dim myShape As Integer()
      Dim myIndexing As Indexing

      UtilsShape.CheckValue(aValue)
      UtilsShape.CheckValue(aSubscript)
      myIndexing = New Indexing(Shape, aSubscript)
      myShape = aValue.Shape
      If UtilsShape.TimesReduce(myShape) <> 1 Then
        If Not SameShapes(myShape, myIndexing.ResultShape) Then
          ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
        End If
      End If

      mySize = UtilsShape.TimesReduce(myIndexing.ResultShape) - 1
      If IsCharacter AndAlso aValue.IsCharacter Then
        SubString(mySize, myIndexing) = aValue.CharacterVector

      Else
        If IsCharacter Then
          ' This implementation only supports characters and numbers
          ' (numbers include enclosed arrays)
          '    aValue.Sub()=
          ' doesn't return a value like all other APL functions
          ' it transforms aValue
          ' So if you assign numbers to characters,
          ' the characters have to transform themselves into numbers
          myChars = UtilsStrict.Chars(thisCharacters)
          thisCharacters = Nothing

          ReDim thisValues(myChars.Length - 1)
          Array.Copy(myChars, thisValues, myChars.Length)
        End If

        myValues = aValue.ValueVector

        If aValue.Rank = 0 Then
          myValue = myValues(0)
          For myIndex = 0 To mySize
            thisValues(myIndexing.Next) = myValue
          Next

        Else
          For myIndex = 0 To mySize
            thisValues(myIndexing.Next) = myValues(myIndex)
          Next
        End If
      End If
    End Set
  End Property

  Private Property SubString( _
      ByVal aSize As Integer, _
      ByVal anIndexing As Indexing) _
      As String
    Get
      Dim myValue As Char()
      Dim myIndex As Integer

      CheckCharset()
      ReDim myValue(aSize)
      For myIndex = 0 To myValue.Length - 1
        myValue(myIndex) = thisCharacters(anIndexing.Next)
      Next

      Return myValue
    End Get

    Set(ByVal aValue As String)
      Dim myIndex As Integer
      Dim myResult As Char()
      Dim myChar As Char

      myResult = UtilsStrict.Chars(CharacterVector)
      If aValue.Length = 1 Then
        myChar = aValue(0)
        For myIndex = 0 To aSize
          myResult(anIndexing.Next) = myChar
        Next

      Else
        For myIndex = 0 To aSize
          myResult(anIndexing.Next) = aValue(myIndex)
        Next
      End If

      thisCharacters = myResult
    End Set
  End Property

  Private Function SameShapes(ByVal aLeft As Integer(), ByVal aRight As Integer()) As Boolean
    Dim myIndex As Integer

    If aLeft.Length = aRight.Length Then
      For myIndex = 0 To aLeft.Length - 1
        If aLeft(myIndex) <> aRight(myIndex) Then
          Return False
        End If
      Next
      Return True

    Else
      Return False
    End If
  End Function

#End Region

#Region "Append and AppendLine"

  ''' <summary>
  ''' Provides a high speed way of doing
  ''' Character Catenations to a single value.
  ''' </summary>
  Public Sub Append(ByVal aVector As String)
    Append(False, aVector)
  End Sub

  ''' <summary>
  ''' Provides a high speed way of doing
  ''' Character Catenations to a single value,
  ''' with the addition of a NewLine at the end.
  ''' </summary>
  Public Sub AppendLine(ByVal aVector As String)
    Append(True, aVector)
  End Sub

  Private Sub Append(ByVal aLine As Boolean, ByVal aVector As String)
    UtilsShape.CheckValue(aVector)
    If IsCharacter AndAlso Rank = 1 Then
      If thisCharacters IsNot Nothing Then
        thisStringBuilder = New StringBuilder(thisCharacters)
        thisCharacters = Nothing
      End If

      If aLine Then
        thisStringBuilder.AppendLine(aVector)
      Else
        thisStringBuilder.Append(aVector)
      End If
      thisShape(0) = thisStringBuilder.Length

    Else
      ExceptionAPL.Signal(ExceptionAPL.Is.Nonce)
    End If
  End Sub

#End Region

#Region "Clone"

  ''' <summary>
  ''' Makes a safe copy of this value.
  ''' </summary>
  Public ReadOnly Property Clone() As APL
    Get
      Dim myResult As APL

      If IsCharacter Then
        myResult = New APL(CharacterVector)

      Else
        myResult = New APL(ValueVector)
      End If
      myResult.Shape = thisShape
      Return myResult
    End Get
  End Property

#End Region

#Region "Shape Rank"
  ''' <summary>
  ''' Provides the Shape of this APL object.
  '''    obj.Shape = newShape
  ''' Provides a way to reassign the shape of this
  ''' APL object.  Guranteed to provide a proper 
  ''' value vector.
  ''' </summary>
  Public Property Shape() As Integer()
    Get
      Return DirectCast(thisShape.Clone, Integer())
    End Get

    Set(ByVal aValue As Integer())
      Dim myOld, myNew, myItem As Integer

      myOld = UtilsShape.TimesReduce(thisShape)
      myNew = UtilsShape.TimesReduce(aValue)

      If myOld = 0 Then
        If myNew <> 0 Then
          ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
        End If
      End If

      If myNew = 0 Then
        If IsCharacter Then
          thisCharacters = ""
          thisStringBuilder = Nothing

        Else
          thisValues = New Object() {}
        End If

      Else
        If IsCharacter Then
          ' N.B. myOld = myNew requires no work
          If myOld <> myNew Then
            CheckCharset()
            Do Until thisCharacters.Length > myNew
              thisCharacters = thisCharacters & thisCharacters
            Loop

            thisCharacters = thisCharacters.Substring(0, myNew)
          End If

        Else
          ReDim Preserve thisValues(myNew - 1)
          For myItem = myOld To myNew - 1
            thisValues(myItem) = thisValues(myItem Mod myOld)
          Next
        End If
      End If

      thisShape = aValue
    End Set
  End Property

  ''' <summary>
  ''' Provides the Rank of this APL object.
  ''' </summary>
  Public ReadOnly Property Rank() As Integer
    Get
      Return thisShape.Length
    End Get
  End Property

#End Region

#Region "VectorLength"

  Public ReadOnly Property VectorLength() As Integer
    Get
      If IsCharacter Then
        If thisStringBuilder IsNot Nothing Then
          Return thisStringBuilder.Length

        Else
          Return thisCharacters.Length
        End If

      Else
        Return thisValues.Length
      End If
    End Get
  End Property

#End Region

#Region "ValueVector and CompareValues"

  ''' <summary>
  ''' Return a vector of numerics if this value has any.
  ''' The values can be safely assigned to another value.
  ''' Signals an ExceptionAPL if no numeric values.
  ''' </summary>
  Public ReadOnly Property ValueVector() As Object()
    Get
      If IsCharacter Then
        ' No need to clone again
        Return CompareValues
      Else
        ' Clone whenever the value will be used for next result
        Return DirectCast(CompareValues.Clone, Object())
      End If
    End Get
  End Property

  ''' <summary>
  ''' Return a vector of numerics if this value has any.
  ''' The values may not be safely assigned to another value.
  ''' Signals an ExceptionAPL if no numeric values.
  ''' </summary>
  Public ReadOnly Property CompareValues() As Object()
    ' Don't bother to Clone for Compare purposes
    Get
      Dim myValues As Object()
      Dim myChars As Char()

      If IsCharacter Then
        ' APL2 requires a few functions to be type agnostic
        ' So if called when the type is characters, the
        ' result must be transformed into an array of
        ' scalar characters

        CheckCharset()
        ReDim myValues(thisCharacters.Length - 1)
        myChars = UtilsStrict.Chars(thisCharacters)
        Array.Copy(myChars, myValues, myChars.Length)
        Return myValues

      Else
        Return thisValues
      End If
    End Get
  End Property

#End Region

#Region "IsCharacter CharacterVector"

  Public ReadOnly Property IsCharacter() As Boolean
    Get
      Return thisCharacters IsNot Nothing OrElse _
          thisStringBuilder IsNot Nothing
    End Get
  End Property

  ''' <summary>
  ''' Returns a String of character values.
  ''' Permits this array to be multidimensional.
  ''' Signals an ExceptionAPL for all other values.
  ''' </summary>
  Public ReadOnly Property CharacterVector() As String
    Get
      If Not IsCharacter Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End If
      CheckCharset()
      Return thisCharacters
    End Get
  End Property

  Private Sub CheckCharset()
    If thisStringBuilder IsNot Nothing Then
      thisCharacters = thisStringBuilder.ToString
      thisStringBuilder = Nothing
    End If
  End Sub

#End Region

#Region "IntegerVector and SubscriptVector"

  ''' <summary>
  ''' Returns a vector of Integer values.
  ''' Signals an ExceptionAPL for all other values.
  ''' </summary>
  Public ReadOnly Property IntegerVector() As Integer()
    Get
      If Rank > 1 Then _
          ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
      Return SubscriptVector
    End Get
  End Property

  ''' <summary>
  ''' Returns a vector of Integer values.
  ''' Permits this array to be multidimensional.
  ''' Signals an ExceptionAPL for all other values.
  ''' </summary>
  Public ReadOnly Property SubscriptVector() As Integer()
    Get
      If thisShape.Length = 1 AndAlso thisShape(0) = 0 Then
        Return New Integer() {}
      End If

      If IsCharacter Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
      End If
      Return UtilsStrict.Integers(thisValues)
    End Get
  End Property

#End Region

#Region "IntegerIndex and DoubleIndex"

  ''' <summary>
  ''' Returns a single Integer value.
  ''' Signals an ExceptionAPL for all other values.
  ''' </summary>
  Public Function IntegerIndex() As Integer
    If thisValues.Length <> 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Length)
    End If

    Return IntegerVector(0)
  End Function

  ''' <summary>
  ''' Returns a single Double value.
  ''' Signals an ExceptionAPL for all other values.
  ''' </summary>
  Public Function DoubleIndex() As Double
    If Rank > 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If
    If IsCharacter Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If
    If thisValues.Length <> 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Length)
    End If

    Return CType(thisValues(0), Double)
  End Function

#End Region

#Region "SameShape"

  ''' <summary>
  ''' Returns True if the shape provided in aRight is
  ''' the same as this value.
  ''' </summary>
  Public Function SameShape(ByVal aRight As Integer()) As Boolean
    Dim myIndex As Integer

    If thisShape.Length = aRight.Length Then
      For myIndex = 0 To thisShape.Length - 1
        If thisShape(myIndex) <> aRight(myIndex) Then
          Return False
        End If
      Next
      Return True
    Else
      Return False
    End If
  End Function

#End Region

#Region "IsTrue and IsFalse"

  ''' <summary>
  ''' Returns True IfAndOnlyIf this value is a single 1.
  ''' Returns False IfAndOnlyIf this value is a single 0.
  ''' Signals an ExceptionAPL for all other values.
  ''' </summary>
  Public ReadOnly Property IsTrue() As Boolean
    Get
      If VectorLength <> 1 Then
        ExceptionAPL.Signal(ExceptionAPL.Is.Length)
      End If
      Return UtilsStrict.IsBool(CompareValues(0)) = 1
    End Get
  End Property

  ''' <summary>
  ''' Returns False IfAndOnlyIf this value is a single 1.
  ''' Returns True IfAndOnlyIf this value is a single 0.
  ''' Signals an ExceptionAPL for all other values.
  ''' </summary>
  Public ReadOnly Property IsFalse() As Boolean
    Get
      Return Not IsTrue
    End Get
  End Property

#End Region

#Region "ToString"

  ''' <summary>
  ''' Returns a String representation of an APL object.
  ''' </summary>
  Public Overrides Function ToString() As String
    If IsCharacter Then
      Return Displays
    Else
      Return _APL._Display(Me).Displays
    End If
  End Function

  ''' <summary>
  ''' Breaks properly on Rows and Matrices
  ''' However, does not introduce extra blank rows
  ''' when Rank > 3
  ''' </summary>
  Private ReadOnly Property Displays() As String
    Get
      Dim myResult As StringBuilder
      Dim myIndex, myRowLength, myRowsLength As Integer

      RowLengths(myRowLength, myRowsLength)
      If myRowLength = -1 Then
        Return CharacterVector
      ElseIf VectorLength = 0 Then
        Return ""
      Else
        myResult = New StringBuilder()
        CheckCharset()
        For myIndex = 0 To thisCharacters.Length - 1 Step myRowLength
          myResult.AppendLine(thisCharacters.Substring(myIndex, myRowLength))
          If myRowsLength <> -1 AndAlso 0 = (myIndex + myRowLength) Mod myRowsLength Then
            myResult.AppendLine()
          End If
        Next

        Return myResult.ToString.TrimEnd(ControlChars.Cr, ControlChars.Lf)
      End If
    End Get
  End Property

  Private Sub RowLengths( _
      ByRef aRowLength As Integer, _
      ByRef aRowsLength As Integer)
    aRowLength = -1
    aRowsLength = -1
    If thisShape.Length > 1 Then
      aRowLength = thisShape(thisShape.Length - 1)
      If thisShape.Length > 2 Then
        aRowsLength = aRowLength * thisShape(thisShape.Length - 2)
      End If
    End If
  End Sub

#End Region

#Region "ToStrings"

  ''' <summary>
  ''' Format every element as a constant element
  ''' </summary>
  Public ReadOnly Property ToStrings() As String()
    Get
      Dim myResults As String()
      Dim myItem As Object
      Dim myIndex As Integer

      ReDim myResults(thisValues.Length - 1)
      For myIndex = 0 To myResults.Length - 1
        myItem = thisValues(myIndex)
        If TypeOf myItem Is String Then
          myResults(myIndex) = Quote(DirectCast(myItem, String))
        ElseIf TypeOf myItem Is Char Then
          myResults(myIndex) = Quote(DirectCast(myItem, Char))
        ElseIf TypeOf myItem Is APL Then
          myResults(myIndex) = Quote(DirectCast(myItem, APL).ToString)
        Else
          myResults(myIndex) = myItem.ToString
        End If
      Next
      Return myResults
    End Get
  End Property

  Private Function Quote(ByVal aLine As String) As String
    aLine = aLine.Replace("""", """""")
    Return """" & aLine & """"
  End Function

#End Region

End Class