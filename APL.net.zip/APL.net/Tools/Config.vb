Option Explicit On
Option Strict On
Imports Microsoft.Win32
Imports System.Windows.Forms

#Region "Config Class"

Public Class Config
  Private thisRoot As String
  Private thisRegistry As Registry
  Private thisBase As RegistryKey

  Public Sub New(ByVal aHive As RegistryKey)
    thisBase = aHive
  End Sub

  Public Sub New(ByVal aHive As RegistryKey, ByVal aSection As String)
    thisBase = aHive
    thisRoot = Names.Combine(aSection, "")
  End Sub

#Region "Value, Values, Sections, Delete"

  Public Property Value(ByVal aSection As String, ByVal aName As String) As Object
    Get
      Dim myReg As RegistryKey
      myReg = thisBase.OpenSubKey(thisRoot & aSection, False)
      If myReg Is Nothing Then
        Return Nothing
      Else
        Return myReg.GetValue(aName)
      End If
    End Get

    Set(ByVal aValue As Object)
      Dim myReg As RegistryKey

      myReg = thisBase.CreateSubKey(thisRoot & aSection)
      myReg.SetValue(aName, aValue)
      myReg.Flush()
    End Set
  End Property

  Public Function Values(ByVal aSection As String) As Collections.SortedList
    Dim myReg As RegistryKey
    Dim myNames() As String
    Dim myName As String
    Dim myResult As New Collections.SortedList

    Try
      myReg = thisBase.OpenSubKey(thisRoot & aSection)
      aSection = Names.Combine(aSection, "")

      myNames = myReg.GetValueNames()
      For Each myName In myNames
        myResult.Add(aSection & myName, myReg.GetValue(myName))
      Next
    Catch ex As Exception
    End Try

    Return myResult
  End Function

  Public Function Sections(ByVal aSection As String) As Collections.SortedList
    Dim myReg As RegistryKey
    Dim myNames() As String
    Dim myName As String
    Dim myResult As New Collections.SortedList

    myReg = thisBase.OpenSubKey(thisRoot & aSection)
    aSection = Names.Combine(aSection, "")

    myNames = myReg.GetSubKeyNames()
    For Each myName In myNames
      myResult.Add(Names.Combine(aSection & myName, ""), myReg.GetValue(myName).ToString)
    Next

    Sections = myResult
  End Function

  Public Sub Delete(ByVal aSection As String, Optional ByVal aName As String = Nothing)
    Dim myReg As RegistryKey

    If aName Is Nothing Then
      myReg = Registry.CurrentUser.OpenSubKey(thisRoot)
      myReg.DeleteSubKey(aSection)

    Else
      myReg = Registry.CurrentUser.OpenSubKey(Names.Combine(thisRoot, aSection))
      myReg.DeleteValue(aName)
    End If
  End Sub

#End Region

#Region "Value with aDefault"

  Public Property Value( _
      ByVal aSection As String, _
      ByVal aName As String, _
      ByVal aDefault As String) _
      As String
    Get
      Dim myValue As Object

      myValue = Value(aSection, aName)
      If myValue IsNot Nothing Then
        Return myValue.ToString

      Else
        Return aDefault
      End If
    End Get

    Set(ByVal aValue As String)
      If aDefault Is Nothing OrElse aDefault <> aValue Then
        Value(aSection, aName) = aValue
      End If
    End Set
  End Property

#End Region

#Region "OpenWith"

  Public Shared Sub OpenWith( _
    ByVal anExt As String, _
    ByVal anApp As String, _
    ByVal aType As String, _
    ByVal aName As String)

    Dim myConfig As New Config(Microsoft.Win32.Registry.ClassesRoot)

    myConfig.Value(anExt, Nothing) = aName
    myConfig.Value(aName, Nothing) = aType
    myConfig.Value(aName & "\shell\open\command", Nothing) = anApp
  End Sub

#End Region

End Class

#End Region

#Region "Program Class"

Public Class Program
  Inherits Config

  Public Sub New(ByVal aProgram As String)
    MyBase.New(Microsoft.Win32.Registry.CurrentUser, "Software\" & aProgram)
  End Sub

  Public Function Location(ByVal aForm As Form, ByVal aName As String) As Location
    Return New Location(Me, aForm, aName)
  End Function

End Class

#End Region

#Region "Location Class"

Public Class Location
  Private thisConfig As Config
  Private thisForm As Form
  Private thisName As String
  Private thisLocation As String

  Friend Sub New(ByVal aConfig As Program, ByVal aForm As Form, ByVal aName As String)
    thisConfig = aConfig
    thisForm = aForm
    thisName = aName
    Location(True)
  End Sub

  Public Sub Close()
    Location(False)
  End Sub

  Private Sub Location(ByVal anOpen As Boolean)
    ' Provides memory of position, and repositioning of thisForm
    ' When opening thisForm:
    ' Resizes to previous size and positions at previous location
    ' Maximizes when it was previously Maximized
    ' When closing thisForm:
    ' Remembers current size, unless Maximized or Minimized,
    ' and whether thisForm was Maximized or Normal
    Dim myLocation As String
    Dim mySplit() As String

    With thisForm
      If .Left < 0 Then
        .Left = 0
      End If

      If .Top < 0 Then
        .Top = 0
      End If

      myLocation = .Left & "," & .Top & "," & _
                   .Width & "," & .Height

      If anOpen Then
        thisLocation = thisConfig.Value(thisName, "Location", "")
        If thisLocation.Length = 0 Then
          thisLocation = myLocation & "," & .WindowState

        Else
          mySplit = thisLocation.Split(",".ToCharArray)
          .Left = Integer.Parse(mySplit(0))
          .Top = Integer.Parse(mySplit(1))
          .Width = Integer.Parse(mySplit(2))
          .Height = Integer.Parse(mySplit(3))
          If mySplit(4) = "1" Then
            .WindowState = FormWindowState.Maximized
          End If
        End If

      Else
        If .WindowState = FormWindowState.Normal Then
          myLocation &= ",0"

        Else
          myLocation = thisLocation.Substring(0, thisLocation.Length - 1)
          If .WindowState = FormWindowState.Maximized Then
            myLocation &= "1"

          Else
            myLocation &= "0"
          End If
        End If

        thisConfig.Value(thisName, "Location", thisLocation) = myLocation
      End If
    End With
  End Sub

End Class

#End Region
