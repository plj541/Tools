Option Explicit On
Option Strict On
Imports System.Windows.Forms
Imports System.Text

Public Class Host

#Region "Launch"

  Public Shared Function Launch( _
      ByVal aFile As String, _
      ByVal ParamArray anArgs As String()) _
      As Integer
    Return Launch(aFile, "", True, ProcessWindowStyle.Normal, anArgs)
  End Function

  Public Shared Function Launch( _
      ByVal aFile As String, _
      ByVal anArg As String, _
      ByVal aWait As Boolean, _
      ByVal aStyle As ProcessWindowStyle, _
      ByVal ParamArray anArgs As String()) _
      As Integer
    Dim myCommand As System.Diagnostics.ProcessStartInfo
    Dim myProcess As Process
    Dim myArg, myArgs As String

    myArgs = anArg
    For Each myArg In anArgs
      myArgs &= Quote(myArg)
    Next

    myCommand = New System.Diagnostics.ProcessStartInfo
    With myCommand
      .FileName = aFile
      .Arguments = myArgs
      .WindowStyle = aStyle
    End With

    myProcess = Diagnostics.Process.Start(myCommand)
    If aWait Then
      With myProcess
        Do While Not .HasExited()
          .WaitForExit(100)
        Loop
        Return .ExitCode
      End With
    End If
  End Function

  Private Shared Function Quote(ByVal aName As String) As String
    Return String.Format(" ""{0}""", aName.Replace("""", """"""))
  End Function

#End Region

#Region "LaunchWith"

  Private Declare Function FindExecutable Lib "shell32.dll" _
      Alias "FindExecutableA" (ByVal lpFile As String, _
      ByVal lpDirectory As String, _
      ByVal lpResult As String) As Int32

  Public Shared Function LaunchWith( _
      ByVal aFile As String) _
      As String
    ' Find the application associated with aFile
    Dim myFile, myPath, myResult As String
    Dim myReturn As Long
    Dim mySample As Boolean

    myFile = Space(257)
    myPath = ""

    If aFile.StartsWith(".") Then
      aFile = Temp() & "\Tools.Launch.Temp" & aFile
      Try
        Files.Lines(aFile) = ""
        mySample = True
      Catch ex As Exception
      End Try
    End If

    myReturn = FindExecutable(aFile, myPath, myFile)
    If myReturn > 32 Then
      myResult = Left(myFile, InStr(myFile, ControlChars.NullChar) - 1)

    Else
      myResult = Nothing
    End If

    If mySample Then
      Names.Erase(aFile)
    End If

    Return myResult
  End Function

#End Region

#Region "Recycle"

  Public Shared Sub Recycle( _
      ByVal aPath As String)
    Try
      If My.Computer.FileSystem.DirectoryExists(aPath) Then
        My.Computer.FileSystem.DeleteDirectory(aPath, _
            FileIO.UIOption.OnlyErrorDialogs, _
            FileIO.RecycleOption.SendToRecycleBin)
      Else
        My.Computer.FileSystem.DeleteFile(aPath, _
            FileIO.UIOption.OnlyErrorDialogs, _
            FileIO.RecycleOption.SendToRecycleBin)
      End If

    Catch ex As Exception
      ' Ignore errors
    End Try
  End Sub

#End Region

#Region "Desktop, MyDocuments, Program, ProgramFiles and Temp"

  Public Shared ReadOnly Property Desktop() As String
    Get
      Return My.Computer.FileSystem.SpecialDirectories.Desktop
    End Get
  End Property

  Public Shared ReadOnly Property MyDocuments() As String
    Get
      Return My.Computer.FileSystem.SpecialDirectories.MyDocuments
    End Get
  End Property

  Public Shared ReadOnly Property Program() As String
    Get
      Return My.Application.Info.DirectoryPath
    End Get
  End Property

  Public Shared ReadOnly Property ProgramFiles() As String
    Get
      Return My.Computer.FileSystem.SpecialDirectories.ProgramFiles
    End Get
  End Property

  Public Shared ReadOnly Property Temp() As String
    Get
      Return My.Computer.FileSystem.SpecialDirectories.Temp
    End Get
  End Property

#End Region

#Region "WebPage"

  Public Shared Function WebPage(ByVal aURL As String) As String
    Dim myHTTP As New Net.WebClient

    myHTTP.Proxy = Net.WebRequest.DefaultWebProxy
    Return Encoding.UTF8.GetString(myHTTP.DownloadData(aURL))
  End Function

  Public Shared Function WebData(ByVal aFile As String, ByVal aURL As String) As Byte()
    Dim myHTTP As New Net.WebClient

    myHTTP.Proxy = Net.WebRequest.DefaultWebProxy
    Return myHTTP.DownloadData(aURL)
  End Function

#End Region

End Class