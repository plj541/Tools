﻿Option Explicit On
Option Strict On
Imports System.IO
Imports System.Text

Public Class Names
  Private Shared thisSeparator As String = Separator

#Region "Separator"

  Public Shared ReadOnly Property Separator() As String
    Get
      If thisSeparator IsNot Nothing Then
        Return thisSeparator

      ElseIf Environment.CommandLine.StartsWith("/") Then
        Return "/"

      Else
        Return "\"
      End If
    End Get
  End Property

#End Region

#Region "Combine and IsFile"

  Public Shared Function Combine(ByVal aPath As String, ByVal aFile As String) As String
    If Not aPath.EndsWith(thisSeparator) AndAlso aPath.Length <> 0 Then
      aPath &= thisSeparator
    End If

    If aFile.StartsWith(thisSeparator) Then
      aFile = aFile.Substring(1)
    End If

    Return aPath & aFile
  End Function

  Public Shared Function IsFile(ByVal aPath As String) As Boolean
    ' Test if aPath is a File
    Return IO.File.Exists(aPath)
  End Function

#End Region

#Region "CreateFolder, IsFolder and Path"

  Public Shared Function CreateFolder(ByVal aPath As String) As String
    ' Ensure a directory exists
    If Not IsFolder(aPath) Then
      Directory.CreateDirectory(aPath)
    End If
    Return aPath
  End Function

  Public Shared Function IsFolder(ByVal aPath As String) As Boolean
    ' Test if aPath is a Directory
    Return Directory.Exists(aPath)
  End Function

  Public Shared Property Path() As String
    Get
      Return Environment.CurrentDirectory
    End Get

    Set(ByVal aValue As String)
      Environment.CurrentDirectory = aValue
    End Set
  End Property

#End Region

#Region "Files and Paths"

  Public Shared Function Files(ByVal aPath As String) As String()
    ' Provide the files in 
    Dim myFiles As String()

    myFiles = IO.Directory.GetFiles(FullPath(aPath))
    Return AdjustNames(aPath, myFiles)
  End Function

  Public Shared Function Paths(ByVal aPath As String) As String()
    ' Provide the directories in aPath
    Dim myPaths As String()

    myPaths = IO.Directory.GetDirectories(FullPath(aPath))
    Return AdjustNames(aPath, myPaths)
  End Function

#End Region

#Region "FullPath and AdjustNames"

  Private Shared Function FullPath(ByVal aPath As String) As String
    If aPath.Contains(thisSeparator) Then
      Return aPath
    Else
      Return Combine(Path, aPath)
    End If
  End Function

  Private Shared Function AdjustNames(ByVal aPath As String, ByVal aNames As String()) As String()
    Dim myIndex As Integer

    If aPath.Length = 0 Then
      For myIndex = 0 To aNames.Length - 1
        aNames(myIndex) = Names.JustFile(aNames(myIndex))
      Next
    End If

    Return aNames
  End Function

#End Region

#Region "Just Folder, File, Ext and NoExt"

  Public Shared Function JustFolder(ByVal aPath As String) As String
    ' Return just the portion before the last \
    Dim myIndex As Integer

    myIndex = aPath.LastIndexOf(thisSeparator)
    If myIndex > 0 Then
      Return aPath.Substring(0, myIndex)

    Else
      Return ""
    End If
  End Function

  Public Shared Function JustFile(ByVal aPath As String) As String
    ' Return just the portion after the last \
    Dim myIndex As Integer

    myIndex = aPath.LastIndexOf(thisSeparator)
    If myIndex <> -1 Then
      Return aPath.Substring(myIndex + 1)

    Else
      Return aPath
    End If
  End Function

  Public Shared Function JustExt(ByVal aPath As String) As String
    ' Return just the EXT portion of FILE.EXT
    Dim myIndex As Integer
    Dim myFile As String

    myFile = JustFile(aPath)
    myIndex = myFile.LastIndexOf(".")
    If myIndex <> -1 Then
      Return myFile.Substring(myIndex + 1)

    Else
      Return ""
    End If
  End Function

  Public Shared Function JustNoExt(ByVal aPath As String) As String
    ' Return everything except .EXT
    Dim myIndex As Integer
    Dim myFile As String

    myFile = JustFile(aPath)
    myIndex = myFile.LastIndexOf(".")
    If myIndex <> -1 Then
      Return Combine(JustFolder(aPath), myFile.Substring(0, myIndex))

    Else
      Return aPath
    End If
  End Function

#End Region

#Region "Erase"

  Public Shared Sub [Erase](ByVal aPath As String)
    Try
      If My.Computer.FileSystem.DirectoryExists(aPath) Then
        My.Computer.FileSystem.DeleteDirectory(aPath, _
            FileIO.UIOption.OnlyErrorDialogs, _
            FileIO.RecycleOption.DeletePermanently)
      Else
        My.Computer.FileSystem.DeleteFile(aPath, _
            FileIO.UIOption.OnlyErrorDialogs, _
            FileIO.RecycleOption.DeletePermanently)
      End If
    Catch ex As Exception
    End Try
  End Sub

#End Region

#Region "Dialogs Open, Save and Folder"

  Public Shared Function OpenFileDialog( _
      ByVal aTitle As String, _
      ByVal aDirectory As String, _
      Optional ByVal aFileExists As Boolean = True, _
      Optional ByVal aFilter As String = "All Files|*", _
      Optional ByVal anIndex As Integer = 0, _
      Optional ByVal aFile As String = "", _
      Optional ByVal isMultiple As Boolean = False) _
      As String
    Dim myOpen As New Windows.Forms.OpenFileDialog

    With myOpen
      .Title = aTitle
      .InitialDirectory = aDirectory
      .CheckFileExists = aFileExists
      .Filter = aFilter
      .FilterIndex = anIndex
      .ReadOnlyChecked = False
      .FileName = aFile
      .Multiselect = isMultiple

      If .ShowDialog = Windows.Forms.DialogResult.OK Then
        Return Join(myOpen.FileNames, ControlChars.Lf)

      Else
        Return Nothing
      End If
    End With
  End Function

  Public Shared Function SaveFileDialog( _
      ByVal aTitle As String, _
      ByVal aDirectory As String, _
      Optional ByVal aFilter As String = "All Files|*", _
      Optional ByVal anIndex As Integer = 0, _
      Optional ByVal aFile As String = "") _
      As String
    Dim myOpen As New Windows.Forms.SaveFileDialog

    With myOpen
      .Title = aTitle
      .InitialDirectory = aDirectory
      .FileName = aFile
      .Filter = aFilter
      .FilterIndex = anIndex

      If .ShowDialog = Windows.Forms.DialogResult.OK Then
        Return .FileName

      Else
        Return Nothing
      End If
    End With
  End Function

  Public Shared Function FolderBrowserDialog( _
      ByVal aDirectory As String) _
      As String
    Dim myOpen As New Windows.Forms.FolderBrowserDialog
    With myOpen
      .SelectedPath = aDirectory
      If .ShowDialog = Windows.Forms.DialogResult.OK Then
        Return .SelectedPath

      Else
        Return Nothing
      End If
    End With
  End Function

#End Region

End Class
