﻿Option Explicit On
Option Strict On
Imports System.IO
Imports System.Text

Public Class Files
  Private thisInPath, thisOutPath, thisFilter, thisNext As String
  Private thisNames As String()
  Private thisNamesIndex As Integer

  Public Shared Property Lines(ByVal aPath As String) As String
    Get
      Dim myReader As New IO.StreamReader(aPath, Encoding.Default)
      Dim myResult As String

      myResult = myReader.ReadToEnd()
      myReader.Close()
      Return myResult
    End Get

    Set(ByVal aValue As String)
      Dim myWriter As New IO.StreamWriter(aPath, False, Encoding.UTF8)

      myWriter.Write(aValue)
      myWriter.Close()
    End Set
  End Property

  Public Shared Property Bytes(ByVal aFile As String) As Byte()
    Get
      Return IO.File.ReadAllBytes(aFile)
    End Get

    Set(ByVal aValue As Byte())
      IO.File.WriteAllBytes(aFile, aValue)
    End Set
  End Property

#Region "New variants, with SetPaths and FirstFile"

  Public Sub New( _
      ByVal anInFolder As String, _
      ByVal anOutFolder As String)
    SetPaths(anInFolder, anOutFolder)
  End Sub

  Public Sub New( _
      ByVal anInFolder As String, _
      ByVal aFilter As String, _
      ByVal anOutFolder As String)
    SetPaths(anInFolder, anOutFolder)
    thisFilter = aFilter
    thisNext = FirstFile(thisInPath, thisFilter)
  End Sub

  Public Sub New( _
      ByVal anInFolder As String, _
      ByVal aFileList As String(), _
      ByVal anOutFolder As String)
    SetPaths(anInFolder, anOutFolder)
    thisNames = aFileList
  End Sub

  Public Sub Renew()
    thisNamesIndex = 0
    If thisFilter IsNot Nothing Then
      thisNext = FirstFile(thisInPath, thisFilter)
    End If
  End Sub

  Public Sub Renew(ByVal aFilter As String)
    thisNames = Nothing
    thisNext = FirstFile(thisInPath, aFilter)
  End Sub

  Public Sub Renew(ByVal aFileList As String())
    thisNext = Nothing
    thisNames = aFileList
    thisNamesIndex = 0
  End Sub

  Private Sub SetPaths( _
      ByVal anInFolder As String, _
      ByVal anOutFolder As String)
    thisInPath = anInFolder
    thisOutPath = anOutFolder
  End Sub

  Private Function FirstFile(ByVal anInPath As String, ByVal aFilter As String) As String
    Dim myName As String

    myName = Dir(Names.Combine(thisInPath, aFilter))
    If myName = "" Then
      Return Nothing

    Else
      Return myName
    End If
  End Function

#End Region

#Region "File and Folder"

  Public Sub File()
    File("All Files|*")
  End Sub

  Public Sub File(ByVal aFilter As String)
    Dim myName As String

    myName = Names.OpenFileDialog("Choose a File", thisInPath, _
                               True, aFilter, 1)
    If myName IsNot Nothing Then
      thisInPath = Names.Path
      ReDim thisNames(0)
      thisNames(0) = myName.Substring(thisInPath.Length + 1)
    End If
  End Sub

  Public Sub Folder()
    Folder(Nothing)
  End Sub

  Public Sub Folder(ByVal aFilter As String)
    Dim myName As String

    If aFilter IsNot Nothing Then
      myName = thisInPath

    Else
      myName = thisOutPath
    End If

    myName = Names.FolderBrowserDialog(myName)

    If myName IsNot Nothing Then
      If aFilter IsNot Nothing Then
        thisInPath = myName
        thisNext = FirstFile(thisInPath, aFilter)

      Else
        thisOutPath = myName
      End If
    End If
  End Sub

#End Region

#Region "Next"

  Public ReadOnly Property [Next]() As String
    Get
      Dim myFile As String

      If thisNames IsNot Nothing Then
        If thisNamesIndex < thisNames.Length Then
          myFile = thisNames(thisNamesIndex)
          thisNamesIndex += 1
          Return myFile
        End If

      Else
        myFile = thisNext
        If thisNext IsNot Nothing Then
          thisNext = Dir()
          Return myFile
        End If
      End If

      Return Nothing
    End Get
  End Property

#End Region

#Region "AllLines, ReadLines, WriteLines, AppendLines"

  Public Property AllLines(ByVal aFile As String) As String
    Get
      Return Files.Lines(Names.Combine(thisInPath, aFile))
    End Get

    Set(ByVal aValue As String)
      Files.Lines(Names.Combine(thisOutPath, aFile)) = aValue
    End Set
  End Property

  Public Function ReadLines(ByVal aFile As String) As LinesIn
    Return New LinesIn(Names.Combine(thisInPath, aFile), Encoding.Default)
  End Function

  Public Function WriteLines(ByVal aFile As String) As LinesOut
    Return New LinesOut(Names.Combine(thisOutPath, aFile), False, Encoding.UTF8)
  End Function

  Public Function AppendLines(ByVal aFile As String) As LinesOut
    Return New LinesOut(Names.Combine(thisOutPath, aFile), True, Encoding.UTF8)
  End Function

#End Region

End Class

#Region "Class LinesIn and LinesOut"

Public Class LinesIn
  Private thisInput As StreamReader

  Public Sub New( _
    ByVal aFile As String, _
    ByVal anEncoding As System.Text.Encoding)
    thisInput = New StreamReader(aFile, anEncoding)
  End Sub

  Public ReadOnly Property Line() As String
    Get
      If thisInput Is Nothing Then Return Nothing
      Return thisInput.ReadLine
    End Get
  End Property

  Public Sub Close()
    If thisInput IsNot Nothing Then
      thisInput.Close()
      thisInput = Nothing
    End If
  End Sub

End Class

Public Class LinesOut
  Friend thisOutput As StreamWriter

  Public Sub New( _
      ByVal aFile As String, _
      ByVal anAppend As Boolean, _
      ByVal anEncoding As System.Text.Encoding)
    thisOutput = New StreamWriter(aFile, anAppend, anEncoding)
  End Sub

  Public WriteOnly Property Line() As String
    Set(ByVal aValue As String)
      If thisOutput Is Nothing Then Exit Property
      thisOutput.WriteLine(aValue)
    End Set
  End Property

  Public Sub Flush()
    If thisOutput IsNot Nothing Then
      thisOutput.Flush()
    End If
  End Sub

  Public Sub Close()
    If thisOutput IsNot Nothing Then
      thisOutput.Close()
      thisOutput = Nothing
    End If
  End Sub

  Public Property AutoFlush() As Boolean
    Get
      If thisOutput IsNot Nothing Then
        Return thisOutput.AutoFlush
      End If
    End Get

    Set(ByVal aValue As Boolean)
      If thisOutput IsNot Nothing Then
        thisOutput.AutoFlush = aValue
      End If
    End Set
  End Property

End Class


#End Region
