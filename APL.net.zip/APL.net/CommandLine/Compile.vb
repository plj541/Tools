﻿Imports System.Text
Imports Tools
Imports PLJsAPL

Partial Public Class Commands

#Region "AdjustProject"

  Private Sub AdjustProject()
    Dim myPath, myCompile, myPart, myLast, myFile As String
    Dim myParts As String()
    Dim myLib As SortedList(Of String, String)
    Dim myResult As StringBuilder

    myPath = Names.Path
    Try
      Names.Path = thisLibPath
      myCompile = Files.Lines("WorkSpaces.vbproj")

      ' Get the Compile entries
      myParts = Split(myCompile, "<Compile ")
      myPart = myParts(myParts.Length - 1)
      myLast = myPart.Substring(myPart.IndexOf("</ItemGroup>"))
      myParts(myParts.Length - 1) = myPart.Substring(0, myPart.Length - myLast.Length)

      ' Keep the ones which still exist
      myLib = New SortedList(Of String, String)
      For myIndex = 1 To myParts.Length - 1
        myPart = myParts(myIndex)
        myFile = NameFrom(myPart)
        If myFile.Contains("\") OrElse Names.IsFile(myFile) Then
          myLib.Add(myFile, myPart)
        End If
      Next

      ' Add the new compiled workspaces
      myFile = Dir("*.aplws")
      Do Until myFile Is Nothing
        myFile = Names.JustNoExt(myFile) & ".vb"
        If Not myLib.Keys.Contains(myFile) AndAlso Names.IsFile(myFile) Then
          myLib.Add(myFile, CreateCompile(myFile))
        End If
        myFile = Dir()
      Loop

      ' Put the Compile list back in the control file
      myResult = New StringBuilder(myParts(0))
      For Each myPart In myLib.Values
        myResult.Append("<Compile ")
        myResult.Append(myPart)
      Next
      myResult.Append(myLast)

      ' Recreate the control file
      Files.Lines("WorkSpaces.vbproj") = myResult.ToString

    Catch ex As Exception
      Names.Path = myPath
      Output(ex.Message)
      _Signal(ExceptionAPL.Is.Domain)
    End Try

    Names.Path = myPath
  End Sub

#End Region

#Region "NameFrom CreateCompile"

  Private Function NameFrom(ByVal aLine As String) As String
    Return aLine.Split(""""c)(1)
  End Function

  Private Function CreateCompile(ByVal aName As String) As String
    aName = "Include=""" & aName
    aName &= """ />" & ControlChars.CrLf & "    "
    Return aName
  End Function

#End Region

End Class
