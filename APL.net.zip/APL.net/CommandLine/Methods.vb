﻿Imports PLJsAPL
Public Class Methods

#Region "Private Properties"

  Private thisEvaluate As Evaluate
  Private thisCompile As New Compile
  Private thisNames As New SortedList(Of String, Statements)

#End Region

  Public Sub New(ByVal anEvaluate As Evaluate)
    thisEvaluate = anEvaluate
  End Sub

#Region "Keys"

  Public ReadOnly Property Keys() As System.Collections.Generic.IList(Of String)
    Get
      Return thisNames.Keys
    End Get
  End Property

#End Region

#Region "Add"

  Public Sub Add(ByVal aName As String, ByVal aLines As String)
    Dim myStatements As Statements

    myStatements = New Statements(aLines, thisEvaluate, Me)
    thisNames.Add(aName, myStatements)
  End Sub

#End Region

#Region "Define"

  Public Function Define(ByVal aName As String) As String
    Dim myDef As String
    Dim myStatements As Statements

    myStatements = thisNames(aName)
    Try
      myDef = myStatements.Define(Me)
    Catch ex As ExceptionAPL
      _Out = aName & " got a " & ex.Message
      Return Nothing
      _Signal(ex.Event, "'" & aName & "'")
    Catch ex As Exception
      _Out = aName & " got a " & ex.Message
      Return Nothing
      _Signal(ExceptionAPL.Is.System, "'" & aName & "'" & _
              ControlChars.CrLf & ex.Message)
    End Try
    myDef = thisCompile.RemoveQuotes(myDef)
    ' ⍙
    myDef = myDef.Replace("⍙", "_" & aName & " ")
    myDef = myDef.Replace("_∆", "_" & aName & " ")
    myDef = myDef.Replace("[∆]", "[" & aName & "]")
    myDef = myDef.Replace("∆", " " & aName & " ")
    ' ⍺⍶⌶⍹⍵
    myDef = myDef.Replace("⍺", " l_a ")
    myDef = myDef.Replace("⍶", " l_f ")
    myDef = myDef.Replace("⌶", " a_x ")
    myDef = myDef.Replace("⍹", " r_f ")
    myDef = myDef.Replace("⍵", " r_a ")

    myDef = UtilsShape.RemoveDups(myDef, " ")
    ' Remove embedded blank
    myDef = myDef.Replace("l_a .", "l_a.")
    myDef = myDef.Replace("l_f .", "l_f.")
    myDef = myDef.Replace("a_x .", "a_x.")
    myDef = myDef.Replace("r_f .", "r_f.")
    myDef = myDef.Replace("r_a .", "r_a.")

    myDef = myDef.Replace(" (", "(")
    myDef = myDef.Replace(" )", ")")
    myDef = myDef.Replace(" [", "[")
    myDef = myDef.Replace(" ]", "]")

    myDef = thisCompile.RestoreQuotes(myDef)
    myDef = myDef.Replace(ControlChars.NullChar, """")
    Return myDef
  End Function

#End Region

#Region "Type"

  Public ReadOnly Property Type(ByVal aName As String) As Char
    Get
      Dim myDef As Statements
      If thisNames.ContainsKey(aName) Then
        myDef = thisNames(aName)
        Return myDef.Type
      Else
        Return "v"c
      End If
    End Get
  End Property

#End Region

End Class
