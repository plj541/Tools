﻿Imports System.Reflection
Imports System.Windows.Forms
Imports System.Text
Imports AltKeys
Imports PLJsAPL
Imports Tools

Partial Public Class Evaluate
  Inherits WorkSpace

  Private thisContext As Context
  Private thisValues As SortedList(Of String, Definition)

  Public Sub New(ByVal aPath As String)
    Link.LibPath(aPath)
    thisContext = _a.Context
    thisValues = New SortedList(Of String, Definition)
  End Sub

#Region "Evaluate"

  ''' <summary>
  ''' Execute with this instance of Evaluate as a context.
  ''' This makes public functions like Value available to the user.
  ''' </summary>
  ''' <remarks>
  ''' _Last is a property set by _a.Execute to preserve what was
  ''' the crucial statement or two of the compiled function.
  ''' </remarks>
  Friend Sub Evaluate(ByVal aLine As String)
    Dim myResult As Object

    Try
      If aLine.ToLower = "_x.last" Then
        _Out = thisContext._Last
        Return
      End If

      myResult = _a.Execute(_a.Value(aLine))
      If myResult IsNot Nothing Then
        _Out = myResult
      End If

    Catch ex As Exception
      _Out = ex.Message
    End Try
  End Sub

#End Region

  ' Friends

#Region "ValueOf Assign"

  Friend Function ValueOf(ByVal aName As String) As Definition
    If thisValues.ContainsKey(aName) Then
      Return thisValues.Item(aName)
    End If
    Return Nothing
  End Function

  Friend Sub Assign(ByVal aName As String, ByVal aValue As Object)
    Dim myDef As Definition

    myDef = New Definition(aName, aValue)
    If aName.StartsWith("∇") Then
      aName = aName.Substring(1)
    End If
    If thisValues.ContainsKey(aName) Then
      thisValues.Item(aName) = myDef
    Else
      thisValues.Add(aName, myDef)
    End If
  End Sub

#End Region

#Region "AllNames Set_My_Shell_ToMe"

  Friend Function AllNames() As String()
    Dim myNames As String()
    Dim myDef As Definition
    Dim myIndex As Integer

    ReDim myNames(thisValues.Count - 1)
    For Each myDef In thisValues.Values
      myNames(myIndex) = myDef.Name
      myIndex += 1
    Next
    Return myNames
  End Function

  Friend Sub My_Shell_IsMe(ByVal aLink As Link)
    Utils_Strict.My_Shell_IsMe(aLink, Me)
  End Sub

#End Region

  ' Public

#Region "LinkTo"

  Public Function LinkTo(ByVal aRight As APL) As Link
    Dim myObjects As Object()

    If aRight.Rank > 1 Then
      _Signal(ExceptionAPL.Is.Rank)
    End If

    If aRight.IsCharacter Then
      Return New Link(aRight.CharacterVector, "")
    ElseIf aRight.VectorLength <> 2 Then
      _Signal(ExceptionAPL.Is.Length)
    End If

    myObjects = aRight.ValueVector
    Return New Link(EnsureString(myObjects(1)), _
                    EnsureString(myObjects(0)))
  End Function

#End Region

#Region "Named"

  ''' <summary>
  ''' Value is invoked to handle names for a
  ''' ShellAPL session. 
  ''' </summary>
  ''' <remarks>
  ''' N.B. The names are case sensative, just like Value
  ''' </remarks>
  Public Property Named( _
      ByVal aName As String, _
      Optional ByVal aMsg As Boolean = True) _
      As Object
    Get
      Dim myValue As Object
      Dim myDef As Definition

      If Not aName.StartsWith("_") AndAlso IllegalName(aName) Then
        Return Nothing
      End If
      If thisValues.ContainsKey(aName) Then
        myDef = thisValues.Item(aName)
        If myDef.Name.StartsWith("∇") Then
          _Signal(ExceptionAPL.Is.Syntax, "'" & aName & "'")
        End If
        myValue = myDef.Value
        If TypeOf myValue Is Link Then
          Return DirectCast(myValue, Link).Value
        Else
          Return myValue
        End If
      Else
        If aMsg Then
          _Signal(ExceptionAPL.Is.Value, "'" & aName & "'")
        End If
        Return Nothing
      End If
    End Get

    Set(ByVal aValue As Object)
      Dim myDef As Definition

      If aName.StartsWith("∇") OrElse aName.ToLower = "me" Then
        ' N.B.  I have to restrict Me, but the list below may be better.
        ' " me if then else elseif do while until loop select case for each to step as of " _
        ' .Contains(" " & aName.ToLower & " ") Then
        _Signal(ExceptionAPL.Is.Syntax, aName & " =")
      ElseIf IllegalName(aName) Then
        Return
      End If
      If aValue Is Nothing Then
        _Signal(ExceptionAPL.Is.Value, "'" & aName & "'")
      End If

      myDef = ValueOf(aName)
      If myDef IsNot Nothing AndAlso _
          myDef.Name.StartsWith("∇") Then
        _Signal(ExceptionAPL.Is.Syntax, "'" & aName & "'")
      End If

      ' N.B. aName <- aValue
      If TypeOf aValue Is APL OrElse _
          TypeOf aValue Is Method Then
        Assign(aName, aValue)
      ElseIf TypeOf aValue Is Link Then
        Try
          Assign(aName, aValue)
          My_Shell_IsMe(DirectCast(aValue, Link))
        Catch ex As Exception
        End Try
      ElseIf TypeOf aValue Is Integer OrElse _
          TypeOf aValue Is Double Then
        Assign(aName, _a.Value(aValue))
      ElseIf TypeOf aValue Is String Then
        Assign(aName, _a.Value(DirectCast(aValue, String)))
      ElseIf TypeOf aValue Is Char Then
        Assign(aName, _a.Value(aValue.ToString))
      ElseIf TypeOf aValue Is String() Then
        Assign(aName, _a.Value(DirectCast(aValue, String())))
      ElseIf TypeOf aValue Is Char() Then
        Assign(aName, _a.Value(DirectCast(aValue, Char())))
      ElseIf TypeName(aValue).StartsWith("Double(") Then
        Assign(aName, UtilsStrict.FromDouble(aValue))
      Else
        _Signal(ExceptionAPL.Is.Nonce, "'" & TypeName(aValue) & "'")
      End If
    End Set
  End Property

#End Region

#Region "CharacterVectors"

  Private Function CharacterVectors(ByVal aValue As String()) As APL
    Dim myValue As Object()

    If aValue.Length = 0 Then
      Return _a.Enclose("")
    Else
      ReDim myValue(aValue.Length - 1)
      Array.Copy(aValue, myValue, aValue.Length)
      Return New APL(myValue, False)
    End If
  End Function

#End Region

#Region "Clear"

  Friend Sub Clear()
    thisValues = New SortedList(Of String, Definition)
  End Sub

#End Region

#Region "EnsureString"

  Public Function EnsureString(ByVal aValue As Object) As String
    Dim myValue As APL
    Dim myItem As Object

    If aValue Is Nothing Then
      _Signal(ExceptionAPL.Is.Value)
    ElseIf TypeOf aValue Is String Then
      Return DirectCast(aValue, String)
    ElseIf TypeOf aValue Is Char Then
      Return aValue.ToString
    ElseIf TypeOf aValue Is APL Then
      myValue = DirectCast(aValue, APL)
      If myValue.IsCharacter Then
        If myValue.Rank > 1 Then
          _Signal(ExceptionAPL.Is.Rank)
        End If
        Return myValue.CharacterVector
      ElseIf myValue.VectorLength = 1 Then
        myItem = myValue.ValueVector(0)
        If TypeOf myItem Is String Then
          Return DirectCast(myItem, String)
        End If
      End If
    End If
    Return _Signal(ExceptionAPL.Is.Domain).ToString
  End Function

#End Region

End Class
