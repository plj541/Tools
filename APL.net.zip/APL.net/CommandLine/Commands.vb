﻿Imports System.Text
Imports Tools
Imports PLJsAPL

Partial Public Class Commands

#Region "Public Events"

  Public Event Inputs(ByVal aLine As String)
  Public Event Restart(ByVal aWsid As String, ByVal aLoaded As Boolean)
  Public Event Wsid(ByVal aWsid As String)
  Public Event Off(ByVal aFile As String)

#End Region

#Region "Private Properties"

  Private thisEvaluate As Evaluate
  Private thisLast, thisPrevious, thisLastCommand, _
      thisLibPath, thisCompilePath As String
  Private thisIndirect As Boolean
  Private thisOutput, thisNames, thisLinks, thisLog As StringBuilder
  Private thisMethods As Methods
  Private thisCompile As New Compile
  Private _a As New _APL

#End Region

#Region "New"

  Public Sub New( _
      ByVal aLib As String, _
      ByVal aCompile As String, _
      ByVal aUserDll As String)
    thisLibPath = aLib
    thisCompilePath = aCompile
    thisLog = New StringBuilder
    thisEvaluate = New Evaluate(aUserDll)
  End Sub

#End Region

#Region "Commands"

  Public Function Commands(ByVal aLine As String) As Boolean
    aLine = aLine.Trim
    If aLine.Length = 0 OrElse aLine.StartsWith("'") Then
      Base(aLine)
      Return True
    ElseIf aLine.StartsWith(")") Then
      SystemCommands(RemoveExtraBlanks(aLine))
      Return True
    End If

    If aLine.StartsWith("∇") Then
      Base(aLine)
      DefineFunction(aLine)
      Return True
    End If

    Return False
  End Function

#End Region

#Region "InputAPL EstablishMe"

  Public Sub InputAPL(ByVal aLine As String, ByVal anIndirect As Boolean)
    thisIndirect = anIndirect
    If Commands(aLine) Then Return
    thisLastCommand = ""
    aLine = aLine.TrimStart
    thisLast = aLine
    Base(aLine)

    If anIndirect Then
      aLine = "]" & aLine
    End If

    Try
      If aLine.StartsWith(":") Then
        Colons(aLine.Substring(1))
      ElseIf aLine.StartsWith("]") Then
        InputVB(aLine, anIndirect)
      Else
        InputAPL(aLine)
      End If
      LogCommand = aLine
    Catch ex As Exception
      Output(ex.Message)
    End Try
  End Sub

  Private Sub InputAPL(ByVal aLine As String)
    Dim myStatement As Statement
    Dim myLine As String

    myStatement = New Statement(aLine, thisEvaluate, True)
    Try
      EstablishMe()
      myLine = myStatement.ToEvaluate
      If myLine = "" Then Return
      thisLastCommand = myStatement.ToDisplay

    Catch ex As Exception
      Output(ex.Message)
#If Debug Then
      Dim myProblem As Integer
      myProblem = myStatement.Problem
      If myProblem <> -1 Then
        Output(Space(myProblem) & "↓")
        Output(myStatement.Types)
      End If
#End If
      Return
    End Try

    thisEvaluate.Evaluate(myStatement.ToEvaluate)
  End Sub

  Private Sub EstablishMe()
    Dim myDef As Definition
    Dim myLink As Link

    myDef = thisEvaluate.ValueOf("Me")
    If myDef Is Nothing Then
      If thisInitial AndAlso thisWsid IsNot Nothing AndAlso thisWsid.ToLower <> "continue" Then
        Try
          myLink = New Link(thisWsid, "")
          thisEvaluate.Assign("Me", myLink)
          thisEvaluate.My_Shell_IsMe(myLink)
        Catch ex As Exception
          thisInitial = False
        End Try
      End If
    End If
  End Sub

#End Region

#Region "InputVB"

  Private Sub InputVB(ByVal aLine As String, ByVal anIndirect As Boolean)
    Dim myLine, myParens As String
    Dim myStatement As Statement

    myLine = aLine.Substring(1).Trim
    If myLine.Length = 0 Then Return
    thisLastCommand = "]" & myLine

    myStatement = New Statement(myLine, thisEvaluate)
    myLine = myStatement.WrapNames

    ' N.B. This is just for AutoType mode
    If anIndirect Then
      myParens = myStatement.BalanceParens()
      myLine &= myParens
      thisLastCommand &= myParens
    End If

    thisEvaluate.Evaluate(myLine)
  End Sub

#End Region

#Region "Colons"

  Private Sub Colons(ByVal aLine As String)
    aLine = New StatementColon().ColonLine(aLine)
    If aLine.StartsWith("'") Then
      If aLine = "'Not recognized'" Then
        Output("Colon must be followed by one of the following:")
        Output("If ..., ElseIf ..., Else, End If")
        Output("Do, Do While ..., Do Until ..., Loop While ..., Loop Until ..., Loop")
        Output("Select Case ..., Select First ..., Case ..., Case Else, End Select")
        Output("Return ..., Exit Do, Exit Select")
      End If
      _Signal(ExceptionAPL.Is.Syntax, aLine)
    End If
  End Sub

  Private Function Colon( _
      ByVal aCommand As String) _
      As Boolean

    If thisLastCommand.StartsWith(aCommand) Then
      thisLastCommand = thisLast.Substring(aCommand.Length).TrimStart
      Return True
    End If
  End Function

#End Region

#Region "DefineFunction"

  Public Sub DefineFunction(ByVal aName As String)
    Dim myDef As Definition
    Dim myLines As String

    aName = aName.Substring(1).Trim
    If "⍺⍵⍶⍹⌶".Contains(aName) OrElse aName.ToLower = "me" Then
      Illegal(aName)
      Return
    End If
    If IllegalName(aName) Then
      Return
    End If

    myDef = thisEvaluate.ValueOf(aName)
    If myDef Is Nothing Then
      If thisIndirect Then
        myLines = EmptyFunction()
      Else
        myLines = "∇"
      End If
      thisEvaluate.Assign(aName, myLines)
    ElseIf myDef.Name.StartsWith("∇") Then
      myLines = myDef.Value.ToString
    Else
      Output(aName & " is already in use.")
      Return
    End If

    AssignDef("∇" & aName, thisEvaluate._Edit(aName, myLines))
  End Sub

#End Region

#Region "EmptyFunction"

  ''' <summary>
  ''' The Public Property provides ambivalent APL syntax.
  ''' The two Private Functions provide the actual functionality.
  ''' </summary>
  ''' <remarks>
  ''' If you fail to provide a Return statement,
  ''' subsequent use will cause a Value Error.
  ''' </remarks>
  Private Function EmptyFunction() As String
    Dim myLines As New StringBuilder

    myLines.AppendLine("Public ReadOnly Property ∆() As Method")
    myLines.AppendLine(" Get")
    myLines.AppendLine("  Return New Method(AddressOf _∆, AddressOf _∆)")
    myLines.AppendLine(" End Get")
    myLines.AppendLine("End Property")
    myLines.AppendLine("")

    myLines.AppendLine("Private Function _∆(ByVal ⍵ As APL) As APL")
    myLines.AppendLine(" ' Replace with your monadic function definition")
    myLines.AppendLine(" _Signal(ExceptionAPL.Is.Valence)")
    myLines.AppendLine("End Function")
    myLines.AppendLine("")

    myLines.AppendLine("Private Function _∆(ByVal ⍺ As APL, ByVal ⍵ As APL) As APL")
    myLines.AppendLine(" ' Replace with your dyadic function definition")
    myLines.AppendLine(" _Signal(ExceptionAPL.Is.Valence)")
    myLines.AppendLine("End Function")

    Return myLines.ToString
  End Function

#End Region

#Region "AssignDef"

  Private Sub AssignDef( _
      ByVal aName As String, _
      ByVal aLines As APL)
    Dim myCheck As String

    thisEvaluate.Assign(aName, aLines)
    myCheck = New Statements(aLines.CharacterVector).CheckType
    If myCheck IsNot Nothing Then
      Output(myCheck)
    End If
  End Sub

#End Region

#Region "RemoveExtraBlanks"

  Friend Function RemoveExtraBlanks(ByVal aLine As String) As String
    Return UtilsShape.RemoveDups(aLine, " ")
  End Function

#End Region

#Region "Base Output and NoGood"

  Private Sub Base(ByVal aLine As String)
    Output("   " & aLine)
  End Sub

  Public Sub Output(ByVal aLine As String)
    _Out = aLine
  End Sub

  Private Sub NoGood(ByVal aLine As String, ByVal aMsg As String)
    Base(aLine)
    Output(aMsg)
  End Sub

#End Region

#Region "LogCommand"

  ''' <summary>
  ''' Return and reset the command log
  ''' </summary>
  Public Property LogCommand() As String
    Get
      Return thisLog.ToString
    End Get
    Set(ByVal aValue As String)
      If aValue Is Nothing Then
        thisLog = New StringBuilder
      Else
        thisLog.AppendLine(aValue)
      End If
    End Set
  End Property

#End Region

End Class