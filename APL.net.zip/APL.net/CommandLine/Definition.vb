﻿
Public Class Definition

  Private thisName As String
  Private thisValue As Object

  Public Sub New(ByVal aName As String, ByVal aValue As Object)
    thisName = aName
    thisValue = aValue
  End Sub

#Region "Name Value"

  Public ReadOnly Property Name() As String
    Get
      Return thisName
    End Get
  End Property

  Public ReadOnly Property Value() As Object
    Get
      Return thisValue
    End Get
  End Property

#End Region

End Class

