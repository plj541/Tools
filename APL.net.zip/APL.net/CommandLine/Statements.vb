﻿Imports System.Text
Imports PLJsAPL

Public Class Statements

#Region "How Statements Work"

  ''' There are three forms of functions:
  ''' 
  ''' Single Line, as in direct definition
  ''' Multiple lines beginning with ∇, 
  '''     arguments as in direct definition
  ''' Multiple lines with VB syntax
  ''' 
  ''' There are four possible signatures for the first two.
  ''' We test for then in the following sequence:
  ''' 
  ''' ⍙   indicates a  Property
  ''' ⍶   indicates an OpDyadic
  ''' ⍹   indicates an OpMonadic
  '''     none of the above indicates a Function
  ''' 
  ''' ⍺   means not dyadic method
  '''     no ⍺ means monadic method
  ''' 
  ''' ∆   means self refererence as in direct definition
  ''' ⌶   means [axis] is ok, it is only tested for in Ops
  '''  
  ''' Please note:
  '''     The examples show a default value being provided,
  '''     and both definitions being provided.
  ''' 
  '''     Neither of these are required.
  ''' __________________________________________
  ''' 
  ''' Function    One Line
  ''' "Default" ∆ ⍵ ∇ ⍺,⍵
  ''' 
  ''' Function    Multiple Lines
  ''' ∇;Monadic;Locals
  ''' "Default" ∆ ⍵
  ''' 
  ''' ∇;Dyadic;Locals
  ''' ⍺,⍵
  ''' __________________________________________
  ''' 
  ''' OpMonadic   One Line
  ''' "Default" ⍶ ⍵ ∇ ⍺ ⍶ ⍵
  ''' 
  ''' OpMonadic   Multiple Lines
  ''' ∇;Monadic;Locals
  ''' "Default" ⍶ ∆ ⍵
  ''' 
  ''' ∇;Dyadic;Locals
  ''' ⍺ ⍶ ⍵
  ''' __________________________________________
  ''' 
  ''' OpDyadic    One Line
  ''' "Default" ⍹ ∆ ⍶ ⍵ ∇ ⍺ ⍹ ⍶ ⍵
  ''' 
  ''' ∇;Monadic;Locals
  ''' "Default" ⍶ ∆ ⍹ ⍵
  ''' 
  ''' ∇;Dyadic;Locals
  ''' ⍺ ⍶ ⍹ ⍵
  ''' __________________________________________
  ''' 
  ''' Property    One Line
  ''' ⍙ ∇ ⍙←⍺
  ''' 
  ''' Property    Multiple Lines
  ''' ∇;Reference;Locals
  ''' ⍙
  ''' 
  ''' ∇;Assignment;Locals
  ''' ⍙←⍺
  ''' __________________________________________
  ''' 
  ''' Methods can contain three types of statements:
  ''' 
  ''' ]Leading indicates include VB as is
  ''' :Leading indicates VB structure with an APL expression
  ''' Neither of the above indicates APL
  ''' 
  ''' Considering a trailing ⍫ to indicate Private
  ''' Not sure how to indicate a Shared version?

#End Region

#Region "Private Properties"

  Private thisLines As String
  Private thisTypes As String
  Private thisEvaluate As Evaluate
  Private thisMethods As Methods
  Private thisLocalNames, thisFixedQuotes As String

#End Region

#Region "New"

  Public Sub New( _
    ByVal aLines As String)
    thisLines = NoNulls(aLines)
    Analize()
  End Sub

  Public Sub New( _
      ByVal aLines As String, _
      ByVal anEvaluate As Evaluate, _
      ByVal aMethods As Methods)
    thisLines = NoNulls(aLines)
    thisEvaluate = anEvaluate
    thisMethods = aMethods
    Analize()
  End Sub

  Private Function NoNulls(ByVal aLines As String) As String
    Return aLines.Replace(ControlChars.NullChar, Chr(&HA0))
  End Function

#End Region

  ' Public Properties

#Region "Type Types"

  Public ReadOnly Property Type() As Char
    Get
      Return thisTypes(1)
    End Get
  End Property

  Public ReadOnly Property Types() As String
    Get
      Return thisTypes
    End Get
  End Property

#End Region

#Region "CheckType"

  Public ReadOnly Property CheckType() As String
    Get
      If Not thisTypes.StartsWith("V") AndAlso thisTypes(1) = "?" Then
        Return "Not a recogized ∇ type"
      ElseIf thisTypes.Length > 3 AndAlso thisTypes(2) = thisTypes(3) Then
        If thisTypes(2) = "⍺" Then
          Return "Both ∇ definitions are dyadic"
        Else
          Return "Both ∇ definitions are monadic"
        End If
      ElseIf thisFixedQuotes IsNot Nothing Then
        Return "Quotes mismatched on lines [" & thisFixedQuotes.Substring(1) & "]"
      End If

      Return Nothing
    End Get
  End Property

#End Region

  ' Analize and sub functions

#Region "Analize FixQuotes QuotesUnbalanced"

  Private Sub Analize()
    Dim myLines As String()

    thisLines = thisLines.TrimStart
    myLines = Split(thisLines, ControlChars.CrLf)
    If Not thisLines.Trim.Contains(ControlChars.CrLf) Then
      thisTypes = "D"
      Def(RemoveQuotes(myLines(0)))
    ElseIf myLines(0).StartsWith("∇") Then
      thisTypes = "A"
      APL(FixQuotes(myLines, False))
    Else
      thisTypes = "V"
      VB(FixQuotes(myLines, True))
    End If
  End Sub

  ''' <summary>
  ''' Ensure quotes are balanced, and
  '''   ∇ is first character on lines where it appears.
  ''' </summary>
  Private Function FixQuotes( _
      ByVal aLines As String(), _
      ByVal aNoSkip As Boolean) _
      As String()
    Dim myLine As String
    Dim myIndex As Integer
    Dim myLines As New StringBuilder

    For myIndex = 0 To aLines.Length - 1
      myLine = aLines(myIndex).TrimStart

      If myLine.Length <> 0 OrElse aNoSkip Then
        If myLine.StartsWith("'") OrElse myLine.StartsWith("⍝") Then
          myLine = myLine.Replace("""", ControlChars.NullChar)
        ElseIf QuotesUnbalanced(myLine) Then
          thisFixedQuotes &= " " & myIndex
          myLine &= """"
        End If

        myLines.AppendLine(myLine.TrimEnd)
      End If
    Next

    thisLines = myLines.ToString.TrimEnd
    Return Split(thisLines, ControlChars.NewLine)
  End Function

  Private Function QuotesUnbalanced(ByVal aLine As String) As Boolean
    Return 1 = (aLine.Length - aLine.Replace("""", "").Length) Mod 2
  End Function

#End Region

#Region "Def MonDyad"

  Private Sub Def(ByVal aLine As String)
    Dim myDefs As String()
    Dim myAxis As Boolean

    aLine = aLine.Trim
    myDefs = aLine.Split("∇"c)
    If myDefs.Length > 2 OrElse myDefs(0).Length = 0 Then
      thisTypes &= "?"
    Else
      If aLine.Contains("⍙") Then
        ' Property
        thisTypes &= "v"
      ElseIf aLine.Contains("⍹") Then
        ' OpDyadic
        thisTypes &= "O"
      ElseIf aLine.Contains("⍶") Then
        ' OpMonadic
        thisTypes &= "o"
      Else
        ' Functions
        thisTypes &= "f"
      End If

      MonDyad(myDefs(0))
      myAxis = myDefs(0).Contains("⌶")
      If myDefs.Length = 2 Then
        MonDyad(myDefs(1))
        myAxis = myAxis OrElse myDefs(1).Contains("⌶")
      Else
        thisTypes &= "_"
      End If

      If myAxis Then
        thisTypes &= "⌶"
      End If
    End If
  End Sub

  Private Sub MonDyad(ByVal aDef As String)
    If aDef.Contains("⍺") Then
      thisTypes &= "⍺"
    Else
      thisTypes &= "⍵"
    End If
  End Sub

#End Region

#Region "APL"

  Private Sub APL(ByVal aLines As String())
    Dim myLine As String
    Dim myIndex As Integer
    Dim myLines As New StringBuilder

    For myIndex = 0 To aLines.Length - 1
      myLine = aLines(myIndex).Trim
      If Not (myLine.StartsWith("'") OrElse myLine.StartsWith("⍝")) Then
        myLine = RemoveQuotes(myLine).Trim.ToLower
        If myLine.Length <> 0 Then
          myLines.AppendLine(myLine)
        End If
      End If
    Next

    Def(myLines.ToString.Substring(1))
  End Sub

#End Region

#Region "VB"

  Private Sub VB(ByVal aLines As String())
    Dim myLine As String
    Dim myIndex As Integer

    For myIndex = 0 To aLines.Length - 1
      myLine = aLines(myIndex).Trim
      If Not myLine.StartsWith("'") Then
        myLine = RemoveQuotes(myLine).ToLower
        If myLine.Contains(" property ") Then
          If myLine.Contains(")") Then
            myLine = myLine.Split(")"c)(1).Trim
            If myLine.StartsWith("as ") Then
              myLine = myLine.Substring(3).TrimStart
              Select Case myLine
                Case "method"
                  thisTypes &= "f"
                Case "apl"
                  thisTypes &= "v"
                Case "opmonadic"
                  thisTypes &= "o"
                Case "opdyadic"
                  thisTypes &= "O"
                Case Else
                  Exit For
              End Select
              Return
            End If
          End If
          Exit For
        End If
      End If
    Next

    thisTypes &= "f⍺⍵: " & aLines(myIndex).Trim
  End Sub

#End Region

#Region "RemoveQuotes"

  Private Function RemoveQuotes(ByVal aLine As String) As String
    Dim myIndex As Integer
    Dim myParts As String()
    Dim myOutput As New StringBuilder

    If aLine.Contains("""") Then
      myParts = aLine.Split(""""c)
      For myIndex = 0 To myParts.Length - 1 Step 2
        myOutput.Append(myParts(myIndex))
      Next
      aLine = myOutput.ToString
    End If
    Return aLine
  End Function

#End Region

  ' Define each Method types

#Region "Define TwoFunctions"

  Public ReadOnly Property Define(ByVal aMethods As Methods) As String
    Get
      Dim myDefs As String()
      If thisTypes(0) = "D" Then
        myDefs = TwoFunctions(Split(thisLines, "∇"))
        ' Provide empty initial line for Direct Def
        myDefs(0) = ControlChars.CrLf & myDefs(0)
        If myDefs.Length = 2 Then
          myDefs(1) = ControlChars.CrLf & myDefs(1)
        End If
        thisLines = ProvideMethods(GetMonadic(myDefs), GetDyadic(myDefs))
      ElseIf thisTypes(0) = "A" Then
        myDefs = TwoFunctions(Split(thisLines.Substring(1), ControlChars.CrLf & "∇"))
        thisLines = ProvideMethods(GetMonadic(myDefs), GetDyadic(myDefs))
      End If

      Return thisLines
    End Get
  End Property

  Private Function TwoFunctions(ByVal aDefs As String()) As String()
    If aDefs.Length > 2 Then
      _Signal(ExceptionAPL.Is.Valence)
    ElseIf aDefs.Length = 2 AndAlso _
        thisTypes(2) = thisTypes(3) Then
      _Signal(ExceptionAPL.Is.Valence)
    End If

    Return aDefs
  End Function

#End Region

#Region "GetMonadic GetDyadic"

  Private Function GetMonadic(ByVal aDef As String()) As String
    If thisTypes(2) = "⍵" Then
      Return MethodDef(aDef(0), False)
    ElseIf aDef.Length = 2 AndAlso thisTypes(3) = "⍵" Then
      Return MethodDef(aDef(1), False)
    End If

    Return Nothing
  End Function

  Private Function GetDyadic(ByVal aDef As String()) As String
    Dim myProperty As Boolean

    myProperty = thisTypes(1) = "v"

    If aDef.Length = 2 AndAlso thisTypes(3) = "⍺" Then
      Return MethodDef(aDef(1), myProperty)
    ElseIf thisTypes(2) = "⍺" Then
      Return MethodDef(aDef(0), myProperty)
    End If

    Return Nothing
  End Function

#End Region

#Region "MethodDef"

  Private Function MethodDef(ByVal aDef As String, ByVal aProperty As Boolean) As String
    Dim myDef As String()
    Dim myLine As String
    Dim myLines As New StringBuilder
    Dim myIndex, myLast As Integer

    myDef = Split(aDef.TrimEnd, ControlChars.CrLf)
    myLine = myDef(0).Replace(" ", "").Trim(";"c)
    thisLocalNames = Nothing
    If myLine.Length <> 0 Then
      thisLocalNames = ";" & myLine & ";"
      myLines.Append("Dim ")
      myLines.Append(myLine.Replace(";", ","))
      myLines.AppendLine(" As APL")
    End If

    If Not aProperty Then
      myLast = myDef.Length - 1
    End If

    For myIndex = 1 To myDef.Length - 1
      StatementType(myLines, myDef(myIndex).TrimStart, myIndex = myLast)
    Next

    Return myLines.ToString
  End Function

  Private Sub StatementType( _
      ByVal aLines As StringBuilder, _
      ByVal aLine As String, _
      ByVal aLast As Boolean)
    Dim myLine As String
    Dim myAssign As Boolean
    Dim myStatement As Statement

    ' N.B.  lines starting ''' need to move to the top of the output
    If aLine.StartsWith("'") Then
      aLines.AppendLine(aLine)
    ElseIf aLine.StartsWith("⍝") Then
      aLines.Append("' ")
      aLines.AppendLine(aLine)
    ElseIf aLine.StartsWith("]") Then
      aLines.AppendLine(aLine.Substring(1))
    ElseIf aLine.Length = 0 Then
      aLines.AppendLine()
    ElseIf aLine.StartsWith(":") Then
      aLines.AppendLine(Colons(aLine.Substring(1)))
    Else
      myStatement = New Statement(aLine, thisEvaluate)
      myLine = myStatement.ToCompile(Me)

      myAssign = myStatement.Types.Contains("←")
      If aLast Then
        If myAssign Then
          aLines.AppendLine(myLine)
          aLines.Append("Return ")
          myLine = myStatement.Tokens(0).Trim
        Else
          aLines.Append("Return ")
        End If
      Else
        If Not myAssign Then
          aLines.Append("_a.Quad=")
        End If
      End If
      aLines.AppendLine(myLine)
    End If
  End Sub

#End Region

  ' Provide Function, Property, OpMonadic and OpDyadic methods

#Region "ProvideMethods"

  Private Function ProvideMethods( _
        ByVal aMonadic As String, _
        ByVal aDyadic As String) _
        As String
    Select Case thisTypes(1)
      Case "f"c
        Return ProvideFunction(aMonadic, aDyadic)
      Case "v"c
        Return ProvideProperty(aMonadic, aDyadic)
      Case "o"c
        Return ProvideOpMonadic(aMonadic, aDyadic)
      Case "O"c
        Return ProvideOpDyadic(aMonadic, aDyadic)
      Case Else
        _Signal(ExceptionAPL.Is.System)
    End Select
  End Function

#End Region

#Region "ProvideFunction"

  Private Function ProvideFunction( _
      ByVal aMonadic As String, _
      ByVal aDyadic As String) _
      As String
    Dim myLines As New StringBuilder

    myLines.AppendLine("Public ReadOnly Property ∆() As Method")
    myLines.AppendLine(" Get")
    myLines.Append("  Return New Method(")
    myLines.Append(AddressOrNothing(aMonadic))
    myLines.Append(", ")
    myLines.Append(AddressOrNothing(aDyadic))
    myLines.AppendLine(")")
    myLines.AppendLine(" End Get")
    myLines.AppendLine("End Property")

    If aMonadic IsNot Nothing Then
      myLines.AppendLine()
      myLines.AppendLine("Private Function _∆(ByVal ⍵ As APL) As APL")
      myLines.Append(aMonadic)
      myLines.AppendLine("End Function")
    End If

    If aDyadic IsNot Nothing Then
      myLines.AppendLine()
      myLines.AppendLine("Private Function _∆(ByVal ⍺ As APL, ByVal ⍵ As APL) As APL")
      myLines.Append(aDyadic)
      myLines.AppendLine("End Function")
    End If

    Return myLines.ToString
  End Function

#End Region

#Region "ProvideProperty"

  Private Function ProvideProperty( _
     ByVal aMonadic As String, _
     ByVal aDyadic As String) _
     As String
    Dim myLines As New StringBuilder

    myLines.Append("Public ")
    If aMonadic Is Nothing Then
      If aDyadic Is Nothing Then
        _Signal(ExceptionAPL.Is.Valence)
      End If
      myLines.Append("WriteOnly ")
    ElseIf aDyadic Is Nothing Then
      myLines.Append("ReadOnly ")
    End If
    myLines.AppendLine("Property ∆() As APL")

    If aMonadic IsNot Nothing Then
      myLines.AppendLine(" Get")
      myLines.Append(aMonadic)
      myLines.AppendLine(" End Get")
    End If

    If aDyadic IsNot Nothing Then
      myLines.AppendLine(" Set(ByVal ⍺ As APL)")
      myLines.Append(aDyadic)
      myLines.AppendLine(" End Set")
    End If

    myLines.AppendLine("End Property")
    myLines.AppendLine()
    myLines.AppendLine("Private ⍙ As APL")
    Return myLines.ToString
  End Function

#End Region

#Region "ProvideOpMonadic"

  Private Function ProvideOpMonadic( _
      ByVal aMonadic As String, _
      ByVal aDyadic As String) _
      As String
    Dim myLines As New StringBuilder

    OpProperty(myLines, "OpMonadic", aMonadic, aDyadic)

    If aMonadic IsNot Nothing Then
      myLines.AppendLine()
      myLines.AppendLine("Private Function _∆( _")
      myLines.AppendLine(" ByVal ⍶ As Method, _")
      myLines.AppendLine(" ByVal ⌶ As APL, _")
      myLines.AppendLine(" ByVal ⍵ As APL) As APL")
      myLines.Append(aMonadic)
      myLines.AppendLine("End Function")
    End If

    If aDyadic IsNot Nothing Then
      myLines.AppendLine()
      myLines.AppendLine("Private Function _∆( _")
      myLines.AppendLine(" ByVal ⍺ As APL, _")
      myLines.AppendLine(" ByVal ⍶ As Method, _")
      myLines.AppendLine(" ByVal ⌶ As APL, _")
      myLines.AppendLine(" ByVal ⍵ As APL) As APL")
      myLines.Append(aDyadic)
      myLines.AppendLine("End Function")
    End If

    Return myLines.ToString
  End Function

#End Region

#Region "ProvideOpDyadic"

  Private Function ProvideOpDyadic( _
      ByVal aMonadic As String, _
      ByVal aDyadic As String) _
      As String
    Dim myLines As New StringBuilder

    OpProperty(myLines, "OpDyadic", aMonadic, aDyadic)

    If aMonadic IsNot Nothing Then
      myLines.AppendLine()
      myLines.AppendLine("Private Function _∆( _")
      myLines.AppendLine(" ByVal ⍶ As Method, _")
      myLines.AppendLine(" ByVal ⌶ As APL, _")
      myLines.AppendLine(" ByVal ⍹ As Method, _")
      myLines.AppendLine(" ByVal ⍵ As APL) As APL")
      myLines.Append(aMonadic)
      myLines.AppendLine("End Function")
    End If

    If aDyadic IsNot Nothing Then
      myLines.AppendLine()
      myLines.AppendLine("Private Function _∆( _")
      myLines.AppendLine(" ByVal ⍺ As APL, _")
      myLines.AppendLine(" ByVal ⍶ As Method, _")
      myLines.AppendLine(" ByVal ⌶ As APL, _")
      myLines.AppendLine(" ByVal ⍹ As Method, _")
      myLines.AppendLine(" ByVal ⍵ As APL) As APL")
      myLines.Append(aDyadic)
      myLines.AppendLine("End Function")
    End If

    Return myLines.ToString
  End Function

#End Region

#Region "OpProperty"

  Private Sub OpProperty( _
      ByVal anOutput As StringBuilder, _
      ByVal anOp As String, _
      ByVal aMonadic As String, _
      ByVal aDyadic As String)

    anOutput.Append("Public ReadOnly Property ∆() As ")
    anOutput.AppendLine(anOp)
    anOutput.AppendLine(" Get")
    anOutput.Append("  Return New ")
    anOutput.Append(anOp)
    anOutput.Append("(")
    anOutput.Append(AddressOrNothing(aMonadic))
    anOutput.Append(", ")
    anOutput.Append(AddressOrNothing(aDyadic))
    If thisTypes.Contains("⌶") Then
      anOutput.AppendLine(", True)")
    Else
      anOutput.AppendLine(", False)")
    End If
    anOutput.AppendLine(" End Get")
    anOutput.AppendLine("End Property")
  End Sub

#End Region

#Region "AddressOrNothing"

  Private Function AddressOrNothing(ByVal aLine As String) As String
    If aLine Is Nothing Then
      Return "Nothing"
    Else
      Return "AddressOf _∆"
    End If
  End Function

#End Region

#Region "Colons"

  Private Function Colons(ByVal aLine As String) As String
    Dim myLine As String

    myLine = New StatementColon().ColonCompile(aLine, thisEvaluate, Me)
    If myLine.StartsWith("'") Then
      _Signal(ExceptionAPL.Is.Syntax, myLine)
    End If
    Return myLine
  End Function

#End Region

#Region "Type"

  Public ReadOnly Property Type(ByVal aName As String) As Char
    Get
      If thisLocalNames IsNot Nothing Then
        ' FixMe: We need code to set thisLocalNames
        If thisLocalNames.Contains(";" & aName & ";") Then
          Return "v"c
        End If
      End If

      Return thisMethods.Type(aName)
    End Get
  End Property

#End Region

End Class
