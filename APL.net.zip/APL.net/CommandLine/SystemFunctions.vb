﻿Imports System.Windows.Forms
Imports System.Text
Imports PLJsAPL
Imports Tools

Partial Public Class Evaluate

#Region "#Tokens"

  Public ReadOnly Property Tokens() As Method
    Get
      Return New Method(AddressOf _Tokens, Nothing)
    End Get
  End Property

  Public Function _Tokens(ByVal aLine As APL) As APL
    Dim myTokens As String()
    Dim myResult As Object()
    Dim myStatement As Statement

    myStatement = New Statement(EnsureString(aLine), Me)
    myTokens = myStatement.Tokens

    ReDim myResult(myTokens.Length - 1)
    Array.ConstrainedCopy(myTokens, 0, myResult, 0, myTokens.Length)
    Return New APL(myResult, False)
  End Function

#End Region

  ' Methods to discover compiled workspaces and their functions
  '   can also discover classes and their methods  

#Region "#Lib"

  Public ReadOnly Property [Lib]() As Method
    Get
      Return New Method(AddressOf _Lib, Nothing)
    End Get
  End Property

  Private Function _Lib(ByVal aDll As APL) As APL
    If aDll.Rank = 1 AndAlso aDll.Shape(0) = 0 Then
      Return New APL(Link.LoadLib.Lib)
    End If
    Return New APL(EnsureDll(aDll).Lib)
  End Function

  Private Function EnsureDll(ByVal aDll As APL) As LoadDll
    Return Link.EnsureDll(EnsureString(aDll))
  End Function

#End Region

#Region "#Fns"

  Public ReadOnly Property Fns() As Method
    Get
      Return New Method(AddressOf _Fns, AddressOf _Fns)
    End Get
  End Property

  Private Function _Fns(ByVal aName As APL) As APL
    Return _a.Comma.Sub(0.5)(New APL(Link.LoadLib.Fns(EnsureString(aName))))
  End Function

  Private Function _Fns(ByVal aDll As APL, ByVal aName As APL) As APL
    Return _a.Comma.Sub(0.5)(New APL(EnsureDll(aDll).Fns(EnsureString(aName))))
  End Function

#End Region

#Region "#Def"

  Public ReadOnly Property Def() As Method
    Get
      Return New Method(AddressOf _Def, AddressOf _Def)
    End Get
  End Property

  Private Function _Def(ByVal aName As APL) As APL
    Dim myDef As Definition

    myDef = ValueOf(EnsureString(aName))
    If myDef Is Nothing Then
      _Signal(ExceptionAPL.Is.Value)
    ElseIf Not myDef.Name.StartsWith("∇") Then
      _Signal(ExceptionAPL.Is.Domain)
    End If
    Return DirectCast(myDef.Value, APL)
  End Function

  Private Function _Def(ByVal aLeft As APL, ByVal aRight As APL) As APL
    Dim myName, myLines, myTypes As String
    Dim myDef As Definition
    Dim myStatements As Statements

    If aLeft.Rank > 2 Then
      _Signal(ExceptionAPL.Is.Rank)
    End If
    If Not aLeft.IsCharacter Then
      _Signal(ExceptionAPL.Is.Domain)
    End If
    
    myName = EnsureString(aRight)
    If "⍺⍵".Contains(myName) OrElse IllegalName(myName) Then
      _Signal(ExceptionAPL.Is.Domain)
    End If
    myDef = ValueOf(myName)
    If myDef IsNot Nothing AndAlso _
        Not myDef.Name.StartsWith("∇") Then
      _Signal(ExceptionAPL.Is.Domain)
    End If

    myLines = aLeft.ToString
    myStatements = New Statements(myLines)
    myTypes = myStatements.CheckType
    If myTypes IsNot Nothing Then
      _Signal(ExceptionAPL.Is.Domain, ControlChars.CrLf & myTypes)
    End If

    Assign("∇" & myName, _a.Value(myLines))

    myTypes = myStatements.Types
    Select Case myTypes(1)
      Case "f"c
        myTypes = "Function "
      Case "v"c
        myTypes = "Property "
      Case "o"c, "O"c
        myTypes = "Operator "
    End Select
    Return _a.Value(myTypes & myName)
  End Function

#End Region

  ' Methods to provide extended APL functionality

#Region "#NL"

  Public ReadOnly Property NL() As Method
    Get
      Return New Method(AddressOf _NL, Nothing)
    End Get
  End Property

  Private Function _NL(ByVal aNumber As APL) As APL
    Dim myNames As Object()
    Dim myName As String
    Dim myDef As Definition
    Dim myIndex, myFilter As Integer

    myFilter = aNumber.IntegerIndex
    ReDim myNames(thisValues.Count - 1)
    For Each myDef In thisValues.Values
      myName = myDef.Name
      If myName.StartsWith("∇") Then
        If myFilter = 3 Then
          myNames(myIndex) = myName.Substring(1)
          myIndex += 1
        End If
      ElseIf myFilter = 2 Then
        myNames(myIndex) = myName
        myIndex += 1
      End If
    Next

    ReDim Preserve myNames(myIndex - 1)
    Return New APL(myNames)
  End Function

#End Region

#Region "#EX"

  Public ReadOnly Property EX() As Method
    Get
      Return New Method(AddressOf _EX, Nothing)
    End Get
  End Property

  Private Function _EX(ByVal aName As Object) As Object
    Return _EX(EnsureString(aName))
  End Function

  Friend Function _EX(ByVal aName As String) As Integer
    If thisValues.ContainsKey(aName) Then
      thisValues.Remove(aName)
      Return 1
    Else
      Return 0
    End If
  End Function

#End Region

#Region "#VI"

  ''' <summary>
  ''' Verify character Input
  ''' </summary>
  Public ReadOnly Property VI() As Method
    Get
      Return New Method(AddressOf _Vi, Nothing)
    End Get
  End Property

  Private Function _Vi(ByVal aRight As APL) As APL
    Dim myLine As String

    UtilsShape.CheckValue(aRight)
    If aRight.Rank > 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If

    If aRight.IsCharacter Then
      myLine = aRight.CharacterVector.Trim
      If myLine.Length = 0 Then
        Return _a.Value()
      Else
        Return _Vi(myLine)
      End If

    Else
      Return ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If
  End Function

  Private Function _Vi(ByVal aLine As String) As APL
    Dim myItems As String()
    Dim myIndex As Integer
    Dim myValues As Object()

    UtilsShape.CheckValue(aLine)
    aLine = aLine.Replace("¯", "-")
    myItems = UtilsShape.RemoveDups(aLine, " ").Split(" "c)
    ReDim myValues(myItems.Length - 1)

    For myIndex = 0 To myItems.Length - 1
      If IsNumeric(myItems(myIndex)) Then
        myValues(myIndex) = 1
      Else
        myValues(myIndex) = 0
      End If
    Next

    Return New APL(myValues)
  End Function

#End Region

#Region "#FI and #FIN"

  ''' <summary>
  ''' Parse numbers from character input,
  ''' provide 0 for failures.
  ''' </summary>
  Public ReadOnly Property FI() As Method
    Get
      Return New Method(AddressOf _Fi, Nothing)
    End Get
  End Property

  Private Function _Fi(ByVal aRight As APL) As APL
    Dim myLine As String

    UtilsShape.CheckValue(aRight)
    If aRight.Rank > 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If

    If aRight.IsCharacter Then
      myLine = aRight.CharacterVector.Trim
      If myLine.Length = 0 Then
        Return _a.Value()
      Else
        Return _Fin(myLine, 0)
      End If

      Return _Fin(aRight.CharacterVector, 0)
    Else
      Return ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If
  End Function

  ''' <summary>
  ''' Parse numbers from character input,
  ''' provide NaN for failures.
  ''' </summary>
  Public ReadOnly Property FIN() As Method
    Get
      Return New Method(AddressOf _Fin, Nothing)
    End Get
  End Property

  Private Function _Fin(ByVal aRight As APL) As APL
    Dim myLine As String

    UtilsShape.CheckValue(aRight)
    If aRight.Rank > 1 Then
      ExceptionAPL.Signal(ExceptionAPL.Is.Rank)
    End If

    If aRight.IsCharacter Then
      myLine = aRight.CharacterVector.Trim
      If myLine.Length = 0 Then
        Return _a.Value()
      Else
        Return _Fin(myLine, Double.NaN)
      End If
    Else
      Return ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If
  End Function

  Private Function _Fin( _
      ByVal aLine As String, _
      ByVal aWrong As Object) _
      As APL
    Dim myItems As String()
    Dim myItem As String
    Dim myIndex, myInteger As Integer
    Dim myValues As Object()

    aLine = aLine.Replace("¯", "-")
    myItems = UtilsShape.RemoveDups(aLine, " ").Split(" "c)
    ReDim myValues(myItems.Length - 1)

    For myIndex = 0 To myItems.Length - 1
      myItem = myItems(myIndex)
      If Integer.TryParse(myItem, myInteger) Then
        myValues(myIndex) = myInteger
      ElseIf IsNumeric(myItem) Then
        myValues(myIndex) = Conversion.Val(myItem)
      Else
        myValues(myIndex) = aWrong
      End If
    Next

    Return New APL(myValues)
  End Function

#End Region

#Region "#Dictionary"

  Private thisDictionary As APL
  ''' <summary>
  ''' A special instance value, for use with
  ''' Dyadic UpGrades and DownGrades
  ''' </summary>
  Public ReadOnly Property Dictionary() As APL
    Get
      If thisDictionary Is Nothing Then
        thisDictionary = New APL( _
            " 0abcdefghijklmnopqrstuvwxyz" & _
            " 1ABCDEFGHIJKLMNOPQRSTUVWXYZ" & _
            " 2                          " & _
            " 3                          " & _
            " 4                          " & _
            " 5                          " & _
            " 6                          " & _
            " 7                          " & _
            " 8                          " & _
            " 9                          ")
        thisDictionary.Shape = New Integer() {10, 28}
      End If

      Return thisDictionary
    End Get
  End Property

#End Region

#Region "#Format"

  ''' <summary>
  ''' Provide String.Format functionality for APL arrays.
  ''' The aFormat is a character vector which contains
  '''   {number} or
  '''   {number:format}
  ''' for each remaining element.
  ''' </summary>
  Public ReadOnly Property Format() As Method
    Get
      Return New Method(Nothing, AddressOf _Formats)
    End Get
  End Property

  ''' <summary>
  ''' Provide String.Format functionality for APL arrays.
  ''' The aFormat is a character vector which contains
  '''   {number} or
  '''   {number:format}
  ''' for each remaining element.
  ''' </summary>
  Private Function _Formats( _
      ByVal aFormat As APL, _
      ByVal aValue As APL) _
      As APL
    UtilsShape.CheckValue(aValue)
    If aFormat.IsCharacter Then
      Return _Formats(aFormat.CharacterVector, aValue)

    Else
      Return ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End If
  End Function

  Private Function _Formats( _
      ByVal aFormat As String, _
      ByVal aValue As APL) _
      As APL
    Dim myIndex, myValueIndex, myItem As Integer
    Dim myShape As Integer()
    Dim myValues, myResults, myLine As Object()
    Dim myResult As APL

    If aValue.IsCharacter Then
      _Signal(ExceptionAPL.Is.Domain)
    End If
    myValues = aValue.ValueVector

    Try
      myShape = aValue.Shape
      If myShape.Length = 0 Then
        ReDim myResults(0)
        myResults(0) = String.Format(aFormat, myValues)
        Return New APL(myResults)
      Else
        myItem = myShape.Length - 1
        ReDim myLine(myShape(myItem) - 1)
        myShape(myItem) = 1
        myItem = UtilsShape.TimesReduce(myShape) - 1
        ReDim myResults(myItem)
      End If

      For myIndex = 0 To myResults.Length - 1
        For myItem = 0 To myLine.Length - 1
          myLine(myItem) = myValues(myValueIndex)
          myValueIndex += 1
        Next
        myResults(myIndex) = String.Format(aFormat, myLine)
      Next

      myResult = New APL(myResults)
      myResult.Shape = myShape
      Return myResult

    Catch ex As Exception
      Return ExceptionAPL.Signal(ExceptionAPL.Is.Domain)
    End Try
  End Function

#End Region

#Region "#CrLf #Tab #Null"

  Public ReadOnly Property CrLf() As APL
    Get
      Return _a.Value(ControlChars.CrLf)
    End Get
  End Property

  Public ReadOnly Property Tab() As APL
    Get
      Return _a.Value(ControlChars.Tab)
    End Get
  End Property

  Public ReadOnly Property Null() As APL
    Get
      Return _a.Value(ControlChars.NullChar)
    End Get
  End Property

#End Region

  ' Methods to provide .Net functionality

#Region "#Edit"

  Public ReadOnly Property Edit() As Method
    Get
      Return New Method(AddressOf _Edit, AddressOf _Edit)
    End Get
  End Property

  Private Function _Edit(ByVal aValue As APL) As APL
    Return _Edit("", EnsureString(aValue))
  End Function

  Private Function _Edit(ByVal aName As APL, ByVal aValue As APL) As APL
    Return _Edit(EnsureString(aName), EnsureString(aValue))
  End Function

  Friend Function _Edit(ByVal aName As String, ByVal aValue As String) As APL
    Dim myEdit As AltKeys.Shell

    If aValue.Contains(ControlChars.NullChar) Then
      If MessageBox.Show("Caution, this value contains Null characters." & ControlChars.Lf & _
                        "Using Edit with modify the result by changing each Null to a non breaking blank." & ControlChars.Lf & _
                        "Do you wish to continue?", "Edit of Null Characters", _
                        MessageBoxButtons.YesNo) = DialogResult.No Then
        Return Nothing
      End If
    End If
    myEdit = New AltKeys.Shell
    myEdit.ShellOutput.Text = aValue.Replace(ControlChars.NullChar, Chr(&HA0))
    myEdit.NoAutoSave()
    myEdit.Viewing(aName.TrimStart("∇"c)) = False
    myEdit.ShowDialog()
    Return _a.Value(myEdit.ShellOutput.Text)
  End Function

#End Region

#Region "#Replace #Split"

  Public ReadOnly Property Replace() As Method
    Get
      Return New Method(Nothing, AddressOf _Replace)
    End Get
  End Property

  Private Function _Replace(ByVal aPair As APL, ByVal aValue As APL) As APL
    Dim myValue As Object()

    If aPair.IsCharacter Then
      _Signal(ExceptionAPL.Is.Domain)
    End If
    If aPair.Rank <> 1 Then
      _Signal(ExceptionAPL.Is.Rank)
    End If
    If aPair.VectorLength <> 2 Then
      _Signal(ExceptionAPL.Is.Length)
    End If
    myValue = aPair.CompareValues
    Return _a.Value(aValue.ToString.Replace(myValue(0).ToString, myValue(1).ToString))
  End Function

  Public ReadOnly Property Split() As Method
    Get
      Return New Method(Nothing, AddressOf _Split)
    End Get
  End Property

  Private Function _Split(ByVal aSplit As APL, ByVal aValue As APL) As APL
    If Not aValue.IsCharacter OrElse Not aSplit.IsCharacter Then
      _Signal(ExceptionAPL.Is.Domain)
    End If
    Return CharacterVectors(Strings.Split(aValue.ToString, aSplit.CharacterVector))
  End Function

#End Region

#Region "#Join"

  Public ReadOnly Property Join() As Method
    Get
      Return New Method(Nothing, AddressOf _Join)
    End Get
  End Property

  Private Function _Join(ByVal aJoin As APL, ByVal aValue As APL) As APL
    Dim myValues As Object()
    Dim myJoin As String
    Dim myResult As StringBuilder
    Dim myIndex As Integer

    If aValue.IsCharacter Then
      Return New APL(aValue.CharacterVector, False)

    ElseIf aValue.VectorLength = 0 Then
      Return New APL("")

    Else
      myJoin = aJoin.CharacterVector
      myValues = aValue.ValueVector
      myResult = New StringBuilder()

      For myIndex = 0 To myValues.Length - 2
        myResult.Append(myValues(myIndex).ToString)
        myResult.Append(myJoin)
      Next

      myResult.Append(myValues(myIndex).ToString)
      Return New APL(myResult.ToString, False)
    End If
  End Function

#End Region

  ' Methods to access .Tools

#Region "#Names"

  Private thisNames As Names
  Public Function Names() As Names
    If thisNames Is Nothing Then
      thisNames = New Names
    End If

    Return thisNames
  End Function

#End Region

#Region "#Host"

  Private thisHost As Host
  Public Function Host() As Host
    If thisHost Is Nothing Then
      thisHost = New Host
    End If
    Return thisHost
  End Function

#End Region

#Region "#Lines"

  Public ReadOnly Property Lines() As Method
    Get
      Return New Method(AddressOf _Lines, AddressOf _Lines)
    End Get
  End Property

  Private Function _Lines(ByVal aName As APL) As APL
    Return New APL(Tools.Files.Lines(EnsureString(aName)), False)
  End Function

  Private Function _Lines(ByVal aValue As APL, ByVal aName As APL) As APL
    Dim myData As String

    myData = aValue.ToString
    Tools.Files.Lines(EnsureString(aName)) = myData
    Return _a.Value(myData.Length)
  End Function

#End Region

#Region "#Path"

  Public Property Path() As Object
    Get
      Return _a.Value(Tools.Names.Path)
    End Get
    Set(ByVal aValue As Object)
      If TypeOf aValue Is String Then
        Tools.Names.Path = DirectCast(aValue, String)
      ElseIf TypeOf aValue Is APL Then
        Tools.Names.Path = EnsureString(aValue)
      Else
        _Signal(ExceptionAPL.Is.Domain)
      End If
    End Set
  End Property

#End Region

#Region "#Files and #Paths"

  Public ReadOnly Property Files() As Method
    Get
      Return New Method(AddressOf _Files, Nothing)
    End Get
  End Property

  Private Function _Files(ByVal aPath As APL) As APL
    Return (_a.Comma.Sub(0.5)(CharacterVectors( _
        Tools.Names.Files(EnsureString(aPath)))))
  End Function

  Public ReadOnly Property Paths() As Method
    Get
      Return New Method(AddressOf _Paths, Nothing)
    End Get
  End Property

  Public Function _Paths(ByVal aPath As APL) As APL
    Return _a.Comma.Sub(0.5)(CharacterVectors( _
        Tools.Names.Paths(EnsureString(aPath))))
  End Function

#End Region

#Region "#Bytes"

  Public ReadOnly Property Bytes() As Method
    Get
      Return New Method(AddressOf _Bytes, AddressOf _Bytes)
    End Get
  End Property

  Public Function _Bytes(ByVal aName As APL) As APL
    Return New APL(_ToString(Tools.Files.Bytes(EnsureString(aName))), False)
  End Function

  Private Function _ToString(ByVal aBytes As Byte()) As String
    Dim myResult As Char()
    Dim myIndex As Integer
    Dim myTranslate As String

    myTranslate = BytesAV.CharacterVector
    ReDim myResult(aBytes.Length - 1)

    For myIndex = 0 To myResult.Length - 1
      myResult(myIndex) = myTranslate(aBytes(myIndex))
    Next

    Return myResult
  End Function

  Private Function _Bytes(ByVal aValue As APL, ByVal aName As APL) As APL
    Dim myValue As String
    Dim myBytes As Byte()
    Dim myTranslate As String
    Dim myIndex, myByte As Integer

    If aValue.IsCharacter Then
      If thisBytesAV Is Nothing Then
        myTranslate = Nothing
      Else
        myTranslate = BytesAV.CharacterVector
      End If

      myValue = aValue.CharacterVector
      ReDim myBytes(myValue.Length - 1)

      For myIndex = 0 To myValue.Length - 1
        If myTranslate Is Nothing Then
          myByte = AscW(myValue(myIndex))
        Else
          myByte = myTranslate.IndexOf(myValue(myIndex))
        End If

        If myByte < 256 Then
          myBytes(myIndex) = CType(myByte, Byte)
        Else
          _Signal(ExceptionAPL.Is.Domain)
        End If
      Next

      Tools.Files.Bytes(EnsureString(aName)) = myBytes
      Return _a.Value(myBytes.Length - 1)

    Else
      _Signal(ExceptionAPL.Is.Domain)
      Return Nothing
    End If
  End Function

#End Region

#Region "#BytesAV"

  Private thisBytesAV As APL
  Public Property BytesAV() As APL
    Get
      If thisBytesAV Is Nothing Then
        Return New APL(_a.QuadAV.CharacterVector.Substring(0, 256))
      End If
      Return thisBytesAV
    End Get
    Set(ByVal aValue As APL)
      Dim myTran As String
      If aValue.IsCharacter Then
        If aValue.Rank <> 1 Then
          _Signal(ExceptionAPL.Is.Rank)
        End If

        myTran = aValue.CharacterVector
        If myTran.Length = 65536 AndAlso _
            myTran = _a.QuadAV.CharacterVector Then
          thisBytesAV = Nothing
        ElseIf aValue.CharacterVector.Length = 256 Then
          thisBytesAV = aValue.Clone
        Else
          _Signal(ExceptionAPL.Is.Length)
        End If

      Else
        _Signal(ExceptionAPL.Is.Domain)
      End If
    End Set
  End Property

#End Region

  ' Other systems QuadAV
  ' These are useful values for BytesAV

#Region "#AvAPLse"

  Private thisAPLse As APL
  Public ReadOnly Property AvAPLse() As APL
    Get
      Dim myAV As StringBuilder

      If thisAPLse Is Nothing Then
        myAV = New StringBuilder
        myAV.Append(ControlChars.NullChar)
        myAV.Append("☺≢⍷⋄¨←␇©")
        myAV.Append(ControlChars.Tab)
        myAV.Append(ControlChars.Lf)
        myAV.Append("⊂␌")
        myAV.Append(ControlChars.Cr)
        myAV.Append("⊃⊛▷◁⍸⍫¶⌶⍬⍵↑↓→®⊢⊣⍋⍒")

        '            0123456789ABCDEF0123456789ABCDEF  
        myAV.Append(" !""#$%&'()*+,-./0123456789:;<=>?")
        myAV.Append("@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_")
        myAV.Append("`abcdefghijklmnopqrstuvwxyz{¦}~␡")
        myAV.Append("Çüéâäà≠çêëèïî⌈Ä⌊É∆×ôö⎕û⍞⌹ÖÜ¢£¥⍪⍨")
        myAV.Append("áíóú⍝⍀¿⌷⍡⍢⍣¡«»░▒▓│┤╡╢╥╕╣║╗╝╜╛┐")
        myAV.Append("└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀")
        myAV.Append("⍺β⍳⍤⍥⍱⊥⊤⌽⊖⍲⌿∇⍉∊∩≡⍙≥≤⍕⍎÷‥∘○∨⍴∪¯|")
        '            0123456789ABCDEF0123456789ABCDEF  
        myAV.Append(Chr(&HA0)) ' A non breaking blank
        thisAPLse = New APL(myAV.ToString, False)
      End If

      Return thisAPLse
    End Get
  End Property

#End Region

#Region "#AvEbcdic"

  Private thisEbcdic As APL
  Public ReadOnly Property AvEbcdic() As APL
    Get
      Dim myAV As StringBuilder
      Dim myIndex As Integer
      Dim myChars As String

      If thisEbcdic Is Nothing Then
        Dim myIndexes As Integer() = { _
            0, 1, 2, 3, 5, 9, 21, 24, 223, 25, 176, 11, 12, 31, 14, 15, _
            16, 17, 18, 19, 26, 13, 8, 221, 219, 222, 179, 191, 218, 29, 192, 217, _
            177, 160, 28, 162, 163, 10, 23, 27, 220, 168, 178, 173, 197, 196, 6, 7, _
            186, 185, 22, 187, 188, 30, 171, 4, 201, 202, 206, 194, 20, 195, 193, 180}
        myChars = AvAPL2pc.CharacterVector

        myAV = New StringBuilder
        For myIndex = 0 To 63
          myAV.Append(myChars(myIndexes(myIndex)))
        Next

        '            0123456789ABCDEF0123456789ABCDEF
        myAV.Append(" " & Chr(&HA0) & _
                      "Çüéâäàåçø.<(+╦&êëèïîìÄÅô╠$*);¬")
        myAV.Append("-/öòûùÖÜ£₧ñ,%_>?⋄^¨⌻⍸⍷⊢⊣∨`:#@'=""")
        myAV.Append("~abcdefghi↑↓≤⌈⌊→⎕jklmnopqr⊃⊂═○Ñ←")
        myAV.Append("¯ístuvwxyz∩∪⊥[≥∘⍺∊⍳⍴⍵º×\÷╚∇∆⊤]≠|")
        myAV.Append("{ABCDEFGHI⍲⍱⌷⌽⍂⍉}JKLMNOPQR⌶!⍒⍋⍞⍝")
        myAV.Append("ª≡STUVWXYZ⌿⍀∵⊖⌹⍕0123456789ß⍫⍙⍟⍎" & myChars(255))
        '            0123456789ABCDEF0123456789ABCDEF  
        thisEbcdic = New APL(myAV.ToString, False)
      End If

      Return thisEbcdic
    End Get
  End Property

#End Region

#Region "#AvAPL2pc"

  Private thisAPL2pc As APL
  Public ReadOnly Property AvAPL2pc() As APL
    Get
      Dim myAV As StringBuilder

      If thisAPL2pc Is Nothing Then
        myAV = New StringBuilder( _
            _a.QuadAV.CharacterVector.Substring(0, 128))
        '            0123456789ABCDEF0123456789ABCDEF
        myAV.Append("ÇüéâäàåçêëèïîìÄÅ⎕⍞⌹ôöòûù⊤ÖÜø£⊥₧⌶")
        myAV.Append("áíóúñÑªº¿⌈¬½∪¡⍕⍎░▒▓│┤⍟∆∇→╣║╗╝←⌊┐")
        myAV.Append("└┴┬├─┼↑↓╚╔╩╦╠═╬≡⍸⍷∵⌷⍂⌻⊢⊣⋄┘┌█▄¦Ì▀")
        myAV.Append("⍺ß⊂⊃⍝⍲⍴⍱⌽⊖○∨⍳⍉∊∩⌿⍀≥≤≠×÷⍙∘⍵⍫⍋⍒¯¨")
        '            0123456789ABCDEF0123456789ABCDEF
        myAV.Append(Chr(&HA0)) ' A non breaking blank
        thisAPL2pc = New APL(myAV.ToString, False)
      End If

      Return thisAPL2pc
    End Get
  End Property
#End Region

End Class
