﻿Option Strict Off

Public Class Utils_Strict

#Region "My_Shell_IsMe"

  Public Shared Sub My_Shell_IsMe(ByVal aLink As Link, ByVal aValue As Evaluate)
    aLink.Value.My_Shell = aValue
  End Sub

#End Region

End Class
