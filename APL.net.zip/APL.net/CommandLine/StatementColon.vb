﻿Imports PLJsAPL

Public Class StatementColon

  Private thisColon, thisCommand As String

#Region "ColonCompile"

  Public Function ColonCompile( _
      ByVal aLine As String, _
      ByVal anEvaluate As Evaluate, _
      ByVal aStatements As Statements) _
      As String
    Dim myLine, myFormat As String

    myFormat = ColonLine(aLine)
    If myFormat.StartsWith("'") Then
      _Signal(ExceptionAPL.Is.Syntax, myFormat)
    End If

    If thisCommand.Length = 0 Then
      Return myFormat
    End If
    myLine = New Statement(thisCommand, anEvaluate).ToCompile(aStatements)
    Return String.Format(myFormat, myLine)
  End Function

#End Region

#Region "ColonLine"

  Public Function ColonLine(ByVal aLine As String) As String
    Dim myFormat As String

    myFormat = ""
    thisCommand = aLine.Trim & " "
    thisColon = thisCommand.ToLower
    If Colon("if ") Then
      myFormat = "If ({0}).IsTrue Then"
    ElseIf Colon("else ") Then
      myFormat = "Else"
    ElseIf Colon("end if ") Then
      myFormat = "End If"
    ElseIf Colon("elseif ") Then
      myFormat = "ElseIf ({0}).IsTrue Then"
    ElseIf Colon("do while ") Then
      myFormat = "Do While ({0}).IsTrue"
    ElseIf Colon("do until ") Then
      myFormat = "Do Until ({0}).IsTrue"
    ElseIf Colon("do ") Then
      myFormat = "Do"
    ElseIf Colon("loop while ") Then
      myFormat = "Loop While ({0}).IsTrue"
    ElseIf Colon("loop until ") Then
      myFormat = "Loop Until ({0}).IsTrue"
    ElseIf Colon("loop ") Then
      myFormat = "Loop"
    ElseIf Colon("exit do ") Then
      myFormat = "Exit Do"
    ElseIf Colon("select case ") Then
      myFormat = "Select Case ({0}).CharacterVector"
    ElseIf Colon("select first ") Then
      myFormat = "Select Case ({0}).ValueVector(0)"
    ElseIf Colon("case ") Then
      myFormat = "Case {0}"
    ElseIf Colon("case else ") Then
      myFormat = "Case Else"
    ElseIf Colon("end select ") Then
      myFormat = "End Select"
    ElseIf Colon("exit select ") Then
      myFormat = "Exit Select"
    ElseIf Colon("return ") Then
      myFormat = "Return {0}"
    Else
      Return "'Not recognized'"
    End If

    If myFormat.Contains("{0}") <> (thisCommand.Length <> 0) Then
      If thisCommand.Length = 0 Then
        Return "'Requires an argument'"
      Else
        Return "'" & thisCommand & "'"
      End If
    End If

    Return myFormat
  End Function

  Private Function Colon( _
      ByVal aCommand As String) _
      As Boolean
    If thisColon.StartsWith(aCommand) Then
      thisCommand = thisCommand.Substring(aCommand.Length).TrimStart
      Return True
    End If
  End Function

#End Region

End Class
