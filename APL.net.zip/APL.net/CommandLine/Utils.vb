﻿Imports PLJsAPL

Public Module Utils

#Region "IllegalName and Illegal"

  ''' <summary>
  ''' Test the name to insure it is legal
  ''' </summary>
  ''' <remarks>
  ''' N.B. I may need to check more than the initial character
  ''' </remarks>
  Friend Function IllegalName(ByVal aName As String) As Boolean
    Dim myIndex As Integer

    If aName.StartsWith("∇") Then
      If aName.Length <> 1 Then
        myIndex = 1
      Else
        Return Illegal(aName)
      End If
    End If

    ' N.B. support for ⍺ and ⍵
    ' If "⍺⍵".Contains(aName) Then Return False

    If IsAlpha(aName(myIndex)) Then
      For myIndex = myIndex + 1 To aName.Length - 1
        If Not IsAlpha(aName(myIndex)) AndAlso _
           Not IsNumeric(aName(myIndex)) Then
          Return Illegal(aName)
        End If
      Next
    Else
      Return Illegal(aName)
    End If
  End Function

  Friend Function Illegal(ByVal aName As String) As Boolean
    _Out = String.Format("Illegal name '{0}'", aName)
    Return True
  End Function

#End Region

#Region "IsAlpha"

  Public Function IsAlpha(ByVal aChar As String) As Boolean
    Dim myChar As Integer

    myChar = AscW(aChar.ToLower)
    If myChar >= 97 AndAlso myChar <= 122 Then
      Return True
    End If
  End Function

#End Region

End Module
