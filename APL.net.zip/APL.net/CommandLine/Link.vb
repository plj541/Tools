﻿Public Class Link
  Private Shared thisDlls As New SortedList(Of String, LoadDll)
  Private Shared thisLib As LoadDll
  Private Shared thisLibPath As String
  Private thisName As String
  Private thisDll As String
  Private thisInstance As Object

  Public Sub New(ByVal aName As String, ByVal aDll As String)
    thisName = aName
    thisDll = aDll
    Instance()
  End Sub

  ''' <summary>
  ''' Called by )Load
  ''' Will Instance at first use
  ''' </summary>
  Public Sub New(ByVal aSaved As String())
    thisName = aSaved(0)
    thisDll = aSaved(1)
  End Sub

#Region "Shared LibPath LoadLib EnsureDll and Loaded"

  Public Shared Sub LibPath(ByVal aPath As String)
    thisLibPath = aPath
  End Sub

  Public Shared Function LoadLib() As LoadDll
    If thisLib Is Nothing Then
      thisLib = New LoadDll(thisLibPath)
      thisDlls.Add(thisLibPath, thisLib)
    End If

    Return thisLib
  End Function

  Public Shared Function EnsureDll(ByVal aDll As String) As LoadDll
    Dim myDll As LoadDll

    If thisDlls.ContainsKey(aDll) Then
      Return thisDlls(aDll)
    Else
      myDll = New LoadDll(aDll)
      thisDlls.Add(aDll, myDll)
      Return myDll
    End If
  End Function

  Public Shared Function Loaded() As Boolean
    Return thisLib IsNot Nothing
  End Function

#End Region

#Region "Value"

  Public ReadOnly Property Value() As Object
    Get
      Instance()
      Return thisInstance
    End Get
  End Property

  Private Sub Instance()
    Dim myDll As LoadDll

    If thisInstance Is Nothing Then
      If thisDll.Length = 0 Then
        myDll = LoadLib()
      Else
        If thisDlls.ContainsKey(thisDll) Then
          myDll = thisDlls(thisDll)
        Else
          myDll = New LoadDll(thisDll)
          thisDlls.Add(thisDll, myDll)
        End If
      End If
      thisInstance = myDll.Link(thisName)
    End If
  End Sub

#End Region

#Region "SaveAs"

  Public ReadOnly Property SaveAs() As String()
    Get
      Return New String() {thisName, thisDll}
    End Get
  End Property

#End Region

End Class
