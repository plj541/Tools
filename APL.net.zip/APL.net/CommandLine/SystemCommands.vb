﻿Imports System.Text
Imports System.Xml
Imports Tools
Imports PLJsAPL

Partial Public Class Commands
  Private thisWsid As String
  Private thisInitial As Boolean

#Region "SystemCommands with FileName JustOne"

  Private Sub SystemCommands(ByVal aLine As String)
    Dim myParts As String()
    Dim myName As String = Nothing

    Base(aLine)
    aLine = aLine.Substring(1).TrimStart
    myParts = aLine.Split(" "c)
    Try
      Select Case myParts(0).ToLower
        Case ""
          RaiseEvent Inputs("  " & thisLast)
        Case "clear"
          If JustOne(myParts, "Clear") Then
            thisEvaluate.Clear()
            LogCommand = Nothing
            thisWsid = Nothing
            RaiseEvent Wsid(thisWsid)
          End If
        Case "wsid"
          If JustOne(myParts, "Wsid") Then
            RaiseEvent Wsid(thisWsid)
            If thisWsid Is Nothing Then
              Output("Unnamed Workspace")
            Else
              Output("Named " & thisWsid)
            End If
          End If
        Case "erase"
          EraseCommand(myParts)
        Case "fns"
          If JustOne(myParts, "Fns") Then
            FnsCommand()
          End If
        Case "vars"
          If JustOne(myParts, "Vars") Then
            VarsCommand()
          End If
        Case "lib"
          If JustOne(myParts, "Lib") Then
            LibCommand()
          End If
        Case "copy"
          If myParts.Length = 1 Then
            Output(")Copy  requires a file name")
          ElseIf myParts.Length = 2 Then
            If FileName(myParts, myName) Then
              LoadCommand(myName, "Copy")
            End If
          Else
            If FileName(("Copy " & myParts(1)).Split(" "c), myName) Then
              myParts(0) = ""
              myParts(1) = ""
              LoadCommand(myName, "Copy", Join(myParts, " ") & " ")
            End If
          End If
        Case "load"
          If FileName(myParts, myName) Then
            LoadCommand(myName, "Load")
          End If
        Case "save"
          If FileName(DefaultWsid(myParts), myName) Then
            SaveCommand(myName, "Save")
          End If
        Case "drop"
          If FileName(myParts, myName) Then
            DropCommand(myName)
          End If
        Case "edit"
          EditCommand(myParts)
        Case "xml"
          XmlCommand(myParts)
        Case "show"
          ShowCommand(myParts)
        Case "compile"
          If JustOne(myParts, "Compile") Then
            CompileCommand()
          End If
        Case "off"
          RaiseEvent Off(aLine.Substring(3).TrimStart)
        Case "last"
          Output(thisLastCommand)
        Case "help"
          myName = Names.Combine(Host.Program, "Help\index.html")
          If Not Names.IsFile(myName) Then
            myName = "https://home.comcast.net/~paul.l.jackson/PLJsAPL/Help/index.html"
          End If
          Host.Launch(myName, "", False, ProcessWindowStyle.Normal)
        Case Else
          Output(myParts(0) & " command not recognized.")
          Output("   )Help")
          Output("will list all system commands.")
      End Select
    Catch ex As Exception
      Output(ex.Message)
    End Try
  End Sub

  Private Function FileName( _
      ByVal aParts As String(), _
      ByRef aName As String) _
      As Boolean
    If aParts.Length = 2 Then
      aName = aParts(1)
      If Not IllegalName(aName) Then
        Return True
      End If
    Else
      Output(")" & aParts(0) & " requires a file name.")
    End If
  End Function

  Private Function JustOne( _
      ByVal aParts As String(), _
      ByVal aCommand As String) _
      As Boolean
    If aParts.Length > 1 Then
      Output(")" & aCommand & " does not use additional arguments.")
      Return False
    End If
    Return True
  End Function


#End Region

#Region "EraseCommmand"

  Private Sub EraseCommand(ByVal aParts As String())
    Dim myIndex As Integer

    If aParts.Length > 1 Then
      For myIndex = 1 To aParts.Length - 1
        thisEvaluate._EX(aParts(myIndex))
      Next

    Else
      Output(")Erase  needs Variable of Function names.")
    End If
  End Sub

#End Region

#Region "FnsCommand"

  Private Sub FnsCommand()
    Dim myName As String
    Dim myResult As StringBuilder

    myResult = New StringBuilder
    For Each myName In thisEvaluate.AllNames
      If myName.StartsWith("∇") Then
        myResult.Append(myName.Substring(1) & "  ")
      End If
    Next
    Output(myResult.ToString.TrimEnd)
  End Sub

#End Region

#Region "VarsCommand"

  Private Sub VarsCommand()
    Dim myName As String
    Dim myResult As StringBuilder

    myResult = New StringBuilder
    For Each myName In thisEvaluate.AllNames
      If Not myName.StartsWith("∇") Then
        myResult.Append(myName & "  ")
      End If
    Next
    Output(myResult.ToString.TrimEnd)
  End Sub

#End Region

#Region "LibCommand"

  Private Sub LibCommand()
    Dim myName As String
    Dim myNames As StringBuilder

    If thisLibPath Is Nothing Then
      Output("No library, )Lib is not available")

    Else
      myNames = New StringBuilder
      myName = Dir(Names.Combine(thisLibPath, "*.aplws"))
      Do Until myName Is Nothing
        myNames.Append(myName.Substring(0, myName.Length - 6) & "  ")
        myName = Dir()
      Loop
      Output(myNames.ToString.TrimEnd)
    End If
  End Sub

#End Region

#Region "DropCommand"

  Private Sub DropCommand(ByVal aFile As String)
    Dim myFile, myDrop As String

    If thisLibPath Is Nothing Then
      Output("No library, )Load is not available")
      Return
    End If

    myFile = FileLib(aFile)
    If Names.IsFile(myFile) Then
      myDrop = TimeStamp(myFile)
      Host.Recycle(myFile)
      Output("Last saved " & myDrop)
    Else
      Output(aFile & " not found")
    End If

    myFile = FileOnly(myFile) & ".vb"
    If Names.IsFile(myFile) Then
      Host.Recycle(myFile)
    End If
  End Sub

#End Region

#Region "LoadCommand"

  Public Sub LoadCommand( _
      ByVal aFile As String, _
      ByVal aCommand As String, _
      Optional ByVal aNames As String = Nothing)
    Dim myNext As APLws
    Dim myFile, myLines As String

    If thisLibPath Is Nothing Then
      Output("No library, )" & aCommand & " is not available")
      Return
    End If

    Try
      myFile = FileLib(aFile)
      myLines = Files.Lines(myFile).Trim
      If aCommand = "Load" Then
        thisEvaluate.Clear()
        LogCommand = Nothing
        thisWsid = RealName(myFile)
        RaiseEvent Wsid(thisWsid)
      End If

      If aCommand = "Copy" Then
        Output(aFile & " saved " & TimeStamp(myFile))
      Else
        Output(thisWsid & " saved " & TimeStamp(myFile))
      End If
    Catch ex As Exception
      Output(aFile & " not found")
      Return
    End Try

    If myLines.Length <> 0 Then
      Try
        myNext = New APLws(myLines)
        Do While myNext.NextValue
          If aNames Is Nothing Then
            CreateValue(myNext)

          ElseIf aNames.Contains(" " & myNext.Name & " ") Then
            CreateValue(myNext)
          End If
        Loop
        thisInitial = True
      Catch ex As Exception
        Output(ex.Message)
        Output("Damaged Workspace")
        thisWsid = Nothing
      End Try
    End If
  End Sub

  Private Function RealName(ByVal aFile As String) As String
    aFile = My.Computer.FileSystem.GetFileInfo(aFile).Name
    Return aFile.Remove(aFile.Length - 6)
  End Function

#End Region

#Region "RestoreWsid"

  Public Sub RestoreWsid(ByVal aWsid As String)
    If aWsid IsNot Nothing Then
      aWsid = aWsid.Trim
      If aWsid.Length = 0 Then
        aWsid = Nothing
      End If
    End If
    thisWsid = aWsid
    RaiseEvent Wsid(thisWsid)
    '   MsgBox("After you've compiled, click to restart ShellAPL")
    ' N.B. This ensures Me doesn't survive )Compile
    thisEvaluate._EX("Me")
  End Sub

#End Region

#Region "CreateValue and CreateEnclose"

  Private Sub CreateValue(ByVal aNext As APLws)
    Dim myName As String
    Dim myShape As Integer()
    Dim myValue As APL
    Dim myItem As XmlNode

    myName = aNext.Name
    myShape = thisEvaluate.FIN(_a.Value(aNext.Shape)).IntegerVector
    myValue = Nothing

    myItem = aNext.Node
    Select Case aNext.Type
      Case "C"
        myValue = _a.Value(myItem.InnerText)

      Case "F"
        myValue = _a.Value(myItem.InnerText)
        myName = "∇" & myName
        myShape = Nothing

      Case "V"
        myValue = NewAPL(myItem.InnerText)
        If myValue Is Nothing Then
          Output("Damaged Workspace  " & myName & " will be saved as text.")
          myValue = _a.Value(myItem.InnerText)
          myShape = Nothing
        End If

      Case "E"
        myValue = New APL(CreateEnclose(myShape, New APLws(myItem)))

      Case "L"
        thisEvaluate.Assign(myName, New Link(myItem.InnerText.Split(ControlChars.Lf)))
        Return

      Case Else
        Output(myName & " has Type='" & aNext.Type & "'")
        myValue = _a.Value(myItem.InnerText)
    End Select

    If myShape IsNot Nothing AndAlso myShape.Length <> 0 Then
      If myValue.VectorLength = UtilsShape.TimesReduce(myShape) Then
        myValue.Shape = myShape
      Else
        Output("Damaged Workspace  Shape '" & aNext.Shape & _
            "' does not agree with the number of elements.")
        Output(aNext.Name & " will not be reshaped.")
      End If
    End If
    thisEvaluate.Assign(myName, myValue)
  End Sub

  Private Function CreateEnclose(ByVal aShape As Integer(), ByVal aPart As APLws) As Object()
    Dim myValue As APL
    Dim myValues, myResult As Object()
    Dim myShape As Integer()
    Dim myIndex As Integer

    ReDim myResult(UtilsShape.TimesReduce(aShape) - 1)

    Do While aPart.NextValue
      Select Case aPart.Type
        Case "B"
          myShape = thisEvaluate.FIN(aPart.Shape).IntegerVector
          myValues = CreateEnclose(myShape, aPart)
          myValue = New APL(myValues)
          myValue.Shape = myShape
          myResult(myIndex) = myValue
          myIndex += 1

        Case "M"
          myValues = NewValues(aPart.Node.InnerText)
          Array.ConstrainedCopy(myValues, 0, myResult, myIndex, myValues.Length)
          myIndex += myValues.Length

        Case "E"
          Return myResult

        Case "S"  ' FixMe:  Obsolete!  Remove soon 2010-11-05
          myValues = NewValues(aPart.Node.InnerText)
          myResult(myIndex) = thisEvaluate.FI(aPart.Shape)(_a.Shape, New APL(myValues))
          myIndex += 1

        Case "C"
          myResult(myIndex) = thisEvaluate.FI(aPart.Shape)(_a.Shape, New APL(aPart.Node.InnerText))
          myIndex += 1

        Case Else
          Output("Damaged Type='" & aPart.Type & "'")
          myResult(myIndex) = New APL(aPart.Node.InnerXml)
          myIndex += 1
      End Select
    Loop

    Return myResult
  End Function

#End Region

#Region "NewAPL and NewValues with Numbers and Strings"

  Private Function NewAPL(ByVal aLine As String) As APL
    Return New APL(NewValues(aLine))
  End Function

  Private Function NewValues(ByVal aLine As String) As Object()
    Dim myParts As String()
    Dim myString As String
    Dim myValues As Object()
    Dim myIndex, myItem As Integer

    aLine = aLine.Trim
    If aLine.Length = 0 Then
      Return New Object() {}
    End If

    aLine = " " & aLine & " "
    myParts = aLine.Split(""""c)
    If 0 = myParts.Length Mod 2 Then
      Return Nothing
    End If

    ReDim myValues(aLine.Length \ 2)
    Do While myItem < myParts.Length
      If Numbers(myParts(myItem), myValues, myIndex) Then
        myItem += 1
        If myItem < myParts.Length Then
          myString = Strings(myParts, myItem)
          If myString.Length = 1 Then
            myValues(myIndex) = CType(myString, Char)
          Else
            If myString.StartsWith("¹") Then
              myString = myString.Substring(1)
            End If
            myValues(myIndex) = myString
          End If
          myIndex += 1
        End If
      Else
        Return Nothing
      End If
    Loop
    ReDim Preserve myValues(myIndex - 1)
    Return myValues
  End Function

  Private Function Numbers( _
      ByVal aPart As String, _
      ByVal aResult As Object(), _
      ByRef anIndex As Integer) _
      As Boolean
    Dim myItems As String()
    Dim myItem As String
    Dim myIndex, myInteger As Integer
    Dim myDouble As Double

    aPart = aPart.Replace(ControlChars.Cr, " ") _
        .Replace(ControlChars.Lf, " ")
    If Not aPart.StartsWith(" ") OrElse _
      Not aPart.EndsWith(" ") Then
      Return False
    End If

    aPart = aPart.Replace("¯", "-").Trim
    If aPart.Length = 0 Then
      Return True
    End If

    myItems = UtilsShape.RemoveDups(aPart, " ").Split(" "c)
    For myIndex = 0 To myItems.Length - 1
      myItem = myItems(myIndex)
      If Integer.TryParse(myItem, myInteger) Then
        aResult(anIndex) = myInteger
      ElseIf Double.TryParse(myItem, myDouble) Then
        aResult(anIndex) = myDouble
      Else
        Return False
      End If

      anIndex += 1
    Next

    Return True
  End Function

  Private Function Strings( _
      ByVal aParts As String(), _
      ByRef anItem As Integer) As String
    Dim myString As StringBuilder
    Dim myLast As String

    myLast = aParts(anItem)
    myString = New StringBuilder(myLast)
    myLast = ""
    anItem += 1

    Do While anItem < aParts.Length
      If aParts(anItem).Length = 0 Then
        If myLast.Length = 0 Then
          myLast = """"
          myString.Append("""")
        Else
          myLast = ""
        End If

      ElseIf myLast = """" Then
        '  myLast = aParts(anItem)
        myString.Append(aParts(anItem))
        myLast = ""
      Else
        Return myString.ToString
      End If

      anItem += 1
    Loop
    Return myString.ToString
  End Function

#End Region

#Region "Continue"

  Public Sub [Continue]()
    Dim myName As String

    myName = "Continue"
    If thisEvaluate.AllNames.Length = 0 Then
      DropCommand(myName)
    Else
      SaveCommand(myName, "Save")
    End If
  End Sub

#End Region

#Region "SaveCommand"

  Private Function SaveCommand( _
      ByVal aFile As String, _
      ByVal aCommand As String) _
      As Boolean
    Dim myName, myFile As String

    If thisLibPath Is Nothing Then
      myName = "No library, ){0} is not available"
      Output(String.Format(myName, aCommand))
      Return True
    End If

    If aFile.ToLower = "continue" Then
      EstablishMe()
    Else
      thisEvaluate._EX("Me")
    End If

    thisNames = New StringBuilder
    thisLinks = New StringBuilder
    thisMethods = New Methods(thisEvaluate)
    thisOutput = New StringBuilder
    thisOutput.AppendLine("<PLJsAPLws>")
    For Each myName In thisEvaluate.AllNames
      SaveValue(myName)
    Next

    thisOutput.AppendLine("</PLJsAPLws>")
    myFile = FileLib(aFile)
    aFile = RealName(myFile)
    Files.Lines(myFile) = thisOutput.ToString
    myFile = TimeStamp(myFile)

    If aFile.ToLower <> "continue" AndAlso thisMethods.Keys.Count <> 0 Then
      SaveClass(aFile)
    End If
    thisOutput = Nothing
    thisMethods = Nothing

    thisWsid = aFile
    RaiseEvent Wsid(thisWsid)
    Output(aCommand & "d " & aFile & " at " & myFile)
  End Function

  Private Function TimeStamp(ByVal aFile As String) As String
    Return My.Computer.FileSystem.GetFileInfo(aFile).LastWriteTime.ToString
  End Function

#End Region

#Region "SaveValue and SaveXML with EnclosedValues"

  Private Sub SaveValue(ByRef aName As String)
    Dim myValue As APL
    Dim myItem As Object
    Dim myDef, myShape As String
    Dim myLink As String()
    Dim myOutput As StringBuilder

    If aName.StartsWith("∇") Then
      aName = aName.Substring(1)
      myDef = thisEvaluate.ValueOf(aName).Value.ToString.Trim
      If myDef.Length <> 0 Then
        SaveXML(aName, "F", Nothing, ToXML(myDef))
        ' SaveClass needs these as well
        thisMethods.Add(aName, myDef)
      End If

    Else
      myItem = thisEvaluate.ValueOf(aName).Value
      If TypeOf myItem Is APL Then
        myValue = DirectCast(myItem, APL)
      ElseIf TypeOf myItem Is Link Then
        myLink = DirectCast(myItem, Link).SaveAs
        myDef = Join(myLink, ControlChars.Lf)
        SaveXML(aName, "L", Nothing, ToXML(myDef))
        myDef = String.Format(thisFormatLinks, aName, myLink(0), myLink(1))
        thisLinks.AppendLine(myDef)
        Return
      Else
        Return
      End If

      thisNames.AppendLine(aName)
      myShape = _a.Shape(myValue).ToString.Trim

      If myValue.IsCharacter Then
        myDef = myValue.CharacterVector
        SaveXML(aName, "C", myShape, ToXML(myValue.CharacterVector))

      Else
        myOutput = New StringBuilder
        If EnclosedValues(myOutput, myValue) Then
          SaveXML(aName, "E", myShape, myOutput.ToString)
        Else
          SaveXML(aName, "V", myShape, myOutput.ToString)
        End If
      End If
    End If
  End Sub

  Private Function EnclosedValues( _
      ByVal anOutput As StringBuilder, _
      ByVal aValue As APL) _
      As Boolean
    Dim myItem As Object
    Dim myAPL As APL
    Dim myEnclosed, myStarted As Boolean
    Dim myShape As String

    For Each myItem In aValue.ValueVector
      If TypeOf myItem Is APL Then
        If myStarted Then
          anOutput.Append("</Part>")
          myStarted = False
        End If

        myEnclosed = True
        myAPL = DirectCast(myItem, APL)
        myShape = _a.Shape(myAPL).ToString

        If myAPL.IsCharacter Then
          SaveXML(anOutput, "C", myShape, ToXML(myAPL.CharacterVector))

        Else
          anOutput.Append("<Part Type=""B""")
          If myShape.Length <> 0 Then
            anOutput.Append(" Shape=""")
            anOutput.Append(myShape)
            anOutput.Append("""")
          End If
          anOutput.Append("/>")
          EnclosedValues(anOutput, myAPL)
          anOutput.Append("<Part Type=""E""/>")
        End If

      Else
        If myStarted Then
          anOutput.Append(" ")
        Else
          anOutput.Append("<Part Type=""M"">")
        End If
        myStarted = True

        If TypeOf myItem Is String Then
          anOutput.Append(StringXML(DirectCast(myItem, String)))
        ElseIf TypeOf myItem Is Char Then
          anOutput.Append(CharXML(DirectCast(myItem, Char)))
        Else
          anOutput.Append(myItem.ToString)
        End If
      End If
    Next

    If myStarted Then
      anOutput.Append("</Part>")
    End If
    Return myEnclosed
  End Function

  Private Function CharXML(ByVal aLine As String) As String
    aLine = aLine.Replace("""", """""")
    Return """" & ToXML(aLine) & """"
  End Function

  Private Function StringXML(ByVal aLine As String) As String
    If aLine.Length = 1 OrElse aLine.StartsWith("¹") Then
      aLine = "¹" & aLine
    End If
    Return CharXML(aLine)
  End Function

  Private Function ToXML(ByVal aLine As String) As String
    Dim myIndex As Integer

    aLine = aLine.Replace("&", "&amp;")
    aLine = aLine.Replace("<", "&lt;")
    aLine = aLine.Replace(">", "&gt;")
    For myIndex = 0 To 31
      aLine = aLine.Replace(Chr(myIndex), _
          String.Format("&#{0:00};", myIndex))
    Next

    If aLine.StartsWith(" ") Then
      aLine = "&#32;" & aLine.Substring(1)
    End If

    Return aLine
  End Function

  Private Sub SaveXML( _
      ByVal aName As String, _
      ByVal aType As String, _
      ByVal aShape As String, _
      ByVal aValue As String)
    thisOutput.AppendLine()
    thisOutput.Append("<Value Name=""" & aName & """")
    _SaveXML(thisOutput, aType, aShape, aValue)
    thisOutput.AppendLine("</Value>")
  End Sub

  Private Sub SaveXML( _
    ByVal anOutput As StringBuilder, _
    ByVal aType As String, _
    ByVal aShape As String, _
    ByVal aValue As String)

    anOutput.Append("<Part")
    _SaveXML(anOutput, aType, aShape, aValue)
    anOutput.Append("</Part>")
  End Sub

  Private Sub _SaveXML( _
      ByVal anOutput As StringBuilder, _
      ByVal aType As String, _
      ByVal aShape As String, _
      ByVal aValue As String)

    anOutput.Append(" Type=""" & aType & """")
    If aShape IsNot Nothing AndAlso aShape.Length <> 0 Then
      anOutput.Append(" Shape=""" & aShape & """")
    End If
    anOutput.Append(">")

    ' N.B.  Replaced with coded sequences
    '   While &<> are longer this way, 
    '   Of 0-31, only 9, 10, 13 can be in XML uncoded  
    ' anOutput.Append("<![CDATA[")
    anOutput.Append(aValue)
    ' anOutput.AppendLine("]]>")
  End Sub

#End Region

#Region "SaveClass"

  Private Sub SaveClass(ByVal aFile As String)
    Dim myName As String

    thisOutput = New StringBuilder
    myName = thisLinks.ToString
    thisLinks = Nothing
    If myName.Length <> 0 Then
      thisOutput.AppendLine("Option Strict Off")
    End If

    thisOutput.AppendLine("Imports PLJsAPL")
    thisOutput.AppendLine("Imports CommandLine")
    thisOutput.AppendLine("Public Class " & aFile)
    thisOutput.AppendLine("Inherits WorkSpace")

    If myName.Length <> 0 Then
      thisOutput.AppendLine()
      thisOutput.AppendLine("#Region ""Links""")
      thisOutput.AppendLine()
      thisOutput.Append(myName)
      thisOutput.AppendLine("#End Region")
    End If

    thisOutput.AppendLine()
    thisOutput.AppendLine("#Region ""My_Shell""")
    thisOutput.AppendLine()
    thisOutput.AppendLine("Private _x As New Evaluate("""")")
    thisOutput.AppendLine()
    thisOutput.AppendLine("Public WriteOnly Property My_Shell()As Evaluate")
    thisOutput.AppendLine("Set (aValue As Evaluate)")
    thisOutput.AppendLine(" _x=aValue")
    thisOutput.AppendLine("End Set")
    thisOutput.AppendLine("End Property")
    thisOutput.AppendLine()
    thisOutput.AppendLine("#End Region")

    myName = thisNames.ToString
    thisNames = Nothing
    If myName.Length <> 0 Then
      myName = myName.TrimEnd.Replace(ControlChars.NewLine, ",")
    End If

    thisOutput.AppendLine()
    For Each myName In thisMethods.Keys
      thisOutput.AppendLine("#Region """ & myName & """")
      thisOutput.AppendLine()
      thisOutput.AppendLine(thisMethods.Define(myName))
      thisOutput.AppendLine()
      thisOutput.AppendLine("#End Region")
      thisOutput.AppendLine()
    Next

    thisOutput.AppendLine("End Class")
    Files.Lines(FileOnly(FileLib(aFile)) & ".vb") = thisOutput.ToString
  End Sub

#End Region

#Region "FormatLinks"

  Private thisFormatLinks As String = FormatLinks()

  Private Function FormatLinks() As String
    Dim myOutput As New StringBuilder

    myOutput.AppendLine("Private _{0}Link As New Link(""{1}"", ""{2}"")")
    myOutput.AppendLine()
    myOutput.AppendLine("Public ReadOnly Property {0}() As Object")
    myOutput.AppendLine("Get")
    myOutput.AppendLine("Return _{0}Link.Value")
    myOutput.AppendLine("End Get")
    myOutput.AppendLine("End Property")

    Return myOutput.ToString
  End Function

#End Region

#Region "FileLib and FileOnly"

  Private Function FileLib(ByVal aFile As String) As String
    Return Names.Combine(thisLibPath, aFile & ".aplws")
  End Function

  Private Function FileOnly(ByVal aFile As String) As String
    Return aFile.Remove(aFile.Length - 6)
  End Function

  Private Function DefaultWsid(ByVal aFile As String()) As String()
    If aFile.Length = 1 AndAlso thisWsid IsNot Nothing Then
      Return New String() {"", thisWsid}
    Else
      Return aFile
    End If
  End Function

#End Region

#Region "EditCommand"

  Private Sub EditCommand(ByVal aParts As String())
    Dim myDef As Definition
    Dim myOld, myNew As APL
    Dim myItem As Object
    Dim myValues As String()
    Dim myName, myLines As String
    Dim myIndex As Integer

    If aParts.Length = 2 Then
      myName = aParts(1)
      myDef = thisEvaluate.ValueOf(myName)
      If myDef Is Nothing Then
        Output(myName & " is not defined")
        Return

      Else
        myItem = myDef.Value
        If TypeOf myItem Is APL Then
          myOld = DirectCast(myItem, APL)
        Else
          Output(myName & " is not an APL value")
          Return
        End If
      End If

      If myName.StartsWith("_") Then
        thisEvaluate._EX(myName)
        myName = myName.Substring(1)
      End If

      If myDef.Name.StartsWith("∇") Then
        myLines = myOld.ToString
        myName = "∇" & myName
      ElseIf myOld.IsCharacter Then
        myLines = myOld.CharacterVector
      Else
        myValues = myOld.ToStrings
        If myOld.Rank > 1 Then
          myIndex = myOld.Shape(myOld.Rank - 1)
          For myIndex = myIndex - 1 To myValues.Length - 1 Step myIndex
            myValues(myIndex) &= ControlChars.NewLine
          Next
        End If
        myLines = " " & Join(myValues, " ")
      End If

      myNew = thisEvaluate._Edit(myName, myLines)
      If myName.StartsWith("∇") Then
        AssignDef(myName, myNew)

      ElseIf myOld.IsCharacter Then
        RestoreShape(myName, myOld, myNew)

      Else
        myLines = myNew.ToString
        myNew = NewAPL(myLines)
        If myNew Is Nothing Then
          SaveError(myName, myLines)
          Return
        End If
        RestoreShape(myName, myOld, myNew)
      End If
    ElseIf aParts.Length = 1 Then
      myNew = thisEvaluate.Edit(_a.Value(LogCommand))
    Else
      Output(")Edit only accepts one name")
    End If
  End Sub

  Private Sub RestoreShape(ByVal aName As String, ByVal anOld As APL, ByVal aNew As APL)
    Dim myShape As Integer()

    If anOld.Rank <> 1 Then
      myShape = anOld.Shape
      If aNew.VectorLength = UtilsShape.TimesReduce(myShape) Then
        aNew.Shape = myShape
      Else
        Output("Your result does not conform to the original shape of '" & _a.Shape(anOld).ToString & "'.")
        Output(aName & " will be vector.")
      End If
    End If

    thisEvaluate.Assign(aName, aNew)
  End Sub

  Private Sub SaveError(ByVal aName As String, ByVal aLine As String)
    thisEvaluate.Assign("_" & aName, _a.Value(aLine))
    Output("Domain Error  )Edit _" & aName & " to resume.")
  End Sub

#End Region

#Region "XmlCommand"

  Private Sub XmlCommand(ByVal aParts As String())
    Dim myDef As Definition
    Dim myName As String

    If aParts.Length = 2 Then
      myName = aParts(1)
      myDef = thisEvaluate.ValueOf(myName)
      If myDef Is Nothing Then
        Output(myName & " is not defined")
        Return
      End If

      thisNames = New StringBuilder
      thisMethods = New Methods(thisEvaluate)
      thisOutput = New StringBuilder

      SaveValue(myName)
      myName = thisOutput.ToString
      myName = myName.Replace("&#10;", ControlChars.Lf)
      myName = myName.Replace("<", ControlChars.Lf & "<")
      myName = myName.Replace(ControlChars.Lf & "</", "</")
      Output(myName.Trim)

      thisNames = Nothing
      thisMethods = Nothing
      thisOutput = Nothing
    Else
      Output(")Xml  requires a name")
    End If
  End Sub

#End Region

#Region "ShowCommand"

  Private Sub ShowCommand(ByVal aParts As String())
    Dim myDef As Definition
    Dim myValue As Object
    Dim myName As String

    If aParts.Length = 2 Then
      myName = aParts(1)
      myDef = thisEvaluate.ValueOf(myName)
      If myDef Is Nothing Then
        Output(myName & " is not defined")
        Return
      End If

      myValue = myDef.Value
      If TypeOf myValue Is APL Then
        Dim myOutput As New StringBuilder

        Show(DirectCast(myValue, APL), myOutput, 0)
        Output(myOutput.ToString)
      Else
        Output(myName & " is " & TypeName(myValue))
      End If

    Else
      Output(")Show  requires a name")
    End If
  End Sub

#End Region

#Region "Show"

  Private Sub Show( _
      ByVal aValue As APL, _
      ByVal anOutput As StringBuilder, _
      ByVal anIndent As Integer)
    Dim myShape As Integer
    Dim myItem As Object

    anOutput.Append(Space(anIndent))
    anOutput.Append("Shape =".PadLeft(10))
    If aValue.Rank = 0 Then
      anOutput.Append(" Scalar")
    Else
      For Each myShape In aValue.Shape
        anOutput.Append(" " & myShape)
      Next
    End If

    If aValue.IsCharacter Then
      anOutput.AppendLine("  contains CharacterVector")
      anOutput.Append(Space(anIndent))
      anOutput.Append("String = ".PadLeft(11))
      anOutput.AppendLine(aValue.CharacterVector)
    Else
      anOutput.AppendLine("  contains ValueVector")
      For Each myItem In aValue.ValueVector
        anOutput.Append(Space(anIndent))
        If TypeOf myItem Is APL Then
          anOutput.AppendLine(TypeName(myItem).PadLeft(8) & " = {")
          Show(DirectCast(myItem, APL), anOutput, anIndent + 2)
          anOutput.Append(Space(anIndent))
          anOutput.AppendLine("}")
        Else
          anOutput.AppendLine(TypeName(myItem).PadLeft(8) _
                             & " = " & myItem.ToString)
        End If
      Next
    End If
  End Sub

#End Region

#Region "CompileCommand"

  Private Sub CompileCommand()
    If Not Names.IsFile(thisCompilePath) Then
      Output(")Compile  cannot find")
      Output(thisCompilePath)
      Return
    End If

    AdjustProject()
    RaiseEvent Restart(thisWsid, Link.Loaded)
  End Sub

#End Region

End Class
