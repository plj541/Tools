﻿Imports System.Reflection
Imports System.Text
Imports Tools
Imports PLJsAPL

Public Class LoadDll

  Private thisDll As Assembly

#Region "New"

  Public Sub New(ByVal aDll As String)
    thisDll = Assembly.LoadFile(aDll)
  End Sub

#End Region

#Region "Link"

  Public ReadOnly Property Link(ByVal aClass As String) As Object
    Get
      Dim myObject As Object

      myObject = NewInstance(aClass)
      If myObject Is Nothing Then
        _Signal(ExceptionAPL.Is.Value)
      End If
      Return myObject
    End Get
  End Property

#End Region

#Region "Lib and Fns"

  Public ReadOnly Property [Lib]() As String()
    Get
      Dim myTypes As System.Type()
      Dim myNames As String()
      Dim myIndex As Integer

      myTypes = thisDll.GetExportedTypes
      ReDim myNames(myTypes.Length - 1)
      For myIndex = 0 To myTypes.Length - 1
        myNames(myIndex) = myTypes(myIndex).Name
      Next
      Return myNames
    End Get
  End Property

  Public ReadOnly Property Fns(ByVal aName As String) As String()
    Get
      Dim myNew As ConstructorInfo
      Dim myMethod As MethodInfo
      Dim myType As System.Type
      Dim myName, myReturn As String
      Dim myMethods As String()
      Dim myResult As StringBuilder

      myResult = New StringBuilder
      For Each myType In thisDll.GetExportedTypes
        If myType.Name = aName Then
          For Each myNew In myType.GetConstructors
            myResult.AppendLine(" New" & Args(myNew))
          Next

          For Each myMethod In myType.GetMethods
            If myMethod.DeclaringType Is myType Then
              'If Not myMethod.IsVirtual Then
              myName = myMethod.Name
              If myMethod.IsSpecialName Then
                If myName.StartsWith("get_") OrElse _
                    myName.StartsWith("set_") Then
                  myName = myName.Substring(4)
                End If
              End If

              myReturn = myMethod.ReturnType.Name
              If myReturn = "Void" Then
                myResult.AppendLine(myName & Args(myMethod))
              ElseIf myReturn = "DyadicAPL" Then
                myResult.AppendLine(myName & "(_Alpha As APL, _Omega As APL) As APL")
              Else
                myResult.AppendLine(myName & Args(myMethod) & "  As " & VBBrackets(myReturn))
              End If
            End If
          Next
          myMethods = Split(myResult.ToString, ControlChars.NewLine)
          Array.Sort(myMethods)
          Return Join(myMethods, ControlChars.Lf). _
              Replace(" New(", "New("). _
              Replace(")  ", ") ").Trim.Split(ControlChars.Lf)
        End If
      Next
      _Signal(ExceptionAPL.Is.User, aName & " was not found")
      Return Nothing
    End Get
  End Property

  Private Function Args(ByVal aMethod As ConstructorInfo) As String
    Dim myParm As ParameterInfo
    Dim myResult As String = Nothing
    Dim myIndex As Integer

    For Each myParm In aMethod.GetParameters
      myResult &= ", " & myParm.Name & " As " & VBBrackets(myParm.ParameterType.Name)
    Next

    If myResult Is Nothing Then
      Return "()"
    End If

    If aMethod.IsSpecialName AndAlso aMethod.Name.StartsWith("set_") Then
      myIndex = myResult.LastIndexOf(",")
      If myIndex = 0 Then
        Return "() = " & myResult.Substring(myIndex + 2)

      Else
        Return "(" & myResult.Substring(0, myIndex).Substring(2) & _
               ") = " & myResult.Substring(myIndex + 2)
      End If
    Else
      Return "(" & myResult.Substring(2) & ")"
    End If
  End Function

  Private Function Args(ByVal aMethod As MethodInfo) As String
    Dim myParm As ParameterInfo
    Dim myResult As String = Nothing
    Dim myIndex As Integer

    For Each myParm In aMethod.GetParameters
      myResult &= ", " & myParm.Name & " As " & VBBrackets(myParm.ParameterType.Name)
    Next

    If myResult Is Nothing Then
      Return "()"
    End If

    If aMethod.IsSpecialName AndAlso aMethod.Name.StartsWith("set_") Then
      myIndex = myResult.LastIndexOf(",")
      If myIndex = 0 Then
        Return "() = " & myResult.Substring(myIndex + 2)

      Else
        Return "(" & myResult.Substring(0, myIndex).Substring(2) & _
               ") = " & myResult.Substring(myIndex + 2)
      End If
    Else
      Return "(" & myResult.Substring(2) & ")"
    End If
  End Function

  Private Function VBBrackets(ByVal aType As String) As String
    Return aType.Replace("[]", "()")
  End Function

#End Region

#Region "NewInstance"

  Public Function NewInstance(ByVal aClass As String) As Object
    Return thisDll.CreateInstance(thisDll.FullName.Split(","c)(0) & "." & aClass)
  End Function

#End Region

End Class
