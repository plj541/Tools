﻿Imports System.Text
Imports PLJsAPL

Public Class Statement

#Region "Private Properties"

  Private thisEvaluate As Evaluate
  Private thisStatements As Statements
  Private thisStatement, thisLine, thisTypes, thisLastType As String
  Private thisTokens As String()
  Private thisOpenQuote, thisHasMe As Boolean
  Private thisIndex As Integer
  '                                  "∆⍶⍹/\⌿⍀+-×÷*○⊛!|⌈⌊<≤=≥>≠≡^~∧∨⍲⍱?∊⍴↑↓⍳,⍪⌽⊖⍉⍒⍋⊥⊤⍊⍑⍎⍕⌹⍞⊂⊃⊣⊢⌷∩∪"
  Private Shared thisFns As String = "∆⍶⍹/\⌿⍀+-×÷*○⊛!|⌈⌊<≤=≥>≠≡^~∧∨⍲⍱?∊⍴↑↓⍳,⍪⌽⊖⍉⍒⍋⊥⊤⍊⍑⍎⍕⌹⍞⊂⊃⊣⊢⌷"
  Private Shared thisFnsDef As String() = { _
      "∆", "⍶", "⍹", _
      "_a.Select", "_a.Expand", "_a.Select.Sub(0)", "_a.Expand.Sub(0)", _
      "_a.Plus", "_a.Minus", "_a.Times", "_a.Divide", _
      "_a.Power", "_a.Circle", "_a.Log", "_a.Exclaim", _
      "_a.Stile", "_a.Hi", "_a.Low", _
      "_a.Less", "_a.LessOrEqual", "_a.Equal", _
      "_a.GreaterOrEqual", "_a.Greater", "_a.NotEqual", "_a.Id", _
      "_a.And", "_a.Not", "_a.And", "_a.Or", "_a.Nand", "_a.Nor", _
      "_a.Random", "_a.Element", "_a.Shape", "_a.Take", "_a.Drop", _
      "_a.Index", "_a.Comma", "_a.Comma.Sub(0)", "_a.Pivot", "_a.Pivot.Sub(0)", _
      "_a.Transpose", "_a.GradeDown", "_a.GradeUp", _
      "_a.Decode", "_a.Encode", "_a.Decoder", "_a.Encoder", _
      "_a.Execute", "_a.Format", "_a.Matrix", "_a.Prompt", _
      "_a.Enclose", "_a.Disclose", "_a.Left", "_a.Right", "_a.Sub"}
  Private Shared thisOps As String = "/\⌿⍀.∙∘¨"
  Private Shared thisOpsDef As String() = { _
      "_a.Reduce", "_a.Scan", _
      "_a.Reduce.Sub(0)", "_a.Scan.Sub(0)", _
      "_a.Dot", "_a.Dot", "_a.DotDot", "_a.Each"}

#End Region

#Region "New"

  Public Sub New( _
      ByVal aLine As String, _
      ByVal anEvaluate As Evaluate, _
      Optional ByVal aHasMe As Boolean = False)
    thisLine = aLine.TrimStart
    thisEvaluate = anEvaluate
    thisHasMe = aHasMe
    thisTokens = FindTokens()
  End Sub

#End Region

  ' Properties for status

#Region "Tokens"

  Public ReadOnly Property Tokens() As String()
    Get
      Return thisTokens
    End Get
  End Property

#End Region

#Region "OpenQuote"

  Public ReadOnly Property OpenQuote() As Boolean
    Get
      Return thisOpenQuote
    End Get
  End Property

#End Region

#Region "Types"

  Public ReadOnly Property Types() As String
    Get
      Return thisTypes.TrimEnd
    End Get
  End Property

#End Region

#Region "Problem"

  Public ReadOnly Property Problem() As Integer
    Get
      Return thisIndex
    End Get
  End Property

#End Region

  ' Properties with various forms of VB Statement

#Region "ToCompile AlwaysAssign"

  Public ReadOnly Property ToCompile(ByVal aStatements As Statements) As String
    Get
      thisStatements = aStatements
      Return ToDisplay
    End Get
  End Property

  ''' <summary>
  ''' Provide a VB statement, 
  ''' sdding ⎕← when it doesn't have an assignment
  ''' </summary>
  Private ReadOnly Property AlwaysAssign() As String
    Get
      Dim myLine As String = ""

      _Signal(ExceptionAPL.Is.Nonce)
      'myLine = ToCompile
      If Not thisTypes.Contains("←") Then
        myLine = "⎕←" & myLine
      End If
      Return myLine
    End Get
  End Property

#End Region

#Region "ToDisplay ToEvaluate"

  ''' <summary>
  ''' Provide a VB statement with values wrapped for Evaluate
  ''' </summary>
  Public ReadOnly Property ToDisplay() As String
    Get
      SubStatement()
      Return thisStatement _
          .Replace(ControlChars.Cr, "") _
          .Replace(ControlChars.Lf, "")
    End Get
  End Property

  ''' <summary>
  ''' Provide a VB statement, assumed to be part of a function
  ''' </summary>
  ''' <value></value>
  ''' <returns></returns>
  ''' <remarks></remarks>
  Public ReadOnly Property ToEvaluate() As String
    Get
      SubStatement()
      Return thisStatement _
          .Replace(ControlChars.Cr, "_x.Named(""") _
          .Replace(ControlChars.Lf, """)")
    End Get
  End Property

#End Region

  ' FindTokens and subfunctions

#Region "FindTokens"

  Private Function FindTokens() As String()
    Dim myInput, myChar As String
    Dim myIndex As Integer
    Dim myOutput, myType As StringBuilder

    myInput = thisLine.TrimStart.Replace(ControlChars.Lf, " ")
    If myInput.Length = 0 Then
      Return New String() {}
    End If

    ' N.B.  The trailing blank on myInPut is to allow testing
    '       myInput(myIndex + 1)
    '       without an Index Error
    If (myInput.Split(""""c).Length Mod 2) = 0 Then
      myInput = myInput & """ "
      thisOpenQuote = True
    Else
      myInput = myInput.TrimEnd & " "
    End If

    myOutput = New StringBuilder
    myType = New StringBuilder
    thisLastType = " "

    Do While myIndex < myInput.Length
      myChar = myInput(myIndex)
      If "⎕" = myChar Then
        myIndex = Quads(myChar, myInput, myIndex)
        If "⎕ ⎕av ⎕ct ⎕rl ⎕ts ".Contains(myChar.ToLower & " ") Then
          SaveLast(myType, "v")
          myChar = "_a.Quad" & myChar.Substring(1).ToUpper
        ElseIf "⎕crlf ⎕tab ⎕null ⎕dictionary ⎕path ⎕bytesav ⎕avaplse ⎕avebcdic ⎕avapl2pc ".Contains(myChar.ToLower & " ") Then
          SaveLast(myType, "v")
          myChar = "_x." & myChar.Substring(1)
        Else
          SaveLast(myType, "f")
          myChar = "_x." & myChar.Substring(1)
        End If
        myOutput.Append(myChar)
        myOutput.Append(ControlChars.Lf)
      ElseIf "⍙⍺⍵⌶⍬".Contains(myChar) Then
        If myInput(myIndex + 1) = "." Then
          ' SaveLast is in Names
          myIndex = Names(myOutput, myType, myInput, myIndex)
        Else
          If myChar = "⍬" Then
            myChar = "_a.Value()"
          End If
          myOutput.Append(myChar)
          myOutput.Append(ControlChars.Lf)
          SaveLast(myType, "v")
          myIndex += 1
        End If
        
      ElseIf "∆⍶⍹".Contains(myChar) Then
        myOutput.Append(myChar)
        myOutput.Append(ControlChars.Lf)
        SaveLast(myType, "f")
        myIndex += 1
      ElseIf "_abcdefghijklmnopqrstuvwxyz".Contains(myChar.ToLower) Then
        ' SaveLast is in Names
        myIndex = Names(myOutput, myType, myInput, myIndex)
      ElseIf myChar = "."c Then
        myChar = myInput(myIndex + 1)
        If "0123456789".Contains(myChar) Then
          myIndex = Numbers(myOutput, myInput, myIndex)
          SaveLast(myType, "c")
        ElseIf "_abcdefghijklmnopqrstuvwxyz".Contains(myChar.ToLower) Then
          ' SaveLast is in Names
          myIndex = Names(myOutput, myType, myInput, myIndex)
        Else
          SaveLast(myType, "O")
          myOutput.Append(".")
          myOutput.Append(ControlChars.Lf)
          myIndex += 1
        End If
      ElseIf "0123456789¯".Contains(myChar) Then
        myIndex = Numbers(myOutput, myInput, myIndex)
        SaveLast(myType, "c")
      ElseIf myChar = """" Then
        myIndex = Quotes(myOutput, myInput, myIndex)
        SaveLast(myType, "c")
      ElseIf myChar = " " Then
        myIndex += 1
      Else
        myOutput.Append(myChar)
        If "←()[;]".Contains(myChar) Then
          SaveLast(myType, myChar)
        ElseIf myChar = "∙" Then
          SaveLast(myType, "O")
        ElseIf "∘¨".Contains(myChar) Then
          SaveLast(myType, "o")
        ElseIf "/\⌿⍀".Contains(myChar) Then
          If thisLastType = "?" Then
            SaveLast(myType, "?")
          ElseIf " vc()".Contains(thisLastType) Then
            SaveLast(myType, "f")
          Else
            SaveLast(myType, "o")
          End If
        Else
          SaveLast(myType, "f")
        End If

        myOutput.Append(ControlChars.Lf)
        myIndex += 1
      End If
    Loop

    thisTypes = myType.ToString
    myInput = myOutput.ToString.TrimEnd
    Return myInput.Split(ControlChars.Lf)
  End Function

  Private Sub SaveLast(ByVal aSave As StringBuilder, ByVal aType As String)
    aSave.Append(aType)
    thisLastType = aType
  End Sub

#End Region

#Region "Names Quads"

  Private Function Names( _
      ByVal anOutput As StringBuilder, _
      ByVal aType As StringBuilder, _
      ByVal anInput As String, _
      ByVal anIndex As Integer) _
      As Integer
    Dim myChar As String
    Dim myValue As New StringBuilder

    myChar = anInput(anIndex)
    Do
      myValue.Append(myChar)
      anIndex += 1
      myChar = anInput(anIndex)
    Loop While "_abcdefghijklmnopqrstuvwxyz0123456789.".Contains(myChar.ToLower)

    myChar = myValue.ToString
    If "._⍙⍺⍵⌶".Contains(myChar.Substring(0, 1)) Then
      SaveLast(aType, "v")
    Else
      ' N.B.  This is analized later
      SaveLast(aType, "?")
    End If
    anOutput.Append(myChar)
    anOutput.Append(ControlChars.Lf)
    Return anIndex
  End Function

  Private Function Quads( _
      ByRef anOutput As String, _
      ByVal anInput As String, _
      ByVal anIndex As Integer) _
      As Integer
    Dim myChar As String

    Do
      anIndex += 1
      myChar = anInput(anIndex)
      If "abcdefghijklmnopqrstuvwxyz0123456789.".Contains(myChar.ToLower) Then
        anOutput &= myChar
      Else
        Exit Do
      End If
    Loop

    Return anIndex
  End Function

#End Region

#Region "Numbers Quotes"

  Private Function Numbers( _
      ByVal anOutput As StringBuilder, _
      ByVal anInput As String, _
      ByVal anIndex As Integer) _
      As Integer
    Dim myChar, myLast As String

    myChar = anInput(anIndex)
    myLast = "0"
    anOutput.Append(myChar)
    Do
      anIndex += 1
      myChar = anInput(anIndex)
      If ".0123456789¯eE".Contains(myChar) Then
        anOutput.Append(myChar)
      ElseIf "eE".Contains(myLast) AndAlso "+-".Contains(myChar) Then
        ' N.B.  This is an attempt to honor .Net numbers as well
        anOutput.Append(myChar)
      Else
        Exit Do
      End If
      myLast = myChar
    Loop

    anOutput.Append(ControlChars.Lf)
    Return anIndex
  End Function

  Private Function Quotes( _
    ByVal anOutput As StringBuilder, _
    ByVal anInput As String, _
    ByVal anIndex As Integer) _
    As Integer
    Dim myChar As String

    anOutput.Append("""")
    Do While anIndex < anInput.Length
      anIndex += 1
      myChar = anInput(anIndex)
      If myChar = """" Then
        anOutput.Append("""")
        anIndex += 1
        If anInput(anIndex) = """" Then
          anOutput.Append("""")
        Else
          anOutput.Append(ControlChars.Lf)
          Exit Do
        End If
      Else
        anOutput.Append(myChar)
      End If
    Loop

    Return anIndex
  End Function

#End Region

  ' Validate and subfunctions

#Region "Validate"

  Private Sub Validate()
    Dim myToken As String
    Dim myNameType As String()
    Dim myTypes As Char()

    Simplify()
    myTypes = UtilsStrict.Chars(thisTypes)
    For Me.thisIndex = 0 To thisTokens.Length - 1
      If myTypes(thisIndex) = "?" Then
        If "/\⌿⍀".Contains(thisTokens(thisIndex)) Then
          If myTypes(thisIndex - 1) = "v" Then
            myTypes(thisIndex) = "f"c
          Else
            myTypes(thisIndex) = "o"c
          End If
        Else
          If Not thisTokens(thisIndex).Contains(".") Then
            myTypes(thisIndex) = NameType()
          End If
          ' N.B.  These tests look exclusive, but
          '       NameType could have added a "."
          If thisTokens(thisIndex).Contains(".") Then
            myNameType = DotNames(thisTokens(thisIndex))
            thisTokens(thisIndex) = myNameType(0)
            myTypes(thisIndex) = myNameType(1)(0)
          End If
        End If
      End If
    Next

    thisTypes = UtilsStrict.Chars(myTypes)
    For Me.thisIndex = 0 To thisTokens.Length - 1
      myToken = thisTokens(thisIndex)
      If thisTypes(thisIndex) = "c" AndAlso (Not myToken.StartsWith("""")) Then
        ' Modify minus in numeric tokens for further actions
        myToken = myToken.Replace("¯", "-")
        If IsNumeric(myToken) Then
          thisTokens(thisIndex) = myToken
        Else
          _Signal(ExceptionAPL.Is.Domain)
        End If
      End If
    Next

    If "[])oO←".Contains(thisTypes(0)) Then
      _Signal(ExceptionAPL.Is.Syntax)
    End If

    thisIndex = thisTypes.IndexOf("←")
    If thisIndex <> -1 Then
      If thisTypes(0) <> "v"c Then
        _Signal(ExceptionAPL.Is.Syntax)
      End If
      If thisTypes.EndsWith("←") OrElse " [])oO".Contains(NextType(thisIndex)) Then
        _Signal(ExceptionAPL.Is.Syntax)
      End If
      If thisIndex > 1 Then
        If thisTypes(1) <> "["c OrElse PreviousType(thisIndex) <> "]"c Then
          _Signal(ExceptionAPL.Is.Syntax)
        End If
      End If
      If thisIndex <> thisTypes.LastIndexOf("←") Then
        _Signal(ExceptionAPL.Is.Syntax)
      End If
    End If

    For Me.thisIndex = 0 To thisTokens.Length - 1
      Select Case thisTypes(thisIndex)
        Case "("c
          Parens()
        Case "["c
          Brackets()
        Case ")"c, ";"c, "]"c
          _Signal(ExceptionAPL.Is.Syntax)
      End Select
    Next

    thisIndex = -1
    ProvideNames()
    FnsOpsSub()
    DerivedFns()
  End Sub

#End Region

#Region "NameType"

  Private Function NameType() As Char
    Dim myItem As Object
    Dim myName As String
    Dim myDef As Definition

    myName = thisTokens(thisIndex)
    myDef = thisEvaluate.ValueOf(myName)
    If myDef IsNot Nothing Then
      ' N.B. Get proper case for myName
      myName = myDef.Name
      myItem = myDef.Value
      If TypeOf myItem Is APL Then
        If myName.StartsWith("∇") Then
          myName = myName.Substring(1)
          If thisHasMe Then
            thisTokens(thisIndex) = "Me." & myName
            Return "?"c
          ElseIf thisStatements IsNot Nothing Then
            thisTokens(thisIndex) = myName
            Return thisStatements.Type(myName)
          End If
        End If
      End If
      thisTokens(thisIndex) = myName
      Return "v"c

    ElseIf TypeOf myItem Is Method Then
      thisTokens(thisIndex) = myName
      Return "f"c

    ElseIf TypeOf myItem Is OpMonadic OrElse _
         TypeOf myItem Is OpScalar Then
      thisTokens(thisIndex) = myName
      Return "o"c

    ElseIf TypeOf myItem Is OpDyadic Then
      thisTokens(thisIndex) = myName
      Return "O"c
    End If

    thisTokens(thisIndex) = myName
    Return "v"c
  End Function

#End Region

#Region "DotNames"

  Private Function DotNames(ByVal aName As String) As String()
    Dim myItem As Object
    Dim myValues As Object()
    Dim myNames, myLinks, myParts As String()
    Dim myType, myName, myPart As String
    Dim myDef As Definition

    If aName.EndsWith(".") Then
      _Signal(ExceptionAPL.Is.Syntax)
    End If
    myType = "f"
    myNames = aName.Split("."c)
    If myNames.Length = 2 Then
      myDef = thisEvaluate.ValueOf(myNames(0))
      If myDef Is Nothing Then
        thisIndex = -1
        _Signal(ExceptionAPL.Is.Value, "'" & myNames(0) & "'")
      Else
        myItem = myDef.Value

        ' FixMe:  There may be a reason to consider thisMethods
        ' If TypeOf myItem Is APL AndAlso thisMethods IsNot Nothing Then
        '   myItem = New Link
        ' End If

        If TypeOf myItem Is Link Then
          myLinks = DirectCast(myItem, Link).SaveAs
          If myLinks(1) = "" Then
            myValues = thisEvaluate.Fns(myLinks(0)).ValueVector
          Else
            myValues = (New APL(myLinks(1)))(thisEvaluate.Fns, myLinks(0)).ValueVector
          End If
          myName = myNames(1).ToLower & "("
          For Each myPart In myValues
            If myPart.ToLower.StartsWith(myName) Then
              myParts = myPart.Split(" "c)
              myNames(1) = myParts(0).Replace("()", "")
              aName = Strings.Join(myNames, ".")

              Select Case myParts(myParts.Length - 1)
                Case "Method"
                  myType = "f"
                Case "OpMonadic"
                  myType = "o"
                Case "OpDyadic"
                  myType = "O"
                Case "APL"
                  myType = "v"
                Case Else
                  myType = "f"
              End Select
              Return New String() {aName, myType}
            End If
          Next
        Else
          myType = "v"
        End If
      End If
    End If
    Return New String() {aName, myType}
  End Function

#End Region

#Region "Parens and Brackets"

  Private Sub Parens()
    For Me.thisIndex = thisIndex + 1 To thisTypes.Length - 1
      Select Case thisTypes(thisIndex)
        Case "("c
          Parens()
        Case "["c
          Brackets()
        Case ")"c
          Return
        Case ";"c, "]"c
          _Signal(ExceptionAPL.Is.Syntax)
      End Select
    Next
    _Signal(ExceptionAPL.Is.Syntax, "')' expected")
  End Sub

  Private Sub Brackets()
    For Me.thisIndex = thisIndex + 1 To thisTypes.Length - 1
      Select Case thisTypes(thisIndex)
        Case "("c
          Parens()
        Case "["c
          Brackets()
        Case ";"c
          ' No problem
        Case "]"c
          Return
        Case ")"c
          _Signal(ExceptionAPL.Is.Syntax)
      End Select
    Next
    _Signal(ExceptionAPL.Is.Syntax, "']' expected")
  End Sub

#End Region

#Region "Simplify"
  ''' <summary>
  ''' Remove parens around simple expressions, such as:
  '''   (v)
  ''' Loop until no simple expressions were found
  ''' </summary>
  Private Sub Simplify()
    Dim myType As Char()

    Do
      ' N.B.  Add two elements for myType(thisIndex + 2)
      myType = UtilsStrict.Chars(thisTypes & "??")
      thisIndex = thisTypes.IndexOf("(")
      If thisIndex = -1 Then
        Return
      End If
      For Me.thisIndex = thisIndex To thisTokens.Length - 1
        If myType(thisIndex) = "("c Then
          If "vcfo".Contains(myType(thisIndex + 1)) Then
            If myType(thisIndex + 2) = ")"c Then
              myType(thisIndex) = " "c
              myType(thisIndex + 2) = " "c
              thisIndex += 2
            End If
          ElseIf myType(thisIndex + 1) = ")" Then
            _Signal(ExceptionAPL.Is.Syntax)
          End If
        End If
      Next

      ' N.B.  Remove two elements added above
    Loop While SelectNotBlank(myType, 2)
  End Sub

#End Region

#Region "SelectNotBlank"

  Private Function SelectNotBlank(ByVal aTypes As Char(), ByVal aDiscard As Integer) As Boolean
    Dim myTemp As String
    Dim myIndex, myItem As Integer
    Dim myTokens As String()

    myTemp = UtilsStrict.Chars(aTypes)
    ' N.B.  Remove elements added previously
    myTemp = myTemp.Remove(myTemp.Length - aDiscard)
    If myTemp.Contains(" ") Then
      thisTypes = myTemp.Replace(" ", "")
      myTokens = thisTokens

      ReDim thisTokens(thisTypes.Length - 1)
      For myIndex = 0 To myTemp.Length - 1
        If myTemp(myIndex) <> " " Then
          thisTokens(myItem) = myTokens(myIndex)
          myItem += 1
        End If
      Next
      Return True
    Else
      Return False
    End If
  End Function

#End Region

#Region "ProvideNames"

  ''' <summary>
  ''' Provide VB names for primitives
  ''' And markers for _x.Named values
  ''' </summary>
  Private Sub ProvideNames()
    Dim myType, myToken As String
    Dim myTokens As String()
    Dim myIndex As Integer

    ReDim myTokens(thisTokens.Length - 1)
    For myIndex = 0 To thisTokens.Length - 1
      myToken = thisTokens(myIndex)
      myType = thisTypes(myIndex)
      If myType = "v" Then
        myTokens(myIndex) = Named(myToken)
      ElseIf myType = "f" Then
        If "abcdefghijklmnopqrstuvwxyz".Contains(myToken.Substring(0, 1).ToLower) Then
          myTokens(myIndex) = Named(myToken)
        Else
          myTokens(myIndex) = Fns(myToken)
        End If
      ElseIf "oO".Contains(myType) Then
        If "abcdefghijklmnopqrstuvwxyz".Contains(myToken.Substring(0, 1).ToLower) Then
          myTokens(myIndex) = Named(myToken)
        Else
          myTokens(myIndex) = Ops(myToken)
        End If
      Else
        myTokens(myIndex) = myToken
      End If
    Next

    thisTokens = myTokens
  End Sub

  ''' <summary>
  ''' Provide wrappers to indicate where
  '''  _x.Named("   and  ")
  ''' should be inserted.
  ''' Not actually provided so that compiling
  ''' and display can remove the indicators.
  ''' ControlChars.Cr indicates _x.Named("
  '''   and
  ''' ControlChars.Lf indicates ")
  ''' </summary>
  Private Function Named(ByVal aToken As String) As String
    Dim myTokens As String() = Nothing

    If aToken.StartsWith("_") Then Return aToken
    If aToken.Contains(".") Then
      myTokens = aToken.Split("."c)
      aToken = myTokens(0)
    End If
    aToken = ControlChars.Cr & aToken & ControlChars.Lf
    If myTokens IsNot Nothing Then
      myTokens(0) = aToken
      aToken = Join(myTokens, ".")
    End If
    Return aToken
  End Function

#End Region

#Region "FnsOpsSub"

  Private Sub FnsOpsSub()
    Dim myTypes As Char()
    Dim myTemp As String

    myTypes = UtilsStrict.Chars(thisTypes & "???")
    For Me.thisIndex = 0 To thisTokens.Length - 1
      If "foO".Contains(myTypes(thisIndex)) AndAlso _
        myTypes(thisIndex + 1) = "[" Then
        If "vc".Contains(myTypes(thisIndex + 2)) AndAlso _
            myTypes(thisIndex + 3) = "]" Then
          myTemp = thisTokens(thisIndex).Replace(".Sub(0)", "")
          thisTokens(thisIndex) = myTemp & ".Sub(" & thisTokens(thisIndex + 2) & ")"
          myTypes(thisIndex + 1) = " "c
          myTypes(thisIndex + 2) = " "c
          myTypes(thisIndex + 3) = " "c
          thisIndex += 3
        Else
          _Signal(ExceptionAPL.Is.Nonce)
        End If
      End If
    Next
    ' N.B.  Remove three elements added above
    SelectNotBlank(myTypes, 3)
  End Sub

#End Region

#Region "DerivedFns"

  Private Sub DerivedFns()
    Dim myTypes As Char()

    For myIndex = 0 To 3
      Do
        Simplify()
        myTypes = UtilsStrict.Chars(thisTypes & "?")
        For Me.thisIndex = 0 To thisTokens.Length - 1
          If myTypes(thisIndex) = "o" Then
            If myTypes(thisIndex - 1) = "f" Then
              thisTokens(thisIndex) = _
                thisTokens(thisIndex - 1) & "(" & _
                thisTokens(thisIndex) & ")"
              myTypes(thisIndex - 1) = " "c
              myTypes(thisIndex) = "f"c
            ElseIf myTypes(thisIndex - 1) <> ")" Then
              _Signal(ExceptionAPL.Is.Syntax)
            End If
          ElseIf myTypes(thisIndex) = "O" Then
            If myTypes(thisIndex - 1) = "f" Then
              If myTypes(thisIndex + 1) = "f" Then
                thisTokens(thisIndex + 1) = _
                    thisTokens(thisIndex - 1) & "(" & _
                    thisTokens(thisIndex) & "," & _
                    thisTokens(thisIndex + 1) & ")"
                myTypes(thisIndex - 1) = " "c
                myTypes(thisIndex) = " "c
                myTypes(thisIndex + 1) = "f"c
              ElseIf myTypes(thisIndex + 1) <> "(" Then
                _Signal(ExceptionAPL.Is.Syntax)
              End If
            ElseIf myTypes(thisIndex - 1) <> ")" Then
              _Signal(ExceptionAPL.Is.Syntax)
            End If
          End If
        Next
        ' N.B.  Remove three elements added above
      Loop While SelectNotBlank(myTypes, 1)

      thisIndex = Math.Min(TypesIndex("o"), TypesIndex("O"))
      If thisIndex = thisTypes.Length Then Return
    Next
    If thisIndex <> thisTypes.Length Then
      _Signal(ExceptionAPL.Is.Syntax)
    End If
  End Sub

  Private Function TypesIndex(ByVal aType As String) As Integer
    Dim myIndex As Integer

    myIndex = thisTypes.IndexOf(aType)
    If myIndex = -1 Then
      myIndex = thisTypes.Length
    End If
    Return myIndex
  End Function

#End Region

  ' SubStatement and subfunctions

#Region "SubStatement"

  Private Sub SubStatement()
    Dim myOutput As StringBuilder
    Dim myFormat As String = Nothing
    Dim myType As Char()
    Dim myColons As Integer

    If thisStatement Is Nothing Then
      If thisLine.StartsWith(":") Then
        thisIndex = 0
        ' FixMe: Colons should test
        '     That statement ends when it should
        '     That statement shouldn't end when it shouldn't
        myColons = Colons(myFormat)
        If myColons = 0 Then
          thisStatement = myFormat
          Return
        Else
          myType = UtilsStrict.Chars(thisTypes)
          For myColons = 0 To myColons
            myType(myColons) = " "c
          Next
          SelectNotBlank(myType, 0)
        End If
      End If

      Validate()
      myOutput = New StringBuilder
      SubStatement(0, myOutput)
      thisStatement = myOutput.ToString
      If myFormat IsNot Nothing Then
        thisStatement = String.Format(myFormat, thisStatement)
      End If
    End If
  End Sub

  Private Function SubStatement( _
      ByVal anIndex As Integer, _
      ByVal anOutput As StringBuilder) _
      As Integer
    Dim myIndex, myCount As Integer
    Dim myPrevious As Char

    For myIndex = anIndex To thisTokens.Length - 1
      myPrevious = PreviousType(myIndex)
      Select Case thisTypes(myIndex)
        Case "("c
          If myPrevious = "f" Then
            MonDyad(myCount, anOutput, myIndex - 1)
          End If
          myIndex = SubStatement(myIndex + 1, anOutput)
        Case ")"c
          CloseParens(myCount, anOutput)
          Return myIndex
        Case "v"c
          BeforeValue(myCount, anOutput, myPrevious, myIndex)
          If "cv(".Contains(NextType(myIndex)) Then
            myIndex = Values(anOutput, myIndex)
          Else
            anOutput.Append(thisTokens(myIndex))
          End If
        Case "c"c
          BeforeValue(myCount, anOutput, myPrevious, myIndex)
          myIndex = Values(anOutput, myIndex)
        Case "f"c
          If myPrevious = "f" Then
            MonDyad(myCount, anOutput, myIndex - 1)
          ElseIf ")]cv".Contains(myPrevious) Then
            OpenParens(myCount, anOutput)
          ElseIf Not " ←([;".Contains(myPrevious) Then
            anOutput.Append(",")
          End If
          anOutput.Append(thisTokens(myIndex))
        Case "["c
          anOutput.Append(".Sub(")
          myIndex = SubStatement(myIndex + 1, anOutput)
        Case ";"c
          CloseParens(myCount, anOutput)
          myCount = 0
          If "[;".Contains(PreviousType(myIndex)) Then
            anOutput.Append("_a.Empty")
          End If
          anOutput.Append(",")
        Case "]"c
          If "[;".Contains(PreviousType(myIndex)) Then
            anOutput.Append("_a.Empty")
          End If
          CloseParens(myCount + 1, anOutput)
          Return myIndex
        Case "←"c
          anOutput.Append("=")
      End Select
    Next

    CloseParens(myCount, anOutput)
    Return myIndex
  End Function

#End Region

#Region "PreviousType NextType"

  Private Function PreviousType(ByVal anIndex As Integer) As Char
    If anIndex <= 0 Then
      Return " "c
    Else
      Return thisTypes(anIndex - 1)
    End If
  End Function

  Private Function NextType(ByVal anIndex As Integer) As Char
    anIndex += 1
    If anIndex >= thisTypes.Length Then
      Return " "c
    Else
      Return thisTypes(anIndex)
    End If
  End Function

#End Region

#Region "BeforeValue MonDyad"

  Private Sub BeforeValue( _
      ByRef aCount As Integer, _
      ByVal anOutput As StringBuilder, _
      ByVal aPrevious As Char, _
      ByVal anIndex As Integer)
    If aPrevious = "f" Then
      ' 1p
      ' ?fv
      MonDyad(aCount, anOutput, anIndex - 1)
    ElseIf "])".Contains(aPrevious) Then
      _Signal(ExceptionAPL.Is.Syntax)
    End If
  End Sub

  Private Sub MonDyad( _
      ByRef aCount As Integer, _
      ByVal anOutput As StringBuilder, _
      ByVal anIndex As Integer)
    If "])cv".Contains(PreviousType(anIndex)) Then
      anOutput.Append(",")
    Else
      OpenParens(aCount, anOutput)
    End If
  End Sub

#End Region

#Region "BeforeFns"

  Private Sub BeforeFns( _
      ByRef aCount As Integer, _
      ByVal anOutput As StringBuilder, _
      ByVal anIndex As Integer, _
      ByVal aPrevious As Integer)
    If "])vc".Contains(PreviousType(anIndex - aPrevious)) Then
      anOutput.Append(",")
    Else
      OpenParens(aCount, anOutput)
    End If
  End Sub

#End Region

#Region "OpenParens CloseParens"

  Private Sub OpenParens(ByRef aCount As Integer, ByVal anOutput As StringBuilder)
    aCount += 1
    anOutput.Append("(")
  End Sub

  Private Sub CloseParens(ByVal aCount As Integer, ByVal anOutput As StringBuilder)
    anOutput.Append(StrDup(aCount, ")"))
  End Sub

#End Region

#Region "Values"

  Private Function Values(ByVal anOutput As StringBuilder, ByVal anIndex As Integer) As Integer
    anOutput.Append("_a.Value(")
    anOutput.Append(thisTokens(anIndex))
    anIndex += 1

    For anIndex = anIndex To thisTokens.Length - 1
      If "vc".Contains(thisTypes(anIndex)) Then
        anOutput.Append(",")
        anOutput.Append(thisTokens(anIndex))
      Else
        If "(" = thisTypes(anIndex) AndAlso _
            "vc".Contains(NextType(anIndex)) Then
          anOutput.Append(",")
          anIndex += 1
          anIndex = Values(anOutput, anIndex)
        Else
          Exit For
        End If
      End If
    Next

    anOutput.Append(")")
    Return anIndex - 1
  End Function

#End Region

#Region "Fns and Ops"

  Private Function Fns(ByVal aName As String) As String
    Dim myIndex As Integer

    If aName.Length = 1 Then
      myIndex = thisFns.IndexOf(aName)
      If myIndex = -1 Then
        _Signal(ExceptionAPL.Is.Nonce, aName)
      End If
      aName = thisFnsDef(myIndex)
    End If
    Return aName
  End Function

  Private Function Ops(ByVal aName As String) As String
    Dim myIndex As Integer

    If aName.Length = 1 Then
      myIndex = thisOps.IndexOf(aName)
      If myIndex = -1 Then
        _Signal(ExceptionAPL.Is.System)
      End If
      aName = thisOpsDef(myIndex)
    End If
    Return aName
  End Function

#End Region

  ' WrapNames and BalanceParens

#Region "WrapNames"

  Public ReadOnly Property WrapNames() As String
    Get
      Dim myIndex As Integer
      Dim myTokens As String()
      Dim myResult As StringBuilder

      myTokens = DirectCast(thisTokens.Clone, String())
      If myTokens.Length > 2 AndAlso _
          thisTypes(0) = "?" AndAlso _
          myTokens(1) = "=" Then
        If myTokens(0).Contains(".") Then
          myTokens(0) = WrapName(myTokens(0))
        Else
          myTokens(0) = "_x.Named(""" & myTokens(0) & """)"
        End If
        myIndex = 2
      End If

      For myIndex = myIndex To myTokens.Length - 1
        If "v?".Contains(thisTypes(myIndex)) Then
          myTokens(myIndex) = WrapName(myTokens(myIndex))
        End If
      Next

      myResult = New StringBuilder
      For myIndex = 0 To myTokens.Length - 1
        If "vc".Contains(thisTypes(myIndex)) Then
          myResult.Append(" ")
        ElseIf thisTypes(myIndex) = "?" AndAlso _
          Not myTokens(myIndex).StartsWith(".") Then
          myResult.Append(" ")
        End If
        myResult.Append(myTokens(myIndex))
      Next
      Return myResult.ToString
    End Get
  End Property

  Private Function WrapName(ByVal aName As String) As String
    Dim myNames As String()
    Dim myDef As Definition

    If Not (aName.StartsWith("_") OrElse aName.StartsWith(".")) Then
      myNames = aName.Split("."c)

      myDef = thisEvaluate.ValueOf(myNames(0))
      If myDef IsNot Nothing Then
        myNames(0) = "_x.Named(""" & myNames(0) & """)"
        aName = Join(myNames, ".")
      End If
    End If
    Return aName
  End Function

#End Region

#Region "BalanceParens"

  Public Function BalanceParens() As String
    Dim myParens As Integer

    myParens = thisTypes.Replace(")", "").Length
    myParens = myParens - thisTypes.Replace("(", "").Length
    If myParens > 0 Then
      Return StrDup(myParens, ")")
    End If
    Return ""
  End Function

#End Region

#Region "Colons"

  Private Function Colons(ByRef aFormat As String) As Integer
    If Colon("if") Then
      aFormat = "If ({0}).IsTrue Then"
      Return 1
    ElseIf Colon("else") Then
      aFormat = "Else"
      Return 0
    ElseIf Colon("end", "if") OrElse Colon("endif") Then
      aFormat = "End If"
      Return 0
    ElseIf Colon("elseif") Then
      aFormat = "ElseIf ({0}).IsTrue Then"
      Return 1
    ElseIf Colon("else", "if") Then
      aFormat = "ElseIf ({0}).IsTrue Then"
      Return 2
    ElseIf Colon("do") Then
      aFormat = "Do"
      Return 0
    ElseIf Colon("loop") Then
      aFormat = "Loop"
      Return 0
    ElseIf Colon("do", "while") Then
      aFormat = "Do While ({0}).IsTrue"
      Return 2
    ElseIf Colon("dowhile") Then
      aFormat = "Do While ({0}).IsTrue"
      Return 1
    ElseIf Colon("do", "until") Then
      aFormat = "Do Until ({0}).IsTrue"
      Return 2
    ElseIf Colon("dountil") Then
      aFormat = "Do Until ({0}).IsTrue"
      Return 1
    ElseIf Colon("loop", "while") Then
      aFormat = "Loop While ({0}).IsTrue"
      Return 2
    ElseIf Colon("loopwhile") Then
      aFormat = "Loop While ({0}).IsTrue"
      Return 1
    ElseIf Colon("loop", "until") Then
      aFormat = "Loop Until ({0}).IsTrue"
      Return 2
    ElseIf Colon("loopuntil") Then
      aFormat = "Loop Until ({0}).IsTrue"
      Return 1
    ElseIf Colon("case") Then
      aFormat = "Case {0}"
      Return 1
    ElseIf Colon("case", "else") OrElse Colon("caseelse") Then
      aFormat = "Case Else"
      Return 0
    ElseIf Colon("end", "select") OrElse Colon("endselect") Then
      aFormat = "End Select"
      Return 0
    ElseIf Colon("return") Then
      aFormat = "Return {0}"
      Return 0
    Else
      aFormat = ""
      Return 0
    End If
  End Function

  Private Function Colon( _
      ByVal aFirst As String) _
      As Boolean
    If thisTokens(1).ToLower = aFirst Then
      Return True
    End If
  End Function

  Private Function Colon( _
      ByVal aFirst As String, _
      ByVal aSecond As String) _
      As Boolean
    If Colon(aFirst) Then
      If thisTokens(2).ToLower = aSecond Then
        Return True
      End If
    End If
  End Function

#End Region

End Class
