﻿Imports System.Xml
Imports PLJsAPL

Public Class APLws
  Inherits WorkSpace

  Private thisNodes As Xml.XmlNodeList
  Private thisNode As Xml.XmlNode
  Private thisAttributes As Xml.XmlAttributeCollection
  Private thisItem, thisPartItem As Integer

#Region "New and NextValue"

  Public Sub New(ByVal aFile As String)
    Dim myDoc As New XmlDocument

    myDoc.LoadXml(aFile)
    thisNodes = myDoc.DocumentElement.SelectNodes("Value")
  End Sub

  Public Sub New(ByVal aNode As XmlNode)
    thisNodes = aNode.SelectNodes("Part")
  End Sub

  Public Function NextValue() As Boolean
    Dim myItem As Integer

    myItem = thisItem
    If thisItem = thisNodes.Count Then
      Return False

    Else
      thisItem += 1
      thisNode = thisNodes.Item(myItem)
      thisAttributes = thisNode.Attributes
      Return True
    End If
  End Function

#End Region

#Region "Name Type Shape with Attribute"

  Public ReadOnly Property Name() As String
    Get
      Dim myName As String

      myName = Attribute("Name")
      If myName.Length = 0 Then
        _Out = "Damaged Workspace  Name not specified!"
        myName = "_ErrorName" & thisItem
        _Out = "Will use " & myName & " instead."
      Else
        If IllegalName(myName) Then
          myName = "_ErrorName" & thisItem
          _Out = "Will use " & myName & " instead."
        End If
      End If

      Return myName
    End Get
  End Property

  Public ReadOnly Property Type() As String
    Get
      Return Attribute("Type")
    End Get
  End Property

  Public ReadOnly Property Shape() As String
    Get
      Return Attribute("Shape")
    End Get
  End Property

  Private Function Attribute(ByVal aName As String) As String
    Dim myAttribute As Xml.XmlAttribute

    myAttribute = thisAttributes.ItemOf(aName)
    If myAttribute Is Nothing Then
      Return ""
    Else
      Return myAttribute.InnerText
    End If
  End Function

#End Region

#Region "Node"

  Public ReadOnly Property Node() As XmlNode
    Get
      Return thisNode
    End Get
  End Property

#End Region

End Class