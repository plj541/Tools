//  This platform file is for most browsers.
//  It contains functions with common signatures.

//  callMain()					Redisplays the APL Session 
//  callShow(aPage)				Loads then Shows aPage of html
//  callUrl(aPage)				Load aPage in a full browser
//  callExit()					Closes the application
//  fileDownload(aFile, aValue)	Writes aFile to the download directory

function callMain() {
  window.close()
  return ''
}

function callShow(aPage) {
  window.open(aPage)
  return ''
}

function callUrl(aPage) {
  window.open(aPage)
  return ''
}

function callExit() {
  window.close()  //  On some systems, this fails unless a child window!
  return ''
}

function fileDownload(aFile, aValue) {
 var myBlob = new Blob([aValue], {type:'text/plain'})
 var myLink = document.createElement("a")
 myLink.download = aFile
 myLink.innerHTML = "Download File"
 if (window.webkitURL != null) {
  //  Chrome allows the link to be clicked, without actually adding it to the DOM.
  myLink.href = window.webkitURL.createObjectURL(myBlob)
 } else {
  //  Firefox requires the link to be added to the DOM, before it can be clicked.
  myLink.href = window.URL.createObjectURL(myBlob)
  myLink.onclick = destroyClickedElement
  myLink.style.display = "none"
  document.body.appendChild(myLink)
 }
 myLink.click()
 return aFile
}

function destroyClickedElement(event) {
 document.body.removeChild(event.target)
}