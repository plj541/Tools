To get started, please do the following:

1)	Click on PLJsAPL.zip and agree to install into
	your Program Files.  As a .Net application, 
	it will do nothing more than add files to the
	directory PLJ in Program Files.

2)	Click on
		SImPL medium APL.ttf
	then click the Install button on the font display.

3)	Copy the two short cut files
		APL from PLJ
		EditAPL
	to whichever locations you prefer.  Typical
	choices are your desktop or somewhere on the
	Start menu.

4)	When you first click on the APL from PLJ icon,
	it will copy an empty development library into
	your My Documents folder.

5)	Read further information by typing
	)HELP  in the session.

Please send your feedback to:
	plj541@gmail.com